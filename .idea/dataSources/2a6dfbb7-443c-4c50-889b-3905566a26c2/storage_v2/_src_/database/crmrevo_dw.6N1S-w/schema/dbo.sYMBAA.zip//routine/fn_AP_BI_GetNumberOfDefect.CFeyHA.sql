Create FUNCTION [dbo].[fn_AP_BI_GetNumberOfDefect]
(
	@ProductID nvarchar(15),
	@UnitNumber nvarchar(15)
	
)
RETURNS int
AS
BEGIN
	DECLARE @NumberOfDefect int
	
	set @NumberOfDefect =0
	
	set @NumberOfDefect =(	
		Select top 1 Count( Distinct RAuditDate )
From [DBLINK_SVR_DEFECT].[defecttracking].[dbo].vwCallDefectRoundAudit  v
--From [Temp_vwCallDefectRoundAudit]  v With(NoLock) 
where DocIsActive=1 --and ProjectNO in(Select PROJECT_CODE From SM_D_PROJECT Where BU_Code='3')
and ProjectNO=@ProductID and Unit=@UnitNumber
and RAuditDate>= '20150720' 
)
	
	--if(@NumberOfDefect is null or @NumberOfDefect=0)
	--set @NumberOfDefect =(
	--Select top 1 Count( Distinct dr.check_date)
	----From
	----[192.168.0.128].DefectLogs.dbo.tbl_defect_report as dr
	----Left Join [192.168.0.128].DefectLogs.dbo.tbl_project as pj on (dr.project_id = pj.id)
	----Left Join [192.168.0.128].DefectLogs.dbo.tbl_room as Room on (dr.room_id = Room.id)
	--	From
	--[Temp_tbl_defect_report] as dr With(NoLock) 
	--Left Join [Temp_tbl_project] as pj  With(NoLock) on (dr.project_id = pj.id)
	--Left Join [Temp_tbl_room] as Room  With(NoLock) on (dr.room_id = Room.id)
	--where pj.ProductID = @ProductID
	--and dr.status = '1'
	--and Room.room_code = @UnitNumber)
	
	
	
	RETURN @NumberOfDefect
END

go

