
CREATE VIEW [dbo].[vw_UnitStatusBacklog] AS 
SELECT SUBSTRING(p.[Group],1,1) AS BG, p.[Group] AS SubBG,
p.ID AS ProjectID, p.ProjectNo,  p.ProjectNameTH, u.ID AS UnitID, u.UnitNo,
bk.ID AS BookingID, bk.BookingNo, bk.BookingDate,
--------------------------------
--Get Contact No. from Booking Owner
--------------------------------
bko.FromContactID AS BKContactID, bko.ContactNo AS BKContactNo, bko.FullnameTH AS BKContactName, bko.IsThaiNationality AS BKIsThaiNationality,
--*** Add Nation Booking
crmrevo_dw.dbo.fn_GetNationality(ISNULL(M1.Name,ISNULL(BKO.OtherNational,ISNULL(CC1.C1_Nation,ISNULL(CC1.OtherNationalTH,CC1.OtherNationalEN))))) AS BKNationality,
--BKO.OtherNational,CC1.C1_Nation,CC1.OtherNationalTH,CC1.OtherNationalEN,
(SELECT TOP 1 BOE.Email FROM crmrevo.sal.BookingOwnerEmail BOE WHERE BOE.BookingOwnerID = BKO.id AND ISNULL(BOE.IsDeleted,0) = 0 ORDER BY BOE.Created desc) BKEmail,
ag.ID AS AgreementID, ag.AgreementNo, ag.SignContractApprovedDate,
ag.TransferOwnershipDate AS TransferDateInContract, -- Due โอนตามสัญญา
--------------------------------
--Get Contact No. from Agreement Owner
--------------------------------
ago.FromContactID AS AGContactID, ago.ContactNo AS AGContactNo, ago.FullnameTH AS AGContactName, ago.IsThaiNationality AS AGIsThaiNationality,
--*** Add Nation Agreement
crmrevo_dw.dbo.fn_GetNationality(ISNULL(M2.Name,ISNULL(CC2.C2_Nation,ISNULL(CC2.OtherNationalTH,CC2.OtherNationalEN)))) AS AGNationality,
(SELECT TOP 1 AGE.Email FROM crmrevo.sal.AgreementOwnerEmail AGE WHERE AGE.AgreementOwnerID = AGO.id AND ISNULL(AGE.IsDeleted,0) = 0 ORDER BY AGE.Created desc) AGEmail,
--
tf.ID AS TransferID, tf.TransferNo
, tf.ScheduleTransferDate -- วันที่นัดโอน
, tf.ActualTransferDate, --วันที่โอนจริง
--------------------------------
--Get Contact No. from Transfer Owner
--------------------------------
tfo.FromContactID AS TFContactID, 
(SELECT TOP 1 cc.ContactNo FROM crmrevo.CTM.Contact cc WHERE cc.ID = tfo.FromContactID) AS TFContactNo,
tfo.FullnameTH AS TFContactName,
(SELECT TOP 1 ct.IsThaiNationality FROM crmrevo.CTM.Contact ct WHERE ct.ID = tfo.FromContactID) AS TFIsThaiNationality,
--*** Add Nation Transfer
crmrevo_dw.dbo.fn_GetNationality(ISNULL(M3.Name,ISNULL(CC3.C3_Nation,ISNULL(CC3.OtherNationalTH,CC3.OtherNationalEN)))) AS  TFNationality,
TFO.Email TFEmail,
--
CASE 
WHEN TF.TransferNo IS NOT NULL AND TF.ActualTransferDate IS NOT NULL THEN 'TF' -- Transfer Stage
WHEN AG.AgreementNo IS NOT NULL AND TF.ActualTransferDate IS NULL THEN 'AG' --Agreement Stage
WHEN BK.BookingNo IS NOT NULL AND AG.AgreementNo IS NULL THEN 'BK' --Booking Stage
ELSE 'AV' END AS UnitStatus --Available
--------------------------------
--Get Unit Price for Last Stage
--------------------------------
,CASE 
WHEN TF.TransferNo IS NOT NULL AND TF.ActualTransferDate IS NOT NULL THEN 
	(SELECT TOP 1 up_tf.TotalPrice FROM crmrevo.sal.UnitPrice up_tf WITH(NOLOCK) WHERE bk.ID = up_tf.BookingID AND up_tf.IsDeleted = 0 AND up_tf.UnitPriceStageMasterCenterID = '8258151F-CBD3-45FA-85D7-57D946BAB097' ORDER BY up_tf.Created DESC) -- Transfer Stage
WHEN AG.AgreementNo IS NOT NULL AND TF.ActualTransferDate IS NULL THEN 
	(SELECT TOP 1 up_ag.TotalPrice FROM crmrevo.sal.UnitPrice up_ag WITH(NOLOCK) WHERE bk.ID = up_ag.BookingID AND up_ag.IsDeleted = 0 AND up_ag.UnitPriceStageMasterCenterID = '4F3260E5-1CEA-4FA6-9914-E9BE4FA95431' ORDER BY up_ag.Created DESC) --Agreement Stage
WHEN BK.BookingNo IS NOT NULL AND AG.AgreementNo IS NULL THEN 
	(SELECT TOP 1 up_bk.TotalPrice FROM crmrevo.sal.UnitPrice up_bk WITH(NOLOCK) WHERE bk.ID = up_bk.BookingID AND up_bk.IsDeleted = 0 AND up_bk.UnitPriceStageMasterCenterID = '310F92DD-6698-4304-AA00-D9955E1E1E2D' ORDER BY up_bk.Created DESC) -- Booking Stage Price
ELSE 
	(SELECT TOP 1 plt.Amount FROM crmrevo.PRJ.PriceList pl WITH (NOLOCK) LEFT JOIN crmrevo.PRJ.PriceListItem plt WITH (NOLOCK)  ON pl.ID = plt.PriceListID WHERE pl.UnitID = u.ID AND MasterPriceItemID = '3DADBDF5-4E10-46DB-A374-D71B7C6E38EB' ORDER BY pl.Created DESC) --ราคาขาย, Unit Available
END AS TotalPrice
--------------------------------
--Get Freedown Discount Price
--------------------------------
,CASE 
WHEN TF.TransferNo IS NOT NULL AND TF.ActualTransferDate IS NOT NULL THEN 
	(SELECT TOP 1up_tf.FreedownDiscount FROM crmrevo.sal.UnitPrice up_tf WITH(NOLOCK) WHERE bk.ID = up_tf.BookingID AND up_tf.IsDeleted = 0 AND up_tf.UnitPriceStageMasterCenterID = '8258151F-CBD3-45FA-85D7-57D946BAB097' ORDER BY up_tf.Created DESC) -- Transfer Stage
WHEN AG.AgreementNo IS NOT NULL AND TF.ActualTransferDate IS NULL THEN 
	(SELECT TOP 1 up_ag.FreedownDiscount FROM crmrevo.sal.UnitPrice up_ag WITH(NOLOCK) WHERE bk.ID = up_ag.BookingID AND up_ag.IsDeleted = 0 AND up_ag.UnitPriceStageMasterCenterID = '4F3260E5-1CEA-4FA6-9914-E9BE4FA95431' ORDER BY up_ag.Created DESC) --Agreement Stage
WHEN BK.BookingNo IS NOT NULL AND AG.AgreementNo IS NULL THEN 
	(SELECT TOP 1 up_bk.FreedownDiscount FROM crmrevo.sal.UnitPrice up_bk WITH(NOLOCK) WHERE bk.ID = up_bk.BookingID AND up_bk.IsDeleted = 0 AND up_bk.UnitPriceStageMasterCenterID = '310F92DD-6698-4304-AA00-D9955E1E1E2D' ORDER BY up_bk.Created DESC) -- Booking Stage Price
ELSE 
	0
END AS FreedownPrice
--,crmrevo.SAL.fn_TSF_CALC_EstimatePriceBooking(p.ID,u.ID, NULL) AS LandEstimatePrice --ราคาประเมิน
,crmrevo.SAL.fn_TSF_CALC_EstimatePriceBooking(p.ID,u.ID, bk.BookingDate) AS LandEstimatePrice --ราคาประเมิน --Modified by Suchat S. 2020-12-08
,td.TitledeedNo -- เลขที่โฉนด
,u.SaleArea --พท.ขาย
,td.TitledeedArea --พื้นที่ตามโฉนด
,crmrevo.dbo.fn_GetValueStatusByID('LandStatus', td.LandStatusMasterCenterID) AS TitledeedStatus --สถานะโฉนดล่าสุด
,CAST(td.LandStatusDate AS DATE) AS TitledeedLastUpdated --วันที่สถานะโฉนด
,u.HouseNo --บ้านเลขที่
,td.BookNo	--เล่มที่
,td.PageNo	--หน้า
,td.LandSurveyArea	--หน้าสำรวจ
,td.LandNo	--เลขที่ดิน
,ISNULL(crmrevo.[SAL].fnTS_Get_EstimateLandPrice(p.ID, u.ID), 0) AS EstimateLandPricePerMetre --ราคาประเมินที่ดินต่อหน่วย
,CASE WHEN ISNULL(td.TitledeedArea,'') <> '' THEN ISNULL(crmrevo.[SAL].fnTS_Get_EstimateLandPrice(p.ID, u.ID), 0)*td.TitledeedArea 
ELSE ISNULL(crmrevo.[SAL].fnTS_Get_EstimateLandPrice(p.ID, u.ID), 0)*u.SaleArea END AS LandPureEstimatePrice --ราคาประเมินที่ดิน x พท.โฉนด
,qc.EndProduct -- EndProduct Flag 
,qc.EndProductDate -- EndProduct Date
FROM crmrevo.PRJ.Project p WITH(NOLOCK), crmrevo.PRJ.Unit u WITH(NOLOCK) 
LEFT OUTER JOIN crmrevo.SAL.Booking BK WITH (NOLOCK) ON bk.ProjectID = u.ProjectID AND bk.UnitID = u.ID AND ISNULL(BK.IsDeleted,0) = 0 AND bk.CancelDate IS NULL
LEFT OUTER JOIN crmrevo.sal.BookingOwner BKO WITH (NOLOCK) ON bk.ID = bko.BookingID AND bko.IsMainOwner = 1 AND bko.IsAgreementOwner = 0 AND ISNULL(BKO.IsDeleted,0) = 0 /*--แก้ไข เลือกคนจองหลักแทน--*/  
LEFT OUTER JOIN crmrevo.MST.MasterCenter M1 WITH (NOLOCK) ON BKO.NationalMasterCenterID = M1.ID
LEFT OUTER JOIN (SELECT C1.*,M1.Name C1_Nation 
				FROM crmrevo.CTM.Contact C1 WITH(NOLOCK)
				LEFT JOIN crmrevo.MST.MasterCenter M1 WITH (NOLOCK) ON C1.NationalMasterCenterID = M1.ID) CC1 ON BKO.FromContactID = CC1.ID 
LEFT OUTER JOIN crmrevo.SAL.Agreement AG WITH (NOLOCK) ON AG.BookingID = BK.ID AND ISNULL(AG.IsDeleted,0)=0 AND AG.IsCancel = 0
LEFT OUTER JOIN crmrevo.sal.AgreementOwner AGO WITH(NOLOCK) ON AG.ID = AGO.AgreementID AND ISNULL(ago.IsDeleted,0) = 0 AND ago.IsMainOwner = 1 --AND AGO.IsActive = 1 
LEFT OUTER JOIN crmrevo.MST.MasterCenter M2 WITH (NOLOCK) ON AGO.NationalMasterCenterID = M2.ID
LEFT OUTER JOIN (SELECT C2.*,M2.Name C2_Nation 
				FROM crmrevo.CTM.Contact C2 WITH(NOLOCK)
				LEFT JOIN crmrevo.MST.MasterCenter M2 WITH (NOLOCK) ON C2.NationalMasterCenterID = M2.ID) CC2 ON AGO.FromContactID = CC2.ID 
LEFT OUTER JOIN crmrevo.CTM.Contact C2 WITH (NOLOCK) ON AGO.FromContactID = C2.ID
LEFT OUTER JOIN crmrevo.SAL.Transfer TF WITH (NOLOCK) ON AG.ID = TF.AgreementID AND ISNULL(TF.IsDeleted,0) = 0
LEFT OUTER JOIN crmrevo.sal.TransferOwner TFO WITH(NOLOCK) ON TF.ID = TFO.TransferID AND TFO.IsDeleted = 0 AND TFO.[Order] = 1
LEFT OUTER JOIN crmrevo.MST.MasterCenter M3 WITH (NOLOCK) ON TFO.NationalMasterCenterID = M3.ID
LEFT OUTER JOIN (SELECT C3.*,M3.Name C3_Nation 
				 FROM crmrevo.CTM.Contact C3 WITH(NOLOCK)
				 LEFT JOIN crmrevo.MST.MasterCenter M3 WITH (NOLOCK) ON C3.NationalMasterCenterID = M3.ID) CC3 ON TFO.FromContactID = CC3.ID 
LEFT OUTER JOIN crmrevo.PRJ.TitledeedDetail td WITH(NOLOCK) ON u.ID = td.UnitID AND u.ProjectID = td.ProjectID AND td.IsDeleted = 0
LEFT OUTER JOIN DBLINK_SVR_QISV2.[db_QIS_V2].[dbo].[vw_EndProduct] qc ON qc.WBS = u.SAPWBSNo
WHERE p.IsDeleted = 0 
AND p.IsActive = 1
AND p.ProjectNameTH NOT LIKE '%ระงับใช้%'
AND p.ID = u.ProjectID
AND SUBSTRING(p.[Group], 3, 1) <> '0'
AND u.AssetTypeMasterCenterID IN (
		SELECT ID FROM crmrevo.MST.MasterCenter mc WITH(NOLOCK) 
		WHERE mc.MasterCenterGroupKey = 'AssetType'
		AND mc.[Key] IN ('2','4'))
AND u.IsDeleted = 0

--AND BK.ID = '14030EA7-F752-4C81-A68B-96EB469FAA87'


go

