Create FUNCTION [dbo].[fn_AP_BI_GetEndDateDefectComplete]
(
	@ProductID nvarchar(15),
	@UnitNumber nvarchar(15)
	
)
RETURNS Datetime
AS
BEGIN
	DECLARE @EndDate Datetime
	
	set @EndDate =(
	Select top 1 RAuditCloseDate
From [DBLINK_SVR_DEFECT].[defecttracking].[dbo].vwCallDefectRoundAudit  v
--From [Temp_vwCallDefectRoundAudit]  v With(NoLock)
where DocIsActive=1 --and ProjectNO in(Select PROJECT_CODE From SM_D_PROJECT Where BU_Code='3')
and ProjectNO=@ProductID and Unit=@UnitNumber
and RAuditDate>= '20150720' and docisactive=1
and RAuditCloseDate is not null
order by RAuditCloseDate desc
)
	
	--if(@EndDate is null)
	--set @EndDate =(
	--Select top 1 dr.end_date
	--From
	----[192.168.0.128].DefectLogs.dbo.tbl_defect_report as dr
	----Left Join [192.168.0.128].DefectLogs.dbo.tbl_project as pj on (dr.project_id = pj.id)
	----Left Join [192.168.0.128].DefectLogs.dbo.tbl_room as Room on (dr.room_id = Room.id)
	--[Temp_tbl_defect_report] as dr With(NoLock)
	--Left Join [Temp_tbl_project] as pj  With(NoLock)on (dr.project_id = pj.id)
	--Left Join [Temp_tbl_room] as Room  With(NoLock)on (dr.room_id = Room.id)
	--where pj.ProductID = @ProductID
	--and Room.room_code =@UnitNumber
	--	and dr.status = '1'	
	--	and check_date<'20150720' 
	--Order by dr.check_no desc,dr.check_date Desc)
	
	
	
	RETURN @EndDate
END



go

