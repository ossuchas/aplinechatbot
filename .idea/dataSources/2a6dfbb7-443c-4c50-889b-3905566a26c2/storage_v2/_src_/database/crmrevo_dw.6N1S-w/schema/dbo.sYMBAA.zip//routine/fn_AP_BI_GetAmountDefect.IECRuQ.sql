

CREATE FUNCTION [dbo].[fn_AP_BI_GetAmountDefect]
(
	@ProductID nvarchar(15),
	@UnitNumber nvarchar(15)
	
)
RETURNS int
AS
BEGIN
	DECLARE @AmountDefect int
	
	set @AmountDefect =0
	
	set @AmountDefect =(
	Select top 1 RAuditNumOfTask
From [DBLINK_SVR_DEFECT].[defecttracking].[dbo].vwCallDefectRoundAudit  v
--rom [Temp_vwCallDefectRoundAudit]  v With(NoLock)
where DocIsActive=1 --and ProjectNO in(Select PROJECT_CODE From SM_D_PROJECT Where BU_Code='3')
and ProjectNO=@ProductID and Unit=@UnitNumber
and RAuditDate>= '20150720' 
order by RAuditNO desc
	)
	
--	if(@AmountDefect is null)
--	set @AmountDefect =(
--	select top 1 a.defect_count
----from [192.168.0.128].DefectLogs.dbo.tbl_defect_report a 
----inner join [192.168.0.128].DefectLogs.dbo.tbl_room b on a.room_id=b.id
----inner Join [192.168.0.128].DefectLogs.dbo.tbl_project as pj on (a.project_id = pj.id)
--from [Temp_tbl_defect_report] a  With(NoLock)
--inner join [Temp_tbl_room] b  With(NoLock)on a.room_id=b.id
--inner Join [Temp_tbl_project] as pj  With(NoLock)on (a.project_id = pj.id)
--where  1=1
--and pj.ProductID = @ProductID
--and b.room_code= @UnitNumber
----and b.room_code not in 
----(
----select c.UnitNumber  from [192.168.0.128].DefectLogs.dbo.ZReceiveUnit  c
----where 1=1
----and c.ProjectID=@ProductID
----and IsReceive ='1'
----)
--and a.status = '1'
--order by a.room_id asc,a.check_no desc

--	)
	
	
	
	RETURN @AmountDefect
END
go

