--USE [crmrevo_dw]
--GO
--/****** Object:  StoredProcedure [dbo].[AP_BI_UnitDetail_Import_Project_BG]    Script Date: 9/10/2563 15:46:12 ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
----EXEC [AP_BI_UnitDetail_Import_Project_BG]'20027'
CREATE PROC [dbo].[AP_BI_UnitDetail_Import_Project_BG]
--DECLARE 
@ProductID NVARCHAR(50) = ''

 as
--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET NOCOUNT ON;
--SET @ProductID = '40031'
PRINT'start'+@ProductID
----------------------------------Tempdefect----------------------------

If(object_id('tempdb..#Defect')is not null) DROP table #Defect
Select Distinct ProjectNO AS ProductID ,Unit AS UnitNumber,RAuditDate AS check_date ,ISNULL(RAuditCloseDueDate,DATEADD(d,14,RAuditDate)) AS expect_date
INTO #Defect
	From [DBLINK_SVR_DEFECT].[defecttracking].[dbo].vwCallDefectRoundAudit  v with(nolock)
	where DocIsActive=1 --and ProjectNO in(Select PROJECT_CODE From SM_D_PROJECT Where BU_Code='3')
	and RAuditDate>= '20150720' 
	and ProjectNO=@ProductID

IF(object_id('tempdb..#TempDefectNull')is not null) DROP table #TempDefectNull
Select Distinct tb.UnitNumber ,ProductID,
			tb.check_date,
			tb.expect_date
	INTO #TempDefectNull
			From #Defect tb With(NoLock)
			where dbo.fn_AP_BI_GetUnitReceiptDate(tb.ProductID,tb.UnitNumber) is null		

IF(object_id('tempdb..#TempDefectNotNull')is not null) DROP table #TempDefectNotNull
Select Distinct tb.UnitNumber ,ProductID,
			tb.check_date,
			tb.expect_date
INTO #TempDefectNotNull
			From #Defect tb With(NoLock)
			where dbo.fn_AP_BI_GetUnitReceiptDate(tb.ProductID,tb.UnitNumber) IS not null	

/*---------------------------------------------------------------------------------------*/
IF(object_id('tempdb..#TUnit')is not null) DROP table #TUnit
IF(object_id('tempdb..#TProduct')is not null) DROP table #TProduct
IF(object_id('tempdb..#TBooking')is not null) DROP table #TBooking
IF(object_id('tempdb..#TBookingOwner')is not null) DROP table #TBookingOwner
IF(object_id('tempdb..#TBookingOwnerPhone')is not null) DROP table #TBookingOwnerPhone
IF(object_id('tempdb..#TAgreement')is not null) DROP table #TAgreement
IF(object_id('tempdb..#TAgreementOwner')is not null) DROP table #TAgreementOwner
IF(object_id('tempdb..#TAgreementOwnerPhone')is not null) DROP table #TAgreementOwnerPhone
IF(object_id('tempdb..#TTransfer')is not null) DROP table #TTransfer
IF(object_id('tempdb..#M_Unit')is not null) DROP table #M_Unit
IF(object_id('tempdb..#U_Phase')is not null) DROP table #U_Phase
IF(object_id('tempdb..#PaseStart')is not null) DROP table #PaseStart
IF(object_id('tempdb..#SalePromotion')is not null) DROP table #SalePromotion
IF(object_id('tempdb..#TCreditBanking')is not null) DROP table #TCreditBanking
IF(object_id('tempdb..#vwCallDefectReceiveUnitDoc')is not null) DROP table #vwCallDefectReceiveUnitDoc
IF(object_id('tempdb..#vw_PROJECT_F_UNIT_STATUS_QIS')is not null) DROP table #vw_PROJECT_F_UNIT_STATUS_QIS
IF(object_id('tempdb..#BU3_Tranfer')is not null) DROP table #BU3_Tranfer
IF(object_id('tempdb..#BU3_Remark')is not null) DROP table #BU3_Remark
IF(object_id('tempdb..#MasterCenter')is not null) DROP table #MasterCenter

If(object_id('tempdb..#TUnit')is null)
BEGIN
SELECT * into #MasterCenter FROM [crmrevo].mst.MasterCenter 
select * into #TProduct from [crmrevo].prj.Project With(NoLock) WHERE IsActive = 1 AND IsDeleted = 0  AND ProjectNo = @ProductID
select * into #TUnit from [crmrevo].prj.unit  With(NoLock) WHERE  IsDeleted = 0  AND ProjectID IN (SELECT id FROM #TProduct)
select * into #TBooking from [crmrevo].sal.Booking With(NoLock)   WHERE IsDeleted = 0 AND IsCancelled = 0 AND ProjectID IN (SELECT id FROM #TProduct) 
select * into #TBookingOwner from  [crmrevo].sal.BookingOwner  With(NoLock)  WHERE  IsDeleted = 0 AND BookingID IN (SELECT id FROM #TBooking)
select * into #TAgreement from [crmrevo].sal.Agreement With(NoLock)  WHERE IsDeleted = 0 AND IsCancel = 0 AND BookingID IN (SELECT id FROM #TBooking)
select * into #TAgreementOwner from [crmrevo].sal.AgreementOwner With(NoLock)  WHERE  IsDeleted = 0 AND AgreementID IN (SELECT id FROM #TAgreement)
select * into #TTransfer from  [crmrevo].sal.[Transfer] With(NoLock)  WHERE IsDeleted = 0 AND AgreementID IN  (SELECT id FROM #TAgreement)
select * into #M_Unit from (SELECT  [UnitID] ,u.[ProjectID],p.ProjectCRMCode,p.ProjectName,[WBS],[UnitNumber],[SE],[QA],[EndProduct],[EndProductDate],[Ready],[ConstructorID],[ModelID]
									,[BlockID],[WaiveBy],[WaiveDate],u.[CreatedDate],u.[ModifiedDate],u.[DeletedDate] 
							FROM [DBLINK_SVR_QISV2].db_QIS_V2.dbo.M_Unit  u
							LEFT JOIN [DBLINK_SVR_QISV2].db_QIS_V2.dbo.M_Project p ON u.ProjectID = p.ProjectID
							WHERE p.ProjectCRMCode = @ProductID
							UNION ALL
							SELECT  [UnitID] ,u.[ProjectID],p.ProjectCRMCode,p.ProjectName,[WBS],[UnitNumber],[SE],[QA],[EndProduct],[EndProductDate],[Ready],[ConstructorID],[ModelID]
									,[BlockID],[WaiveBy],[WaiveDate],u.[CreatedDate],u.[ModifiedDate],u.[DeletedDate] 
							FROM [DBLINK_SVR_CMIS].db_QIS_H.dbo.M_Unit u
							LEFT JOIN [DBLINK_SVR_CMIS].db_QIS_H.dbo.M_Project p ON u.ProjectID = p.ProjectID
							WHERE p.ProjectCRMCode =@ProductID )aa


SELECT * INTO #U_Phase FROM (SELECT   [UPhaseID] ,[UnitID] ,[PhaseID]  ,[ModelID],[SE] ,[SEComplete] ,[SECompleteDate] ,[QA],[QAComplete],[QACompleteDate],[Complete] ,[StartDate]
						  ,[FinishDate]  ,[IsReq]   ,[RefID],[RowClientId] ,[RowState] ,[RowVersion],[RowSyncDate]  ,[CreateDeviceId],[CreateUserId] ,[ModifiedDeviceId]
						  ,[ModifiedUserId] ,[CreatedDate] ,[ModifiedDate] ,[ActualProcessDays]
						FROM [DBLINK_SVR_QISV2].db_QIS_V2.dbo.U_Phase  u												
						UNION ALL
						SELECT  [UPhaseID] ,[UnitID] ,[PhaseID]  ,[ModelID],[SE] ,[SEComplete] ,[SECompleteDate] ,[QA],[QAComplete],[QACompleteDate],[Complete] ,[StartDate]
							,[FinishDate]  ,[IsReq]   ,[RefID],[RowClientId] ,[RowState] ,[RowVersion],[RowSyncDate]  ,[CreateDeviceId],[CreateUserId] ,[ModifiedDeviceId]
							,[ModifiedUserId] ,[CreatedDate] ,[ModifiedDate] ,[ActualProcessDays] 
						FROM [DBLINK_SVR_CMIS].db_QIS_H.dbo.U_Phase  u)aa
WHERE UnitID IN (SELECT [UnitID]  FROM #M_Unit)

SELECT MIN(a.StartDate)StartDate,uu.UnitID,uu.UnitNumber
INTO #PaseStart
 FROM #M_Unit uu 
LEFT JOIN  #U_Phase a ON a.UnitID = uu.UnitID
 GROUP BY uu.UnitID,uu.UnitNumber

SELECT * INTO #TBookingOwnerPhone FROM [crmrevo].sal.BookingOwnerPhone With(NoLock) WHERE IsDeleted = 0 AND BookingOwnerID IN (SELECT id FROM #TBookingOwner)
SELECT * INTO #TAgreementOwnerPhone FROM [crmrevo].sal.AgreementOwnerPhone WHERE IsDeleted = 0 AND AgreementOwnerID IN (SELECT ID FROM #TAgreementOwner)
SELECT * INTO #SalePromotion FROM [crmrevo].PRM.SalePromotion WHERE IsDeleted = 0 AND BookingID IN (SELECT id FROM #TBooking)
SELECT * INTO #TCreditBanking FROM [crmrevo].sal.CreditBanking WHERE IsDeleted = 0 AND BookingID IN (SELECT id FROM #TBooking)
select * into #vwCallDefectReceiveUnitDoc from [DBLINK_SVR_DEFECT].[defecttracking].[dbo].vwCallDefectReceiveUnitDoc With(NoLock)  WHERE @ProductID = ProjectNo
--SELECT * INTO #vw_PROJECT_F_UNIT_STATUS_QIS FROM vw_PROJECT_F_UNIT_STATUS_QIS WHERE ProductID IN (SELECT ProjectNo FROM #TProduct)
SELECT * INTO #BU3_Tranfer FROM [DBLINK_SVR_BI].[AP_DW].dbo.BU3_Tranfer  
SELECT * INTO #BU3_Remark FROM   [DBLINK_SVR_BI].[AP_DW].dbo.BU3_Remark

--select * into ICON_EntForms_NotificationTranfer from  dbo.ICON_EntForms_NotificationTranfer With(NoLock)  Where Contractnumber in(Select ContractNumber From ICON_EntForms_Agreement)
--select * into ICON_EntForms_Creditbanking from  dbo.ICON_EntForms_Creditbanking With(NoLock) 
--select * into vwCallDefectReceiveUnitDoc from dbo.vwCallDefectReceiveUnitDoc With(NoLock)   
--select * into zreceiveunit from dbo.zreceiveunit With(NoLock)  
--select * into ICON_EntForms_Bank from  dbo.ICON_EntForms_Bank With(NoLock) 
--select * into Z_CreditBanking from  dbo.Z_CreditBanking With(NoLock)  
--select * into Users from  dbo.Users  With(NoLock) 
--select * into PROJECT_F_UNIT_STATUS_QIS from PROJECT_F_UNIT_STATUS_QIS  With(NoLock) 
--SELECT * INTO BU3_Remark FROM dbo.BU3_Remark  with(nolock)
--SELECT * INTO BU3_Tranfer FROM dbo.BU3_Tranfer  with(nolock)
end

-----------------------------------------TempCreditbanking-------------------------------
IF(object_id('tempdb..#TempCreditBanking')is not null) DROP table #TempCreditBanking
Select Credit.BookingID,m.[Key]
INTO #TempCreditBanking
   From #TCreditBanking as Credit With(NoLock)
   INNER JOIN #MasterCenter m With(NoLock) ON Credit.LoanStatusMasterCenterID = m.id 
WHERE Credit.IsDeleted = 0 

------------------------------------------------TempLetter-------------------------------
IF(object_id('tempdb..#TempLetter')is not null) DROP table #TempLetter
Select TransferLetterNo,TransferLetterDate,AgreementID,m.[Key]
INTO #TempLetter
	From [crmrevo].let.TransferLetter as a With(NoLock)
	INNER JOIN #MasterCenter m With(NoLock) ON a.TransferLetterTypeMasterCenterID = m.id 
	WHERE a.IsDeleted = 0 
---------------------------------------------------
--INSERT INTO Log_BU3_AP_BI_UnitDetail_NEW ([DateTime],[Productid],[Text])
--SELECT GETDATE(),@ProductID,'Start'


If(Object_Id('tempdb..#TBU3_AP_BI_UnitDetail_NEW')Is Not Null) DROP Table #TBU3_AP_BI_UnitDetail_NEW

Select distinct StartDate,
'Unit Status' as ReportName,
tb.QC_BL_IND_1_15_PTD ,
tb.QC_BL_OVD_16_30_PTD ,
tb.QC_BL_OVD_30_PTD ,
tb.QC_BL_CRD_PTD,
tb.NQC_BL_IND_1_15_PTD ,
tb.NQC_BL_OVD_16_30_PTD ,
tb.NQC_BL_OVD_30_PTD ,
tb.NQC_BL_CRD_PTD,
tb.projectID,
tb.ProductID,
tb.Proj_Name,
tb.UnitID,
tb.UnitNumber,
tb.FloorID,
tb.FloorName,
Case tb.[สถานะQIS]
when 'QA' then 'Pass'
when 'No act' then 'No Act'
else  tb.[สถานะQIS] end [สถานะQIS],
tb.IsQA,
tb.IsWIP,
tb.IsNoAct,
tb.ContractNumber,
tb.bookingnumber ,
tb.BookingID,
tb.TransferDate,
Convert(DATETIME,'') AS  TransferDateApprove,
Convert(INTEGER,0) AS  OverDueDay,
tb.ฉ1,
tb.ฉ2,
tb.[ฉ.ยกเลิก],
tb.วันที่ฉ1,
tb.วันที่ฉ2,
tb.[วันที่ฉ.ยกเลิก],
tb.ฉพิเศษ,
tb.วันที่ฉพิเศษ,
tb.ฉเตือน1,
tb.วันที่ฉเตือน1,
tb.ฉเตือน2,
tb.วันที่ฉเตือน2,
tb.ฉยกเลิกพิเศษ,
tb.วันที่ฉยกเลิกพิเศษ,
(Case 
when (tb.Defect1+tb.Defect2+tb.[Defect>2]) >0  then 0
when ((tb.Defect1+tb.Defect2+tb.[Defect>2]) <=0 )and ((tb.DefectEndDateNotNull - tb.DefectEndDateNull) = 1) then 0
when (tb.Defect1+tb.Defect2+tb.[Defect>2]) <=0 then 1
end ) as [ยังไม่ตรวจ],
tb.Defect1,
tb.Defect2,
tb.[Defect>2],
Convert(INTEGER,0) AS  NumberOfDefect,
Convert(NVARCHAR(50),'') AS  DefectName,
Convert(NVARCHAR(50),'') AS  NumberOfDefectName,
Convert(DATETIME,'') AS  CheckDate,
Convert(INTEGER,0) AS  AmountDefect,
Convert(INTEGER,0) AS  AmountDefectComplete,
Convert(DATETIME,0) AS  EndDateDefectComplete,
Convert(DATETIME,0) AS  ExpectDate,
Convert(INTEGER,0) AS  AmountDefect1,
Convert(DATETIME,0) AS  CheckDateDefect1,
Convert(INTEGER,0) AS  FixDayOfDefect1,
Convert(INTEGER,0) AS  AmountDefect2,
Convert(DATETIME,0) AS  CheckDateDefect2,
Convert(INTEGER,0) AS  FixDayOfDefect2,
Convert(INTEGER,0) AS  [รับห้องแล้ว],
(Case 
when Exists(Select * From #vwCallDefectReceiveUnitDoc z  With(NoLock) WHERE z.projectno=tb.ProductID and z.serialno=tb.UnitNumber and isnull(z.docisactive,0)=1 AND z.DocReceiveUnitDate IS NOT null )then 'รับห้องแล้ว'
--when Exists(Select * From zreceiveunit z  With(NoLock) WHERE z.projectId=tb.ProductID and z.unitnumber=tb.UnitNumber and isnull(z.isreceive,0)=1) then 'รับห้องแล้ว'
when (tb.Defect1+tb.Defect2+tb.[Defect>2]) >0 then 'ระหว่างซ่อม'
when ((tb.Defect1+tb.Defect2+tb.[Defect>2]) <=0 )and ((tb.DefectEndDateNotNull - tb.DefectEndDateNull) = 1) then 'พร้อมตรวจ'
when (tb.Defect1+tb.Defect2+tb.[Defect>2]) <=0 then 'รอตรวจ'end) as [สถานะซ่อม],
(Case 
when tb.[Status] =8 then 1
else 0 
end) as BC,
'ยังไม่ยื่นกู้' = (case when tb.bookingID in (select BookingID from #TCreditBanking  With(NoLock)) or tb.[status] = 1  then 0 else 1 end),
(Case
when   (tb.CreditWait >0) and (tb.CreditPass <=0) then 1
else 0
end) as [รออนุมัติเงินกู้],
(Select Max(Creditbanking.ApprovedAmount)  from #TCreditBanking as Creditbanking With(NoLock)
 INNER JOIN #MasterCenter m ON m.id = Creditbanking.LoanStatusMasterCenterID
where (Creditbanking.BookingID =tb.bookingID)
and m.[Key] ='1'
and Creditbanking.IsUseBank = 1) as [เงินกู้อนุมัติ],
(Select Top 1 Bank.NameTH  from #TCreditBanking as Creditbanking With(NoLock)
 Left JOIN [crmrevo].mst.Bank as Bank  With(NoLock)on (Creditbanking.BankID = Bank.id)
 INNER JOIN #MasterCenter m ON m.id = Creditbanking.LoanStatusMasterCenterID
where (Creditbanking.BookingID =tb.bookingID)
and m.[Key] ='1'
and Creditbanking.IsUseBank = 1) as [BankName],
(Select Top 1 Bank.Alias  from #TCreditBanking as Creditbanking With(NoLock)
 Left JOIN [crmrevo].mst.Bank as Bank  With(NoLock)on (Creditbanking.BankID = Bank.id)
 INNER JOIN #MasterCenter m ON m.id = Creditbanking.LoanStatusMasterCenterID
where (Creditbanking.BookingID =tb.bookingID )
and m.[Key] ='1'
and Creditbanking.IsUseBank = 1) as AdBankName,
(Case 
when tb.[Status] =1 then 1
else 0 
end) as [เงินสด],
(Case 
When (tb.[UnitCRMว่าง] >0) and (tb.QC_STK_PTD =1) then 1
else 0 
end) as [ห้องรอขาย],
tb.CreditWait,
tb.CreditPass,
tb.CreditReject,
tb.[Status],
tb.[UnitCRMว่าง],
tb.QC_STK_PTD,
tb.DefectEndDateNotNull,
tb.DefectEndDateNull,
tb.FullOwnerName,
tb.FullPhone,
Convert(NVARCHAR(max),0) AS  BankList,
Convert(NVARCHAR(50),0) AS  Letter1,
Convert(NVARCHAR(50),0) AS  Letter2,
Convert(NVARCHAR(50),0) AS  LetterCancel,
'DefectStatus'=(Case 
when Exists(Select * From #vwCallDefectReceiveUnitDoc z  With(NoLock)Where z.projectno=tb.ProductID and z.serialno=tb.UnitNumber and isnull(z.docisactive,0)=1 AND DocReceiveUnitDate IS NOT null) then 4
--when Exists(Select * From zreceiveunit z  With(NoLock)Where z.projectId=tb.ProductID and z.unitnumber=tb.UnitNumber and isnull(z.isreceive,0)=1) then 4
when (tb.Defect1+tb.Defect2+tb.[Defect>2]) >0 then 1
when ((tb.Defect1+tb.Defect2+tb.[Defect>2]) <=0 )and ((tb.DefectEndDateNotNull - tb.DefectEndDateNull) = 1) then 2
when (tb.Defect1+tb.Defect2+tb.[Defect>2]) <=0 then 3
Else 0
end) ,
Convert(NVARCHAR(50),0) AS  Letter4,
Convert(NVARCHAR(50),0) AS  Letter5,
Convert(NVARCHAR(50),0) AS  Letter6,
Convert(NVARCHAR(50),0) AS  Letter7,
Convert(NVARCHAR(max),0) AS  LetterStatus
,'BankReject'=Case When Exists(Select *  From #TCreditBanking as Credit With(NoLock)
   INNER JOIN #MasterCenter m With(NoLock) ON Credit.LoanStatusMasterCenterID = m.id 
   where  Credit.BookingID =  tb.BookingID and m.[KEY] = '1' )Then 1 Else 0 End
,Convert(INTEGER,0) AS  LetterAmountDays,
'LCName' = (select Top 1 u.DisplayName from [crmrevo].USR.[User] u  With(NoLock)where tb.saleID = u.id)
-----------------------------------------------------------------------------				    
,'SEName'=''
,'BookingDate'= bookingdate --(Select Top 1 BookingDate From SM_F_BOOKING_DETAILS t Where t.ProductID=tb.ProductID and t.UnitNumber=tb.UnitNumber and t.CancelDate Is Null)
,'ContractDate'= ContractDate --(Select Top 1 ContractDate From SM_F_AGREEMENT_DETAILS t Where t.ProductID=tb.ProductID and t.UnitNumber=tb.UnitNumber and t.CancelDate Is Null)
,Convert(DateTime,Null)[LoanDueDate]
,Convert(DateTime,Null) LoadDate,Convert(DateTime,Null) LoadApproveDate
,''[PromotionSale]
,''[PromotionTransfer]
,'AcceptUnitDate'=(Select top 1 DocReceiveUnitDate From #vwCallDefectReceiveUnitDoc z  With(NoLock) WHERE z.projectno=tb.ProductID and z.serialno=tb.UnitNumber and isnull(z.docisactive,0)=1)
						--,(Select top 1 receiveDate From zreceiveunit z  With(NoLock) WHERE z.projectId=tb.ProductID and z.unitnumber=tb.UnitNumber and isnull(z.isreceive,0)=1))
,'TransferDueDate'= ISNULL((Select Top 1 DueDate From #BU3_Tranfer t  With(NoLock) Where t.projectid=tb.ProductID and t.UnitNumber=tb.UnitNumber AND tb.bookingdate <= t.duedate),'')
,'TransferGrade'=Isnull((Select top 1 Grade From #BU3_Remark t  With(NoLock) WHERE t.ProjectID=tb.ProductID and t.UnitNumber=tb.UnitNumber and t.bookingNumber=tb.bookingNumber),'')
,EndDate 
--,EndProduct
Into #TBU3_AP_BI_UnitDetail_NEW
From
(

Select DISTINCT 
'startdate' = (CASE WHEN @ProductID IN (SELECT DISTINCT a.ProductID FROM dbo.BU3_AP_BI_UnitDetail_NEW a  With(NoLock)
								LEFT JOIN [crmrevo].prj.Project b  With(NoLock) ON a.ProductID = b.ProjectNo AND b.IsDeleted = 0
								INNER JOIN #MasterCenter m ON m.id = b.ProjectTypeMasterCenterID AND m.IsDeleted = 0 
								WHERE  1=1 AND m.[Key] = '2'
								--b.PType = 1
									 )
					THEN CONVERT(NVARCHAR(50),getdate(),105)+' '+'00:00:00'
					ELSE (SELECT TOP 1 a.StartDate FROM dbo.BU3_AP_BI_UnitDetail_NEW a  With(NoLock)
							LEFT JOIN [crmrevo].prj.Project b  With(NoLock) ON a.ProductID = b.ProjectNo AND b.IsDeleted = 0
							INNER JOIN #MasterCenter m ON m.id = b.ProjectTypeMasterCenterID AND m.IsDeleted = 0 
							WHERE 1=1 AND m.[Key] = '2'
							-- b.PType = 1 
							AND a.StartDate IS NOT NULL) 
							END ),
b.bookingdate,
Agree.ContractDate,
pro.TransferDateBefore AS PromotionTransferDate,
'QC_BL_IND_1_15_PTD' = null ,
'QC_BL_OVD_16_30_PTD' = null ,
'QC_BL_OVD_30_PTD'= null  ,
'QC_BL_CRD_PTD' = null,
'NQC_BL_IND_1_15_PTD' = null ,
'NQC_BL_OVD_16_30_PTD' = null ,
'NQC_BL_OVD_30_PTD' = null ,
'NQC_BL_CRD_PTD'= null ,
p.id AS ProjectID,
p.projectNo AS ProductID,
p.ProjectNameTH AS Proj_Name,
UNIT.UnitNo AS Unitnumber ,
Unit.ID AS UnitID,
RoomFloor.NameTH AS FloorID,
RoomFloor.Description as FloorName,
--(Case
--when (Isnull(u.EndProduct,'')='Y'
--or UNIT_STATUS_QIS.QC_BL_IND_1_15_PTD =1
--or UNIT_STATUS_QIS.QC_BL_OVD_16_30_PTD =1
--or UNIT_STATUS_QIS.QC_BL_OVD_30_PTD =1
--or UNIT_STATUS_QIS.QC_BL_CRD_PTD=1) then 'QA'
--when (UNIT_STATUS_QIS.NQC_BL_IND_1_15_PTD =1
--or UNIT_STATUS_QIS.NQC_BL_OVD_16_30_PTD =1
--or UNIT_STATUS_QIS.NQC_BL_OVD_30_PTD =1
--or UNIT_STATUS_QIS.NQC_BL_CRD_PTD =1) then 'WIP'
--else 'No act'
--end) as 'สถานะQIS',
--UNIT_STATUS_QIS.EndProduct,
'สถานะQIS' = (CASE WHEN ISNULL(UNIT_STATUS_QIS.EndProduct,'') = 'Y'  THEN 'QA' 
					WHEN ISNULL(UNIT_STATUS_QIS.EndProduct,'') <> 'Y' --AND b.BookingNo IS NOT NULL 
					AND UNIT_STATUS_QIS.unitid IN (SELECT unitid FROM #PaseStart ps WHERE StartDate IS  NOT NULL AND  ps.UnitID = UNIT_STATUS_QIS.UnitID) THEN 'WIP'   
					WHEN ISNULL(UNIT_STATUS_QIS.EndProduct,'') <> 'Y'  AND UNIT_STATUS_QIS.unitid  IN (SELECT unitid FROM #PaseStart ps WHERE StartDate IS null AND  ps.UnitID = UNIT_STATUS_QIS.UnitID) THEN 'No act'
					END ),
'IsQA' = CASE WHEN ISNULL(UNIT_STATUS_QIS.EndProduct,'') = 'Y'  THEN 1 ELSE 0 END  ,
'IsWIP' = CASE WHEN ISNULL(UNIT_STATUS_QIS.EndProduct,'') <> 'Y' --AND b.BookingNo IS NOT NULL 
AND UNIT_STATUS_QIS.unitid IN (SELECT unitid FROM #PaseStart ps WHERE ISNULL(StartDate,'') <> '' AND  ps.UnitID = UNIT_STATUS_QIS.UnitID) THEN 1 ELSE 0 end   ,
'IsNoAct' = CASE WHEN ISNULL(UNIT_STATUS_QIS.EndProduct,'') <> 'Y'  AND UNIT_STATUS_QIS.unitid  IN (SELECT unitid FROM #PaseStart ps WHERE StartDate IS null AND  ps.UnitID = UNIT_STATUS_QIS.UnitID) THEN 1 ELSE 0 END  
--(Case
----when (Isnull(u.complete,'')='Y'
--when (Isnull(u.EndProduct,'')='Y'
--or UNIT_STATUS_QIS.QC_BL_IND_1_15_PTD =1
--or UNIT_STATUS_QIS.QC_BL_OVD_16_30_PTD =1v
--or UNIT_STATUS_QIS.QC_BL_OVD_30_PTD =1
--or UNIT_STATUS_QIS.QC_BL_CRD_PTD=1
--and isnull(UNIT_STATUS_QIS.WIP_PTD,0) <>1
--) then 1
--else '0'
--end) as 'IsQA',
--(Case
--when (Isnull(u.EndProduct,'')<>'Y'
--and UNIT_STATUS_QIS.WIP_PTD =1
--) 
--then 1
--else '0'
--end) as 'IsWIP',
--(Case
--when (Isnull(u.EndProduct,'')='Y'
--or UNIT_STATUS_QIS.QC_BL_IND_1_15_PTD =1
--or UNIT_STATUS_QIS.QC_BL_OVD_16_30_PTD =1
--or UNIT_STATUS_QIS.QC_BL_OVD_30_PTD =1
--or UNIT_STATUS_QIS.QC_BL_CRD_PTD=1) then 0
--when (UNIT_STATUS_QIS.NQC_BL_IND_1_15_PTD =1
--or UNIT_STATUS_QIS.NQC_BL_OVD_16_30_PTD =1
--or UNIT_STATUS_QIS.NQC_BL_OVD_30_PTD =1
--or UNIT_STATUS_QIS.NQC_BL_CRD_PTD =1) then 0
--else 1
--end) as 'IsNoAct'
,Agree.AgreementNo AS ContractNumber
,b.BookingNo AS bookingnumber
,b.id AS BookingID,
isnull(Agree.TransferOwnershipDate,pro.TransferDateBefore) as TransferDate,
( 
	Select Count(TransferLetterNo)
	From #TempLetter Letter
	where Letter.AgreementID = Agree.id
	and  Letter.[KEY] = '1' 
	) as ฉ1,
	(Select TOP 1 TransferLetterDate
	From #TempLetter Letter
	where Letter.AgreementID = Agree.id
	and  Letter.[KEY] = '1' 
	) as วันที่ฉ1,
	
	( 
	Select Count(TransferLetterNo)
	From #TempLetter Letter
	where Letter.AgreementID = Agree.id
	and  Letter.[KEY] = '2' 
	) as ฉ2,
	(Select TOP 1 TransferLetterDate
	From #TempLetter Letter
	WHERE Letter.AgreementID = Agree.id
	AND  Letter.[KEY] = '2' 
	) AS วันที่ฉ2,
	( 
	SELECT COUNT(TransferLetterNo)
	FROM #TempLetter Letter
	where Letter.AgreementID = Agree.id
	and  Letter.[KEY] = '3'
	) as [ฉ.ยกเลิก],
	(Select TOP 1 TransferLetterDate
	From #TempLetter Letter
	where Letter.AgreementID = Agree.id
	and  Letter.[KEY] = '3' 
	) as [วันที่ฉ.ยกเลิก],
	
	( 
		Select Count(TransferLetterNo)
	From #TempLetter Letter
	where Letter.AgreementID = Agree.id
	and  Letter.[KEY] = '4' 
	) as ฉพิเศษ,
	(Select TOP 1 TransferLetterDate
	From #TempLetter  Letter
	where Letter.AgreementID = Agree.id
	and  Letter.[KEY] = '4' 
	) as วันที่ฉพิเศษ,
	
	( 
	Select Count(TransferLetterNo)
	From #TempLetter Letter
	WHERE Letter.AgreementID = Agree.id
	AND  Letter.[KEY] = '5' 
	) AS ฉเตือน1,
	(SELECT TOP 1 TransferLetterDate
	FROM #TempLetter Letter
	WHERE Letter.AgreementID = Agree.id
	AND  Letter.[KEY] = '5' 
	) AS วันที่ฉเตือน1,
	
	( 
	SELECT COUNT(TransferLetterNo)
	FROM #TempLetter  Letter
	where Letter.AgreementID = Agree.id
	and  Letter.[KEY] = '6' 
	) as ฉเตือน2,
	(Select TOP 1 TransferLetterDate
	From #TempLetter Letter
	where Letter.AgreementID = Agree.id
	and  Letter.[KEY] = '6' 
	) as วันที่ฉเตือน2,
	
		( Select Count(TransferLetterNo)
	From #TempLetter Letter
	where Letter.AgreementID = Agree.id
	and  Letter.[KEY] = '7' 
	) as ฉยกเลิกพิเศษ,
	(Select TOP 1 TransferLetterDate
	From #TempLetter Letter
	where Letter.AgreementID = Agree.id
	and  Letter.[KEY] = '7'
	) as วันที่ฉยกเลิกพิเศษ
	
,(
			Select Count(UnitNumber) 
			From (Select
					tb.UnitNumber,
					Count(tb.UnitNumber) as CountDefect,
				(Select Max(check_date) FROM #Defect as tdr With(NoLock) WHERE tdr.ProductID = tb.ProductID and  tdr.UnitNumber = tb.UnitNumber) as check_date,
				(Select Max(expect_date) FROM #Defect as tdr With(NoLock) WHERE tdr.ProductID = tb.ProductID and  tdr.UnitNumber = tb.UnitNumber) as expect_date
				From #Defect tb With(NoLock)
				where tb.ProductID = p.ProjectNo
				and tb.UnitNumber = Unit.UnitNo
				Group by UnitNumber,ProductID
				Having Count(tb.UnitNumber) = 1) as tb
   ) as Defect1,
   (
		Select Count(UnitNumber) 
			From (Select
			 tb.UnitNumber,
			 Count(tb.UnitNumber) as CountDefect,
			(Select Max(check_date)
			From #Defect as tdr With(NoLock)
			where tdr.ProductID = tb.ProductID and  tdr.UnitNumber = tb.UnitNumber) as check_date,
			(Select Max(expect_date)
			From #Defect as tdr With(NoLock)
			where tdr.ProductID = tb.ProductID and  tdr.UnitNumber = tb.UnitNumber) as expect_date
			From #Defect tb With(NoLock)
			where tb.ProductID = p.ProjectNo
			and tb.UnitNumber = Unit.UnitNo
			Group by UnitNumber,ProductID
			Having Count(tb.UnitNumber) = 2) as tb
   ) as Defect2,
    (
		Select Count(UnitNumber) 
			From (Select
			 tb.UnitNumber,
			 Count(tb.UnitNumber) as CountDefect,
			(Select Max(check_date)
			From #Defect as tdr With(NoLock)
			where tdr.ProductID = tb.ProductID and  tdr.UnitNumber = tb.UnitNumber) as check_date,
			(Select Max(expect_date)
			From #Defect as tdr With(NoLock)
			where tdr.ProductID = tb.ProductID and  tdr.UnitNumber = tb.UnitNumber) as expect_date
			From #Defect tb With(NoLock)
			where tb.ProductID = p.ProjectNo
			and tb.UnitNumber = Unit.UnitNo
			Group by UnitNumber,ProductID
			Having Count(tb.UnitNumber) >2) as tb
   ) as [Defect>2],
    (
		Select Count(UnitNumber) 
		From (Select
			 tb.UnitNumber,
			 Count(tb.UnitNumber) as CountDefect,
			(Select Max(check_date)
			From #Defect as tdr With(NoLock)
			where tdr.UnitNumber = tb.UnitNumber and tdr.ProductID = tb.ProductID ) as check_date,
			(Select Max(expect_date)
			From #Defect as tdr With(NoLock)
			where tdr.UnitNumber = tb.UnitNumber and tdr.ProductID = tb.ProductID ) as expect_date
			From
			(Select  tb.UnitNumber ,ProductID,
			tb.check_date,
			tb.expect_date
			From #TempDefectNull tb
			WHERE  tb.ProductID = p.ProjectNo
			and tb.UnitNumber = Unit.UnitNo
			) as tb
			Group by tb.UnitNumber,tb.ProductID	) as tb
   ) as DefectEndDateNull,
   (
		Select Count(UnitNumber) 
		From (Select
			 tb.UnitNumber,
			 Count(tb.UnitNumber) as CountDefect,
			(Select Max(check_date)
			From #Defect as tdr With(NoLock)
			where tdr.UnitNumber = tb.UnitNumber and tdr.ProductID = tb.ProductID ) as check_date,
			(Select Max(expect_date)
			From #Defect as tdr With(NoLock)
			where tdr.UnitNumber = tb.UnitNumber and tdr.ProductID = tb.ProductID ) as expect_date
			From
			(Select  tb.UnitNumber ,ProductID,
			tb.check_date,
			tb.expect_date
			From #TempDefectNotNull tb
			WHERE  tb.ProductID = p.ProjectNo
			and tb.UnitNumber = Unit.UnitNo
			) as tb
			Group by tb.UnitNumber,tb.ProductID	) as tb
   ) as DefectEndDateNotNull
  ,'Status' = (SELECT DISTINCT m.[Key] FROM #MasterCenter m WHERE m.id = b.CreditBankingTypeMasterCenterID AND m.IsDeleted = 0 )
   ,'CreditWait'=(Select Count(BookingID)  From #TempCreditBanking Credit  where  Credit.BookingID =  b.id and Credit.[KEY] = '3' )
   ,'CreditPass'= (Select Count(BookingID) FROM #TempCreditBanking Credit where  Credit.BookingID =  b.id and Credit.[KEY] = '1')   
   ,'CreditReject'= (Select Count(BookingID) From #TempCreditBanking  Credit  where  Credit.BookingID =  b.id and Credit.[KEY] = '2')
   ,(
   Select Count(U.UnitNo) From #TUnit  as U With(NoLock) 
   INNER JOIN #MasterCenter m With(NoLock) ON u.UnitStatusMasterCenterID = m.id 
	where m.[Key] IN ('0','1')
	and u.id = unit.id
   ) as [UnitCRMว่าง],
   'QC_STK_PTD' = 0 ,
  isnull(AgreeOwner.FirstNameTH,bookOwner.FirstNameTH)+' '+isnull(AgreeOwner.LastNameTH,bookOwner.LastNameTH) as FullOwnerName,
      Case 
	WHEN ISNULL(bm.[key],'') = '0' or ISNULL(am.[KEY],'') = '0' THEN isnull(am.PhoneNumber,bm.PhoneNumber)
	when ISNULL(bh.[Key],'') = '1'   or ISNULL(ah.[Key],'') = '1' THEN isnull(ah.PhoneNumber,bh.PhoneNumber) 
	----else isnull(AgreeOwner.Phone,bookOwner.Phone)+','+isnull(AgreeOwner.Mobile,bookOwner.Mobile)
	end as FullPhone,
	--CONVERT(INT,0) as 'FullPhone',
	'SaleID'=IsNull(TransferUnit.TransferSaleUserID,b.SaleUserID),
	CONVERT(DATETIME,'') AS EndDate
From #TProduct P 
LEFT JOIN #TUnit as Unit  ON p.id = unit.ProjectID 
Left Join #M_Unit as UNIT_STATUS_QIS on unit.SAPWBSNo = UNIT_STATUS_QIS.WBS
Left Join [crmrevo].prj.[Floor] as RoomFloor  With(NoLock)on (Unit.ProjectID = RoomFloor.ProjectID and Unit.TowerID = RoomFloor.TowerID and Unit.FloorID = RoomFloor.id)
left join #TBooking as b on (UNIT.id = b.UnitID and b.IsDeleted = 0 AND b.CancelDate IS null )
Left Join  #TBookingOwner as bookOwner on (b.id = bookOwner.BookingID and bookOwner.IsMainOwner =1 and isnull(bookOwner.IsDeleted,0) =0 AND bookOwner.IsAgreementOwner = 1)
LEFT JOIN (SELECT bp.BookingOwnerID,bp.PhoneNumber,m.[Name],m.[key] FROM  #TBookingOwnerPhone bp
	INNER JOIN #MasterCenter m 
	 ON bp.PhoneTypeMasterCenterID = m.id where  bp.IsDeleted = 0 AND m.[key] = '0' AND bp.IsMain = 1 AND m.IsActive = 1 ) bm		ON bookOwner.id = bm.BookingOwnerID 
	 LEFT JOIN (SELECT bp.BookingOwnerID,bp.PhoneNumber,m.[Name],m.[key] FROM  #TBookingOwnerPhone bp 
	INNER JOIN #MasterCenter m   ON bp.PhoneTypeMasterCenterID = m.id where  bp.IsDeleted = 0 AND m.[key] = '1'  AND m.IsActive = 1 AND bp.IsMain = 1) bh		ON bookOwner.id = bh.BookingOwnerID 
Left Join #TAgreement as Agree on (b.id = Agree.BookingID and Agree.IsDeleted = 0  AND Agree.IsCancel = 0)
Left Join #TAgreementOwner as AgreeOwner on (Agree.id = AgreeOwner.AgreementID and AgreeOwner.IsMainOwner =1 and isnull(AgreeOwner.IsDeleted,0) =0)
LEFT JOIN (SELECT bp.AgreementOwnerID,bp.PhoneNumber,m.[Name],m.[key]
		FROM  #TAgreementOwnerPhone bp 	INNER JOIN #MasterCenter m   ON bp.PhoneTypeMasterCenterID = m.id  AND bp.IsDeleted = 0  AND m.[key] = '0' AND bp.IsMain = 1 AND m.IsActive = 1) am  
 ON AgreeOwner.id = am.AgreementOwnerID 
LEFT JOIN (SELECT bp.AgreementOwnerID,bp.PhoneNumber,m.[Name],m.[key]
		FROM  #TAgreementOwnerPhone bp With(NoLock) 
			INNER JOIN #MasterCenter m With(NoLock) 
	 ON bp.PhoneTypeMasterCenterID = m.id  AND bp.IsDeleted = 0  AND m.[key] = '1'  AND m.IsActive = 1 AND bp.IsMain = 1) ah   ON AgreeOwner.id = ah.AgreementOwnerID
Left Join #TTransfer as TransferUnit	 With(NoLock)on (Agree.id = TransferUnit.AgreementID AND TransferUnit.IsDeleted = 0)
LEFT JOIN #SalePromotion as Pro With(NoLock) ON pro.BookingID = b.id AND pro.IsDeleted = 0
--Left Join ICON_EntForms_DocumentCheckList as Doc  With(NoLock)on (IsNull(Agree.ContractNumber,'x') = IsNull(Doc.ContractNumber,'xx') or IsNull(b.bookingnumber,'x')  = IsNull(Doc.bookingnumber,'xx') )	
--left join  #M_Unit  u on U.wbs = Unit.SAPWBSNo 
where  1=1 
and p.ProjectNo=@ProductID
--AND UNIT_STATUS_QIS.ProductID = '10177'
--ORDER BY UNIT.UnitNo
and unit.UnitNo not in(Select t.UnitNumber from BU3_AP_BI_UnitDetail_NEW t with(nolock) where t.ProductID=@ProductID and t.TransferDateApprove is not null)
) as tb
Order By ProductID,UnitNumber

--SELECT * FROM #TBU3_AP_BI_UnitDetail_NEW ORDER BY Unitnumber
--Modify by Suchat S. Kai 2019-06-19
CREATE NONCLUSTERED INDEX ix_non_id01 ON #TBU3_AP_BI_UnitDetail_NEW (ProductID, UnitNumber)

---------------------
INSERT INTO Log_BU3_AP_BI_UnitDetail_NEW ([DateTime],[Productid],[Text])
SELECT GETDATE(),@ProductID,'Start Update'

--UPDATE #TBU3_AP_BI_UnitDetail_NEW
--SET FullPhone = 
--FROM #TBU3_AP_BI_UnitDetail_NEW tt

Update #TBU3_AP_BI_UnitDetail_NEW
Set LoadDate=(Select Top 1 Credit.LoanSubmitDate 
				From #TCreditBanking as Credit With(NoLock)
   INNER JOIN #MasterCenter m With(NoLock) ON Credit.LoanStatusMasterCenterID = m.id 
   where  Credit.BookingID =  t.BookingID AND Credit.IsUseBank = 1 )
,LoadApproveDate=(Select Top 1 Credit.ResultDate 
				From #TCreditBanking as Credit With(NoLock)
   INNER JOIN #MasterCenter m With(NoLock) ON Credit.LoanStatusMasterCenterID = m.id 
   where  Credit.BookingID =  t.BookingID AND m.[Key] = '1' AND Credit.IsUseBank = 1)
From #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

Update #TBU3_AP_BI_UnitDetail_NEW
SET OverDueDay = (SELECT  DATEDIFF(day,a.TransferDate,isnull(dbo.fn_AP_BI_GetUnitTransferDate_REVO(a.ProductID,a.Unitnumber),Getdate()))  FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

Update #TBU3_AP_BI_UnitDetail_NEW
SET TransferDateApprove = (SELECT  dbo.fn_AP_BI_GetUnitTransferDate_REVO(a.ProductID,a.Unitnumber)  FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

Update #TBU3_AP_BI_UnitDetail_NEW
SET NumberOfDefect = (SELECT  dbo.fn_AP_BI_GetNumberOfDefect(a.ProductID,a.UnitNumber)   FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

Update #TBU3_AP_BI_UnitDetail_NEW
SET CheckDate = (SELECT  dbo.fn_AP_BI_GetCheckDateOfDefect(a.ProductID,a.UnitNumber)   FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

Update #TBU3_AP_BI_UnitDetail_NEW
SET AmountDefect = (SELECT  dbo.fn_AP_BI_GetAmountDefect(a.ProductID,a.UnitNumber)   FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

Update #TBU3_AP_BI_UnitDetail_NEW
SET AmountDefectComplete = (SELECT  dbo.fn_AP_BI_GetAmountDefectComplete(a.ProductID,a.UnitNumber)  FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

Update #TBU3_AP_BI_UnitDetail_NEW
SET EndDateDefectComplete = (SELECT  dbo.fn_AP_BI_GetEndDateDefectComplete(a.ProductID,a.UnitNumber)  FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

Update #TBU3_AP_BI_UnitDetail_NEW
SET ExpectDate = (SELECT  dbo.fn_AP_BI_GetExpectDateOfDefect(a.ProductID,a.UnitNumber)  FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

Update #TBU3_AP_BI_UnitDetail_NEW
SET AmountDefect1 = (SELECT  dbo.fn_AP_BI_GetAmountDefect1(a.ProductID,a.UnitNumber)  FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

Update #TBU3_AP_BI_UnitDetail_NEW
SET CheckDateDefect1 = (SELECT  dbo.fn_AP_BI_GetCheckDateDefect1(a.ProductID,a.UnitNumber)  FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID
 
 Update #TBU3_AP_BI_UnitDetail_NEW
SET FixDayOfDefect1 = (SELECT  dbo.fn_AP_BI_GetFixDayOfDefect1(a.ProductID,a.UnitNumber)  FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

 Update #TBU3_AP_BI_UnitDetail_NEW
SET AmountDefect2 = (SELECT  dbo.fn_AP_BI_GetAmountDefect2(a.ProductID,a.UnitNumber)  FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

 Update #TBU3_AP_BI_UnitDetail_NEW
SET CheckDateDefect2 = (SELECT  dbo.fn_AP_BI_GetCheckDateDefect2(a.ProductID,a.UnitNumber)  FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

 Update #TBU3_AP_BI_UnitDetail_NEW
SET FixDayOfDefect2 = (SELECT  dbo.fn_AP_BI_GetFixDayOfDefect2(a.ProductID,a.UnitNumber)  FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

 Update #TBU3_AP_BI_UnitDetail_NEW
SET [รับห้องแล้ว] = (SELECT  dbo.fn_AP_BI_IsReceipt(a.ProductID,a.UnitNumber) FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID
	
 Update #TBU3_AP_BI_UnitDetail_NEW
SET BankList = (SELECT  dbo.fn_GetCreditbanking_REVO(isnull(a.ContractNumber,a.bookingnumber)) FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

-- Update #TBU3_AP_BI_UnitDetail_NEW
--SET Letter1 = (SELECT  dbo.fn_AP_BI_GetLetter1_Revo(a.ContractNumber) FROM #TBU3_AP_BI_UnitDetail_NEW a With(NoLock)  WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
--FROM #TBU3_AP_BI_UnitDetail_NEW t
--Where t.ProductID=@ProductID

-- Update #TBU3_AP_BI_UnitDetail_NEW
--SET Letter2 = (SELECT  dbo.fn_AP_BI_GetLetter2_Revo(a.ContractNumber) FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
--FROM #TBU3_AP_BI_UnitDetail_NEW t
--Where t.ProductID=@ProductID

-- Update #TBU3_AP_BI_UnitDetail_NEW
--SET LetterCancel = (SELECT  dbo.fn_AP_BI_GetLetterCancel_Revo(a.ContractNumber) FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
--FROM #TBU3_AP_BI_UnitDetail_NEW t
--Where t.ProductID=@ProductID

-- Update #TBU3_AP_BI_UnitDetail_NEW
--SET Letter4 = (SELECT  dbo.fn_AP_BI_GetLetter4_Revo(a.ContractNumber) FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
--FROM #TBU3_AP_BI_UnitDetail_NEW t
--Where t.ProductID=@ProductID

-- Update #TBU3_AP_BI_UnitDetail_NEW
--SET Letter5 = (SELECT  dbo.fn_AP_BI_GetLetter5_Revo(a.ContractNumber) FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
--FROM #TBU3_AP_BI_UnitDetail_NEW t
--Where t.ProductID=@ProductID

-- Update #TBU3_AP_BI_UnitDetail_NEW
--SET Letter6 = (SELECT  dbo.fn_AP_BI_GetLetter6_Revo(a.ContractNumber) FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
--FROM #TBU3_AP_BI_UnitDetail_NEW t
--Where t.ProductID=@ProductID

-- Update #TBU3_AP_BI_UnitDetail_NEW
--SET Letter7 = (SELECT  dbo.fn_AP_BI_GetLetter7_Revo(a.ContractNumber) FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
--FROM #TBU3_AP_BI_UnitDetail_NEW t
--Where t.ProductID=@ProductID

 Update #TBU3_AP_BI_UnitDetail_NEW
SET LetterStatus = (SELECT  dbo.fn_AP_BI_GetLetterStatus_Revo(a.ContractNumber,a.ProductID,a.UnitNumber) FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

 Update #TBU3_AP_BI_UnitDetail_NEW
SET LetterAmountDays = (SELECT  dbo.fn_AP_BI_GetLetterAmountDays_Revo(a.ContractNumber)  FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

 Update #TBU3_AP_BI_UnitDetail_NEW
SET DefectName = (SELECT  'D '+CAST(dbo.fn_AP_BI_GetNumberOfDefect(a.ProductID,a.UnitNumber) as Nvarchar(2))+':'  FROM #TBU3_AP_BI_UnitDetail_NEW a  With(NoLock) WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

 Update #TBU3_AP_BI_UnitDetail_NEW
SET NumberOfDefectName = (SELECT  '('+CAST(dbo.fn_AP_BI_GetAmountDefect(a.ProductID,a.UnitNumber) as Nvarchar(3))+')'  FROM #TBU3_AP_BI_UnitDetail_NEW a WHERE a.ProductID = t.productid AND a.UnitNumber = t.unitnumber )
FROM #TBU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

INSERT INTO Log_BU3_AP_BI_UnitDetail_NEW ([DateTime],[Productid],[Text])
SELECT GETDATE(),@ProductID,'End of Update'

--Modify by Suchat S. 2019-06-19
--SELECT StartDate [ReportName],[QC_BL_IND_1_15_PTD],[QC_BL_OVD_16_30_PTD],[QC_BL_OVD_30_PTD],[QC_BL_CRD_PTD],[NQC_BL_IND_1_15_PTD],[NQC_BL_OVD_16_30_PTD],[NQC_BL_OVD_30_PTD]
--,[NQC_BL_CRD_PTD],[ProductID],[Proj_Name],[UnitNumber],[FloorID],[FloorName],[สถานะQIS],[IsQA],[IsWIP],[IsNoAct],[ContractNumber],[BookingNumber],[TransferDate]
--,[TransferDateApprove],[OverDueDay],[ฉ1],[ฉ2],[ฉ.ยกเลิก],[วันที่ฉ1],[วันที่ฉ2],[วันที่ฉ.ยกเลิก],[ฉพิเศษ],[วันที่ฉพิเศษ],[ฉเตือน1],[วันที่ฉเตือน1],[ฉเตือน2],[วันที่ฉเตือน2],[ฉยกเลิกพิเศษ],[วันที่ฉยกเลิกพิเศษ]
--,[ยังไม่ตรวจ],[Defect1],[Defect2],[Defect>2],[NumberOfDefect],[DefectName],[NumberOfDefectName],[CheckDate],[AmountDefect],[AmountDefectComplete],[EndDateDefectComplete]
--,[ExpectDate],[AmountDefect1],[CheckDateDefect1],[FixDayOfDefect1],[AmountDefect2],[CheckDateDefect2],[FixDayOfDefect2],[รับห้องแล้ว],[สถานะซ่อม],[BC],[ยังไม่ยื่นกู้]
--,[รออนุมัติเงินกู้],[เงินกู้อนุมัติ],[BankName],[AdBankName],[เงินสด],[ห้องรอขาย],[CreditWait],[CreditPass],CreditReject,[Status],[UnitCRMว่าง],[QC_STK_PTD],[DefectEndDateNotNull]
--,[DefectEndDateNull],[FullOwnerName],[FullPhone],[BankList],[Letter1],[Letter2],[LetterCancel],[DefectStatus],[Letter4],[Letter5],[Letter6],[Letter7],[LetterStatus]
--,[BankReject],[LetterAmountDays],[LCName],[SEName],[BookingDate],[ContractDate],[LoanDueDate],[LoadDate],[LoadApproveDate],[PromotionSale],[PromotionTransfer]
--,[AcceptUnitDate],[TransferDueDate],[TransferGrade],EndDate
--From #TBU3_AP_BI_UnitDetail_NEW
--Order By UnitNumber



Delete From BU3_AP_BI_UnitDetail_NEW Where ProductID=@ProductID
and UnitNumber not in(Select t.UnitNumber from BU3_AP_BI_UnitDetail_NEW t with(nolock) where t.ProductID=@ProductID and t.TransferDateApprove is not null)

INSERT INTO Log_BU3_AP_BI_UnitDetail_NEW ([DateTime],[Productid],[Text])
SELECT GETDATE(),@ProductID,'Insert'

Insert into BU3_AP_BI_UnitDetail_NEW
(StartDate,[ReportName],[QC_BL_IND_1_15_PTD],[QC_BL_OVD_16_30_PTD],[QC_BL_OVD_30_PTD],[QC_BL_CRD_PTD],[NQC_BL_IND_1_15_PTD],[NQC_BL_OVD_16_30_PTD],[NQC_BL_OVD_30_PTD]
,[NQC_BL_CRD_PTD],[ProjectID],[ProductID],[Proj_Name],[UnitNumber],[UnitID],[FloorID],[FloorName],[สถานะQIS],[IsQA],[IsWIP],[IsNoAct],[ContractNumber],[BookingNumber],[BookingID],[TransferDate]
,[TransferDateApprove],[OverDueDay],[ฉ1],[ฉ2],[ฉ.ยกเลิก],[วันที่ฉ1],[วันที่ฉ2],[วันที่ฉ.ยกเลิก],[ฉพิเศษ],[วันที่ฉพิเศษ],[ฉเตือน1],[วันที่ฉเตือน1],[ฉเตือน2],[วันที่ฉเตือน2],[ฉยกเลิกพิเศษ],[วันที่ฉยกเลิกพิเศษ]
,[ยังไม่ตรวจ],[Defect1],[Defect2],[Defect>2],[NumberOfDefect],[DefectName],[NumberOfDefectName],[CheckDate],[AmountDefect],[AmountDefectComplete],[EndDateDefectComplete]
,[ExpectDate],[AmountDefect1],[CheckDateDefect1],[FixDayOfDefect1],[AmountDefect2],[CheckDateDefect2],[FixDayOfDefect2],[รับห้องแล้ว],[สถานะซ่อม],[BC],[ยังไม่ยื่นกู้]
,[รออนุมัติเงินกู้],[เงินกู้อนุมัติ],[BankName],[AdBankName],[เงินสด],[ห้องรอขาย],[CreditWait],[CreditPass],CreditReject,[Status],[UnitCRMว่าง],[QC_STK_PTD],[DefectEndDateNotNull]
,[DefectEndDateNull],[FullOwnerName],[FullPhone],[BankList],[Letter1],[Letter2],[LetterCancel],[DefectStatus],[Letter4],[Letter5],[Letter6],[Letter7],[LetterStatus]
,[BankReject],[LetterAmountDays],[LCName],[SEName],[BookingDate],[ContractDate],[LoanDueDate],[LoadDate],[LoadApproveDate],[PromotionSale],[PromotionTransfer]
,[AcceptUnitDate],[TransferDueDate],[TransferGrade],EndDate
)
Select StartDate,[ReportName],[QC_BL_IND_1_15_PTD],[QC_BL_OVD_16_30_PTD],[QC_BL_OVD_30_PTD],[QC_BL_CRD_PTD],[NQC_BL_IND_1_15_PTD],[NQC_BL_OVD_16_30_PTD],[NQC_BL_OVD_30_PTD]
,[NQC_BL_CRD_PTD],[ProjectID],[ProductID],[Proj_Name],[UnitNumber],[UnitID],[FloorID],[FloorName],[สถานะQIS],[IsQA],[IsWIP],[IsNoAct],[ContractNumber],[BookingNumber],[BookingID],[TransferDate]
,[TransferDateApprove],[OverDueDay],[ฉ1],[ฉ2],[ฉ.ยกเลิก],[วันที่ฉ1],[วันที่ฉ2],[วันที่ฉ.ยกเลิก],[ฉพิเศษ],[วันที่ฉพิเศษ],[ฉเตือน1],[วันที่ฉเตือน1],[ฉเตือน2],[วันที่ฉเตือน2],[ฉยกเลิกพิเศษ],[วันที่ฉยกเลิกพิเศษ]
,[ยังไม่ตรวจ],[Defect1],[Defect2],[Defect>2],[NumberOfDefect],[DefectName],[NumberOfDefectName],[CheckDate],[AmountDefect],[AmountDefectComplete],[EndDateDefectComplete]
,[ExpectDate],[AmountDefect1],[CheckDateDefect1],[FixDayOfDefect1],[AmountDefect2],[CheckDateDefect2],[FixDayOfDefect2],[รับห้องแล้ว],[สถานะซ่อม],[BC],[ยังไม่ยื่นกู้]
,[รออนุมัติเงินกู้],[เงินกู้อนุมัติ],[BankName],[AdBankName],[เงินสด],[ห้องรอขาย],[CreditWait],[CreditPass],CreditReject,[Status],[UnitCRMว่าง],[QC_STK_PTD],[DefectEndDateNotNull]
,[DefectEndDateNull],[FullOwnerName],[FullPhone],[BankList],[Letter1],[Letter2],[LetterCancel],[DefectStatus],[Letter4],[Letter5],[Letter6],[Letter7],[LetterStatus]
,[BankReject],[LetterAmountDays],[LCName],[SEName],[BookingDate],[ContractDate],[LoanDueDate],[LoadDate],[LoadApproveDate],[PromotionSale],[PromotionTransfer]
,[AcceptUnitDate],[TransferDueDate],[TransferGrade],EndDate
From #TBU3_AP_BI_UnitDetail_NEW
Order By UnitNumber

Update BU3_AP_BI_UnitDetail_NEW
SET EndDate = GETDATE()
FROM BU3_AP_BI_UnitDetail_NEW t
Where t.ProductID=@ProductID

INSERT INTO Log_BU3_AP_BI_UnitDetail_NEW ([DateTime],[Productid],[Text])
SELECT GETDATE(),@ProductID,'End'
PRINT 'finish'+@ProductID
go

