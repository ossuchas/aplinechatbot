
CREATE PROCEDURE [dbo].[sp_test_kai]
@p_period AS varchar(10)
As

    SET NOCOUNT ON;

	PRINT 'xxxx kai ทดสอบ ไก่ สอง สาม สี่ one two three yyy'



go

