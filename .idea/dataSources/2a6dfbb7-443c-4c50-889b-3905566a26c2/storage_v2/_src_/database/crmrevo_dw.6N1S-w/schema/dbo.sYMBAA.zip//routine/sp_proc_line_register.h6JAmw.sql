

CREATE PROCEDURE [dbo].[sp_proc_line_register]
AS
BEGIN
    SET NOCOUNT ON;
	DECLARE @i_count_emp INT;
	DECLARE @i_count_user INT;
	DECLARE @logid AS BIGINT;
	DECLARE @source_userId AS VARCHAR(255);
	DECLARE @register_empid AS VARCHAR(50);
	DECLARE @register_email AS VARCHAR(50);
	DECLARE @register_flag AS VARCHAR(2)
	DECLARE @user_type AS VARCHAR(10)
	DECLARE @user_sub_no AS VARCHAR(10)
	DECLARE @user_name AS VARCHAR(255)
	DECLARE @full_name AS VARCHAR(255)
	DECLARE @user_empcode AS VARCHAR(50)
	DECLARE @user_position AS VARCHAR(100)

	SET @register_flag = 'R'

	DECLARE db_cursor CURSOR FOR
	SELECT logid,
		   source_userId,
		   --register_empid, --Modified by Suchat S. 2020-01-06
		   CASE WHEN register_empid LIKE '%@apthai.com' THEN REPLACE(register_empid,'@apthai.com','') ELSE register_empid END register_empid,
		   register_email
	FROM dbo.log_linechatbot WITH (NOLOCK)
	WHERE 1 = 1
		  AND message_text LIKE 'register=>%'
		  AND register_flag = 'Y'
	ORDER BY createdate ASC;


	OPEN db_cursor;
	FETCH NEXT FROM db_cursor
	INTO @logid,
		 @source_userId,
		 @register_empid,
		 @register_email;

	WHILE @@FETCH_STATUS = 0
	BEGIN
  --      PRINT @register_empid
		--PRINT @register_email

		SET @register_flag = 'R'
		SET @user_type = 'NOR'

		--VIP or C Level
		SELECT @i_count_emp = COUNT(*)
		FROM dbo.vw_vw_crm_line_emp WITH (NOLOCK)
		WHERE 1=1
		AND (Status = 'Active' AND (Position LIKE '%Chief%' OR Position LIKE '%Director%')
		AND Devision NOT IN ('BC Management','SSM','Vaari Digital','Clay More','SQE Management') 
		OR EmpCode IN ('AP003910'
		,'AP001283' --พี่เก่ง
		,'AP001488' --พี่นน
		,'AP002838' --แคท
		,'AP004233' --ตา
		,'AP003996' --ต้า
		,'AP001383' --เอี่ยม
		,'AP000782' --พี่กิ๊ก
		,'AP000602' --พี่อ้อ
		,'AP002229' --เพ็ญ
		,'AP002467' --ไอติม
		,'AP002877' --กิ๊ก
		,'AP002996' --ฉิง
		,'AP004773' -- FI กวาง
		,'AP004724' -- FI บี
		,'AP000553' -- FI นิด
		,'AP000034' --พี่ฝน
		,'AP001081' --พี่ณัฐ
		,'AP004259' --แนน
		,'AP000567' --ตุ๊กตา (PR)
		,'AP001866' --ฝ้าย (PR)
		,'AP004213' --
		--,'CR002848' --พี่นุก SSM -- Modified by Suchat S. 2020-02-28 for add SSM Chief
		))
		--AND EmpCode = @register_empid
		--AND Email = @register_email
		AND Email = @register_empid + '@apthai.com'

		--PRINT @i_count_emp
		IF @i_count_emp > 0 
		BEGIN
			--PRINT @source_userId;
			SET @user_type = 'VIP' -- C Level
			SET @user_position = 'C Level'

			--SELECT @full_name = FullName, @user_name = UserName
			--FROM dbo.vw_vw_crm_line_emp WITH (NOLOCK)
			--WHERE 1=1
			----AND EmpCode = @register_empid
			----AND Email = @register_email
			--AND LOWER(Email) = LOWER(@register_empid) + '@apthai.com' --Modified by Suchat S. 2020-01-09
			--AND EmpCode IN ('AP001017','AP000391','AP000749','AP000006','AP000057','AP003726','AP002773','AP000008','AP004354') --VIP2

			IF EXISTS( SELECT *
				FROM dbo.vw_vw_crm_line_emp WITH (NOLOCK)
				WHERE 1=1
				AND LOWER(Email) = LOWER(@register_empid) + '@apthai.com' --Modified by Suchat S. 2020-01-09
				AND EmpCode IN ('AP001017','AP000391','AP000749','AP000006','AP000057','AP003726','AP002773','AP000008','AP004354','AP000567', 'AP001866') --VIP2
			)
			BEGIN
				SET @user_type = 'VIP2'
			END
			ELSE
			BEGIN
				SET @user_type = 'VIP'
			END

			SELECT TOP 1 @full_name = FullName, @user_name = UserName
			FROM dbo.vw_vw_crm_line_emp WITH (NOLOCK)
			WHERE 1=1
			AND LOWER(Email) = LOWER(@register_empid) + '@apthai.com'

			SELECT @i_count_user = COUNT(*) FROM dbo.chatbot_mst_user WITH(NOLOCK) WHERE user_token_Id = @source_userId
			IF @i_count_user <= 0
				SET @register_flag = 'A'
		END
		ELSE
		BEGIN
			--Check Sub BG Level
			IF EXISTS(SELECT *
				FROM dbo.vw_crm_line_userrole WITH(NOLOCK)
				WHERE Email = @register_empid + '@apthai.com'
				AND (SourceType = 'PositionRole' AND rolecode = 'SBG' OR sourcetype = 'SubBG' AND rolecode LIKE 'SubBG%')
				AND SourceType = 'PositionRole' AND rolecode <> 'LCM' -- Modified by Suchat S. 2020-01-10
				) -- is Sub BG
			BEGIN
				PRINT 'Sub BG'
				SET @user_type = 'SUBBG' -- Sub BG Level
				SET @user_position = 'VP'

				--Sub String for get Sub BG Number
				SELECT TOP 1 @user_sub_no = REPLACE(UPPER(rolecode),'SUBBG','')
				FROM dbo.vw_crm_line_userrole WITH(NOLOCK)
				WHERE email = @register_empid + '@apthai.com'
				AND sourcetype = 'SubBG' AND rolecode LIKE 'SubBG%'

				SELECT @i_count_user = COUNT(*) FROM dbo.chatbot_mst_user WITH(NOLOCK) WHERE user_token_Id = @source_userId
				IF @i_count_user <= 0
					SET @register_flag = 'A'
			END
			ELSE
			BEGIN
				--Check Role LCM
				IF EXISTS(SELECT * 
					FROM dbo.vw_crm_line_userrole WITH(NOLOCK)
					WHERE email = @register_empid + '@apthai.com'
					AND (sourcetype = 'PositionRole' AND rolecode = 'LCM' OR sourcetype = 'LCM' AND rolecode LIKE 'LCM_%'))
				BEGIN
					PRINT 'LCM'
					SET @user_type = 'LCM' -- LCM Level
					SET @user_position = 'LCM'

					--Sub String for get Sub BG Number
					SELECT TOP 1 @user_sub_no = REPLACE(UPPER(rolecode),'SUBBG','')
					FROM dbo.vw_crm_line_userrole WITH(NOLOCK)
					WHERE email = @register_empid + '@apthai.com'
					AND sourcetype = 'SubBG' AND rolecode LIKE 'SubBG%'

					SELECT @i_count_user = COUNT(*) FROM dbo.chatbot_mst_user WITH(NOLOCK) WHERE user_token_Id = @source_userId
					IF @i_count_user <= 0
						SET @register_flag = 'A'
				END
				ELSE
				BEGIN
					--Modified by Suchat S. check VP Sale
					IF EXISTS(SELECT * 
						FROM dbo.vw_crm_line_userrole WITH(NOLOCK)
						WHERE email = @register_empid + '@apthai.com'
						AND (sourcetype = 'PositionRole' AND rolecode LIKE 'VP%' OR sourcetype LIKE 'VP%'))
					BEGIN
						PRINT 'VP Sale'
						SET @user_type = 'SUBBG' -- LCM Level
						SET @user_position = 'VP'

						--Sub String for get Sub BG Number
						SELECT TOP 1 @user_sub_no = REPLACE(UPPER(rolecode),'SUBBG','')
						FROM dbo.vw_crm_line_userrole WITH(NOLOCK)
						WHERE email = @register_empid + '@apthai.com'
						AND sourcetype = 'SubBG' AND rolecode LIKE 'SubBG%'

						SELECT @i_count_user = COUNT(*) FROM dbo.chatbot_mst_user WITH(NOLOCK) WHERE user_token_Id = @source_userId
						IF @i_count_user <= 0
							SET @register_flag = 'A'
					END
					ELSE
					BEGIN
						IF EXISTS (
							SELECT *
							FROM dbo.vw_crm_line_userrole WITH(NOLOCK)
							WHERE email = @register_empid + '@apthai.com'
							AND sourcetype = 'PositionRole' 
							AND rolecode LIKE 'MKT'
						)
						BEGIN
						    PRINT 'Marketing'
							SET @user_type = 'MKT' -- MKT Level
							SET @user_position = 'MKT'

							--Sub String for get Sub BG Number
							SELECT TOP 1 @user_sub_no = REPLACE(UPPER(rolecode),'SUBBG','')
							FROM dbo.vw_crm_line_userrole WITH(NOLOCK)
							WHERE email = @register_empid + '@apthai.com'
							AND sourcetype = 'SubBG' 
							AND rolecode LIKE 'SubBG%'

							SELECT @i_count_user = COUNT(*) FROM dbo.chatbot_mst_user WITH(NOLOCK) WHERE user_token_Id = @source_userId
							IF @i_count_user <= 0
								SET @register_flag = 'A'
						END
						ELSE
                        BEGIN
							--Modified by Suchat S. 2020-11-11 for Add PM
							IF EXISTS(
								SELECT *
								FROM dbo.vw_crm_line_userrole WITH(NOLOCK)
								WHERE email = @register_empid + '@apthai.com'
								AND sourcetype IN ('Manual','PositionRole')
								AND rolecode = 'PM'
								)
							BEGIN
							    PRINT 'Project Manager'
								SET @user_type = 'PM' -- PM Level
								SET @user_position = 'PM'

								--Sub String for get Sub BG Number
								SELECT TOP 1 @user_sub_no = REPLACE(UPPER(RoleCode),'SUBBG','')
								FROM [crmrevo].[dbo].[vw_UserRoleProject] WITH(NOLOCK)
								WHERE EmpCode IN (
											SELECT empcode
											FROM dbo.vw_crm_line_userrole WITH(NOLOCK)
											WHERE email = @register_empid + '@apthai.com'
											AND sourcetype IN ('Manual','PositionRole')
											AND rolecode = 'PM'
								)
								AND RoleCode LIKE '%SubBG%'

								SELECT @i_count_user = COUNT(*) FROM dbo.chatbot_mst_user WITH(NOLOCK) WHERE user_token_Id = @source_userId
								IF @i_count_user <= 0
									SET @register_flag = 'A'

							END
							ELSE
							BEGIN
								PRINT 'Reject'
								SET @register_flag = 'R'
							END
                        END
					END
				END
			END
		END

		--PRINT @register_flag

		IF @register_flag = 'A'
		BEGIN
			--Get Employee Code
			--SELECT @user_empcode = b.EmpCode
			--FROM dbo.chatbot_mst_user a WITH(NOLOCK), dbo.vw_vw_crm_line_emp b WITH(NOLOCK)
			--WHERE a.user_emp_id + '@apthai.com' = b.Email
			--AND a.user_emp_id = @register_empid
			SELECT TOP 1 @user_empcode = EmpCode, @full_name = FullName, @user_name = UserName
			FROM dbo.vw_vw_crm_line_emp WITH (NOLOCK)
			WHERE 1=1
			AND LOWER(Email) = LOWER(@register_empid) + '@apthai.com'

			INSERT INTO dbo.chatbot_mst_user
			(
				user_token_Id,
				user_name,
				user_full_name,
				user_type,
				user_sub_no,
				user_position,
				user_emp_id,
				user_empcode,
				user_status,
				createby,
				createdate,
				modifyby,
				modifydate
			)
			VALUES
			(   @source_userId,      
				@user_name,        
				@full_name,        
				@user_type,        
				@user_sub_no,
				@user_position, 
				@register_empid,   
				@user_empcode,
				'A',        
				'batch_reg',
				GETDATE(), 
				'batch_reg',
				GETDATE() 
			)
		END

		--PRINT @logid

		UPDATE dbo.log_linechatbot 
		SET register_flag = @register_flag,
			modifyby = 'batch_check',
			modifydate = GETDATE()
		WHERE logid = @logid

		FETCH NEXT FROM db_cursor
		INTO @logid,
			 @source_userId,
			 @register_empid,
			 @register_email;
	END;

	CLOSE db_cursor;
	DEALLOCATE db_cursor;
END;



go

