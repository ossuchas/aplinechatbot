CREATE PROC [dbo].[sp_RPT_ProjectSummaryMail_CD2]
as
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
DECLARE @Mail NVARCHAR(MAX);
IF (OBJECT_ID('tempdb..#vw_CRM_Walk_1') IS NOT NULL)
    DROP TABLE #vw_CRM_Walk_1;
IF (OBJECT_ID('tempdb..#CRM_Opportunities') IS NOT NULL)
    DROP TABLE #CRM_Opportunities;
IF (OBJECT_ID('tempdb..#CRM_Activity') IS NOT NULL)
    DROP TABLE #CRM_Activity;
IF (OBJECT_ID('tempdb..#CRM_Leads_Call') IS NOT NULL)
    DROP TABLE #CRM_Leads_Call;
IF (OBJECT_ID('tempdb..#CRM_Leads_W') IS NOT NULL)
    DROP TABLE #CRM_Leads_W;
IF (OBJECT_ID('tempdb..#TempCancel') IS NOT NULL)
    DROP TABLE #TempCancel;
IF (OBJECT_ID('tempdb..#ZTEMP_Booking') IS NOT NULL)
    DROP TABLE #ZTEMP_Booking;
IF (OBJECT_ID('tempdb..#ICON_EntForms_Agreement') IS NOT NULL)
    DROP TABLE #ICON_EntForms_Agreement;
IF (OBJECT_ID('tempdb..#ICON_EntForms_Booking') IS NOT NULL)
    DROP TABLE #ICON_EntForms_Booking;
IF (OBJECT_ID('tempdb..#TempTarget') IS NOT NULL)
    DROP TABLE #TempTarget;
IF (OBJECT_ID('tempdb..#vw_RPTAP2_ExV4Booking') IS NOT NULL)
    DROP TABLE #vw_RPTAP2_ExV4Booking;
IF (OBJECT_ID('tempdb..#TempBookThai') IS NOT NULL)
    DROP TABLE #TempBookThai;
IF (OBJECT_ID('tempdb..#TempBookNoThai') IS NOT NULL)
    DROP TABLE #TempBookNoThai;
IF (OBJECT_ID('tempdb..#TempBookAll') IS NOT NULL)
    DROP TABLE #TempBookAll;
IF (OBJECT_ID('tempdb..#TempArea') IS NOT NULL)
    DROP TABLE #TempArea;
IF (OBJECT_ID('tempdb..#Tempvw_UserRoleProject') IS NOT NULL)
    DROP TABLE #Tempvw_UserRoleProject;
IF (OBJECT_ID('tempdb..#vw_RPTAP2_ExV4BookingCancel') IS NOT NULL)
    DROP TABLE #vw_RPTAP2_ExV4BookingCancel;
IF (OBJECT_ID('tempdb..#vw_UnitPrice') IS NOT NULL)
    DROP TABLE #vw_UnitPrice;
IF (OBJECT_ID('tempdb..#TempArea') IS NOT NULL)
    DROP TABLE #TempArea;
IF (OBJECT_ID('tempdb..#TempPriceListItem') IS NOT NULL)
    DROP TABLE #TempPriceListItem;


SET DATEFIRST 1;
DECLARE @StartDate DATE,
        @EndDate DATE,
        @CurrentDate DATETIME,
        @CurrentWeek INT,
        @Year INT;
SET @CurrentDate = GETDATE();                                   
SET @Year = YEAR(@CurrentDate);
SET @CurrentDate = CONVERT(DATETIME, CONVERT(NVARCHAR(8), @CurrentDate, 112) + ' 23:59:59');

SELECT @CurrentWeek = W
FROM [crmrevo].bi.Mst_Calendar_Week WITH (NOLOCK)
WHERE @CurrentDate
BETWEEN StartDate AND CONVERT(DATETIME, CONVERT(NVARCHAR(8), EndDate, 112) + ' 23:59:59');
IF @CurrentWeek = 0
    SET @CurrentWeek = 1;
SELECT @StartDate = StartDate,
       @EndDate = EndDate
FROM [crmrevo].bi.Mst_Calendar_Week WITH (NOLOCK)
WHERE W = @CurrentWeek
      AND @Year = Y;

SET @StartDate = CONVERT(DATETIME, CONVERT(NVARCHAR(8), @StartDate, 112) + ' 23:59:59');
SET @EndDate = CONVERT(NVARCHAR(8), @EndDate, 112);
--Select @StartDate,@EndDate
PRINT @CurrentDate;
PRINT @CurrentWeek;
PRINT @StartDate;
PRINT @EndDate;

SELECT u.id AS UnitID ,u.UnitNo,u.ProjectID,p.ProjectNo ,p.ProjectNameTH,ISNULL(t.TitledeedArea,u.SaleArea) Area
,'Assettype' = m.[Key]
INTO #TempArea
FROM [crmrevo].prj.Unit u  WITH (NOLOCK) 
INNER JOIN [crmrevo].mst.MasterCenter m WITH (NOLOCK) ON u.AssetTypeMasterCenterID = m.id  
LEFT JOIN [crmrevo].prj.TitledeedDetail t  WITH (NOLOCK) ON u.id = t.UnitID  AND t.IsDeleted = 0
LEFT JOIN [crmrevo].prj.Project p WITH (NOLOCK) ON u.ProjectID = p.id AND p.IsDeleted = 0
WHERE u.IsDeleted = 0   AND m.[Key] = '2'


SELECT DISTINCT a.ProjectCode,ProjectName,EmpCode,FullName,Email,PositionName
INTO #Tempvw_UserRoleProject
FROM [crmrevo].[dbo].[vw_UserRoleProject] a WITH (NOLOCK) 
INNER JOIN [crmrevo].prj.Project p WITH (NOLOCK) ON a.ProjectCode = p.ProjectNo
WHERE   (RoleCode IN ('LCM','VP_Sale','LC','HOCS','PM','VP_Marking') OR a.PositionName LIKE '%Marketing Strategist')
AND EmpCode NOT like 'Test%'
AND bu = 4 -- BG 3, 4  -- Modified by Suchat S. 2020-09-30
AND p.IsActive = 1
AND a.EmpCode NOT IN ('AP004259','AP004432','AP003541')-------------- เอาแนน กะพี่สุ ออก (มีเทสapp อื่น )
--and a.ProjectCode not in ('60002','60007','60016','10132')
and a.ProjectCode IN ('60021','70002','60010','60019','60015','60023','40052')  -- Modified by Suchat S. 2020-09-30
ORDER BY ProjectCode,PositionName 

SELECT a.*,m.[Key],m.[Name]
 INTO  #vw_UnitPrice 
 FROM [crmrevo].dbo.vw_UnitPrice a  With(NoLock)
 INNER JOIN [crmrevo].mst.MasterCenter m  With(NoLock) ON a.UnitPriceStageMasterCenterID = m.id 
 WHERE a.IsDeleted = 0


SELECT *
INTO #vw_CRM_Walk_1
FROM [crmrevo].dbo.[vw_CRM_Walk_1] WITH (NOLOCK)
WHERE Project IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )


SELECT c.*,p.ProjectNo
INTO #CRM_Opportunities
FROM [crmrevo].ctm.Opportunity c WITH (NOLOCK)
LEFT JOIN [crmrevo].prj.Project p  With(NoLock) ON c.ProjectID = p.id AND p.IsDeleted = 0
WHERE c.IsDeleted =0
AND p.ProjectNo IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )

SELECT *
INTO #CRM_Activity
FROM [crmrevo].ctm.RevisitActivity WITH (NOLOCK)
WHERE OpportunityID IN
      (
          SELECT ID FROM #CRM_Opportunities
      )
    AND IsDeleted = 0

SELECT  c.*,p.ProjectNo, p.ProjectNameTH 
INTO #CRM_Leads_Call
FROM [crmrevo].ctm.Lead c WITH (NOLOCK)
INNER JOIN [crmrevo].mst.MasterCenter m  WITH (NOLOCK) ON c.LeadTypeMasterCenterID = m.id 
LEFT JOIN [crmrevo].prj.Project p WITH (NOLOCK) ON c.ProjectID = p.id AND p.IsDeleted = 0
WHERE m.[Key] = 'c' AND c.callback = 1 AND c.IsDeleted = 0
AND p.ProjectNo IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )

SELECT c.*,p.ProjectNo, p.ProjectNameTH 
INTO #CRM_Leads_W
FROM [crmrevo].ctm.Lead c WITH (NOLOCK)
LEFT JOIN [crmrevo].prj.Project p WITH (NOLOCK) ON c.ProjectID = p.id AND p.IsDeleted = 0
WHERE Isnull(SubLeadType,'')in('REGISTER','RESALE','PRIVILEGE','READYTOMOVEIN','APPOINTMENT','Facebook','web','register+appointment','Facebook Lead Ad')
AND p.ProjectNo IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )

-------------------------------Agrement-----------------------------------------------------
SELECT a.*,t.Area,up.AgreementPrice,t.projectNo,t.UnitNo
INTO #ICON_EntForms_Agreement
FROM [crmrevo].sal.Agreement a WITH (NOLOCK)
--LEFT JOIN dbo.ICON_EntForms_AgreementOwner ao WITH (NOLOCK) ON a.ContractNumber = ao.ContractNumber
LEFT JOIN #TempArea t ON a.UnitID = t.UnitID
LEFT JOIN   #vw_UnitPrice  up ON up.BookingID = a.BookingID AND up.[Key] = '2'
WHERE  1=1 
AND a.IsCancel = 0 AND a.IsDeleted = 0
AND a.SignAgreementDate IS NOT NULL
AND t.ProjectNo  IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )

IF (OBJECT_ID('tempdb..#ICON_EntForms_AgreementSign') IS NOT NULL)   DROP TABLE #ICON_EntForms_AgreementSign;
SELECT a.*, t.Area,t.projectNo,t.UnitNo,u.AgreementPrice
INTO #ICON_EntForms_AgreementSign
FROM [crmrevo].sal.Agreement a WITH (NOLOCK)
--LEFT JOIN dbo.ICON_EntForms_AgreementOwner ao WITH (NOLOCK) ON a.ContractNumber = ao.ContractNumber
LEFT JOIN #TempArea t ON a.UnitID = t.UnitID
LEFT JOIN #vw_UnitPrice u ON a.BookingID = u.BookingID AND u.[Key] = '2'
WHERE  1=1 
AND a. IsCancel = 0 AND a.IsDeleted = 0
AND a.IsSignContractApproved = 1
AND t.ProjectNo  IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )

IF (OBJECT_ID('tempdb..#ICON_EntForms_Transfer') IS NOT NULL)   DROP TABLE #ICON_EntForms_Transfer;
SELECT t.ProjectNo AS ProductID,t.UnitNo AS UnitNumber,a.AgreementNo AS ContractNumber
,b.TransferNo AS TransferNumber,b.ActualTransferDate AS TransferDateApprove,
v.TotalPrice AS NetSalePrice,c.IsThaiNationality Nationality,t.Area
INTO #ICON_EntForms_Transfer
FROM #ICON_EntForms_Agreement a 
INNER JOIN  [crmrevo].sal.[Transfer] b WITH (NOLOCK) ON a.id = b.AgreementID
LEFT JOIN [crmrevo].sal.TransferOwner bo WITH (NOLOCK) ON b.id = bo.TransferID
LEFT JOIN #TempArea t ON a.UnitID = t.UnitID
LEFT JOIN #vw_UnitPrice v ON a.BookingID = v.BookingID 
LEFT JOIN [crmrevo].ctm.Contact c WITH (NOLOCK) ON bo.FromContactID = c.id AND c.IsDeleted = 0
WHERE b.ActualTransferDate IS NOT NULL
--AND a.TransferNumber = '60005CT9179692'
 AND bo.[Order] = 1 AND v.[Key] = '3'
AND ISNULL(bo.IsDeleted, 0) = 0 AND b.IsDeleted = 0


-----------------------------------------คนไทยต่างชาติ โอนสิทธิ์เปลี่ยนมือ-----------------------------------------------
IF (OBJECT_ID('tempdb..#ICON_EntForms_AgreementAO') IS NOT NULL)   DROP TABLE #ICON_EntForms_AgreementAO;
SELECT a.*, t.Area,ao.ContactNo AS ContactID
, 'Nationality' = CASE WHEN  ao.IsThaiNationality = 1 THEN 'T'ELSE 'F'END 
,ISNULL(u.AgreementPrice,0) SellingPrice
,t.ProjectNo AS ProductID,t.UnitNo AS UnitNumber,a.AgreementNo AS contractnumber 
INTO #ICON_EntForms_AgreementAO
FROM [crmrevo].sal.Agreement a WITH (NOLOCK)
LEFT JOIN [crmrevo].sal.AgreementOwner ao WITH (NOLOCK) ON a.id = ao.AgreementID AND ao.IsDeleted = 0
LEFT JOIN #TempArea t ON a.UnitID = t.UnitID
LEFT JOIN #vw_UnitPrice u ON a.BookingID = u.BookingID AND u.[Key] = '2'
--LEFT JOIN dbo.ICON_EntForms_Contacts c ON ao.ContactID = c.ContactID
WHERE 1=1 
AND a.IsCancel = 0 AND a.IsDeleted = 0
AND t.projectno  IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )

IF (OBJECT_ID('tempdb..#TempTrans') IS NOT NULL)   DROP TABLE #TempTrans;
SELECT c.*,a.AgreementNo,'Nationnality' = CASE WHEN o.IsThaiNationality = 1 THEN 'T'ELSE 'F' END 
--[dbo].[fn_GenCustChangeTransferNationality](o.ContactNo,a.AgreementNo) Nationnality
INTO #TempTrans
FROM [crmrevo].sal.ChangeAgreementOwnerWorkflow c WITH (NOLOCK)
INNER JOIN [crmrevo].mst.MasterCenter m WITH (NOLOCK) ON c.ChangeAgreementOwnerTypeMasterCenterID = m.id 
LEFT JOIN [crmrevo].sal.AgreementOwner o WITH (NOLOCK) ON o.AgreementID = c.AgreementID
LEFT JOIN [crmrevo].sal.Agreement a WITH (NOLOCK) ON c.AgreementID = a.id 
WHERE m.[Key] = '3'
AND c.IsDeleted = 0  AND c.IsApproved = 0

IF (OBJECT_ID('tempdb..#TempNationality') IS NOT NULL)   DROP TABLE #TempNationality;
SELECT a.ProductID,a.UnitNumber,a.ContractNumber,b.AgreementNo, ISNULL(SUM(a.SellingPrice), 0) Price,a.area
,'Nationality' = CASE WHEN a.ContractNumber = b.AgreementNo THEN b.Nationnality
		ELSE a.Nationality END 
INTO #TempNationality
FROM #ICON_EntForms_AgreementAO  a
LEFT JOIN #TempTrans b ON a.id = b.AgentID
WHERE a.SignAgreementDate IS NOT null
GROUP BY a.ContractNumber,b.AgreementNo, CASE WHEN a.ContractNumber = b.AgreementNo THEN b.Nationnality
		ELSE a.Nationality END ,area,a.ProductID,a.UnitNumber

		-----------------------------BOOK -----------------------------------------
SELECT t.projectno AS  ProductID,t.UnitNo AS UnitNumber,ISNULL(u.TotalPrice,0)AS TotalSellingPrice
,t.area ,a.SaleUserID,SaleOfficerTypeMasterCenterID,m.[Name],m.[Key] 
,'nationality' = CASE WHEN bo.IsThaiNationality = 1 THEN 'T'ELSE 'F' end
INTO #TempBookAll
FROM [crmrevo].sal.Booking a  WITH (NOLOCK)
LEFT JOIN [crmrevo].sal.BookingOwner bo WITH (NOLOCK) ON a.id = bo.BookingID
LEFT JOIN #vw_UnitPrice u ON a.id = u.BookingID AND u.[Key] = '1'
LEFT JOIN #TempArea t ON a.UnitID = t.UnitID
LEFT JOIN [crmrevo].mst.MasterCenter m  With(NoLock) ON m.id = a.SaleOfficerTypeMasterCenterID 
WHERE  bo.IsMainOwner = 1 AND a.IsDeleted = 0 AND bo.IsAgreementOwner = 0
AND ISNULL(bo.IsDeleted, 0) = 0
--AND ISNULL(bo.IsBooking, 0) = 1 
AND a.IsCancelled  = 0  
AND t.projectno IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )

-----------------------พื้นที่ทั้งหมด-----------------------------------
--SELECT ProductID,ISNULL(AreaFromPFB,AreaFromRE) area ,UnitNumber 
--INTO #TempArea
--FROM ICON_EntForms_Unit  WITH (NOLOCK)
--WHERE ProductID  IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )
--AND AssetType IN (2)
----WHERE ProductID = '60029'
--GROUP BY ProductID
IF (OBJECT_ID('tempdb..#TempAvail') IS NOT NULL)   DROP TABLE #TempAvail;
SELECT *
INTO #TempAvail
 FROM #TempArea a 
WHERE  a.Assettype= '2'
AND UnitNo NOT IN (SELECT b.UnitNumber FROM #TempBookAll b WHERE b.ProductID = a.ProjectNo )
AND  a.projectno IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )
ORDER BY a.ProjectNo

--------------------------------------UnitPriceList-----------------------------------
SELECT a.* 
INTO #TempPriceListItem
FROM [crmrevo].prj.PriceListItem a WITH (NOLOCK)
INNER JOIN [crmrevo].mst.MasterPriceItem m WITH (NOLOCK) ON a.MasterPriceItemID = m.id 
WHERE a.IsDeleted = 0 AND m.[Key] = 'SellingPrice'

IF (OBJECT_ID('tempdb..#TempICON_EntForms_UnitPriceList') IS NOT NULL)   DROP TABLE #TempICON_EntForms_UnitPriceList;
select isnull(t.Amount,0) TotalSellingPrice ,p.ProjectNo AS ProductID,u.UnitNo AS UnitNumber		
INTO #TempICON_EntForms_UnitPriceList			
from ( select UnitID,max(activedate)activedate FROM  [crmrevo].prj.PriceList  WITH (NOLOCK) group by UnitID) a 		
	inner join [crmrevo].prj.PriceList b WITH (NOLOCK) on a.activedate = b.activedate AND a.UnitID =b.UnitID
	LEFT JOIN #TempPriceListItem t ON t.PriceListID = b.ID
	LEFT JOIN [crmrevo].prj.Unit u  WITH (NOLOCK) ON u.id = a.UnitID
	LEFT JOIN [crmrevo].prj.Project p  WITH (NOLOCK) ON  p.id = u.projectid 
WHERE p.ProjectNo  IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )

--------------------------------------UnitAvaliable Cal Price---------------------
IF (OBJECT_ID('tempdb..#Temp_book') IS NOT NULL)   DROP TABLE #Temp_book;
SELECT a.UnitID,u.UnitNo AS UnitNumber ,p.ProjectNo AS productid 
INTO #Temp_book
FROM [crmrevo].sal.Booking a  WITH (NOLOCK)
LEFT JOIN [crmrevo].sal.BookingOwner bo WITH (NOLOCK) ON a.id = bo.BookingID
LEFT JOIN [crmrevo].prj.Unit u WITH (NOLOCK) ON a.UnitID = u.id 
LEFT JOIN [crmrevo].prj.Project p WITH (NOLOCK) ON a.ProjectID = p.id 
WHERE  bo.IsMainOwner =1 AND bo.IsAgreementOwner = 0
AND ISNULL(bo.IsDeleted, 0) = 0
AND a.IsCancelled = 0
AND p.ProjectNo IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )


--Modify by Suchat S. 2019-05-18
IF (OBJECT_ID('tempdb..#Temp_UnitPriceListAvaliable') IS NOT NULL)   DROP TABLE #Temp_UnitPriceListAvaliable;
SELECT p.ProjectNo AS ProductID, SUM(ISNULL(t.Amount,0))/1000000 AS TotalSellingPrice
INTO #Temp_UnitPriceListAvaliable
FROM
(
    SELECT 
           UnitID,
           MAX(ActiveDate) activedate
    FROM [crmrevo].prj.PriceList WITH (NOLOCK)
    GROUP BY UnitID
) a
    INNER JOIN [crmrevo].prj.PriceList b WITH (NOLOCK)
        ON a.activedate = b.ActiveDate
           AND a.unitid = b.UnitID
LEFT JOIN #TempPriceListItem t ON t.PriceListID = b.ID
LEFT JOIN [crmrevo].prj.Unit u  WITH (NOLOCK) ON u.id = a.UnitID
LEFT JOIN [crmrevo].prj.Project p  WITH (NOLOCK) ON  p.id = u.projectid          
WHERE p.ProjectNo IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )
AND a.unitid NOT IN (SELECT UnitID FROM #Temp_Book)
--AND p.ProjectNo = '60025'
GROUP BY p.ProjectNo

--------------------Target--------------------------------------
SELECT a.*,p.ProjectNo AS productID
INTO #TempTarget
FROM [crmrevo].bi.Mst_LeadIndicator_Target a WITH (NOLOCK)
LEFT JOIN [crmrevo].prj.Project p WITH (NOLOCK) ON a.ProjectID = p.id
WHERE RecType = 'Presales'
AND p.ProjectNo IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )

------------------------Gross-----------------
IF (OBJECT_ID('tempdb..#Temp_vwBook') IS NOT NULL)   DROP TABLE #Temp_vwBook;
SELECT a.* ,u.UnitNo,p.ProjectNo
INTO #Temp_vwBook
FROM dbo.[vw_RPTAP2_ExV4Booking_mail] a
LEFT JOIN [crmrevo].prj.Unit u WITH (NOLOCK) ON a.UnitID = u.id
LEFT JOIN [crmrevo].prj.Project p WITH (NOLOCK) ON p.id = a.ProjectID
WHERE p.ProjectNo  IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )

SELECT a.*, 'Nationality' = CASE WHEN bo.IsThaiNationality = 1 THEN 'T'ELSE 'F' END 
, t.area
INTO #vw_RPTAP2_ExV4Booking
FROM #Temp_vwBook a WITH (NOLOCK) 
LEFT JOIN [crmrevo].sal.BookingOwner bo WITH (NOLOCK) ON a.bookingID = bo.BookingID
LEFT JOIN #TempArea t ON a.unitID = t.UnitID 
WHERE 1=1
AND  t.projectNo  IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )
AND   bo.IsMainOwner = 1 AND bo.IsAgreementOwner = 0 
AND ISNULL(bo.IsDeleted, 0) = 0
--WHERE YEAR(BookingDate) = @Year;

------------------Cancel--------------------------------
IF (OBJECT_ID('tempdb..#Temp_vwCancel') IS NOT NULL)   DROP TABLE #Temp_vwCancel;
SELECT a.* ,u.UnitNo,p.ProjectNo
INTO #Temp_vwCancel
FROM [crmrevo].dbo.[vw_RPTAP2_ExV4BookingCancel_mail] a
LEFT JOIN [crmrevo].prj.unit u WITH (NOLOCK) ON a.unitid = u.id 
LEFT JOIN [crmrevo].prj.project p WITH (NOLOCK) ON a.projectid = p.id
WHERE p.ProjectNo  IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )

SELECT a.*, 'Nationality' = CASE WHEN bo.IsThaiNationality = 1 THEN 'T'ELSE 'F' END 
,t.area
INTO #vw_RPTAP2_ExV4BookingCancel
FROM  #Temp_vwCancel a WITH (NOLOCK)
LEFT JOIN [crmrevo].sal.BookingOwner bo WITH (NOLOCK) ON a.bookingID = bo.BookingID
LEFT JOIN #TempArea t ON a.unitId = t.UnitID
WHERE 1=1
AND  a.ProjectNo  IN (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )
AND   bo.IsMainOwner = 1 AND bo.IsAgreementOwner = 0
AND ISNULL(bo.IsDeleted , 0) = 0

-----------------------------------Cancel---------------------------------
SELECT COUNT(Bk.UnitID) UnitNumber,
       CancelDate,
		p.ProjectNo AS productid,
	  SUM( ISNULL(u.TotalPrice,0) ) AS BookingPrice_Cancel
       --SUM(((TotalSellingPrice + ISNULL(FurniturePrice, 0)) - ISNULL(CashDiscount, 0)) - ISNULL(B.TransferDiscount, 0)) AS BookingPrice_Cancel
--SUM(B.SellingPrice-Isnull(b.TransferDiscount,0)) AS BookingPrice_Cancel แก้ไข SellingPrice
INTO #TempCancel
FROM [crmrevo].sal.Booking Bk WITH (NOLOCK)
LEFT JOIN [crmrevo].dbo.vw_UnitPrice u  With(NoLock) ON bk.id = u.BookingID
INNER JOIN [crmrevo].mst.MasterCenter m  With(NoLock) ON u.UnitPriceStageMasterCenterID = m.id AND m.[Key] = '1'
LEFT JOIN [crmrevo].prj.Project p ON p.id = bk.ProjectID AND p.IsDeleted = 0
WHERE	ISNULL(BK.IsDeleted, 0) = 0
		AND ((BK.CancelDate IS NOT NULL) 
		AND (ISNULL(BK.CancelType, 0) IN (3, 1) 
		AND ISNULL(BK.IsFromChangeUnit, 0) = 0 
		OR ISNULL(BK.CancelType, 0) IN (3, 1) 
		AND ISNULL(BK.IsFromChangeUnit, 0) = 1))
      AND CancelDate <> '20130930'
AND p.ProjectNo IN   (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject )
GROUP BY p.ProjectNo,
         CancelDate;

---------------------------Offline------------------------------------- 
SELECT p.ProjectNo AS ProjectID,
       BookingDate,
       COUNT(b.UnitID) UnitNumber,
       --SUM((SellPrice - ISNULL(Discount, 0)) - ISNULL(b.TransferDiscount, 0)) AS BookingOfflinePrice_NotConfirm
	   SUM(ISNULL(up.TotalPrice,0)) AS BookingOfflinePrice_NotConfirm
INTO #ZTEMP_Booking
FROM [crmrevo].sal.Booking b WITH (NOLOCK)
INNER JOIN [crmrevo].mst.MasterCenter m WITH (NOLOCK) ON b.BookingStatusMasterCenterID = m.id
LEFT JOIN  #vw_UnitPrice up ON b.id = up.BookingID AND up.[Key] = '1'
LEFT JOIN [crmrevo].prj.Project p WITH (NOLOCK) ON b.ProjectID = p.id AND p.IsDeleted = 0
WHERE b.IsDeleted = 0 AND b.BookingNo IS NULL
      AND b.IsCancelled = 0 AND m.[Key] = '1' -----รอยืนยันจอง
      AND BookingDate <> '20130930'
	AND p.ProjectNo IN   (SELECT DISTINCT ProjectCode FROM #Tempvw_UserRoleProject ) 
GROUP BY p.ProjectNo,
         BookingDate;

----------------------------vw_RPTAP2_ExV4Booking-------------------
DECLARE @Booking TABLE
(
    TotalUnit INT,
    TotalPrice MONEY,
    ProjectID NVARCHAR(100),
    Ptype INT,
    bookingdate DATE	
);
INSERT INTO @Booking
(
    TotalUnit,
    TotalPrice,
    ProjectID,
    Ptype,
    bookingdate	
)
SELECT ISNULL(SUM(B.UnitAmt), 0) AS TotalUnit,
       ISNULL(SUM(B.BKPrice), 0) AS TotalPrice,
       b.ProjectNo AS Project,
       bg.BGNo AS PType,
       BookingDate	
FROM #vw_RPTAP2_ExV4Booking B
    LEFT JOIN [crmrevo].prj.Project p WITH (NOLOCK)  ON B.ProjectID = p.id AND p.IsDeleted = 0
	LEFT JOIN [crmrevo].mst.BG bg  With(NoLock) ON p.BGID = bg.id AND bg.IsDeleted = 0
WHERE 1 = 1 --and B.Project='10142'
      AND p.BGID IS NOT NULL	  
GROUP BY b.ProjectNo,
          bg.BGNo,
         BookingDate

Declare @BookingCancel Table (UnitAmt Int,BKPrice Money,Project nvarchar(100),CancelDate DATETIME)
	Insert Into @BookingCancel (UnitAmt,BKPrice,Project,CancelDate  )
	Select	ISNULL(SUM(B.UnitAmt),0) AS TotalUnit,ISNULL(Sum(B.BKPrice),0) AS TotalPrice,B.projectno AS  ProductID,CancelDate
	From	#vw_RPTAP2_ExV4BookingCancel B With(NoLock)
	Where	1=1 
	--	AND (Isnull(@Projects,'')='' Or B.Project In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
		--AND B.Project IN (SELECT ProductID FROM [dbo].[fn_GetProjectAuthorised](@UserName))
	GROUP BY B.projectno,CancelDate

---------------Thai %-------------
SELECT DISTINCT a.ProductID,
       a.UnitNumber,
       a.ContractNumber,
	 Nationality ,
       ISNULL(SUM(a.Price), 0) Price
	   ,area
INTO #TempBookThai
FROM #TempNationality a
WHERE 1=1
 AND  Nationality = 'T'
 GROUP BY a.ProductID,
       a.UnitNumber,
       a.ContractNumber,
	Nationality
	   ,area
	   ORDER BY a.ContractNumber  

IF (OBJECT_ID('tempdb..#TempThaiNotContract') IS NOT NULL) DROP TABLE #TempThaiNotContract;
SELECT a.ProductID,SUM(a.area)area
INTO #TempThaiNotContract
FROM #TempBookAll a
WHERE a.UnitNumber NOT IN (SELECT b.UnitNumber FROM #TempNationality b WHERE a.ProductID = b.ProductID)
AND a.nationality = 'T'
GROUP BY ProductID	   		  

---------------Thai unit_amount  -------------
IF (OBJECT_ID('tempdb..#TempThaiBook') IS NOT NULL) DROP TABLE #TempThaiBook;
IF (OBJECT_ID('tempdb..#TempThaiCancel') IS NOT NULL) DROP TABLE #TempThaiCancel;

SELECT ISNULL(SUM(UnitAmt), 0) AS TotalUnit,
       ISNULL(SUM(BKPrice), 0) AS TotalPrice,
	   ProjectNo AS project 
INTO #TempThaiBook
FROM #vw_RPTAP2_ExV4Booking
WHERE Nationality = 'T'
GROUP BY ProjectNo



SELECT ISNULL(SUM(UnitAmt), 0) AS TotalUnit,
       ISNULL(SUM(BKPrice), 0) AS TotalPrice,
	   ProjectNo project
INTO #TempThaiCancel
 FROM #vw_RPTAP2_ExV4BookingCancel
 WHERE Nationality = 'T'
 GROUP BY ProjectNo

 
 ---------------Foriegn unit_amount  -------------
 IF (OBJECT_ID('tempdb..#TempFQBook') IS NOT NULL) DROP TABLE #TempFQBook;
IF (OBJECT_ID('tempdb..#TempFQCancel') IS NOT NULL) DROP TABLE #TempFQCancel;
IF (OBJECT_ID('tempdb..#TempFQNotContract') IS NOT NULL) DROP TABLE #TempFQNotContract;
SELECT ISNULL(SUM(UnitAmt), 0) AS TotalUnit,
       ISNULL(SUM(BKPrice), 0) AS TotalPrice,
	  ProjectNo project
INTO #TempFQBook
FROM #vw_RPTAP2_ExV4Booking
WHERE Nationality = 'F'
GROUP BY ProjectNo

SELECT ISNULL(SUM(UnitAmt), 0) AS TotalUnit,
       ISNULL(SUM(BKPrice), 0) AS TotalPrice,
	   ProjectNo project
INTO #TempFQCancel
 FROM #vw_RPTAP2_ExV4BookingCancel
 WHERE Nationality = 'F'
 GROUP BY ProjectNo

 --------------Foriegn%-------------
SELECT DISTINCT a.ProductID,
       a.UnitNumber,
       a.ContractNumber,
	 Nationality ,
       ISNULL(SUM(a.Price), 0) Price
	   ,area
INTO #TempBookNoThai
FROM #TempNationality a
WHERE 1=1
 AND  Nationality = 'F'
 GROUP BY a.ProductID,
       a.UnitNumber,
       a.ContractNumber,
	Nationality
	   ,area
	   ORDER BY a.ContractNumber

SELECT a.ProductID,SUM(a.area)area
INTO #TempFQNotContract
FROM #TempBookAll a
WHERE a.UnitNumber NOT IN (SELECT b.UnitNumber FROM #TempNationality b WHERE a.ProductID = b.ProductID)
AND a.nationality = 'F'
GROUP BY ProductID


-------------------------------------Temp---------------------------------------------
IF (OBJECT_ID('tempdb..#TempToday') IS NOT NULL) DROP TABLE #TempToday;
SELECT ROW_NUMBER() OVER (ORDER BY t.ProjectNo ASC) rownum,
       t.ProjectNo AS ProductID,
       t.ProjectNameTH AS Project,
       'FirstWalk' = CONVERT(INT, 0),
       'ReVisit' = CONVERT(INT, 0),
       'Call' = CONVERT(INT, 0),
       'OnlineRegister' = CONVERT(INT, 0),
	   'FaceBook' = CONVERT(INT, 0),
       'Book_Unit' = CONVERT(INT, 0),
       'Book_Amount' = CONVERT(DECIMAL(18, 2), 0),
       'Cancel_Unit' = CONVERT(INT, 0),
       'Cancel_Amount' = CONVERT(DECIMAL(18, 2), 0),
       'Net_Unit' = CONVERT(INT, 0),
       'Net_Amount' = CONVERT(DECIMAL(18, 2), 0),
       'Contract_Unit' = CONVERT(INT, 0),
       'Contract_Amount' = CONVERT(DECIMAL(18, 2), 0),
	   'Trans_Unit' = CONVERT(INT, 0),
       'Trans_Amount' = CONVERT(DECIMAL(18, 2), 0),
	   'SignCon_Unit' = CONVERT(INT, 0),
       'SignCon_Amount' = CONVERT(DECIMAL(18, 2), 0)
INTO #TempToday
FROM [crmrevo].prj.Project t WITH (NOLOCK)
LEFT JOIN [crmrevo].mst.BG b WITH (NOLOCK) ON t.BGID = b.id AND b.IsDeleted = 0
WHERE 1=1
AND t.IsActive = 1 
AND t.IsDeleted = 0
AND t.ProjectNo IN (SELECT  ProjectNo FROM #TempArea )
AND t.ProjectNo IN (SELECT ProjectCode FROM #Tempvw_UserRoleProject )
AND b.BGNo = 4
AND t.ProjectNo IN ('60021','70002','60010','60019','60015','60023','40052') -- Modified by Suchat S. 2020-09-30



IF (OBJECT_ID('tempdb..#Temp') IS NOT NULL)
    DROP TABLE #Temp;
SELECT t.projectno AS  ProductID,
       t.ProjectNameTH AS Project,
	   'Area' = CONVERT(DECIMAL(18,2), ISNULL((SELECT SUM(area) FROM #TempArea a WHERE a.ProjectID = t.ID GROUP BY a.ProjectID ),0)),
	   'TotalUnit' = isnull((SELECT COUNT(a.UnitID) FROM #TempArea a WHERE a.ProjectID = t.ID  GROUP BY a.ProjectID),0),
       'FirstWalk_Week' = CONVERT(INT, 0),
       'FirstWalk_Month' = CONVERT(INT, 0),
       'ReVisit_Week' = CONVERT(INT, 0),
       'ReVisit_Month' = CONVERT(INT, 0),
       'Call_Week' = CONVERT(INT, 0),
       'Call_Month' = CONVERT(INT, 0),
       'Online Register_Week' = CONVERT(INT, 0),
       'Online Register_Month' = CONVERT(INT, 0),
	   'Facebook_week' = CONVERT(INT, 0),
       'Facebook_Month' = CONVERT(INT, 0),
       'Book_Unit_Week' = CONVERT(INT, 0),
       'Book_Unit_Month' = CONVERT(INT, 0),
       'Book_Amount_Week' = CONVERT(DECIMAL(18, 2), 0),
       'Book_Amount_Month' = CONVERT(DECIMAL(18, 2), 0),
       'Cancel_Unit_Week' = CONVERT(INT, 0),
       'Cancel_Unit_Month' = CONVERT(INT, 0),
       'Cancel_Amount_Week' = CONVERT(DECIMAL(18, 2), 0),
       'Cancel_Amount_Month' = CONVERT(DECIMAL(18, 2), 0),
       'Net_Unit_Week' = CONVERT(INT, 0),
       'Net_Unit_Month' = CONVERT(INT, 0),
       'Net_Amount_Week' = CONVERT(DECIMAL(18, 2), 0),
       'Net_Amount_Month' = CONVERT(DECIMAL(18, 2), 0),
       'Contract_Unit_Week' = CONVERT(INT, 0),
       'Contract_Unit_Month' = CONVERT(INT, 0),
       'Contract_Amount_Week' = CONVERT(DECIMAL(18, 2), 0),
       'Contract_Amount_Month' = CONVERT(DECIMAL(18, 2), 0),
	   'Trans_Unit_Week' = CONVERT(INT, 0),
       'Trans_Unit_Month' = CONVERT(INT, 0),
       'Trans_Amount_Week' = CONVERT(DECIMAL(18, 2), 0),
       'Trans_Amount_Month' = CONVERT(DECIMAL(18, 2), 0),
	   'Sign_Unit_Week' = CONVERT(INT, 0),
       'Sign_Unit_Month' = CONVERT(INT, 0),
       'Sign_Amount_Week' = CONVERT(DECIMAL(18, 2), 0),
       'Sign_Amount_Month' = CONVERT(DECIMAL(18, 2), 0),
       'TargetUnitBook_Week' = CONVERT(INT, 0),
       'TargetUnitBook_Month' = CONVERT(INT, 0),
       'TargetAmountBook_Week' = CONVERT(DECIMAL(18, 2), 0),
       'TargetAmountBook_Month' = CONVERT(DECIMAL(18, 2), 0),
       'LocalUnit' = CONVERT(INT, 0),
       'LocalAmount' = CONVERT(DECIMAL(18, 2), 0),
       'FQUnit' = CONVERT(INT, 0),
       'FQAmount' = CONVERT(DECIMAL(18, 2), 0),
       'TotalBook_Unit' = CONVERT(INT, 0),
       'TotalBook_Baht' = CONVERT(DECIMAL(18, 2), 0),
       'TotalContract_Unit' = CONVERT(INT, 0),
       'TotalContract_Baht' = CONVERT(DECIMAL(18, 2), 0),
	   'TotalTrans_Unit' = CONVERT(INT, 0),
       'TotalTrans_Baht' = CONVERT(DECIMAL(18, 2), 0),
	   'TotalBook_Percent' = CONVERT(DECIMAL(18, 2), 0),
	   'Local_Percent' = CONVERT(DECIMAL(18, 2), 0),
	   'FQ_Percent' = CONVERT(DECIMAL(18, 2), 0),
	   'TotalContract_Percent' = CONVERT(DECIMAL(18, 2), 0),
	   'TotalTrans_Percent' = CONVERT(DECIMAL(18, 2), 0),
	   'TotalSign_Unit' = CONVERT(INT, 0),
       'TotalSign_Baht' = CONVERT(DECIMAL(18, 2), 0),
	   'TotalSign_Percent' = CONVERT(DECIMAL(18, 2), 0),
	   'Agent_Unit' = CONVERT(INT, 0),
	   'Agent_Baht' = CONVERT(DECIMAL(18, 2), 0),
	   'Agent_Percent' = CONVERT(DECIMAL(18, 2), 0),
	   'Avail_Unit' = CONVERT(INT, 0),
	   'Avail_Baht' = CONVERT(DECIMAL(18, 2), 0),
	   'Avail_Percent' = CONVERT(DECIMAL(18, 2), 0)
INTO #temp
FROM [crmrevo].prj.Project t WITH (NOLOCK)
--LEFT JOIN mst.BG b WITH (NOLOCK) ON t.BGID = b.id AND b.IsDeleted = 0
WHERE 1=1
AND t.IsActive = 1 
AND t.IsDeleted = 0
AND t.ProjectNo IN (SELECT  ProjectNo FROM #TempArea )
AND t.ProjectNo IN (SELECT ProjectCode FROM #Tempvw_UserRoleProject )

------------------------------------Update---------------------------------------
UPDATE #TempToday
SET FirstWalk = ISNULL(
                (
                    SELECT SUM(WalkAmt)
                    FROM
                    (
                        SELECT Project,
                               ContactNo,
                               MIN(CreateDate) CreateDate,
                               1 WalkAmt
                        FROM #vw_CRM_Walk_1
                        GROUP BY Project,
                                 ContactNo
                    ) v
                    WHERE v.CreateDate <> '20130930'
                          AND dbo.fn_ClearTime(v.CreateDate) = dbo.fn_ClearTime(@CurrentDate)
                          AND v.Project = t.ProductID
                    GROUP BY Project
                ),
                0
                      ),
    ReVisit = ISNULL(
              (
                  SELECT COUNT(ta.id)
                  FROM #CRM_Opportunities TA
                      LEFT OUTER JOIN #CRM_Activity AC
                          ON TA.id = AC.OpportunityID --AND AC.IDActRunning = A.IDActRunning
                  WHERE 1=1
				  AND  dbo.fn_ClearTime(ISNULL(AC.Updated, AC.Created)) <> '20130930'
                        AND dbo.fn_ClearTime(AC.ActualDate) = dbo.fn_ClearTime(@CurrentDate)
                        --and isnull(ac.statusid,'')<>0 (-1 ยกเลิก, 0 ปกติ, 1 complete )
                        AND TA.ProjectNo = t.ProductID
                      --  AND ISNULL(AC.StatusID, 0) <> -1
                  GROUP BY TA.ProjectNo
              ),
              0
                    ),
    [Call] = ISNULL(
    (
        SELECT COUNT(a.id)
        FROM #CRM_Leads_Call a
        WHERE a.ProjectNo = t.ProductID
              AND dbo.fn_ClearTime(a.LeadDate) = dbo.fn_ClearTime(@CurrentDate)
    ),0),
    OnlineRegister = ISNULL(
    (
        SELECT COUNT(a.ID)
        FROM #CRM_Leads_W a
        WHERE a.ProjectNo = t.ProductID
		AND a.SubLeadType NOT LIKE 'Facebook%'
              AND dbo.fn_ClearTime(a.LeadDate) = dbo.fn_ClearTime(@CurrentDate)
),0),
FaceBook = ISNULL(
    (
        SELECT COUNT(a.ID)
        FROM #CRM_Leads_W a
        WHERE a.ProjectNo = t.ProductID
		AND a.SubLeadType in ('Facebook','Facebook Lead Ad')
              AND dbo.fn_ClearTime(a.LeadDate) = dbo.fn_ClearTime(@CurrentDate)
    ),0),
    Book_Unit = ISNULL(
                (
                    SELECT SUM(TotalUnit)
                    FROM @Booking b
                    WHERE bookingdate = dbo.fn_ClearTime(@CurrentDate)
                          AND b.ProjectID = t.ProductID
                ),
                0
                      ),
    Book_Amount = ISNULL(
                  (
                      SELECT SUM(TotalPrice)
                      FROM @Booking b
                      WHERE bookingdate = dbo.fn_ClearTime(@CurrentDate)
                            AND b.ProjectID = t.ProductID
                  ),
                  0
                        ) / 1000000,
    Cancel_Unit = ISNULL(
                  (
                      SELECT COUNT(UnitNumber)
                      FROM #TempCancel b
                      WHERE dbo.fn_ClearTime(CancelDate) = dbo.fn_ClearTime(@CurrentDate)
                            AND b.ProductID = t.ProductID
                      GROUP BY b.ProductID
                  ),
                  0
                        ),
    Cancel_Amount = ISNULL(
                    (
                        SELECT SUM(BookingPrice_Cancel)
                        FROM #TempCancel b
                        WHERE dbo.fn_ClearTime(CancelDate) = dbo.fn_ClearTime(@CurrentDate)
                              AND b.ProductID = t.ProductID
                        GROUP BY b.ProductID
                    ),
                    0
                          ) / 1000000,
			 Net_Unit = ISNULL(
               (
                   SELECT SUM(TotalUnit)
                   FROM @Booking b
                   WHERE bookingdate = dbo.fn_ClearTime(@CurrentDate)
                         AND b.ProjectID = t.ProductID
               ),
               0
                     ) - ISNULL(
                         (
                             SELECT COUNT(UnitNumber)
                             FROM #TempCancel b
                             WHERE dbo.fn_ClearTime(CancelDate) = dbo.fn_ClearTime(@CurrentDate)
                                   AND b.ProductID = t.ProductID
                             GROUP BY b.ProductID
                         ),
                         0),
                             
    Net_Amount = (ISNULL(
                 (
                     SELECT SUM(TotalPrice)
                     FROM @Booking b
                     WHERE bookingdate = dbo.fn_ClearTime(@CurrentDate)
                           AND b.ProjectID = t.ProductID
                 ),
                 0
                       ) - ISNULL(
                           (
                               SELECT SUM(b.BookingPrice_Cancel)
                               FROM #TempCancel b
                               WHERE dbo.fn_ClearTime(CancelDate) = dbo.fn_ClearTime(@CurrentDate)
                                     AND b.ProductID = t.ProductID
                               GROUP BY b.ProductID
                           ),
                           0
                                 ) )/1000000,
    Contract_Unit = ISNULL(
                    (
                        SELECT COUNT(DISTINCT a.Unitno)
                        FROM #ICON_EntForms_Agreement a 
                        WHERE a.ProjectNo = t.ProductID
                              AND dbo.fn_ClearTime(a.SignContractApprovedDate) = dbo.fn_ClearTime(@CurrentDate)
                        GROUP BY a.ProjectID
                    ),0
                          ),
    Contract_Amount = (ISNULL(
                      (
                          SELECT SUM(a.AgreementPrice)
                          FROM #ICON_EntForms_Agreement a  WITH (NOLOCK) 
                          WHERE a.ProjectNo = t.ProductID
                                AND dbo.fn_ClearTime(a.SignContractApprovedDate) = dbo.fn_ClearTime(@CurrentDate)
                          GROUP BY a.ProjectID
                      ),
                      0
                            ))/1000000,
		Trans_Unit = ISNULL(
                    (
                         SELECT COUNT(DISTINCT a.UnitNumber)
                          FROM #ICON_EntForms_Transfer a  WITH (NOLOCK) 
                          WHERE a.ProductID = t.ProductID
                                AND dbo.fn_ClearTime(a.TransferDateApprove) = dbo.fn_ClearTime(@CurrentDate)
                          GROUP BY a.ProductID
                    ),
                    0),
		Trans_Amount = (ISNULL(
                      (
                          SELECT SUM(a.NetSalePrice)
                          FROM #ICON_EntForms_Transfer a  WITH (NOLOCK) 
                          WHERE a.ProductID = t.ProductID
                                AND dbo.fn_ClearTime(a.TransferDateApprove) = dbo.fn_ClearTime(@CurrentDate)
                          GROUP BY a.ProductID
                      ),
                      0
                            ))/1000000,
	SignCon_Unit = ISNULL(
                    (
                        SELECT COUNT(DISTINCT a.unitno)
                        FROM #ICON_EntForms_AgreementSign a 
                        WHERE a.projectNo = t.ProductID
                              AND dbo.fn_ClearTime(a.SignContractApprovedDate) = dbo.fn_ClearTime(@CurrentDate)
                        GROUP BY a.ProjectID
                    ),
                    0
                          ),
    SignCon_Amount = (ISNULL(
                      (
                          SELECT SUM(a.AgreementPrice)
                          FROM #ICON_EntForms_Agreement a 
                          WHERE a.projectNo = t.ProductID
                                AND dbo.fn_ClearTime(a.SignContractApprovedDate) = dbo.fn_ClearTime(@CurrentDate)
                          GROUP BY a.ProjectID
                      ),
                      0
                            ))/1000000

                      
FROM #TempToday t

UPDATE #temp
SET FirstWalk_Week = ISNULL(
                     (
                         SELECT SUM(WalkAmt)
                         FROM
                         (
                             SELECT Project,
                                    ContactNo,
                                    MIN(CreateDate) CreateDate,
                                    1 WalkAmt
                             FROM #vw_CRM_Walk_1
                             GROUP BY Project,
                                      ContactNo
                         ) v
                         WHERE v.CreateDate <> '20130930'
                               AND dbo.fn_ClearTime(v.CreateDate)
                               BETWEEN @StartDate AND @EndDate
                               AND v.Project = t.ProductID
                         GROUP BY Project
                     ),
                     0
                           ),
						   
    FirstWalk_Month = ISNULL(
                      (
                          SELECT SUM(WalkAmt)
                          FROM
                          (
                              SELECT Project,
                                     ContactNo,
                                     MIN(CreateDate) CreateDate,
                                     1 WalkAmt
                              FROM #vw_CRM_Walk_1
                              GROUP BY Project,
                                       ContactNo
                          ) v
                          WHERE v.CreateDate <> '20130930'
                                AND MONTH(v.CreateDate) = MONTH(@CurrentDate)
								AND Year(v.CreateDate) = Year(@CurrentDate)
                                AND v.Project = t.ProductID
                          GROUP BY Project
                      ),
                      0
                            ),
    ReVisit_Week = ISNULL(
                   (
                       SELECT COUNT(*)
                       FROM #CRM_Opportunities TA
                           LEFT OUTER JOIN #CRM_Activity AC
                               ON TA.id = AC.OpportunityID --AND AC.IDActRunning = A.IDActRunning
                       WHERE dbo.fn_ClearTime(ISNULL(AC.Updated, AC.Created)) <> '20130930'
                             AND dbo.fn_ClearTime(AC.ActualDate)
                             BETWEEN @StartDate AND @EndDate
                             --and isnull(ac.statusid,'')<>0 (-1 ยกเลิก, 0 ปกติ, 1 complete )
                             AND TA.projectno = t.ProductID
                            -- AND ISNULL(AC.StatusID, 0) <> -1
                       GROUP BY TA.ProjectID
                   ),
                   0
                         ),
	  ReVisit_Month = ISNULL(
                    (
                        SELECT COUNT(*)
                        FROM #CRM_Opportunities TA
                            LEFT OUTER JOIN #CRM_Activity AC
                                ON TA.id = AC.OpportunityID --AND AC.IDActRunning = A.IDActRunning
                        WHERE dbo.fn_ClearTime(ISNULL(AC.Updated, AC.Created)) <> '20130930'
                              AND MONTH(AC.ActualDate) = MONTH(@CurrentDate)
							   AND Year(AC.ActualDate) = Year(@CurrentDate)
                              AND TA.projectno = t.ProductID
                             -- AND ISNULL(AC.StatusID, 0) <> -1
                        GROUP BY TA.ProjectID
                    ),
                    0
                          ),
		 Call_Week = ISNULL(
                (
                    SELECT COUNT(a.ID)
                    FROM #CRM_Leads_Call a
                    WHERE a.projectno = t.ProductID
                          AND dbo.fn_ClearTime(a.LeadDate)
                          BETWEEN @StartDate AND @EndDate
                ),
                0
                      ),
			 Call_Month = ISNULL(
                 (
                     SELECT COUNT(a.ID)
                     FROM #CRM_Leads_Call a
                     WHERE a.ProjectNo = t.ProductID
                           AND MONTH(a.LeadDate) = MONTH(@CurrentDate)
						   AND Year(a.LeadDate) = Year(@CurrentDate)
                 ),
                 0
                       ),
 [Online Register_Week] = ISNULL(
                             (
                                 SELECT COUNT(a.ID)
                                 FROM #CRM_Leads_W a
                                 WHERE a.ProjectNo = t.ProductID
										AND a.SubLeadType NOT LIKE 'Facebook%'
                                       AND dbo.fn_ClearTime(a.LeadDate)
                                       BETWEEN @StartDate AND @EndDate
                             ),
                             0
                                   ),
	 [Online Register_Month] = ISNULL(
                              (
                                  SELECT COUNT(a.ID)
                                  FROM #CRM_Leads_W a
                                  WHERE a.ProjectNo = t.ProductID
										AND a.SubLeadType NOT LIKE 'Facebook%'
                                        AND MONTH(a.LeadDate) = MONTH(@CurrentDate)
										AND Year(a.LeadDate) = Year(@CurrentDate)
                              ),
                              0
                                    ),
	[Facebook_week] = ISNULL(
                             (
                                 SELECT COUNT(a.ID)
                                 FROM #CRM_Leads_W a
                                 WHERE a.ProjectNo = t.ProductID
										AND a.SubLeadType IN( 'Facebook','Facebook Lead Ad')
                                       AND dbo.fn_ClearTime(a.LeadDate)
                                       BETWEEN @StartDate AND @EndDate
                             ),
                             0
                                   ),
	[Facebook_Month] = ISNULL(
                              (
                                  SELECT COUNT(a.ID)
                                  FROM #CRM_Leads_W a
                                  WHERE a.ProjectNo = t.ProductID
										AND a.SubLeadType IN( 'Facebook','Facebook Lead Ad')
                                        AND MONTH(a.LeadDate) = MONTH(@CurrentDate)
										AND Year(a.LeadDate) = Year(@CurrentDate)
                              ),
                              0
                                    ),
		Book_Unit_Week = ISNULL(
                     (
                         SELECT SUM(TotalUnit)
                         FROM @Booking b
                         WHERE bookingdate
                               BETWEEN @StartDate AND @EndDate
                               AND b.ProjectID = t.ProductID
                     ),
                     0
                           ),
		Book_Unit_Month = ISNULL(
                      (
                          SELECT SUM(TotalUnit)
                          FROM @Booking b
                          WHERE MONTH(bookingdate) = MONTH(@CurrentDate)
								AND year(bookingdate) = year(@CurrentDate)
                                AND b.ProjectID = t.ProductID
                      ),
                      0
                            ) ,
		 Book_Amount_Week = ISNULL(
                       (
                           SELECT SUM(TotalPrice)
                           FROM @Booking b
                           WHERE bookingdate
                                 BETWEEN @StartDate AND @EndDate
                                 AND b.ProjectID = t.ProductID
                       ),
                       0
                             ) / 1000000,
	 Book_Amount_Month = ISNULL(
                        (
                            SELECT SUM(TotalPrice)
                            FROM @Booking b
                            WHERE MONTH(bookingdate) = MONTH(@CurrentDate)
								AND year(bookingdate) = year(@CurrentDate)
                                  AND b.ProjectID = t.ProductID
                        ),
                        0
                              ) / 1000000,
	Cancel_Unit_Week = ISNULL(
                       (
                           SELECT COUNT(UnitNumber)
                           FROM #TempCancel b
                           WHERE dbo.fn_ClearTime(CancelDate)
                                 BETWEEN @StartDate AND @EndDate
                                 AND b.ProductID = t.ProductID
                           GROUP BY b.ProductID
                       ),
                       0
                             ),
	 Cancel_Unit_Month = ISNULL(
                        (
                            SELECT COUNT(UnitNumber)
                            FROM #TempCancel b
                            WHERE MONTH(CancelDate) = MONTH(@CurrentDate)
								AND year(CancelDate) = year(@CurrentDate)
                                  AND b.ProductID = t.ProductID
                            GROUP BY b.ProductID
                        ),
                        0
                              ),
	 Cancel_Amount_Week = ISNULL(
                         (
                             SELECT SUM(BookingPrice_Cancel)
                             FROM #TempCancel b
                             WHERE dbo.fn_ClearTime(CancelDate)
                                   BETWEEN @StartDate AND @EndDate
                                   AND b.ProductID = t.ProductID
                             GROUP BY b.ProductID
                         ),
                         0
                               ) / 1000000,
	    Cancel_Amount_Month = ISNULL(
                          (
                              SELECT SUM(BookingPrice_Cancel)
                              FROM #TempCancel b
                              WHERE MONTH(CancelDate) = MONTH(@CurrentDate)
								AND year(CancelDate) = year(@CurrentDate)
                                    AND b.ProductID = t.ProductID
                              GROUP BY b.ProductID
                          ),
                          0
                                ) / 1000000,
		 Net_Unit_Week = ISNULL(
                    (
                        SELECT SUM(TotalUnit)
                        FROM @Booking b
                        WHERE bookingdate
                              BETWEEN @StartDate AND @EndDate
                              AND b.ProjectID = t.ProductID
                    ),
                    0
                          ) - ISNULL(
                              (
                                  SELECT COUNT(UnitNumber)
                                  FROM #TempCancel b
                                  WHERE dbo.fn_ClearTime(CancelDate)
                                        BETWEEN @StartDate AND @EndDate
                                        AND b.ProductID = t.ProductID
                                  GROUP BY b.ProductID
                              ),
                              0
                                    ) ,
	Net_Unit_Month = ISNULL(
                     (
                         SELECT SUM(TotalUnit)
                         FROM @Booking b
                         WHERE MONTH(bookingdate) = MONTH(@CurrentDate)
							AND  year(bookingdate) = year(@CurrentDate)
                               AND b.ProjectID = t.ProductID
                     ),
                     0
                           ) - ISNULL(
                               (
                                   SELECT COUNT(UnitNumber)
                                   FROM #TempCancel b
                                   WHERE MONTH(CancelDate) = MONTH(@CurrentDate)
									AND year(CancelDate) = year(@CurrentDate)
                                         AND b.ProductID = t.ProductID
                                   GROUP BY b.ProductID
                               ),
                               0
                                     ) ,
		 Net_Amount_Week = ISNULL(
                      (
                          SELECT SUM(b.TotalPrice)
                          FROM @Booking b
                          WHERE bookingdate
                                BETWEEN @StartDate AND @EndDate
                                AND b.ProjectID = t.ProductID
                      ),
                      0
                            ) / 1000000 - ISNULL(
                                          (
                                              SELECT SUM(b.BookingPrice_Cancel)
                                              FROM #TempCancel b
                                              WHERE dbo.fn_ClearTime(CancelDate)
                                                    BETWEEN @StartDate AND @EndDate
                                                    AND b.ProductID = t.ProductID
                                              GROUP BY b.ProductID
                                          ),
                                          0
                                                ) / 1000000,
	Net_Amount_Month = ISNULL(
                       (
                           SELECT SUM(b.TotalPrice)
                           FROM @Booking b
                           WHERE MONTH(bookingdate) = MONTH(@CurrentDate)
						   AND year(bookingdate) = year(@CurrentDate)
                                 AND b.ProjectID = t.ProductID
								 GROUP BY b.ProjectID
                       ),
                       0
                             ) / 1000000 - ISNULL(
                                           (
                                               SELECT sum(b.BookingPrice_Cancel)
                                               FROM #TempCancel b
                                               WHERE MONTH(CancelDate) = MONTH(@CurrentDate)
													AND year(CancelDate) = year(@CurrentDate)
                                                     AND b.ProductID = t.ProductID
                                               GROUP BY b.ProductID
                                           ),
                                           0
                                                 ) / 1000000 ,
		 Contract_Unit_Week = ISNULL(
                         (
                             SELECT COUNT(DISTINCT a.UnitNo)
                             FROM #ICON_EntForms_Agreement a WITH (NOLOCK)
                             WHERE a.ProjectNo = t.ProductID
                                   AND dbo.fn_ClearTime(a.SignAgreementDate)
                                   BETWEEN @StartDate AND @EndDate
                             GROUP BY a.ProjectID
                         ),
                         0
                               ),
		 Contract_Unit_Month = ISNULL(
                          (
                              SELECT COUNT(DISTINCT a.UnitNo)
                              FROM #ICON_EntForms_Agreement a WITH (NOLOCK)
                              WHERE a.ProjectNo = t.ProductID
                                    AND MONTH(a.SignAgreementDate) = MONTH(@CurrentDate)
									AND year(a.SignAgreementDate) = year(@CurrentDate)
                              GROUP BY a.ProjectID
                          ),
                          0
                                ),
		 Contract_Amount_Week = ISNULL(
                           (
                               SELECT SUM(a.AgreementPrice)
                               FROM #ICON_EntForms_Agreement a WITH (NOLOCK)
                               WHERE a.ProjectNo = t.ProductID
                                     AND dbo.fn_ClearTime(a.SignAgreementDate)
                                     BETWEEN @StartDate AND @EndDate
                               GROUP BY a.ProjectID
                           ),
                           0
                                 ) / 1000000,
		    Contract_Amount_Month = ISNULL(
                            (
                                SELECT SUM(a.AgreementPrice)
                                FROM #ICON_EntForms_Agreement a WITH (NOLOCK)
                                WHERE a.ProJectNo = t.ProductID
                                      AND MONTH(a.SignAgreementDate) = MONTH(@CurrentDate)
									  AND year(a.SignAgreementDate) = year(@CurrentDate)
                                GROUP BY a.ProjectID
                            ),
                            0
                                  ) / 1000000,
		TargetUnitBook_Week = ISNULL(
                          (
                              SELECT SUM(ISNULL(a.Unit, 0))
                              FROM #TempTarget a
                              WHERE a.ProductID = t.ProductID
                                    AND W = @CurrentWeek
									AND y =  Year(@CurrentDate)
                          ),
                          0
                                ),
		 TargetUnitBook_Month = ISNULL(
                           (
                               SELECT SUM(ISNULL(a.Unit, 0))
                               FROM #TempTarget a
                               WHERE a.ProductID = t.ProductID
                                     AND M = MONTH(@CurrentDate)
									 AND Y = Year(@CurrentDate)
                           ),
                           0
                                 ),
	TargetAmountBook_Week = ISNULL(
                            (
                                SELECT SUM(ISNULL(a.Amount, 0))
                                FROM #TempTarget a
                                WHERE a.ProductID = t.ProductID
                                      AND W = @CurrentWeek
									  AND y =  Year(@CurrentDate)
                            ),
                            0
                                  ) / 1000000,
	 TargetAmountBook_Month = ISNULL(
                             (
                                 SELECT SUM(ISNULL(a.Amount, 0))
                                 FROM #TempTarget a
                                 WHERE a.ProductID = t.ProductID
                                       AND M = MONTH(@CurrentDate)
									    AND y =  Year(@CurrentDate)
                             ),
                             0
                                   ) / 1000000,
		Trans_Unit_Week = ISNULL(
                         (
                             SELECT COUNT(DISTINCT a.UnitNumber)
                             FROM #ICON_EntForms_Transfer a WITH (NOLOCK)
                             WHERE a.ProductID = t.ProductID
                                   AND dbo.fn_ClearTime(a.TransferDateApprove)
                                   BETWEEN @StartDate AND @EndDate
                             GROUP BY a.ProductID
                         ),
                         0
                               ),
	 Trans_Unit_Month = ISNULL(
                          (
                              SELECT COUNT(DISTINCT a.UnitNumber)
                              FROM #ICON_EntForms_Transfer a WITH (NOLOCK)
                              WHERE a.ProductID = t.ProductID
                                    AND MONTH(a.TransferDateApprove) = MONTH(@CurrentDate)
									AND year(a.TransferDateApprove) = year(@CurrentDate)
                              GROUP BY a.ProductID
                          ),
                          0
                                ),
		 Trans_Amount_Week = ISNULL(
                           (
                               SELECT SUM(a.NetSalePrice)
                               FROM #ICON_EntForms_Transfer a WITH (NOLOCK)
                               WHERE a.ProductID = t.ProductID
                                     AND dbo.fn_ClearTime(a.TransferDateApprove)
                                     BETWEEN @StartDate AND @EndDate
                               GROUP BY a.ProductID
                           ),
                           0
                                 ) / 1000000,
			Trans_Amount_Month = ISNULL(
                            (
                                SELECT SUM(a.NetSalePrice)
                                FROM #ICON_EntForms_Transfer a WITH (NOLOCK)
                                WHERE a.ProductID = t.ProductID
                                      AND MONTH(a.TransferDateApprove) = MONTH(@CurrentDate)
									  AND year(a.TransferDateApprove) = year(@CurrentDate)
                                GROUP BY a.ProductID
                            ),
                            0
                                  ) / 1000000,
	Sign_Unit_Week = ISNULL(
                         (
                             SELECT COUNT(DISTINCT a.UnitNo)
                             FROM #ICON_EntForms_AgreementSign a WITH (NOLOCK)
                             WHERE a.ProjectNo = t.ProductID
                                   AND dbo.fn_ClearTime(a.SignContractApprovedDate)
                                   BETWEEN @StartDate AND @EndDate
                             GROUP BY a.ProjectID
                         ),
                         0
                               ),
		Sign_Unit_Month = ISNULL(
                          (
                              SELECT COUNT(DISTINCT a.unitNO)
                              FROM #ICON_EntForms_AgreementSign a WITH (NOLOCK)
                              WHERE a.ProjectNo = t.ProductID
                                    AND MONTH(a.SignContractApprovedDate) = MONTH(@CurrentDate)
									AND year(a.SignContractApprovedDate) = year(@CurrentDate)
                              GROUP BY a.ProjectID
                          ),
                          0
                                ),
	 Sign_Amount_Week = ISNULL(
                           (
                               SELECT SUM(a.AgreementPrice)
                               FROM #ICON_EntForms_AgreementSign a WITH (NOLOCK)
                               WHERE a.ProjectNo = t.ProductID
                                     AND dbo.fn_ClearTime(a.SignContractApprovedDate)
                                     BETWEEN @StartDate AND @EndDate
                               GROUP BY a.ProjectID
                           ),
                           0
                                 ) / 1000000,
		 Sign_Amount_Month = ISNULL(
                            (
                                SELECT SUM(a.AgreementPrice)
                                FROM #ICON_EntForms_AgreementSign a WITH (NOLOCK)
                                WHERE a.ProjectNo = t.ProductID
                                      AND MONTH(a.SignContractApprovedDate) = MONTH(@CurrentDate)
									  AND year(a.SignContractApprovedDate) = year(@CurrentDate)
                                GROUP BY a.ProjectID
                            ),
                            0
                                  ) / 1000000,
		LocalUnit =(
                        ISNULL((SELECT SUM(b.TotalUnit) FROM #TempThaiBook b WHERE b.project = t.ProductID),0)
						-
						ISNULL((SELECT SUM(c.TotalUnit) FROM #TempThaiCancel c WHERE c.Project = t.ProductID),0)
                      ),
		 LocalAmount = (
                         ISNULL((SELECT SUM(b.TotalPrice) FROM #TempThaiBook b WHERE b.Project = t.ProductID),0)/1000000
						 -
						  ISNULL((SELECT SUM(c.TotalPrice) FROM #TempThaiCancel c WHERE c.Project = t.ProductID),0)/1000000
                    
                       ) ,
		 FQUnit = (
                        ISNULL((SELECT SUM(b.TotalUnit) FROM #TempFQBook b WHERE b.project = t.ProductID),0)
						-
						ISNULL((SELECT SUM(c.TotalUnit) FROM #TempFQCancel c WHERE c.Project = t.ProductID),0)
                      ),
    FQAmount = (
                         ISNULL((SELECT SUM(b.TotalPrice) FROM #TempFQBook b WHERE b.Project = t.ProductID),0)/1000000
						 -
						  ISNULL((SELECT SUM(c.TotalPrice) FROM #TempFQCancel c WHERE c.Project = t.ProductID),0)/1000000
                    
                       ) ,
	 TotalBook_Unit = 
                     (
                        ISNULL((SELECT SUM(b.TotalUnit) FROM @Booking b WHERE b.ProjectID = t.ProductID),0)
						-
						ISNULL((SELECT SUM(c.UnitAmt) FROM @BookingCancel c WHERE c.Project = t.ProductID),0)
                      ),
    TotalBook_Baht =
                     (
                         ISNULL((SELECT SUM(b.TotalPrice) FROM @Booking b WHERE b.ProjectID = t.ProductID),0)/1000000
						 -
						  ISNULL((SELECT SUM(c.BKPrice) FROM @BookingCancel c WHERE c.Project = t.ProductID),0)/1000000
                    
                       ) ,
	totalContract_Unit = ISNULL(
                         (
                             SELECT count( b.unitNo) FROM #ICON_EntForms_Agreement b  WHERE b.ProjectNo = t.ProductID
                         ),
                         0
                               ),
    TotalContract_Baht = ISNULL(
                         (
                             SELECT SUM( b.AgreementPrice) FROM #ICON_EntForms_Agreement b  WHERE b.ProjectNo = t.ProductID
                         ),
                         0
                               ) / 1000000,
		TotalTrans_Unit = ISNULL(
                         (
                             SELECT count( b.UnitNumber) FROM #ICON_EntForms_Transfer b  WHERE b.ProductID = t.ProductID
                         ),
                         0
                               ),
    TotalTrans_Baht = ISNULL(
                         (
                             SELECT SUM( b.NetSalePrice) FROM #ICON_EntForms_Transfer b  WHERE b.ProductID = t.ProductID
                         ),
                         0
                               ) / 1000000,
	TotalSign_Unit = ISNULL(
                         (
                             SELECT count( b.UnitNo) FROM #ICON_EntForms_AgreementSign b  WHERE b.ProjectNo = t.ProductID
                         ),
                         0
                               ),
    TotalSign_Baht = ISNULL(
                         (
                             SELECT SUM( b.AgreementPrice) FROM #ICON_EntForms_AgreementSign b  WHERE b.ProjectNo = t.ProductID
                         ),
                         0
                               ) / 1000000
	,Local_Percent		= ( 
							ISNULL((SELECT CASE WHEN ISNULL(t.Area,0)=0 THEN 0 ELSE (SUM(a.area)/t.area)*100 END 
									FROM #TempBookThai a WHERE a.ProductID = t.ProductID),0)
							+
							ISNULL((SELECT CASE WHEN ISNULL(t.Area,0)=0 THEN 0 ELSE (SUM(a.area)/t.area)*100 END 
									FROM #TempThaiNotContract a WHERE a.ProductID = t.ProductID),0)
							)
		,FQ_Percent			= (
							ISNULL((SELECT CASE WHEN ISNULL(t.Area,0)=0 THEN 0 ELSE (SUM(a.area)/t.area)*100 END 
									FROM #TempBookNoThai a WHERE a.ProductID = t.ProductID),0)
							+
							ISNULL((SELECT CASE WHEN ISNULL(t.Area,0)=0 THEN 0 ELSE (SUM(a.area)/t.area)*100 END 
									FROM #TempFQNotContract a WHERE a.ProductID = t.ProductID),0)
						 )
		,TotalContract_Percent =  CONVERT(DECIMAL(18,2),ISNULL((SELECT CASE WHEN ISNULL(t.totalUnit,0)=0 THEN 0 ELSE ((CONVERT(DECIMAL(18,2),count( a.Unitno)))/t.totalUnit)*100 END 
						 FROM #ICON_EntForms_Agreement a  WHERE a.ProjectNo = t.ProductID),0))
		,TotalTrans_Percent =  CONVERT(DECIMAL(18,2),ISNULL((SELECT CASE WHEN ISNULL(t.totalUnit,0)=0 THEN 0 ELSE ((CONVERT(DECIMAL(18,2),count(a.UnitNumber)))/t.totalUnit)*100 END 
						 FROM #ICON_EntForms_Transfer a  WHERE a.ProductID = t.ProductID),0))
		,TotalSign_Percent =  ISNULL((SELECT CASE WHEN ISNULL(t.totalUnit,0)=0 THEN 0 ELSE ((CONVERT(DECIMAL(18,2),count( a.Unitno)))/t.totalUnit) *100 END 
						 FROM #ICON_EntForms_AgreementSign a  WHERE a.ProjectNo = t.ProductID),0)
		,Agent_Unit  = ISNULL((SELECT COUNT(a.UnitNumber) FROM #TempBookAll a WHERE a.ProductID = t.ProductID AND a.[KEY] = '2' GROUP BY a.ProductID ),0)
		,Agent_Baht  = ISNULL((SELECT sum(a.TotalSellingPrice) FROM #TempBookAll a WHERE a.ProductID = t.ProductID AND a.[KEY] = '2' GROUP BY a.ProductID ),0)/1000000
		,Avail_Percent = ISNULL((SELECT CASE WHEN ISNULL(t.Area,0)=0 THEN 0 ELSE (SUM(a.area)/t.area)*100 END 
						 FROM #TempAvail a  WHERE a.ProjectNo = t.ProductID),0)                      
FROM #temp t

UPDATE #temp
SET Agent_Percent = (SELECT (CONVERT(DECIMAL(18,2),a.Agent_Unit)/CONVERT(DECIMAL(18,2),a.TotalUnit))*100 FROM #temp a  WHERE a.ProductID = t.ProductID)
,Avail_Unit = (		ISNULL((SELECT COUNT(c.UnitNo) FROM #TempArea c WHERE c.ProjectNo = t.ProductID),0)
							-
                         ISNULL((SELECT SUM(b.TotalBook_Unit) FROM #temp b WHERE b.ProductID = t.ProductID),0)
                       ) 
,Avail_Baht =  ISNULL((SELECT sum(c.TotalSellingPrice) FROM #Temp_UnitPriceListAvaliable c WHERE c.ProductID = t.ProductID),0)
,TotalBook_Percent = CONVERT(DECIMAL(18,2),(CASE WHEN t.TotalUnit = 0 THEN 0 ELSE (CONVERT(DECIMAL(18,2),t.TotalBook_Unit)/t.TotalUnit)*100 END ))

FROM #temp t
Select * From #TempToday Order By ProductID 
SELECT * FROM #temp ORDER BY ProductID

--------------------------------------------------------------------------------------
/*Load Email Template*/
IF (OBJECT_ID('tempdb..#EmailTemplate') IS NOT NULL)
    DROP TABLE #EmailTemplate;
SELECT CONVERT(NVARCHAR(MAX), '') Content
INTO #EmailTemplate;
DELETE FROM #EmailTemplate;
--ALTER TABLE #EmailTemplate  
--ALTER COLUMN Content NVarchar(max) COLLATE Thai_CI_AS;  
--BULK INSERT #EmailTemplate FROM 'E:\DB\Template\TemplateMail.html'
--BULK INSERT #EmailTemplate FROM 'O:\Template\TemplateMail.html'
BULK INSERT #EmailTemplate
FROM 'E:\Template\TemplateMail_ProjectSummary.html'
WITH
(
    ROWTERMINATOR = ''
);

SELECT * FROM #EmailTemplate

/*Assign value to Email*/
DECLARE @FormatDecimal NVARCHAR(10) = '0.00',
        @FormatInt NVARCHAR(10) = '0';
--DECLARE @ProductID NVarchar(50)
--SET @ProductID = (Select Top 1 ProductID  From #TempToday t )
--PRINT @ProductID

--SELECT * FROM #TempToday
DECLARE @current_productid NVARCHAR(20),@LCM NVARCHAR(1000)--,@Email NVARCHAR(100)

DECLARE print_cursor CURSOR FOR
SELECT ProductID FROM #TempToday

OPEN print_cursor
FETCH NEXT FROM print_cursor
INTO @current_productid
WHILE @@FETCH_STATUS = 0
BEGIN
	SELECT *
FROM #EmailTemplate;
SELECT @Mail = N'' + Content
FROM #EmailTemplate;
	SET @Mail = REPLACE(@Mail,
                            '@ProjectName',
                            CONVERT(   VARCHAR(200),
                            (
                                SELECT TOP 1
                                       ProductID + '_' + Project
                                FROM #TempToday t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail = REPLACE(@Mail, '@ToDate', CONVERT(NVARCHAR(20), @CurrentDate, 105));
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@WalkIn',
                         CONVERT(   VARCHAR,
                         (
                             SELECT TOP 1 t.FirstWalk FROM #TempToday t WHERE @current_productid = t.ProductID
                         ),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@Revisit',
                         CONVERT(   VARCHAR,
                         (
                             SELECT TOP 1 t.ReVisit FROM #TempToday t WHERE @current_productid = t.ProductID
                         ),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(@Mail,
                      '@Call',
                      CONVERT(   VARCHAR,
                      (
                          SELECT TOP 1 t.[Call] FROM #TempToday t WHERE @current_productid = t.ProductID
                      ),
                                 1
                             )
                     );
        SET @Mail = REPLACE(@Mail,
                            '@OnlineRegister',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.OnlineRegister
                                FROM #TempToday t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
		SET @Mail = REPLACE(@Mail,
                            '@Facebook',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.FaceBook
                                FROM #TempToday t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@BookGrossUnit',
                         CONVERT(   VARCHAR,
                         (
                             SELECT TOP 1 t.Book_Unit FROM #TempToday t WHERE @current_productid = t.ProductID
                         ),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(@Mail,
                      '@BookGrossBaht',
                      CONVERT(   VARCHAR,
                                 CAST(
                                 (
                                     SELECT TOP 1
                                            t.Book_Amount
                                     FROM #TempToday t
                                     WHERE @current_productid = t.ProductID
                                 ) AS MONEY),
                                 1
                             )
                     );
        SET @Mail = REPLACE(@Mail,
                            '@CancelUnit',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.Cancel_Unit
                                FROM #TempToday t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail
            = REPLACE(@Mail,
                      '@CancelBaht',
                      CONVERT(   VARCHAR,
                                 CAST(
                                 (
                                     SELECT TOP 1
                                            t.Cancel_Amount
                                     FROM #TempToday t
                                     WHERE @current_productid = t.ProductID
                                 ) AS MONEY),
                                 1
                             )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@NetBookUnit',
                         CONVERT(   VARCHAR,
                         (
                             SELECT TOP 1 t.Net_Unit FROM #TempToday t WHERE @current_productid = t.ProductID
                         ),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@NetBookBaht',
                         CONVERT(
                                    VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1 t.Net_Amount FROM #TempToday t WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
        SET @Mail = REPLACE(@Mail,
                            '@ContractUnit',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.Contract_Unit
                                FROM #TempToday t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail
            = REPLACE(@Mail,
                      '@ContractBaht',
                      CONVERT(   VARCHAR,
                                 CAST(
                                 (
                                     SELECT TOP 1
                                            t.Contract_Amount
                                     FROM #TempToday t
                                     WHERE @current_productid = t.ProductID
                                 ) AS MONEY),
                                 1
                             )
                     );
		SET @Mail = REPLACE(@Mail,
                            '@TransferUnit',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.Trans_Unit
                                FROM #TempToday t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail
            = REPLACE(@Mail,
                      '@TransferBaht',
                      CONVERT(   VARCHAR,
                                 CAST(
                                 (
                                     SELECT TOP 1
                                            t.Trans_Amount
                                     FROM #TempToday t
                                     WHERE @current_productid = t.ProductID
                                 ) AS MONEY),
                                 1
                             )
                     );		
		              
		SET @Mail = REPLACE(@Mail,
                            '@SignContractUnit',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.SignCon_Unit
                                FROM #TempToday t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail
            = REPLACE(@Mail,
                      '@SignContractBaht',
                      CONVERT(   VARCHAR,
                                 CAST(
                                 (
                                     SELECT TOP 1
                                            t.SignCon_Amount
                                     FROM #TempToday t
                                     WHERE @current_productid = t.ProductID
                                 ) AS MONEY),
                                 1
                             )
                     );		
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@DateWeek',
                         +CONVERT(NVARCHAR(10), @StartDate, 103) + ' - ' + CONVERT(NVARCHAR(10), @EndDate, 103)
                     );
        SET @Mail = REPLACE(@Mail,
                            '@ToMonth',
                            CONVERT(   VARCHAR,
                            (
                                SELECT CASE
                                           WHEN MONTH(GETDATE()) = 1 THEN
                                               'Jan'
                                           WHEN MONTH(GETDATE()) = 2 THEN
                                               'Feb'
                                           WHEN MONTH(GETDATE()) = 3 THEN
                                               'Mar'
                                           WHEN MONTH(GETDATE()) = 4 THEN
                                               'Apr'
                                           WHEN MONTH(GETDATE()) = 5 THEN
                                               'May'
                                           WHEN MONTH(GETDATE()) = 6 THEN
                                               'Jun'
                                           WHEN MONTH(GETDATE()) = 7 THEN
                                               'Jul'
                                           WHEN MONTH(GETDATE()) = 8 THEN
                                               'Aug'
                                           WHEN MONTH(GETDATE()) = 9 THEN
                                               'Sep'
                                           WHEN MONTH(GETDATE()) = 10 THEN
                                               'Oct'
                                           WHEN MONTH(GETDATE()) = 11 THEN
                                               'Nov'
                                           WHEN MONTH(GETDATE()) = 12 THEN
                                               'Dec'
                                       END
                            )
                                   )
                           );

        SET @Mail
            = REPLACE(
                         @Mail,
                         '@DateRange_ActualWalk',
                         CONVERT(   VARCHAR,
                         (
                             SELECT TOP 1 t.FirstWalk_Week FROM #temp t WHERE @current_productid = t.ProductID
                         ),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@Month_ActualWalk',
                         CONVERT(   VARCHAR,
                         (
                             SELECT TOP 1 t.FirstWalk_Month FROM #temp t WHERE @current_productid = t.ProductID
                         ),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@DateRange_Revisit',
                         CONVERT(   VARCHAR,
                         (
                             SELECT TOP 1 t.ReVisit_Week FROM #temp t WHERE @current_productid = t.ProductID
                         ),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@Month_Revisit',
                         CONVERT(   VARCHAR,
                         (
                             SELECT TOP 1 t.ReVisit_Month FROM #temp t WHERE @current_productid = t.ProductID
                         ),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@DateRange_Call',
                         CONVERT(   VARCHAR,
                         (
                             SELECT TOP 1 t.Call_Week FROM #temp t WHERE @current_productid = t.ProductID
                         ),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@Month_Call',
                         CONVERT(   VARCHAR,
                         (
                             SELECT TOP 1 t.Call_Month FROM #temp t WHERE @current_productid = t.ProductID
                         ),
                                    1
                                )
                     );
        SET @Mail = REPLACE(@Mail,
                            '@DateRange_OnlineRegister',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.[Online Register_Week]
                                FROM #temp t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail = REPLACE(@Mail,
                            '@Month_OnlineRegister',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.[Online Register_Month]
                                FROM #temp t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
		SET @Mail = REPLACE(@Mail,
                            '@DateRange_Facebook',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.[Facebook_week]
                                FROM #temp t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail = REPLACE(@Mail,
                            '@Month_Facebook',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.Facebook_Month
                                FROM #temp t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail = REPLACE(@Mail,
                            '@DateRange_TargetBook_Unit',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.TargetUnitBook_Week
                                FROM #temp t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@DateRange_TargetBook_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.TargetAmountBook_Week
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
        SET @Mail = REPLACE(@Mail,
                            '@Month_TargetBook_Unit',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.TargetUnitBook_Month
                                FROM #temp t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@Month_TargetBook_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.TargetAmountBook_Month
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@DateRange_BookGross_Unit',
                         CONVERT(   VARCHAR,
                         (
                             SELECT TOP 1 t.Book_Unit_Week FROM #temp t WHERE @current_productid = t.ProductID
                         ),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@DateRange_BookGross_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.Book_Amount_Week
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@Month_BookGross_Unit',
                         CONVERT(   VARCHAR,
                         (
                             SELECT TOP 1 t.Book_Unit_Month FROM #temp t WHERE @current_productid = t.ProductID
                         ),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@Month_BookGross_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.Book_Amount_Month
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
        SET @Mail = REPLACE(@Mail,
                            '@DateRange_Cancel_Unit',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.Cancel_Unit_Week
                                FROM #temp t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@DateRange_Cancel_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.Cancel_Amount_Week
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
        SET @Mail = REPLACE(@Mail,
                            '@Month_Cancel_Unit',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.Cancel_Unit_Month
                                FROM #temp t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@Month_Cancel_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.Cancel_Amount_Month
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@DateRange_NetBook_Unit',
                         CONVERT(   VARCHAR,
                         (
                             SELECT TOP 1 t.Net_Unit_Week FROM #temp t WHERE @current_productid = t.ProductID
                         ),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@DateRange_NetBook_Baht',
                         CONVERT(
                                    VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1 t.Net_Amount_Week FROM #temp t WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@Month_NetBook_Unit',
                         CONVERT(   VARCHAR,
                         (
                             SELECT TOP 1 t.Net_Unit_Month FROM #temp t WHERE @current_productid = t.ProductID
                         ),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@Month_NetBook_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.Net_Amount_Month
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
        SET @Mail = REPLACE(@Mail,
                            '@DateRange_Contract_Unit',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.Contract_Unit_Week
                                FROM #temp t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@DateRange_Contract_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.Contract_Amount_Week
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
        SET @Mail = REPLACE(@Mail,
                            '@Month_Contract_Unit',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.Contract_Unit_Month
                                FROM #temp t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@Month_Contract_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.Contract_Amount_Month
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
	SET @Mail = REPLACE(@Mail,
                            '@DateRange_Trans_Unit',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.Trans_Unit_Week
                                FROM #temp t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@DateRange_Trans_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.Trans_Amount_Week
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
        SET @Mail = REPLACE(@Mail,
                            '@Month_Trans_Unit',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.Trans_Unit_Month
                                FROM #temp t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@Month_Trans_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.Trans_Amount_Month
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
		SET @Mail = REPLACE(@Mail,
                            '@DateRange_SignContract_Unit',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.Sign_Unit_Week
                                FROM #temp t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@DateRange_SignContract_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.Sign_Amount_Week
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
        SET @Mail = REPLACE(@Mail,
                            '@Month_SignContract_Unit',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.Sign_Unit_Month
                                FROM #temp t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@Month_SignContract_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.Sign_Amount_Month
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@Local_Unit',
                         CONVERT(   VARCHAR,
                         (
                             SELECT TOP 1 t.LocalUnit FROM #temp t WHERE @current_productid = t.ProductID
                         ),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@Local_Baht',
                         CONVERT(
                                    VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1 t.LocalAmount FROM #temp t WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@FQSalesLocal_Unit',
                         CONVERT(   VARCHAR,
                         (
                             SELECT TOP 1 t.FQUnit FROM #temp t WHERE @current_productid = t.ProductID
                         ),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@FQSalesLocal_Baht',
                         CONVERT(
                                    VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1 t.FQAmount FROM #temp t WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@TotalBook_Unit',
                         CONVERT(   VARCHAR,
                         (
                             SELECT TOP 1 t.TotalBook_Unit FROM #temp t WHERE @current_productid = t.ProductID
                         ),
                                    1
                                )
                     );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@TotalBook_Baht',
                         CONVERT(
                                    VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1 t.TotalBook_Baht FROM #temp t WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
        SET @Mail = REPLACE(@Mail,
                            '@TotalContract_Unit',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.TotalContract_Unit
                                FROM #temp t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@TotalContract_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.TotalContract_Baht
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
		 SET @Mail = REPLACE(@Mail,
                            '@TotalTrans_Unit',
                            CONVERT(   VARCHAR,
                            (
                                SELECT TOP 1
                                       t.TotalTrans_Unit
                                FROM #temp t
                                WHERE @current_productid = t.ProductID
                            ),
                                       1
                                   )
                           );
        SET @Mail
            = REPLACE(
                         @Mail,
                         '@TotalTrans_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.TotalTrans_Baht
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
		SET @Mail
            = REPLACE(
                         @Mail,
                         '@TotalBook_Percent',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.TotalBook_Percent
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
			SET @Mail
            = REPLACE(
                         @Mail,
                         '@Local_Percent',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.Local_Percent
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
		SET @Mail
            = REPLACE(
                         @Mail,
                         '@FQSalesLocal_Percent',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.FQ_Percent
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
		SET @Mail
            = REPLACE(
                         @Mail,
                         '@TotalContract_Percent',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.TotalContract_Percent
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
				SET @Mail
            = REPLACE(
                         @Mail,
                         '@TotalTrans_Percent',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.TotalTrans_Percent
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
		SET @Mail
            = REPLACE(
                         @Mail,
                         '@Agent_Unit',
                         CONVERT(   VARCHAR,
                                    
                                    (
                                        SELECT TOP 1
                                               t.Agent_Unit
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) ,
                                    1
                                )
                     );
			SET @Mail
            = REPLACE(
                         @Mail,
                         '@Agent_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.Agent_Baht
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
			SET @Mail
            = REPLACE(
                         @Mail,
                         '@Agent_Percent',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.Agent_Percent
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
					 SET @Mail
            = REPLACE(
                         @Mail,
                         '@UnitAvail_Unit',
                        CONVERT(   VARCHAR,
                                    
                                    (
                                        SELECT TOP 1
                                               t.Avail_Unit
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) ,
                                    1
                                )
                     );
					 SET @Mail
			 = REPLACE(
                         @Mail,
                         '@UnitAvail_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.Avail_Baht
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
					 SET @Mail
			 = REPLACE(
                         @Mail,
                         '@UnitAvail_Percent',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.Avail_Percent
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
				 SET @Mail
            = REPLACE(
                         @Mail,
                         '@TotalSignContract_Unit',
                        CONVERT(   VARCHAR,
                                    
                                    (
                                        SELECT TOP 1
                                               t.TotalSign_Unit
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) ,
                                    1
                                )
                     );
					 SET @Mail
			 = REPLACE(
                         @Mail,
                         '@TotalSignContract_Baht',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.TotalSign_Baht
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
					 SET @Mail
			 = REPLACE(
                         @Mail,
                         '@TotalSignContract_Percent',
                         CONVERT(   VARCHAR,
                                    CAST(
                                    (
                                        SELECT TOP 1
                                               t.TotalSign_Percent
                                        FROM #temp t
                                        WHERE @current_productid = t.ProductID
                                    ) AS MONEY),
                                    1
                                )
                     );
			--SET @Mail
   --         = REPLACE(
   --                      @Mail,
   --                      '@Title',
   --                      CONVERT(   VARCHAR,
                                    
   --                                 (
   --                                     SELECT 'เรียน'
   --                                 ) ,
   --                                 1
   --                             )
   --                  );

			--SET @Mail
   --         = REPLACE(
   --                      @Mail,
   --                      '@LCMName',
   --                      CONVERT(   VARCHAR,
                                    
   --                                 (
   --                                     SELECT  TOP 1 FullName FROM #Tempvw_UserRoleProject a where a.ProjectCode = @current_productid 
   --                                 ) ,
   --                                 1
   --                             )
   --                  );
				SET @Mail
            = REPLACE(
                         @Mail,
                         '@Area',
                         CONVERT(   VARCHAR,
                                    
                                    (
                                        SELECT  '%พื้นที่'
                                    ) ,
                                    1
                                )
                     );
					 SET @Mail
            = REPLACE(
                         @Mail,
                         '@Unit',
                         CONVERT(   VARCHAR,
                                    
                                    (
                                        SELECT  '%Units'
                                    ) ,
                                    1
                                )
                     );
						SET @Mail
            = REPLACE(
                         @Mail,
                         '@Ratio',
                         CONVERT(   VARCHAR(50),
                                    
                                    (
                                        SELECT  'สัดส่วน TH/FQ คิดเป็น % ของพื้นที่'
                                    ) ,
                                    1
                                )
                     );
								SET @Mail
            = REPLACE(
                         @Mail,
                         '@PercentTotal',
                         CONVERT(   VARCHAR(50),
                                    
                                    (
                                        SELECT  'สัดส่วน Total คิดเป็น % ของUnits'
                                    ) ,
                                    1
                                )
                     );
			--Set @Mail=Replace(@Mail,'@LCMName',CONVERT(varchar,(SELECT  TOP 1 FullName FROM #Tempvw_UserRoleProject a where a.ProjectID = @current_productid ), 1))
        ------------------------------------------------------------------------------
        --Set @Mail=Replace(@Mail,'@AsOfDate',convert(nvarchar(20),Getdate(),113))
        --Set @Mail=Replace(@Mail,'@Week','   ( Week '+convert(nvarchar(10),@CurrentWeek)+' : '+ convert(nvarchar(10),@StartDate,103) +' - '+ convert(nvarchar(10),@EndDate,103)+' )'  )

		--SET @Email = (SELECT TOP 1 Email FROM #Tempvw_UserRoleProject a WHERE a.ProjectCode = @current_productid    ) 
--SET @LCM = (SELECT  distinct FullName FROM [dbo].[vw_UserRoleProject] a WHERE RoleCode = 'LCM' AND bu = 3 AND a.ProjectID = @current_productid )
--PRINT @LCM

        PRINT (@Mail);
       -- SELECT @Mail EmailContent;


        /*Send email*/
        DECLARE @To NVARCHAR(100),
                @From NVARCHAR(100),
                @FromName NVARCHAR(100),
                @SendDate DATETIME = GETDATE(),
				@Email NVARCHAR(max),
				@Subject NVARCHAR(500)

				--SET @Email = (	SELECT Email = STUFF((
				--				 SELECT ';' + Email
				--					FROM #Tempvw_UserRoleProject a WHERE  a.ProjectCode = @current_productid
				--					FOR XML PATH('')
				--				 ), 1, 1, '')  ) 
				--PRINT @Email
		SET @Email = N'prajark@apthai.com;manop@apthai.com;ake_c@apthai.com' 
		--SET @Email = N'apichaya@apthai.com'-- for test
		SET @Subject = 'Summary Daily Report by Project'+' '+ (SELECT TOP 1 ProductID + '_' + Project FROM #TempToday t WHERE @current_productid = t.ProductID)
        SET @From = N'crmconsult@apthai.com';
		SET @FromName = N'Summary Daily Report';

        EXEC DBLINK_SVR_EMAIL.APMail.dbo.SP_Save_MailWithName                                                                             -- nvarchar(500)
													  @CMD = 1,
                                                      @AttempTime = @SendDate,
                                                      @MailFrom = @From,
                                                      @MailTo = @Email,
													  @MailCC = N'apichaya@apthai.com;jintana_i@apthai.com',
													  --@MailCC = N'',
                                                      @Topic = @Subject,
                                                      @Detail = @Mail,
                                                      @MailType = N'ProjectSumary',
                                                      @Key1 = '',
                                                      @Key2 = '',
                                                      @Key3 = '',
                                                      @Key4 = '',
                                                      @ReceiverID = N'',
                                                      @MailTime = @SendDate,
													  @MailFromName = @FromName;
PRINT @LCM

	FETCH NEXT FROM print_cursor
	INTO @current_productid
END
CLOSE print_cursor
DEALLOCATE print_cursor



go

