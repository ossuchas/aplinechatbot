CREATE proc [dbo].[sp_RPT_ExecutiveMail_Prepare]
@DateStart DateTime,@DateEnd DateTime
as
	--Declare @DateStart DateTime,@DateEnd DateTime  
	--SET @DateStart='20200921'  set @DateEnd='20200930' 

	Declare @Projects varchar(500),@StatusProject varchar(50),@EmpCode nvarchar(150),@Trans varchar(5)
	Set @Projects=''''''  Set @Trans='2' 
	 set @StatusProject=''   set @EmpCode='AP002838'
	SET @DateStart = CONVERT(VARCHAR(50),@DateStart,120)
	SET @DateEnd = CONVERT(VARCHAR(50),@DateEnd,120)


	Set @Projects=Replace(@Projects,'''','')
	If (@StatusProject='4' or @StatusProject is null) Set @StatusProject='1,2'
	If (@DateStart Is Null)Set @DateStart='18000101'
	If (@DateEnd Is Null OR Year(@DateEnd)=1900)Set @DateEnd='70000101'

EXEC crmrevo.dbo.sp_ExecutiveReport_Adjust------------------รัน vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract 



	PRINT '1'
	If(Object_Id('tempdb..#vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract')Is Not Null)Drop Table #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract
	SELECT *
	INTO #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract 
	FROM ##ExecutiveReport_Adjust With(NoLock)
	Where 1=1 
		AND (Isnull(@Projects,'')='' Or ProjectID In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))

		PRINT '2'
	If(Object_Id('tempdb..#Temp_Subtract')Is Not Null)Drop Table #Temp_Subtract
	SELECT ProjectID
	,'SubtractGrossBookingAmount'=Sum(SubtractGrossBookingAmount) ,'SubtractGrossBookingUnit'=Sum(SubtractGrossBookingUnit)
	INTO #Temp_Subtract 
	FROM #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract With(NoLock)
	Where 1=1 
		AND (Isnull(@Projects,'')='' Or ProjectID In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
		and BookingDate between @DateStart and @DateEnd
	Group by ProjectID

-------------------#Temp_Subtract_Cancel-------------------------------------------
If(Object_Id('tempdb..#Temp_SpecialBook')Is Not Null)Drop Table #Temp_SpecialBook
	SELECT ProjectID,'SubtractCancelAmount'=Sum(SubtractCancelAmount) ,'SubtractCancelUnit'=Sum(1)
	INTO #Temp_SpecialBook
		FROM #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract With(NoLock)
		Where 1=1 
			AND (Isnull(@Projects,'')='' Or ProjectID In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
			--and Convert(nvarchar(8),BookingCancelDate,112) between @DateStart and @DateEnd and CurrentStatus='ยกเลิก' -- 19/9/2019 K.กิ๊ก แจ้งว่ารายงานดึงย้อนหลัง เมือ 1/1/12019-30/6/2019 ยอดไม่ตรง คือ ไม่ได้หักจองพิเศษ
			and (BookingDate BETWEEN @DateStart and @DateEnd AND BookingType='จองพิเศษ')
		Group by ProjectID

	If(Object_Id('tempdb..#Temp_Subtract_Cancel')Is Not Null)Drop Table #Temp_Subtract_Cancel
	Select ProjectID,'SubtractCancelAmount'=Sum(SubtractCancelAmount) ,'SubtractCancelUnit'=Sum(SubtractCancelUnit) 
	into #Temp_Subtract_Cancel
	From(
		SELECT ProjectID,SubtractCancelAmount ,SubtractCancelUnit
		FROM #Temp_SpecialBook WITH(NoLock)
		Where 1=1 
			
		UNION
		SELECT ProjectID
		,'SubtractCancelAmount'=Sum(SubtractCancelAmount) ,'SubtractCancelUnit'=Sum(SubtractCancelUnit)
		FROM #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract a With(NoLock)
		Where 1=1 
			AND (Isnull(@Projects,'')='' Or ProjectID In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
			--and Convert(nvarchar(8),BookingCancelDate,112) between @DateStart and @DateEnd and CurrentStatus='ยกเลิก' -- 19/9/2019 K.กิ๊ก แจ้งว่ารายงานดึงย้อนหลัง เมือ 1/1/12019-30/6/2019 ยอดไม่ตรง คือ ไม่ได้หักจองพิเศษ
			and (Convert(nvarchar(8),BookingCancelDate,112) BETWEEN @DateStart and @DateEnd and CurrentStatus='ยกเลิก')
			and (BookingDate>=@DateStart or BookingType<>'จองพิเศษ')
			and not exists(SELECT *
					FROM #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract b With(NoLock)
					Where 1=1 
						--AND (Isnull(@Projects,'')='' Or ProductID In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
						--and Convert(nvarchar(8),BookingCancelDate,112) between @DateStart and @DateEnd and CurrentStatus='ยกเลิก' -- 19/9/2019 K.กิ๊ก แจ้งว่ารายงานดึงย้อนหลัง เมือ 1/1/12019-30/6/2019 ยอดไม่ตรง คือ ไม่ได้หักจองพิเศษ
						and (BookingDate BETWEEN @DateStart AND @DateEnd   and BookingType ='จองพิเศษ')
						and a.BookingNumber=b.BookingNumber)
		Group by ProjectID
	)t
	Group by ProjectID
	  IF (ISNULL(@Trans, '') = '') SET @Trans = '0'
	  If(Object_Id('tempdb..#vw_RPTAP2_ExV4Booking')Is Not Null)Drop Table #vw_RPTAP2_ExV4Booking
	SELECT * INTO #vw_RPTAP2_ExV4Booking FROM [crmrevo].dbo.vw_RPTAP2_ExV4Booking
	If(Object_Id('tempdb..#vw_RPTAP2_ExV4BookingCancel')Is Not Null)Drop Table #vw_RPTAP2_ExV4BookingCancel
	SELECT * INTO #vw_RPTAP2_ExV4BookingCancel FROM [crmrevo].dbo.vw_RPTAP2_ExV4BookingCancel

	Declare @Booking Table (UnitAmt Int,BKPrice Money,ProjectID nvarchar(100),ProjectNo nvarchar(100),BookingDate DateTime)
	Insert Into @Booking (UnitAmt,BKPrice,ProjectID,ProjectNo,BookingDate)
	Select	ISNULL(SUM(B.UnitAmt),0) AS TotalUnit,ISNULL(Sum(B.BKPrice),0)  AS TotalPrice,b.ProjectID,p.ProjectNo 
	,b.BookingDate
	FROM #vw_RPTAP2_ExV4Booking B With(NoLock)
	INNER JOIN [crmrevo].prj.Project p With(NoLock) ON b.ProjectID = p.ID 
	Where	1=1 
	AND (Isnull(@Projects,'')='' Or B.ProjectID In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
		--AND B.Project IN (SELECT ProductID FROM [dbo].[fn_GetProjectAuthorised](@UserName))
	GROUP BY b.ProjectID, p.ProjectNo,b.BookingDate

Declare @BookingCancel Table (UnitAmt Int,BKPrice Money,ProjectID nvarchar(100),ProjectNo nvarchar(100),CancelDate DateTime)
	Insert Into @BookingCancel (UnitAmt,BKPrice,ProjectID,ProjectNo,CancelDate)
	Select	ISNULL(SUM(B.UnitAmt),0) AS TotalUnit,ISNULL(Sum(B.BKPrice),0) AS TotalPrice,b.ProjectID, p.ProjectNo ,CancelDate
	From	#vw_RPTAP2_ExV4BookingCancel B With(NoLock)
	INNER JOIN [crmrevo].prj.Project p With(NoLock) ON b.ProjectID = p.ID 
	--Left Join #vw_CRM_Freedown_V2 c With(NoLock) on b.BookingNumber=c.BookingNumber--b.Project=c.ProductID and b.UnitNumber=c.UnitNumber and b.BookingDate=c.BookingDate
	Where	1=1 
		AND (Isnull(@Projects,'')='' Or B.ProjectID In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
		--and not exists(Select * From #CRM_Freedown_Cancel t where b.Project=t.ProductID and b.UnitNumber=t.UnitNumber and b.Canceldate=t.Canceldate and t.Canceltype='ยกเลิกพิเศษ'and t.CancelDate<=@DateEnd)
		--AND B.Project IN (SELECT ProductID FROM [dbo].[fn_GetProjectAuthorised](@UserName))
	GROUP BY b.ProjectID, p.ProjectNo,CancelDate

If(Object_Id('tempdb..#TMin')Is Not Null)Drop Table #TMin

	Select a.ProjectID, a.UnitID, MAX(ActiveDate) AS MaxDate,b.[Name]
	Into #TMin
	FROM [crmrevo].prj.MinPrice  a 	WITH(NoLock)
	INNER JOIN [crmrevo].mst.MasterCenter b WITH(NoLock) ON a.MinPriceTypeMasterCenterID = b.id AND b.[Key] = '2' AND a.IsDeleted = 0
	WHERE( a.ActiveDate <= @DateEnd )
	GROUP BY  a.ProjectID, a.UnitID,b.[Name]
	Order By  a.ProjectID, a.UnitID

	Insert Into #TMin
	Select  a.ProjectID, a.UnitID, MAX(ActiveDate) AS MaxDate,b.[Name]
	FROM [crmrevo].prj.MinPrice  a 	WITH(NoLock)
	INNER JOIN [crmrevo].mst.MasterCenter b WITH(NoLock) ON a.MinPriceTypeMasterCenterID = b.id AND b.[Key] = '1' AND a.IsDeleted = 0
	WHERE a.ActiveDate <= @DateEnd  And Not Exists(Select * From #TMin t Where  t.UnitID=a.UnitID)
	GROUP BY  a.ProjectID, a.UnitID,b.[Name]
	Order By  a.ProjectID, a.UnitID

	If(Object_Id('tempdb..#TempBook')Is Not Null)Drop Table #TempBook
	SELECT * INTO #TempBook FROM [crmrevo].sal.Booking b With(NoLock)	 Where b.BookingDate<=@DateEnd AND b.IsDeleted = 0 and (CancelDate Is Null Or CancelDate>@DateEnd /*CancelDate>=@DateEnd*/ )

	Declare @Empty Table(TotalPrice money,TotalUnit Int,ProductID varchar(50))
	Insert Into @Empty (ProductID,TotalUnit,TotalPrice)
	SELECT UN.ProjectID AS Project, COUNT(UN.id) AS UnitAmt, ISNULL(SUM(P.TotalSellingPrice), 0)/1000000 AS UnitPrice
	FROM (SELECT a.ProjectID,a.id , b.[Key] FROM [crmrevo].prj.unit a With(NoLock) INNER JOIN [crmrevo].mst.MasterCenter b With(NoLock) ON a.AssetTypeMasterCenterID = b.id  ) AS  UN  LEFT OUTER JOIN
	(
		SELECT A.UnitID, A.ProjectID, A.ActiveDate, A.ApprovedMinPrice TotalSellingPrice
		FROM [crmrevo].prj.MinPrice AS A With(NoLock) INNER JOIN
			(
				Select Distinct ProjectID, UnitID,MaxDate From #TMin
			) AS B ON  A.UnitID = B.UnitID AND B.MaxDate = A.ActiveDate
		WHERE 1=1
			AND (Isnull(@Projects,'')='' Or A.ProjectID In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
	) AS P ON  P.UnitID = UN.id
	WHERE (UN.[Key] IN ('2', '4')) 
		AND (Isnull(@Projects,'')='' Or UN.ProjectID In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
		AND Not Exists (Select * From #TempBook b WHERE  UN.id =b.UnitID)
	GROUP BY UN.ProjectID

	DECLARE @Total Table(TotalPrice money,ProjectID nvarchar(50))
	Insert Into @Total
	Select Isnull(b.TotalPrice,0)-Isnull(bc.TotalPrice,0)--+Isnull(a.TotalPrice,0)-Isnull(tp.TotalPrice,0)+Isnull(t.ExtraDiscount,0)+t.AreaPrice TotalPrice
	,b.ProjectID
	From 
	(
		Select	ISNULL(SUM(B.UnitAmt),0) AS TotalUnit,Round(ISNULL(Sum(B.BKPrice),0)/1000000,2) AS TotalPrice,B.ProjectID 
		From	@Booking B
		Where	1=1 AND B.BookingDate Between '18000101' and @DateEnd 
		GROUP BY B.ProjectID
	)B Left Join(
		Select	ISNULL(SUM(BC.UnitAmt),0) AS TotalUnit,Round(ISNULL(Sum(BC.BKPrice),0)/1000000,2) AS TotalPrice,BC.ProjectID 
		From	@BookingCancel BC
		Where	1=1	AND BC.CancelDate Between '18000101' and @DateEnd 
		GROUP BY BC.ProjectID
	)BC on b.ProjectID=bc.ProjectID

	If(Object_Id('tempdb..#vw_UnitPrice')Is Not Null)Drop Table #vw_UnitPrice
SELECT a.* ,m.[Key]
INTO #vw_UnitPrice 
FROM [crmrevo].dbo.vw_UnitPrice  a  With(NoLock)
INNER JOIN [crmrevo].mst.MasterCenter m  With(NoLock) ON a.UnitPriceStageMasterCenterID = m.id 
WHERE a.IsDeleted = 0


If(Object_Id('tempdb..#UnitPriceItem')Is Not Null)Drop Table #UnitPriceItem
SELECT a.* 
INTO #UnitPriceItem 
FROM [crmrevo].sal.UnitPriceItem a  With(NoLock)
INNER JOIN [crmrevo].mst.MasterPriceItem b  With(NoLock) ON b.id = a.MasterPriceItemID
WHERE a.IsDeleted = 0 AND b.[Key] = 'ExtraAreaPrice'

If(Object_ID('tempdb..#Temp')Is not null) DROP table #Temp

Select p.id as ProjectID,p.ProjectNo AS ProductID,p.ProjectNameTH AS Project
	--,p.ProjectGroup BU
	,bg.[Name] AS BU
	,CONVERT (DATETIME,p.ProjectStartDate) AS StartSale
	,'TotalUnit'= Isnull((Select	Count(U.id) FROM	[crmrevo].prj.unit U With(NoLock) INNER JOIN [crmrevo].mst.MasterCenter m With(NoLock) ON u.AssetTypeMasterCenterID = m.id AND m.[Key] IN ('2','4')  where u.ProjectID=p.id ),0)
	,'TotalPrice'= ROUND(Isnull((Select TotalPrice From @Total t Where t.ProjectID=p.id),0),2)+ ROUND((Isnull((Select	ISNULL((v.TotalPrice),0) AS TotalPrice From	@Empty v Where v.ProductID=p.id),0)),2)
	,'EmptyUnit'=Isnull((Select	ISNULL((v.TotalUnit),0) From	@Empty v Where v.ProductID=p.id),0)
	,'EmptyPrice'=Round(Isnull((Select	ISNULL((v.TotalPrice),0)  From	@Empty v Where v.ProductID=p.id),0),2)
	,'BookingTotalPrice'=Round(Isnull(b.TotalPrice,0)/1000000,2),'BookingTotalUnit'=Isnull(b.TotalUnit,0)
	,'CancelTotalPrice'=Round(Isnull(bc.TotalPrice,0)/1000000*-1,2),'CancelTotalUnit'=Isnull(bc.TotalUnit,0)*-1
	,'ContractPrice'= convert(decimal(18,2),0)
	,'TransferDiscount'= convert(decimal(18,2),0)
	,'AreaPrice'= convert(decimal(18,2),0)
	,'ExtraDiscount'= convert(decimal(18,2),0)
	,'TransferTotalPrice'=Round((Isnull(t.TotalPrice,0)),2),'TransferTotalUnit'=Isnull(t.TotalUnit,0)
	,'PTDBookingTotalPrice'=Round(Isnull(bb.TotalPrice,0),2),'PTDBookingTotalUnit'=Isnull(bb.TotalUnit,0)
	,'PTDTransferTotalPrice'=Round(Isnull(tt.TotalPrice,0),2),'PTDTransferTotalUnit'=Isnull(tt.TotalUnit,0)
	--,b.productid
	,p.[Group] AS ProjectGroup
	--,p.PType BU
	INTO #Temp
	From [crmrevo].prj.Project p WITH(NoLock)
	INNER JOIN [crmrevo].mst.MasterCenter m WITH(NoLock) ON m.id = p.ProjectStatusMasterCenterID 
	INNER JOIN [crmrevo].mst.BG bg WITH(NoLock) ON p.BGID = bg.id 
	Left Join
	(
		Select	ISNULL(SUM(B.UnitAmt),0)- Isnull((Select (SubtractGrossBookingUnit) From #Temp_Subtract t with(nolock) Where t.ProjectID=b.ProjectID),0) AS TotalUnit
		,ISNULL(Sum(B.BKPrice),0)- Isnull((Select (SubtractGrossBookingAmount) From #Temp_Subtract t with(nolock)Where t.ProjectID=b.ProjectID),0) AS TotalPrice
		,B.ProjectID 
		From	@Booking B
		Where	1=1 AND B.BookingDate Between @DateStart  and @DateEnd 
		GROUP BY B.ProjectID
	)B ON p.id=b.ProjectID LEFT JOIN 
		(
		Select	'TotalUnit'=ISNULL(SUM(BC.UnitAmt),0)- Isnull((Select (SubtractCancelUnit) From #Temp_Subtract_Cancel t with(nolock) Where t.ProjectID=bc.ProjectID),0)
		,'TotalPrice'=ISNULL(Sum(BC.BKPrice),0)- Isnull((Select (SubtractCancelAmount) From #Temp_Subtract_Cancel t with(nolock) Where t.ProjectID=bc.ProjectID),0)
		,BC.ProjectID
		From	@BookingCancel BC
		Where	1=1	AND BC.CancelDate BETWEEN @DateStart  and @DateEnd
			and (Isnull(@Projects,'')='' Or BC.ProjectID In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
		GROUP BY BC.ProjectID
	)BC ON p.id=bc.ProjectID LEFT JOIN
	(
		Select Round(Sum(Isnull(c.TotalPrice,0)-isnull(c.FreedownDiscount,0))/1000000,2)TotalPrice,Count(t.AgreementID)TotalUnit
		,'AreaPrice' =ROUND(Sum(uu.Amount)/1000000,2) 
		,'ExtraDiscount'= 0,a.ProjectID
		From [crmrevo].sal.[Transfer] t with(nolock)
		left join [crmrevo].sal.Agreement a with(nolock) ON t.AgreementID = a.id AND t.IsDeleted = 0 
		Left Join (SELECT a.* FROM #vw_UnitPrice a with(nolock) WHERE  a.[Key] = '3') c ON c.BookingID= a.BookingID 
		LEFT JOIN (SELECT a.Amount , a.UnitPriceID FROM #UnitPriceItem a  ) uu ON uu.UnitPriceID = c.id
		Where 1=1 and t.ActualTransferDate Is Not Null  AND a.IsDeleted = 0
		AND t.ActualTransferDate Between @DateStart  and @DateEnd  --and Isnull(t.IsReadyToTransfer,0)=1 
			and (Isnull(@Projects,'')='' Or a.ProjectID In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
		Group By a.ProjectID
	)t ON p.id=t.ProjectID LEFT JOIN 
	(
		--Select Isnull(b.TotalPrice,0)-Isnull(bc.TotalPrice,0)+Isnull(a.TotalPrice,0)-Isnull(tp.TotalPrice,0)+Isnull(t.ExtraDiscount,0)+isnull(t.AreaPrice,0) TotalPrice,isnull(b.TotalUnit,0)-isnull(bc.TotalUnit,0) TotalUnit,p.ProductID                       
		Select Isnull(b.TotalPrice,0)+Isnull(a.TotalPrice,0)-Isnull(tp.TotalPrice,0)+Isnull(t.ExtraDiscount,0)+isnull(t.AreaPrice,0) TotalPrice,isnull(b.TotalUnit,0) TotalUnit,p.id
		From [crmrevo].prj.Project p 
        INNER JOIN [crmrevo].mst.MasterCenter m WITH(NoLock) ON m.id = p.ProjectStatusMasterCenterID  AND p.IsDeleted = 0
		Left JOIN
		(
			Select Count(b.unitid) AS TotalUnit,Round(ISNULL(Sum(IsNull(c.TotalPrice, 0))-Sum(IsNull(c.FreedownDiscount, 0)),0)/1000000,2) AS TotalPrice,B.ProjectID 
			From [crmrevo].sal.Booking b with(nolock)
			Left Join (SELECT a.* FROM #vw_UnitPrice a WHERE  a.[Key] = '1') c ON c.BookingID = b.id  
			Where 1=1
			and  B.BookingDate Between '18000101' and @DateEnd AND b.IsDeleted = 0 and b.IsCancelled = 0
			And (canceldate Is Null or
				b.BookingNo Not In(Select t.BookingNo FROM [crmrevo].sal.Booking  t Where t.ProjectID=b.ProjectID and canceldate Between '18000101' and CONVERT(VARCHAR(50),@DateEnd,120)  ))
			and b.BookingNo not in(Select t.BookingNumber From [crmrevo].[dbo].[Temp_CRM_Freedown_Cancel] t where t.Canceltype='ยกเลิกพิเศษ' and t.CancelDate<=CONVERT(VARCHAR(50),@DateEnd,120)  )
			GROUP BY B.ProjectID
		)b on p.id=b.ProjectID Left Join
		(	
			Select Round(Sum(c.TotalPrice-Isnull(c.FreedownDiscount,0)-0 -----Lastdownamount ไม่มีmigrate ของเก่าม่ีแค่โครงการ 60014
				-(d.TotalPrice-Isnull(d.FreedownDiscount,0)))/1000000,2) TotalPrice,Count(a.AgreementNo)TotalUnit,a.projectid
			From [crmrevo].sal.Agreement a with(nolock)Left Join 
				[crmrevo].sal.Booking b with(nolock)on a.BookingID=b.id AND a.IsDeleted = 0 AND b.IsDeleted = 0
			Left Join (SELECT a.* FROM #vw_UnitPrice a WHERE  a.[Key] = '2') c ON c.BookingID = a.BookingID
			LEFT Join (SELECT a.* FROM #vw_UnitPrice a WHERE  a.[Key] = '1') d ON d.BookingID = b.id
			Where 1=1 AND a.SignAgreementDate Between '18000101' and @DateEnd and (b.CancelDate Is Null OR b.CancelDate>@DateEnd )
				and (Isnull(@Projects,'')='' Or a.projectid In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
				AND b.BookingNo not in(Select t.BookingNumber From [crmrevo].dbo.[Temp_CRM_Freedown_Cancel] t with(nolock)where t.Canceltype='ยกเลิกพิเศษ'and t.CancelDate<= CONVERT(VARCHAR(50),@DateEnd,120)  )
			Group By a.projectid
		)a on p.id=a.projectid Left Join			
		(SELECT Round(Sum(c.TransferDiscount-Isnull(cc.TransferDiscount,0)-0)/1000000,2)TotalPrice,Count(t.AgreementID)TotalUnit,a.ProjectID
			From [crmrevo].sal.[Transfer] t with(nolock)
			LEFT Join [crmrevo].sal.Agreement a with(nolock)on t.AgreementID = a.id  AND t.IsDeleted = 0 AND a.IsDeleted = 0
			Left Join (SELECT a.* FROM #vw_UnitPrice a WHERE  a.[Key] = '3') c ON c.BookingID = a.BookingID
			Left Join (SELECT a.* FROM #vw_UnitPrice a WHERE  a.[Key] = '2') cc ON cc.BookingID = a.BookingID
			INNER  JOIN [crmrevo].sal.Booking b ON b.id = a.BookingID AND (b.CancelDate Is Null OR b.CancelDate> @DateEnd  )
			Where 1=1 and t.ActualTransferDate Is Not Null AND t.ActualTransferDate Between '18000101' and @DateEnd  -- and Isnull(t.IsReadyToTransfer,0)=1 
			and (Isnull(@Projects,'')='' Or a.ProjectID In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
			Group By a.ProjectID
		)tp ON p.id=tp.projectid Left Join
		(Select Round(Sum(Isnull(c.TotalPrice,0)-isnull(c.FreedownDiscount,0))/1000000,2)TotalPrice,Count(t.AgreementID)TotalUnit
		,'AreaPrice' =ROUND(Sum(uu.Amount)/1000000,2) 
		,'ExtraDiscount'= 0,a.ProjectID
		From [crmrevo].sal.[Transfer] t with(nolock)
		left join [crmrevo].sal.Agreement a with(nolock) ON t.AgreementID = a.id AND t.IsDeleted = 0 AND a.IsDeleted = 0
		Left Join (SELECT a.* FROM #vw_UnitPrice a WHERE  a.[Key] = '3') c ON c.BookingID= a.BookingID 
		LEFT JOIN (SELECT a.Amount , a.UnitPriceID FROM #UnitPriceItem a ) uu ON uu.UnitPriceID = c.id
		Where 1=1 and t.ActualTransferDate Is Not Null AND t.ActualTransferDate Between '18000101'  and @DateEnd   and Isnull(t.IsReadyToTransfer,0)=1 
			and (Isnull(@Projects,'')='' Or a.ProjectID In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
			Group By a.ProjectID
		)t ON p.id=t.ProjectID
		Where (Isnull(@Projects,'')='' Or p.id In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
			and (Isnull(@StatusProject,'')='' Or m.[key] In(SELECT * FROM [dbo].[fn_SplitString](@StatusProject,',')))
	)bb ON p.id=bb.id LEFT JOIN 
	(
		Select Round(Sum(Isnull(c.TotalPrice,0)-isnull(c.FreedownDiscount,0))/1000000,2)TotalPrice,Count(t.AgreementID)TotalUnit
		,'AreaPrice' =ROUND(Sum(uu.Amount)/1000000,2) 
		,'ExtraDiscount'= 0,a.ProjectID
		From [crmrevo].sal.[Transfer] t with(nolock)
		left join [crmrevo].sal.Agreement a with(nolock) ON t.AgreementID = a.id AND t.IsDeleted = 0 AND a.IsDeleted = 0
		Left Join (SELECT a.* FROM #vw_UnitPrice a WHERE a.[Key] = '3') c ON c.BookingID= a.BookingID 
		LEFT JOIN (SELECT a.Amount , a.UnitPriceID FROM #UnitPriceItem a ) uu ON uu.UnitPriceID = c.id
		Where 1=1 and t.ActualTransferDate Is Not Null AND t.ActualTransferDate Between '18000101'   and @DateEnd   and Isnull(t.IsReadyToTransfer,0)=1 
			and (Isnull(@Projects,'')='' Or a.ProjectID In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
			Group By a.ProjectID
	)tt ON p.id=tt.ProjectID
	Where 1=1
		AND (p.id IN (SELECT ProjectID FROM [dbo].[fn_GetProjectAuthorised](@EmpCode))or isnull(@EmpCode,'')='' )
		and (Isnull(@Projects,'')='' Or p.id In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
		and (Isnull(@StatusProject,'')='' Or m.[key] In(SELECT * FROM [dbo].[fn_SplitString](@StatusProject,',')))
		--and p.PType='3'
		AND p.IsDeleted = 0
	Order by 
	p.[Group]
	,bg.[Name]
	,p.ProjectNo
	
	UPDATE #Temp
	SET ContractPrice = ISNULL((Select Round(Sum(isnull(c.TotalPrice,0)-Isnull(c.FreedownDiscount,0)-(isnull(cc.TotalPrice,0) -Isnull(cc.FreedownDiscount,0)))/1000000,2)
						From [crmrevo].sal.Agreement a  With(NoLock)
						LEFT Join [crmrevo].sal.Booking b  With(NoLock) ON a.BookingID=b.id AND a.IsDeleted = 0 AND b.IsDeleted = 0
						LEFT JOIN [crmrevo].sal.[Transfer] t  With(NoLock) ON a.id = t.AgreementID AND t.IsDeleted = 0
						Left Join (SELECT a.* FROM #vw_UnitPrice a WHERE a.[Key] = '2') c ON c.BookingID= a.BookingID 
						Left Join (SELECT a.* FROM #vw_UnitPrice a WHERE a.[Key] = '1') cc ON cc.BookingID= b.id 
						Where 1=1 
						AND a.projectID = aa.projectID
						AND a.SignAgreementDate Between @DateStart  and @DateEnd  and (b.CancelDate Is Null OR b.CancelDate>@DateEnd )
						and (Isnull(@Projects,'')='' Or a.projectID In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
						AND ((@Trans = '1' AND t.ActualTransferDate IS NOT NULL ) OR (@Trans = '0' AND t.ActualTransferDate IS  NULL) OR (ISNULL(@Trans, '') = '2' ))						
						Group By a.projectID),0)
	,TransferDiscount = ISNULL((Select Round(ISNULL(Sum(c.TransferDiscount-Isnull(cc.TransferDiscount,0)-0),0)/1000000,2)
						From [crmrevo].sal.[Transfer] t   With(NoLock)
						LEFT Join [crmrevo].sal.Agreement a  With(NoLock) ON t.AgreementID = a.id AND t.IsDeleted = 0 AND a.IsDeleted = 0
						LEFT JOIN [crmrevo].sal.Booking b With(NoLock) ON a.BookingID = b.id  AND b.IsDeleted = 0 AND (b.CancelDate Is Null OR b.CancelDate>@DateEnd )
						Left Join (SELECT a.* FROM #vw_UnitPrice a WHERE  a.[Key] = '3') c ON c.BookingID= a.BookingID 
						Left Join (SELECT a.* FROM #vw_UnitPrice a WHERE  a.[Key] = '2') cc ON cc.BookingID= a.BookingID 
						Where 1=1 and t.ActualTransferDate Is Not Null AND t.ActualTransferDate BETWEEN @DateStart  and @DateEnd  and Isnull(t.IsReadyToTransfer,0)=1 
							and (Isnull(@Projects,'')='' Or a.ProjectID In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
							And IsNull(c.TransferDiscount,0)>0
							AND a.ProjectID = aa.projectID
							AND ((@Trans = '1' AND t.ActualTransferDate IS NOT NULL ) OR (@Trans = '0' AND t.ActualTransferDate IS  NULL) OR (ISNULL(@Trans, '') = '2' ))	
						Group By a.projectID),0)
		,AreaPrice = ISNULL((SELECT Round(ISNULL(Sum(uu.Amount),0)/1000000,2)
					From [crmrevo].sal.[Transfer] t  With(NoLock)
					left join [crmrevo].sal.Agreement a  With(NoLock) on t.AgreementID = a.id AND t.IsDeleted = 0 AND a.IsDeleted = 0
					Left Join (SELECT a.* FROM #vw_UnitPrice a WHERE  a.[Key] = '3') c ON c.BookingID= a.BookingID 
					LEFT JOIN (SELECT a.Amount , a.UnitPriceID FROM #UnitPriceItem a ) uu ON uu.UnitPriceID = c.id
					Where 1=1 and t.ActualTransferDate Is Not Null AND t.ActualTransferDate Between @DateStart  and @DateEnd--and Isnull(t.Approve3,0)=1 
						and (Isnull(@Projects,'')='' Or a.projectID In(SELECT * FROM [dbo].[fn_SplitString](@Projects,',')))
						AND a.projectID = aa.projectID
						AND ((@Trans = '1' AND t.ActualTransferDate IS NOT NULL and Isnull(t.IsReadyToTransfer,0)=1  ) OR (@Trans = '0' AND t.ActualTransferDate IS  NULL) OR (ISNULL(@Trans, '') = '2' ))	
					Group By a.projectID),0)
	,ExtraDiscount = 0
	FROM #Temp aa

	--SELECT * FROM #temp ORDER BY 
	--ProjectGroup
	--,BU
	--,Project,ProductID

	if(object_id('tempdb..##ExecutiveReport')is not null)drop table ##ExecutiveReport
	Select * into ##ExecutiveReport From #temp ORDER BY 
	ProjectGroup
	,BU
	,Project,ProductID


go

