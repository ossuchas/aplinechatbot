
CREATE PROCEDURE [dbo].[sp_proc_mail_est_reve_byproj]
AS
	SET NOCOUNT ON;

	DECLARE @seqn_no AS INT;
	DECLARE @projectid AS VARCHAR(20);
	DECLARE @types AS VARCHAR(50);
	DECLARE @months_no AS INT;
	DECLARE @actual AS FLOAT;

	DECLARE @curr_quarter AS INT

	SET @curr_quarter = DATEPART(QUARTER, GETDATE())
	--SET @curr_quarter = 3

	DECLARE db_cursor CURSOR FOR
	SELECT a.seqn_no, a.projectid, 'V' AS types, DATEPART(MONTH, ll.ActualTransferDate) AS months, 
	ROUND(SUM(ll.NetPriceExclFD)/1000000,2) AS actual
	FROM dbo.vw_ActualTransfer ll WITH(NOLOCK),
	dbo.crm_mail_est_reve_byproj a WITH(NOLOCK)
	 WHERE 1=1
	 AND a.projectid = ll.ProjectNo
	AND DATEPART(YEAR, ll.ActualTransferDate) = DATEPART(YEAR, GETDATE())
		  AND DATEPART(QUARTER, ll.ActualTransferDate)= @curr_quarter
		  GROUP BY a.seqn_no, a.projectid, DATEPART(MONTH, ll.ActualTransferDate)
	UNION ALL
	SELECT a.seqn_no, a.projectid, 'U' AS types, DATEPART(MONTH, ll.ActualTransferDate) AS months, 
	COUNT(ll.UnitNo) AS actual
	FROM dbo.vw_ActualTransfer ll WITH(NOLOCK),
	dbo.crm_mail_est_reve_byproj a WITH(NOLOCK)
	 WHERE 1=1
	 AND a.projectid = ll.ProjectNo
	AND DATEPART(YEAR, ll.ActualTransferDate) = DATEPART(YEAR, GETDATE())
		  AND DATEPART(QUARTER, ll.ActualTransferDate)= @curr_quarter
		  GROUP BY a.seqn_no, a.projectid, DATEPART(MONTH, ll.ActualTransferDate)


	OPEN db_cursor;
	FETCH NEXT FROM db_cursor INTO @seqn_no, @projectid, @types, @months_no, @actual


	WHILE @@FETCH_STATUS = 0
	BEGIN
		
		IF @types = 'V'
		BEGIN
		 --   PRINT 'Update Vol.'
			--PRINT @actual
			IF @months_no IN (1,4,7,10) BEGIN UPDATE dbo.crm_mail_est_reve_byproj SET curr_q_m1_ac_vol = @actual WHERE seqn_no = @seqn_no END;
			IF @months_no IN (2,5,8,11) BEGIN UPDATE dbo.crm_mail_est_reve_byproj SET curr_q_m2_ac_vol = @actual WHERE seqn_no = @seqn_no END;
			IF @months_no IN (3,6,9,12) BEGIN UPDATE dbo.crm_mail_est_reve_byproj SET curr_q_m3_ac_vol = @actual WHERE seqn_no = @seqn_no END;
		END
		ELSE
		BEGIN
		 --   PRINT 'Update Unit'
			--PRINT @actual
			IF @months_no IN (1,4,7,10) BEGIN UPDATE dbo.crm_mail_est_reve_byproj SET curr_q_m1_ac_u = @actual WHERE seqn_no = @seqn_no END;
			IF @months_no IN (2,5,8,11) BEGIN UPDATE dbo.crm_mail_est_reve_byproj SET curr_q_m2_ac_u = @actual WHERE seqn_no = @seqn_no END;
			IF @months_no IN (3,6,9,12) BEGIN UPDATE dbo.crm_mail_est_reve_byproj SET curr_q_m3_ac_u = @actual WHERE seqn_no = @seqn_no END;
		END

		FETCH NEXT FROM db_cursor INTO @seqn_no, @projectid, @types, @months_no, @actual
	END;

	CLOSE db_cursor;
	DEALLOCATE db_cursor;

	IF @curr_quarter = 1
	BEGIN
		--Update Current Quarteer from each month 1,2,3
		UPDATE dbo.crm_mail_est_reve_byproj
		SET curr_q1_ac_u = ISNULL(curr_q_m1_ac_u,0) + ISNULL(curr_q_m2_ac_u,0) + ISNULL(curr_q_m3_ac_u,0),
		curr_q1_ac_vol = ISNULL(curr_q_m1_ac_vol,0) + ISNULL(curr_q_m2_ac_vol,0) + ISNULL(curr_q_m3_ac_vol,0)
	END
	ELSE
	BEGIN
	   IF @curr_quarter = 2
	   BEGIN
		   --Update Current Quarteer from each month 1,2,3
		   UPDATE dbo.crm_mail_est_reve_byproj
		   SET curr_q2_ac_u = ISNULL(curr_q_m1_ac_u,0) + ISNULL(curr_q_m2_ac_u,0) + ISNULL(curr_q_m3_ac_u,0),
		   curr_q2_ac_vol = ISNULL(curr_q_m1_ac_vol,0) + ISNULL(curr_q_m2_ac_vol,0) + ISNULL(curr_q_m3_ac_vol,0)
	   END 
	   ELSE
	   BEGIN
	       IF @curr_quarter = 3
		   BEGIN
				--Update Current Quarteer from each month 1,2,3
				UPDATE dbo.crm_mail_est_reve_byproj
				SET curr_q3_ac_u = ISNULL(curr_q_m1_ac_u,0) + ISNULL(curr_q_m2_ac_u,0) + ISNULL(curr_q_m3_ac_u,0),
				curr_q3_ac_vol = ISNULL(curr_q_m1_ac_vol,0) + ISNULL(curr_q_m2_ac_vol,0) + ISNULL(curr_q_m3_ac_vol,0)

				SELECT  ISNULL(curr_q_m1_ac_u,0), ISNULL(curr_q_m2_ac_u,0), ISNULL(curr_q_m3_ac_u,0)
				FROM dbo.crm_mail_est_reve_byproj
		   END
		   ELSE
           BEGIN
			   --Update Current Quarteer from each month 1,2,3
				UPDATE dbo.crm_mail_est_reve_byproj
				SET curr_q4_ac_u = ISNULL(curr_q_m1_ac_u,0) + ISNULL(curr_q_m2_ac_u,0) + ISNULL(curr_q_m3_ac_u,0),
				curr_q4_ac_vol = ISNULL(curr_q_m1_ac_vol,0) + ISNULL(curr_q_m2_ac_vol,0) + ISNULL(curr_q_m3_ac_vol,0)
           END
	   END
	END

	--Update Total and Update YTD
	UPDATE dbo.crm_mail_est_reve_byproj
	SET qtd_curr_ac_u = ISNULL(curr_q_m1_ac_u,0) + ISNULL(curr_q_m2_ac_u,0) + ISNULL(curr_q_m3_ac_u,0),
	qtd_curr_q_ac_vol = ISNULL(curr_q_m1_ac_vol,0) + ISNULL(curr_q_m2_ac_vol,0) + ISNULL(curr_q_m3_ac_vol,0),
	--ytd_ac_u = ISNULL(curr_q1_ac_u,0) + ISNULL(curr_q_m1_ac_u,0) + ISNULL(curr_q_m2_ac_u,0) + ISNULL(curr_q_m3_ac_u,0),
	--ytd_ac_vol = ISNULL(curr_q1_ac_vol,0) + ISNULL(curr_q_m1_ac_vol,0) + ISNULL(curr_q_m2_ac_vol,0) + ISNULL(curr_q_m3_ac_vol,0)
	ytd_ac_u = ISNULL(curr_q1_ac_u,0) + ISNULL(curr_q2_ac_u,0) + ISNULL(curr_q3_ac_u,0) + ISNULL(curr_q4_ac_u,0),
	ytd_ac_vol = ISNULL(curr_q1_ac_vol,0) + ISNULL(curr_q2_ac_vol,0) + ISNULL(curr_q3_ac_vol,0) + ISNULL(curr_q4_ac_vol,0)



go

