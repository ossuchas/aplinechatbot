
Create FUNCTION [dbo].[fn_ClearTime]
(
	@Date datetime
)
RETURNS datetime
BEGIN
	RETURN CONVERT(DATE,@Date);
END
go

