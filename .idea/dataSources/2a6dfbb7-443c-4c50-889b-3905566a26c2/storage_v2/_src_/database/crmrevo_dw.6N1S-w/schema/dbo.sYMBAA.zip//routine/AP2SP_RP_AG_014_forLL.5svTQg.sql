Create PROCEDURE [dbo].[AP2SP_RP_AG_014_forLL] @ProjectID  UNIQUEIDENTIFIER=NULL,
    @UnitID varchar(8000)='',
	@DateStart  datetime =NULL,
	@DateEnd    datetime =NULL,	
	@DateStart2 datetime =NULL,
	@DateEnd2   datetime =NULL,	
	@DateStart3 datetime =NULL,
	@DateEnd3   datetime =NULL,	
    @UserName   nvarchar(250),
    @MinPriceType INT=0,  
	@StatusAG varchar(50)='',
	@HomeType nvarchar(20)='',
	@ProjectGroup nvarchar(5)='',
	@ProjectType2 UNIQUEIDENTIFIER=NULL,
	@EmpCode nvarchar(20)=''
AS
SET @StatusAG = ISNULL(@StatusAG,'')
IF(ISNULL(@DateStart,'')='') SET @DateStart='18000101'
IF(ISNULL(@DateEnd,'')='') SET @DateEnd='70000101'
IF(ISNULL(@DateStart2,'')='') SET @DateStart2='18000101'
IF(ISNULL(@DateEnd2,'')='') SET @DateEnd2='70000101'
IF(ISNULL(@DateStart3,'')='') SET @DateStart3='18000101'
IF(ISNULL(@DateEnd3,'')='') SET @DateEnd3='70000101'

DECLARE @DateEndInStore Datetime,@A varchar(10),@DateEndInStore2 Datetime,@DateEndInStore3 Datetime
SET @DateEndInStore = [crmrevo].[dbo].[fn_GetMaxDate](@DateEnd)
SET @DateEndInStore2 = [crmrevo].[dbo].[fn_GetMaxDate](@DateEnd2)
SET @DateEndInStore3 = [crmrevo].[dbo].[fn_GetMaxDate](@DateEnd3)
--SET @A = (Select CHARINDEX('''',@UnitNumber)) 
IF @MinPriceType = 0 SET @MinPriceType = NULL
IF @ProjectGroup = '0' SET @ProjectGroup = NULL
IF @StatusAG = '0' SET @StatusAG = NULL

if(object_id('tempdb..#tmpProject')is not null)drop table #tmpProject
SELECT DISTINCT BK.ID AS BookingID,PR.ID AS ProjectID,UN.ID AS UnitID,BK.BookingNo,BK.BookingDate,BK.CancelDate
INTO #tmpProject
FROM	[crmrevo].SAL.Booking BK WITH (NOLOCK)
		LEFT OUTER JOIN [crmrevo].SAL.Agreement AG WITH (NOLOCK) ON AG.BookingID = BK.ID AND ISNULL(AG.IsDeleted,0)=0 --AND ISNULL(AG.IsCancel,0)=0
		LEFT OUTER JOIN [crmrevo].SAL.Transfer TF WITH (NOLOCK) ON AG.ID = TF.AgreementID AND ISNULL(TF.IsDeleted,0) = 0
		LEFT OUTER JOIN [crmrevo].PRJ.Project PR WITH (NOLOCK) ON PR.ID = ISNULL(AG.ProjectID,BK.ProjectID)
		LEFT OUTER JOIN [crmrevo].PRJ.Unit UN WITH (NOLOCK) ON UN.ProjectID = PR.ID AND UN.ID = ISNULL(AG.UnitID,BK.UnitID)		
		LEFT OUTER JOIN [crmrevo].MST.BG BG WITH (NOLOCK) ON BG.ID = PR.BGID	
		LEFT OUTER JOIN (SELECT	A.Cost SuggestionPrice,A.ProjectID,A.UnitID,MC.[Key] MinPriceType
						FROM	[crmrevo].PRJ.MinPrice AS A WITH (NOLOCK)
						INNER JOIN (
									SELECT S.ProjectID,S.UnitID,MAX(S.ActiveDate) AS MAXImportDate
									FROM [crmrevo].PRJ.MinPrice S WITH (NOLOCK)
									GROUP BY S.ProjectID,S.UnitID
								)B ON A.ProjectID=B.ProjectID AND A.UnitID=B.UnitID AND A.ActiveDate = B.MAXImportDate
						INNER JOIN [crmrevo].MST.MasterCenter MC WITH (NOLOCK)ON MC.ID = A.MinPriceTypeMasterCenterID)
		MAXPRICE ON MAXPRICE.ProjectID = UN.ProjectID AND MAXPRICE.UnitID = UN.ID	
		LEFT JOIN [crmrevo].MST.MasterCenter AssetType WITH (NOLOCK) ON UN.AssetTypeMasterCenterID = AssetType.ID	
WHERE	AssetType.[Key] IN ('2','4')
		AND BK.BookingNo IS NOT NULL 
		AND BK.IsDeleted = 0
		AND  bk.id not in(Select BookingID From [crmrevo].dbo.vw_ChangeUnit)
		--AND  PR.ID IN (SELECT ProjectID FROM [dbo].[fn_GetProjectAuthorised](@EmpCode))
		AND (@ProjectID IS NULL OR PR.ID = @ProjectID)
		AND (ISNULL(@UnitID,'') ='' OR CONVERT(VARCHAR(36),UN.ID) IN (Select * From dbo.fn_SplitString (@UnitID,',')))
		AND (ISNULL(BK.BookingDate,'18000101') Between @DateStart and @DateEndInStore)
		AND (ISNULL(BK.BookingDate,'18000101') <= @DateEndInStore)
		AND (ISNULL(AG.ContractDate,'18000101') Between @DateStart2 and @DateEndInStore2)
		AND (ISNULL(AG.ContractDate,'18000101') <= @DateEndInStore2)
		AND (ISNULL(TF.ActualTransferDate,'18000101') Between @DateStart3 and @DateEndInStore3)
		AND (ISNULL(TF.ActualTransferDate,'18000101') <= @DateEndInStore3)
		AND (ISNULL(@MinPriceType,'') = '' OR MAXPRICE.MinPriceType = @MinPriceType)
		AND ((ISNULL(@StatusAG,'') = '')
			OR (@StatusAG = '1' AND (BK.CancelDate IS NULL OR AG.IsCancel = 0))
			OR (@StatusAG = '2' AND (BK.CancelDate IS NOT NULL OR AG.IsCancel = 1))
			OR (@StatusAG = '3' AND TF.ActualTransferDate IS NULL)-- ยังไม่โอน
			OR (@StatusAG = '4' AND ((BK.CancelDate IS NULL OR AG.IsCancel = 0) AND TF.ActualTransferDate IS NOT NULL))-- โอนแล้ว
			)
		AND (ISNULL(@HomeType,'')='' OR BG.BGNo = @HomeType)
		AND (ISNULL(@ProjectGroup,'')='' OR PR.[Group] = @ProjectGroup)
		AND (@ProjectType2 IS NULL OR PR.ProjectTypeMasterCenterID = @ProjectType2)

if(object_id('tempdb..#tmpTFPrice')is not null)drop table #tmpTFPrice

SELECT UP.BookingID,ISNULL(UPI.Amount,0) AS IncreasingAreaPrice
INTO #tmpTFPrice
FROM #tmpProject BK WITH (NOLOCK)
LEFT JOIN [crmrevo].SAL.UnitPrice UP WITH (NOLOCK) ON UP.BookingID = BK.BookingID
LEFT JOIN [crmrevo].SAL.UnitPriceItem UPI WITH (NOLOCK) ON UPI.UnitPriceID = UP.ID AND UPI.IsDeleted = 0
LEFT JOIN [crmrevo].MST.MasterCenter MC WITH (NOLOCK) ON MC.ID = UP.UnitPriceStageMasterCenterID
LEFT JOIN [crmrevo].MST.MasterPriceItem MPI WITH (NOLOCK) ON MPI.ID = UPI.MasterPriceItemID
WHERE 1=1
AND MC.[Key]='3' AND MPI.[Key] = 'ExtraAreaPrice'--Transfer
AND UP.IsDeleted = 0
GROUP BY UP.BookingID,UPI.Amount


if(object_id('tempdb..#tmpUP')is not null)drop table #tmpUP
SELECT UP.BookingID,MC.[Key] AS stage,UP.SellingPrice AS TotalSellingPrice,UP.CashDiscount,UP.TransferDiscount,UP.FGFDiscount,UP.AgreementPrice AS SellingPrice,UP.FreedownDiscount
		,UP.NetPrice,MC.Name AS UnitPriceStage,UP.IsActive
INTO #tmpUP
FROM #tmpProject BK 
LEFT JOIN [crmrevo].SAL.UnitPrice UP WITH (NOLOCK) ON UP.BookingID = BK.BookingID  AND UP.IsDeleted = 0
LEFT JOIN [crmrevo].MST.MasterCenter MC WITH (NOLOCK) ON MC.ID = UP.UnitPriceStageMasterCenterID
WHERE 1=1
--AND MC.[Key] IN ('1','2','3') 
GROUP BY UP.BookingID,MC.[Key],UP.SellingPrice,UP.CashDiscount,UP.TransferDiscount,UP.FGFDiscount,UP.AgreementPrice,UP.FreedownDiscount,UP.NetPrice,MC.Name,UP.IsActive

if(object_id('tempdb..#tmpZPS')is not null)drop table #tmpZPS
SELECT	C.BookingID DocumentID,SUM(A.Quantity*A.PricePerUnit) AS SPPrice
INTO #tmpZPS
FROM #tmpProject BK WITH (NOLOCK)	
LEFT JOIN [crmrevo].PRM.SalePromotion C WITH (NOLOCK)	ON C.BookingID = BK.BookingID 
LEFT OUTER JOIN [crmrevo].PRM.SalePromotionItem A WITH (NOLOCK) ON A.SalePromotionID = C.ID AND A.IsDeleted = 0
WHERE	ISNULL(A.Quantity,0) > 0 AND ISNULL(A.PricePerUnit,0) > 0 
AND C.IsDeleted = 0
AND C.IsActive = 1
--AND  BK.ProjectID IN (SELECT ProjectID FROM [dbo].[fn_GetProjectAuthorised](@EmpCode))		
GROUP BY C.BookingID

if(object_id('tempdb..#tmpZPSF')is not null)drop table #tmpZPSF
SELECT	C.BookingID DocumentID,SUM(A.Quantity*A.PricePerUnit) AS SPPrice
INTO #tmpZPSF
FROM #tmpProject BK WITH (NOLOCK)
LEFT JOIN  [crmrevo].PRM.PreSalePromotion C WITH (NOLOCK)	ON C.BookingID=BK.BookingID 
LEFT OUTER JOIN [crmrevo].PRM.PreSalePromotionItem A WITH (NOLOCK) ON A.PreSalePromotionID = C.ID AND A.IsDeleted=0
WHERE	1=1
AND A.Quantity > 0 
AND A.PricePerUnit > 0 
AND C.IsDeleted = 0
--AND  BK.ProjectID IN (SELECT ProjectID FROM [dbo].[fn_GetProjectAuthorised](@EmpCode))
GROUP BY C.BookingID

if(object_id('tempdb..#tmpZSF')is not null)drop table #tmpZSF
SELECT  A.BookingID AS DocumentID,
		SUM(CASE C.[Key] WHEN 'TransferFee' THEN B.Amount / 2 ELSE B.Amount END) AS SFPrice
INTO #tmpZSF
FROM #tmpProject BK	
LEFT JOIN [crmrevo].PRM.SalePromotion A WITH (NOLOCK) ON A.BookingID = BK.BookingID
LEFT OUTER JOIN [crmrevo].PRM.SalePromotionExpense B WITH (NOLOCK)ON B.SalePromotionID = A.ID AND B.IsDeleted = 0
LEFT OUTER JOIN [crmrevo].MST.MasterPriceItem C WITH (NOLOCK)ON C.ID = B.MasterPriceItemID
LEFT OUTER JOIN [crmrevo].MST.MasterCenter D WITH (NOLOCK)ON D.ID = B.ExpenseReponsibleByMasterCenterID
WHERE   ((C.[Key] = 'TransferFee' AND D.[Key]='0') OR (C.[Key] IN ('CommonFeeChargeAPPay','CommonFeeCharge','ElectricMeter','WaterMeter','MortgageFee','FirstSinkingFund','DocumentFeeCharge') AND D.[Key] IN ('0','2')))
AND A.IsDeleted = 0
AND A.IsActive = 1
--AND  BK.ProjectID IN (SELECT ProjectID FROM [dbo].[fn_GetProjectAuthorised](@EmpCode))	
GROUP BY A.BookingID


if(object_id('tempdb..#tmpZTP')is not null)drop table #tmpZTP
SELECT	ZT.BookingID,SUM(ZS.Quantity*ZS.PricePerUnit) AS TFPPrice
INTO #tmpZTP
FROM #tmpProject BK
LEFT JOIN [crmrevo].PRM.TransferPromotion ZT WITH (NOLOCK) ON ZT.BookingID = BK.BookingID
LEFT OUTER JOIN [crmrevo].PRM.TransferPromotionItem ZS WITH (NOLOCK)ON ZT.ID = ZS.TransferPromotionID AND ZS.IsDeleted = 0
WHERE	ISNULL(ZT.IsDeleted,0) = 0 AND ISNULL(ZT.IsApprove,0) = 1	
GROUP BY ZT.BookingID

if(object_id('tempdb..#tmpZTF')is not null)drop table #tmpZTF
SELECT  ZT.BookingID,SUM(CASE MP.[Key] WHEN 'TransferFee' THEN ZF.Amount / 2 ELSE ZF.Amount END) AS TFFPrice
INTO #tmpZTF
FROM #tmpProject BK
LEFT JOIN [crmrevo].PRM.TransferPromotion ZT WITH (NOLOCK) ON ZT.BookingID = BK.BookingID
LEFT OUTER JOIN [crmrevo].PRM.TransferPromotionExpense ZF WITH (NOLOCK)ON ZT.ID = ZF.TransferPromotionID AND ZF.IsDeleted = 0
LEFT OUTER JOIN [crmrevo].MST.MasterPriceItem MP WITH (NOLOCK)ON MP.ID = ZF.MasterPriceItemID
LEFT OUTER JOIN [crmrevo].MST.MasterCenter MC WITH (NOLOCK)ON MC.ID = ZF.ExpenseReponsibleByMasterCenterID
WHERE   ISNULL(ZT.IsDeleted,0) = 0 AND ISNULL(ZT.IsApprove,0) = 1 
		AND ((MP.[Key] = 'TransferFee' AND MC.[Key]='0') 
			OR (MP.[Key] IN ('CommonFeeCharge','ElectricMeter','WaterMeter','MortgageFee','FirstSinkingFund','DocumentFeeCharge') AND MC.[Key] IN ('0','2')))	
--AND  BK.ProjectID IN (SELECT ProjectID FROM [dbo].[fn_GetProjectAuthorised](@EmpCode))
GROUP BY ZT.BookingID

if(object_id('tempdb..#tmpZRP')is not null)drop table #tmpZRP
SELECT S.BookingID AS DocumentID,SUM(RD.Quantity*PD.PricePerunit) AS TotalReceivePromotion
INTO #tmpZRP
FROM #tmpProject BK WITH (NOLOCK)
LEFT OUTER JOIN [crmrevo].PRM.SalePromotion S WITH (NOLOCK) ON S.BookingID = BK.BookingID AND S.IsDeleted = 0
LEFT OUTER JOIN [crmrevo].PRM.SalePromotionItem SI WITH (NOLOCK) ON SI.SalePromotionID = S.ID AND SI.IsDeleted = 0
LEFT OUTER JOIN [crmrevo].PRM.MasterSalePromotionItem PD WITH (NOLOCK) ON SI.MasterSalePromotionItemID=PD.ID AND PD.IsDeleted = 0
LEFT OUTER JOIN [crmrevo].PRM.SalePromotionRequestItem RD WITH (NOLOCK) ON RD.SalePromotionItemID = SI.ID AND RD.IsDeleted = 0
LEFT OUTER JOIN [crmrevo].PRM.SalePromotionRequest R WITH (NOLOCK) ON R.ID = RD.SalePromotionRequestID AND R.IsDeleted = 0
WHERE R.PromotionRequestPRStatusMasterCenterID = (SELECT ID  FROM [crmrevo].MST.MasterCenter WHERE MasterCenterGroupKey = 'PromotionRequestPRStatus' AND [Key]='1')
--AND  BK.ProjectID IN (SELECT ProjectID FROM [dbo].[fn_GetProjectAuthorised](@EmpCode))	
GROUP BY S.BookingID

if(object_id('tempdb..#tmpZM')is not null)drop table #tmpZM
SELECT A.ProjectID ProductID,B.UnitNumber,A.SellingPrice AS MinPrice,MC2.Name DocumentType,
				CASE WHEN MC.[Key] = '2' OR MC.[Key] = '3' THEN 'Sale Price*'
					WHEN MC.[Key] = '1' THEN 'Quarterly*' END AS MinPriceType	
				,A.BookingID
INTO #tmpZM						
FROM #tmpProject BK
LEFT JOIN [crmrevo].SAL.MinPriceBudgetWorkflow A  WITH (NOLOCK)ON A.BookingID = BK.BookingID
LEFT JOIN [crmrevo].PRJ.Project PR WITH (NOLOCK)ON PR.ID = A.ProjectID
LEFT JOIN [crmrevo].PRJ.Unit U WITH (NOLOCK)ON U.ID = BK.UnitID
LEFT JOIN [crmrevo].MST.MasterCenter MC WITH (NOLOCK)ON MC.ID = A.MinPriceWorkflowTypeMasterCenterID AND MC.MasterCenterGroupKey='MinPriceWorkflowType' 
LEFT JOIN [crmrevo].MST.MasterCenter MC2 WITH (NOLOCK)ON MC2.ID = A.MinPriceBudgetWorkflowStageMasterCenterID AND MC2.MasterCenterGroupKey='MinPriceBudgetWorkflowStage'
INNER JOIN  (
		SELECT M.ProjectID AS ProductID,U.ID UnitNumber,MAX(M.Created) AS MaxDate  
		FROM [crmrevo].SAL.MinPriceBudgetWorkflow M WITH (NOLOCK)
		LEFT JOIN [crmrevo].SAL.Booking BK WITH (NOLOCK)ON BK.ID = M.BookingID 
		LEFT JOIN [crmrevo].PRJ.Unit U WITH (NOLOCK)ON U.ID = BK.UnitID
		WHERE M.IsApproved = 1 AND M.IsCancelled=0 AND M.IsDeleted = 0
		AND M.MinPriceWorkflowTypeMasterCenterID NOT IN (SELECT ID FROM [crmrevo].MST.MasterCenter WHERE MasterCenterGroupKey='MinPriceWorkflowType' AND [Key]='4')--'Extra'
		GROUP BY M.ProjectID, U.ID
	) AS B ON A.ProjectID = B.ProductID AND U.ID = B.UnitNumber AND B.MaxDate = A.Created
WHERE A.IsApproved = 1 AND A.IsCancelled=0 
AND A.MinPriceWorkflowTypeMasterCenterID NOT IN (SELECT ID FROM [crmrevo].MST.MasterCenter WHERE MasterCenterGroupKey='MinPriceWorkflowType' AND [Key]='4')--'Extra'
AND U.AssetTypeMasterCenterID  IN (SELECT ID FROM [crmrevo].MST.MasterCenter WHERE MasterCenterGroupKey='AssetType' AND [Key] IN ('2','4'))

SELECT	BG.BGNo AS BUID
		,PR.ProjectNo AS ProductID
		,PR.ProjectNameTH AS ProjectName
		,UN.UnitNo AS UnitNumber,
		'AreaSale' = ISNULL(TD.TitledeedArea,ISNULL(UN.SaleArea,0)),
		CONVERT(DATETIME,BK.BookingDate) BookingDate
		,'CancelDate' = CONVERT(DATETIME,ISNULL(CN.Created,BK.CancelDate))
		,'TransferDueDate' = CONVERT(DATETIME,TF.ActualTransferDate)
		,'StatusName' = CASE WHEN BK.CancelDate IS NOT NULL OR AG.IsCancel = 1 THEN 'ยกเลิก'
					WHEN TF.TransferNo IS NOT NULL AND TF.ActualTransferDate IS NOT NULL THEN 'โอน' 
					WHEN AG.AgreementNo IS NOT NULL AND TF.ActualTransferDate IS NULL THEN 'สัญญา' 
					WHEN BK.BookingNo IS NOT NULL AND AG.AgreementNo IS NULL THEN 'จอง' 
					ELSE 'ว่าง' END,
		'TotalSellingPrice' = ISNULL(ISNULL(UPAG.TotalSellingPrice,UPBK.TotalSellingPrice),0),
		'CashDiscount' = ISNULL(ISNULL(UPAG.CashDiscount,UPBK.CashDiscount),0) + ISNULL(ISNULL(UPAG.TransferDiscount,UPBK.TransferDiscount),0),
		'SellingPrice' = ISNULL(ISNULL(UPAG.SellingPrice,UPBK.SellingPrice),0) - ISNULL(ISNULL(UPAG.TransferDiscount,UPBK.TransferDiscount),0),
		'MinROI' = ISNULL(MaxOGN.SuggestionPrice, ISNULL(MinROI.SuggestionPrice,0)),
		'MaxROI' = ISNULL(MaxROI.SuggestionPrice, ISNULL(MaxOGN.SuggestionPrice,0)),
		'MaxPType' = ISNULL(ZM.MinPriceType,CASE MAXPRICE.MinPriceType WHEN 1 THEN 'Original'
							WHEN 2 THEN 'ROI'
							WHEN 3 THEN 'Sale Price'
							WHEN 4 THEN 'Quarterly' End),
		'MaxMinPrice' = ISNULL(ISNULL(ZM.MinPrice,MAXPRICE.SuggestionPrice),0),
		'TotalSalePromotionAmount' = CONVERT(NUMERIC,(ISNULL(ZSP.SPPrice,0)+ISNULL(ZSPF.SPPrice,0) + ISNULL(ZSF.SFPrice,0) + ISNULL(ISNULL(UPAG.FGFDiscount,UPBK.FGFDiscount),0))),
		'TransferPromotionTransferDiscount' = CASE WHEN ISNULL(ZT.TransferDiscount,0) = 0 THEN ISNULL(UPPro.TransferDiscount,0) ELSE ISNULL(ZT.TransferDiscount,0) END,
		'TotalTransferPromotionAmount' = ISNULL(ZTP.TFPPrice,0) + ISNULL(ZTF.TFFPrice,0),
		'TotalPromotionAmount' = CONVERT(NUMERIC,(ISNULL(ZSP.SPPrice,0)+ISNULL(ZSPF.SPPrice,0) + ISNULL(ZSF.SFPrice,0) + ISNULL(ISNULL(UPAG.FGFDiscount,UPBK.FGFDiscount),0) 
			+ (/*comfirm by P'kai 20200921 ISNULL(ZT.TransferDiscount,0)*/ + ISNULL(ZTP.TFPPrice,0) + ISNULL(ZTF.TFFPrice,0)))),
		'TotalReceivePromotion' = CONVERT(NUMERIC,ISNULL(ZRP.TotalReceivePromotion,0)),
		'IncreasingAreaPrice' = ISNULL((SELECT IncreasingAreaPrice FROM #tmpTFPrice WHERE BookingID =  ISNULL(AG.BookingID,BK.BookingID)),0),
		'Freedown' = ISNULL(ISNULL(UPAG.FreedownDiscount,UPBK.FreedownDiscount),0)
FROM	#tmpProject BK WITH (NOLOCK)
		LEFT OUTER JOIN [crmrevo].SAL.Agreement AG WITH (NOLOCK) ON AG.BookingID = BK.BookingID AND ISNULL(AG.IsDeleted,0)=0 --AND ISNULL(AG.IsCancel,0)=0
		LEFT OUTER JOIN [crmrevo].SAL.CancelMemo CN WITH (NOLOCK) ON CN.AgreementID = AG.ID AND CN.IsDeleted = 0
		LEFT OUTER JOIN [crmrevo].SAL.Transfer TF WITH (NOLOCK) ON AG.ID = TF.AgreementID AND ISNULL(TF.IsDeleted,0) = 0
		LEFT OUTER JOIN [crmrevo].PRJ.Project PR WITH (NOLOCK) ON PR.ID = ISNULL(AG.ProjectID,BK.ProjectID)
		LEFT OUTER JOIN [crmrevo].PRJ.Unit UN WITH (NOLOCK) ON UN.ProjectID = PR.ID AND UN.ID = ISNULL(AG.UnitID,BK.UnitID)		
		LEFT OUTER JOIN [crmrevo].MST.BG BG WITH (NOLOCK) ON BG.ID = PR.BGID
		LEFT OUTER JOIN [crmrevo].PRJ.TitledeedDetail TD WITH (NOLOCK) ON TD.UnitID = UN.ID AND TD.ProjectID = PR.ID AND TD.IsDeleted = 0
		OUTER APPLY (SELECT TOP 1 * FROM #tmpUP UPBK WHERE UPBK.BookingID = BK.BookingID AND UPBK.stage='1' ORDER BY UPBK.IsActive DESC) UPBK
		OUTER APPLY (SELECT TOP 1 * FROM #tmpUP UPAG WHERE UPAG.BookingID = BK.BookingID AND UPAG.stage='2' ORDER BY UPAG.IsActive DESC) UPAG
		OUTER APPLY (SELECT TOP 1 * FROM #tmpUP UPPro WHERE UPPro.BookingID = BK.BookingID AND UPPro.stage='4' ORDER BY UPPro.IsActive DESC) UPPro
		--LEFT JOIN #tmpUP UPBK ON UPBK.BookingID = BK.ID AND UPBK.stage='1'
		--LEFT JOIN #tmpUP UPAG ON UPAG.BookingID = BK.ID AND UPAG.stage='2'
		--LEFT JOIN #tmpUP UPPro ON UPPro.BookingID = BK.ID AND UPPro.stage='4'
		LEFT OUTER JOIN	(
			SELECT A.Cost SuggestionPrice,A.ProjectID,A.UnitID
			FROM [crmrevo].PRJ.MinPrice  AS A WITH (NOLOCK) INNER JOIN (
				SELECT S.ProjectID,S.UnitID,MIN(S.ActiveDate) AS MinDate
				FROM [crmrevo].PRJ.MinPrice S WITH (NOLOCK)
				WHERE S.MinPriceTypeMasterCenterID = (SELECT ID FROM [crmrevo].MST.MasterCenter WHERE MasterCenterGroupKey='MinPriceType' AND [Key]='2') -- ROI
				GROUP BY S.ProjectID,S.UnitID
			) AS B ON A.ProjectID=B.ProjectID AND A.UnitID=B.UnitID AND A.ActiveDate=B.MinDate
		)MinROI ON MinROI.ProjectID = UN.ProjectID AND MinROI.UnitID = UN.ID
		LEFT OUTER JOIN (
			SELECT A.Cost SuggestionPrice,A.ProjectID,A.UnitID
			FROM [crmrevo].PRJ.MinPrice AS A WITH (NOLOCK) INNER JOIN (
				SELECT S.ProjectID,S.UnitID,MAX(S.ActiveDate) AS MinDate
				FROM [crmrevo].PRJ.MinPrice S WITH (NOLOCK)
				WHERE S.MinPriceTypeMasterCenterID = (SELECT ID FROM [crmrevo].MST.MasterCenter WHERE MasterCenterGroupKey='MinPriceType' AND [Key]='2') -- ROI
				GROUP BY S.ProjectID,S.UnitID
			) AS B ON A.ProjectID=B.ProjectID AND A.UnitID=B.UnitID AND A.ActiveDate=B.MinDate
		)MaxROI ON MaxROI.ProjectID = UN.ProjectID AND MaxROI.UnitID = UN.ID 	
		LEFT OUTER JOIN (
			SELECT A.Cost SuggestionPrice,A.ProjectID,A.UnitID
			FROM [crmrevo].PRJ.MinPrice AS A WITH (NOLOCK) INNER JOIN (
				SELECT S.ProjectID,S.UnitID,MAX(S.ActiveDate) AS MinDate
				FROM [crmrevo].PRJ.MinPrice S WITH (NOLOCK)
				WHERE S.MinPriceTypeMasterCenterID = (SELECT ID FROM [crmrevo].MST.MasterCenter WHERE MasterCenterGroupKey='MinPriceType' AND [Key]='1') -- Original
				GROUP BY S.ProjectID,S.UnitID
			) AS B ON A.ProjectID=B.ProjectID AND A.UnitID=B.UnitID AND A.ActiveDate=B.MinDate
		)MaxOGN ON MaxOGN.ProjectID = UN.ProjectID AND MaxOGN.UnitID = UN.ID 
		LEFT OUTER JOIN #tmpZM ZM ON /*ZM.BookingID=BK.ID AND*/ BK.ProjectID=ZM.ProductID AND BK.UnitID=ZM.UnitNumber 	
		LEFT OUTER JOIN (
			SELECT	A.Cost SuggestionPrice,A.ProjectID,A.UnitID,MC.[Key] MinPriceType
			FROM	[crmrevo].PRJ.MinPrice AS A WITH (NOLOCK)
			INNER JOIN (
						SELECT S.ProjectID,S.UnitID,MAX(S.ActiveDate) AS MAXImportDate
						FROM [crmrevo].PRJ.MinPrice S WITH (NOLOCK)
						GROUP BY S.ProjectID,S.UnitID
					)B ON A.ProjectID=B.ProjectID AND A.UnitID=B.UnitID AND A.ActiveDate = B.MAXImportDate
			INNER JOIN [crmrevo].MST.MasterCenter MC WITH (NOLOCK)ON MC.ID = A.MinPriceTypeMasterCenterID
		)MAXPRICE ON MAXPRICE.ProjectID = UN.ProjectID AND MAXPRICE.UnitID = UN.ID
		LEFT OUTER JOIN [crmrevo].PRM.TransferPromotion ZT WITH (NOLOCK) ON ISNULL(AG.BookingID,BK.BookingID)  = ZT.BookingID AND ISNULL(ZT.IsDeleted,0) = 0 AND ISNULL(ZT.IsApprove,0) = 1
		LEFT OUTER JOIN	#tmpZPS ZSP ON ZSP.DocumentID = ISNULL(AG.BookingID,BK.BookingID) 
		LEFT OUTER JOIN	#tmpZPSF ZSPF ON ZSPF.DocumentID = ISNULL(AG.BookingID,BK.BookingID) 
		LEFT OUTER JOIN #tmpZSF ZSF ON ZSF.DocumentID = ISNULL(AG.BookingID,BK.BookingID)
		LEFT OUTER JOIN	#tmpZTP ZTP ON ZTP.BookingID = ISNULL(AG.BookingID,BK.BookingID) 
		LEFT OUTER JOIN #tmpZTF ZTF ON ZTF.BookingID = ISNULL(AG.BookingID,BK.BookingID) 
		LEFT OUTER JOIN #tmpZRP ZRP ON ZRP.DocumentID = ISNULL(AG.BookingID,BK.BookingID) 			
WHERE	UN.AssetTypeMasterCenterID  IN (SELECT ID FROM [crmrevo].MST.MasterCenter WHERE MasterCenterGroupKey='AssetType' AND [Key] IN ('2','4'))
		--AND BK.BookingNo IS NOT NULL 
		--AND BK.IsDeleted = 0
		--AND  bk.id not in(Select BookingID From vw_ChangeUnit)
		----AND  PR.ID IN (SELECT ProjectID FROM [dbo].[fn_GetProjectAuthorised](@EmpCode))
		--AND (@ProjectID IS NULL OR PR.ID = @ProjectID)
		--AND (ISNULL(@UnitID,'') ='' OR UN.ID IN (Select * From dbo.fn_SplitString (@UnitID,',')))
		--AND (ISNULL(BK.BookingDate,'18000101') Between @DateStart and @DateEndInStore)
		--AND (ISNULL(BK.BookingDate,'18000101') <= @DateEndInStore)
		--AND (ISNULL(AG.ContractDate,'18000101') Between @DateStart2 and @DateEndInStore2)
		--AND (ISNULL(AG.ContractDate,'18000101') <= @DateEndInStore2)
		--AND (ISNULL(TF.ActualTransferDate,'18000101') Between @DateStart3 and @DateEndInStore3)
		--AND (ISNULL(TF.ActualTransferDate,'18000101') <= @DateEndInStore3)
		--AND (ISNULL(@MinPriceType,'') = '' OR MAXPRICE.MinPriceType = @MinPriceType)
		--AND ((ISNULL(@StatusAG,'') = '')
		--	OR (@StatusAG = '1' AND (BK.CancelDate IS NULL OR AG.IsCancel = 0))
		--	OR (@StatusAG = '2' AND (BK.CancelDate IS NOT NULL OR AG.IsCancel = 1))
		--	OR (@StatusAG = '3' AND TF.ActualTransferDate IS NULL)-- ยังไม่โอน
		--	OR (@StatusAG = '4' AND ((BK.CancelDate IS NULL OR AG.IsCancel = 0) AND TF.ActualTransferDate IS NOT NULL))-- โอนแล้ว
		--	)
		--AND (ISNULL(@HomeType,'')='' OR BG.BGNo = @HomeType)
		--AND (ISNULL(@ProjectGroup,'')='' OR PR.[Group] = @ProjectGroup)
		--AND (@ProjectType2 IS NULL OR PR.ProjectTypeMasterCenterID = @ProjectType2)


UNION SELECT	BG.BGNo AS BUID
		,PR.ProjectNo AS ProductID
		,PR.ProjectNameTH AS ProjectName
		,UN.UnitNo AS UnitNumber,
		'AreaSale' = ISNULL(TD.TitledeedArea,ISNULL(UN.SaleArea,0)),NULL,NULL,NULL,'ว่าง',0,0,0,			
		'MinROI' = ISNULL(MaxOGN.SuggestionPrice, ISNULL(MinROI.SuggestionPrice,0)),
		'MaxROI' = ISNULL(MaxROI.SuggestionPrice, ISNULL(MaxOGN.SuggestionPrice,0)),
		'MaxPType' = CASE MAXPRICE.MinPriceType WHEN 1 THEN 'Original' WHEN 2 THEN 'ROI' WHEN 3 THEN 'Sale Price' WHEN 4 THEN 'Quarterly' End,
		'MaxMinPrice' = ISNULL(MAXPRICE.SuggestionPrice,0),0,0,0,0,0,0,0
FROM	[crmrevo].PRJ.Unit UN WITH (NOLOCK)
		LEFT OUTER JOIN [crmrevo].PRJ.Project PR WITH (NOLOCK)ON PR.ID = UN.ProjectID 
		LEFT OUTER JOIN [crmrevo].MST.BG BG WITH (NOLOCK)ON BG.ID = PR.BGID
		LEFT OUTER JOIN [crmrevo].PRJ.TitledeedDetail TD WITH (NOLOCK)ON TD.UnitID = UN.ID AND TD.ProjectID = PR.ID
		--LEFT OUTER JOIN ICON_EntForms_Booking BK ON BK.ProductID = UN.ProductID AND BK.UnitNumber = UN.UnitNumber
		LEFT OUTER JOIN	(
			SELECT A.Cost SuggestionPrice,A.ProjectID,A.UnitID
			FROM [crmrevo].PRJ.MinPrice AS A INNER JOIN (
				SELECT S.ProjectID,S.UnitID,MIN(S.ActiveDate) AS MinDate
				FROM [crmrevo].PRJ.MinPrice S WITH (NOLOCK)
				WHERE S.MinPriceTypeMasterCenterID = (SELECT ID FROM [crmrevo].MST.MasterCenter WHERE MasterCenterGroupKey='MinPriceType' AND [Key]='2') -- ROI
				GROUP BY S.ProjectID,S.UnitID
			) AS B ON A.ProjectID=B.ProjectID AND A.UnitID=B.UnitID AND A.ActiveDate=B.MinDate
		)MinROI ON MinROI.ProjectID = UN.ProjectID AND MinROI.UnitID = UN.ID
		LEFT OUTER JOIN (
			SELECT A.Cost SuggestionPrice,A.ProjectID,A.UnitID
			FROM [crmrevo].PRJ.MinPrice AS A INNER JOIN (
				SELECT S.ProjectID,S.UnitID,MAX(S.ActiveDate) AS MinDate
				FROM [crmrevo].PRJ.MinPrice S WITH (NOLOCK)
				WHERE S.MinPriceTypeMasterCenterID = (SELECT ID FROM [crmrevo].MST.MasterCenter WHERE MasterCenterGroupKey='MinPriceType' AND [Key]='2') -- ROI
				GROUP BY S.ProjectID,S.UnitID
			) AS B ON A.ProjectID=B.ProjectID AND A.UnitID=B.UnitID AND A.ActiveDate=B.MinDate
		)MaxROI ON MaxROI.ProjectID = UN.ProjectID AND MaxROI.UnitID = UN.ID 	
		LEFT OUTER JOIN (
			SELECT A.Cost SuggestionPrice,A.ProjectID,A.UnitID
			FROM [crmrevo].PRJ.MinPrice AS A INNER JOIN (
				SELECT S.ProjectID,S.UnitID,MAX(S.ActiveDate) AS MinDate
				FROM [crmrevo].PRJ.MinPrice S WITH (NOLOCK)
				WHERE S.MinPriceTypeMasterCenterID = (SELECT ID FROM [crmrevo].MST.MasterCenter WHERE MasterCenterGroupKey='MinPriceType' AND [Key]='1') -- Original
				GROUP BY S.ProjectID,S.UnitID
			) AS B ON A.ProjectID=B.ProjectID AND A.UnitID=B.UnitID AND A.ActiveDate=B.MinDate
		)MaxOGN ON MaxOGN.ProjectID = UN.ProjectID AND MaxOGN.UnitID = UN.ID 	
		LEFT OUTER JOIN (
			SELECT	A.Cost SuggestionPrice,A.ProjectID,A.UnitID,MC.[Key] MinPriceType
			FROM	[crmrevo].PRJ.MinPrice AS A 
			INNER JOIN (
						SELECT S.ProjectID,S.UnitID,MAX(S.ActiveDate) AS MAXImportDate
						FROM [crmrevo].PRJ.MinPrice S WITH (NOLOCK)
						GROUP BY S.ProjectID,S.UnitID
					)B ON A.ProjectID=B.ProjectID AND A.UnitID=B.UnitID AND A.ActiveDate = B.MAXImportDate
			INNER JOIN [crmrevo].MST.MasterCenter MC ON MC.ID = A.MinPriceTypeMasterCenterID
		)MAXPRICE ON MAXPRICE.ProjectID = UN.ProjectID AND MAXPRICE.UnitID = UN.ID				
WHERE	UN.AssetTypeMasterCenterID  IN (SELECT ID FROM [crmrevo].MST.MasterCenter WHERE MasterCenterGroupKey='AssetType' AND [Key] IN ('2','4'))
		--AND EXISTS(SELECT * FROM SAL.Booking WHERE ProjectID = UN.ProjectID AND UnitID = UN.ID AND CancelDate IS NOT NULL)	
	AND NOT EXISTS(SELECT * 
				FROM [crmrevo].SAL.Booking BK 
				WHERE BK.ProjectID = UN.ProjectID 
					AND BK.UnitID = UN.ID 
					AND BK.IsDeleted = 0
					AND BK.IsCancelled = 0
					AND BK.BookingNo IS NOT NULL 
					AND  bk.id not in(Select BookingID From [crmrevo].dbo.vw_ChangeUnit))

	--AND (PR.ProductID = '''+ISNULL(@ProductID,'')+''') '
	AND (@ProjectID IS NULL OR PR.ID = @ProjectID)
	AND (ISNULL(@UnitID,'') ='' OR UN.ID IN (Select * From dbo.fn_SplitString (@UnitID,',')))
	AND 1= CASE WHEN (Year(@DateStart) <> 1800) AND (Year(@DateEnd) <> 7000) AND ISNULL(@DateStart,'')<>'' AND ISNULL(@DateEnd,'')<>'' THEN 0 ELSE 1 END
	AND 1= CASE WHEN (Year(@DateStart2) <> 1800) AND (Year(@DateEnd2) <> 7000) AND ISNULL(@DateStart2,'')<>'' AND ISNULL(@DateEnd2,'')<>'' THEN 0 ELSE 1 END
	AND 1= CASE WHEN (Year(@DateStart3) <> 1800) AND (Year(@DateEnd3) <> 7000) AND ISNULL(@DateStart3,'')<>'' AND ISNULL(@DateEnd3,'')<>'' THEN 0 ELSE 1 END


--set @sql=@sql+' AND '''+@StatusAG+''' IN ('''',''1'',''3'')'

--IF(@StatusAG = '2')set @sql=@sql+' AND (ISNULL(AG.Canceldate,BK.CancelDate) IS NOT NULL)'
--IF(@StatusAG = '3')set @sql=@sql+' AND (TF.TransferDateApprove IS NULL)' -- ยังไม่โอน
--IF(@StatusAG = '4')set @sql=@sql+' AND (ISNULL(AG.Canceldate,BK.CancelDate) IS NULL AND TF.TransferDateApprove IS NOT NULL)' -- โอนแล้ว
	AND (ISNULL(@HomeType,'')='' OR BG.BGNo = @HomeType)
	AND (ISNULL(@ProjectGroup,'')='' OR PR.[Group] = @ProjectGroup)	
	--AND PR.ProjectNo IN (SELECT ProductID FROM [dbo].[fn_GetProjectAuthorised](@UserName))
	AND (@ProjectType2 IS NULL OR PR.ProjectTypeMasterCenterID = @ProjectType2)


 ORDER BY BG.BGNo,PR.ProjectNo,UN.UnitNo ASC;



go

