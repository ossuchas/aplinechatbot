Create FUNCTION [dbo].[fn_AP_BI_GetFixDayOfDefect2]
(
	@ProductID nvarchar(15),
	@UnitNumber nvarchar(15)
	
)
RETURNS int
AS
BEGIN
	DECLARE @NumberOfDefect int
	
	set @NumberOfDefect =0
	
	
	set @NumberOfDefect =isnull((
	
	Select
	top 1	datediff(day,RAuditDate,isnull(v.RAuditCloseDate,getdate())) as FixedDay
From [DBLINK_SVR_DEFECT].[defecttracking].[dbo].vwCallDefectRoundAudit  v
--From [Temp_vwCallDefectRoundAudit]  v With(NoLock)
where DocIsActive=1 --and ProjectNO in(Select PROJECT_CODE From SM_D_PROJECT Where BU_Code='3')
and ProjectNO=@ProductID and Unit=@UnitNumber
and RAuditDate>= '20150720' 
and rauditno=2 and docisactive=1
order by RAuditDate desc
	
	),0)
	
	
	
	RETURN @NumberOfDefect
END
go

