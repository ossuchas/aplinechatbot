
CREATE PROCEDURE [dbo].[sp_Executive_Daily]
--declare
@CloseDate DATE 
AS 
BEGIN
    SET NOCOUNT ON;

	DECLARE @DateStart DATE
	DECLARE @DateEnd DATE

	DECLARE @TotalWalk INT
	DECLARE @GrossTotalUnit INT
	DECLARE @GrossTotalPrice MONEY
	DECLARE @CancelTotalUnit INT
	DECLARE @CancelTotalPrice MONEY
	DECLARE @NetTotalUnit INT
	DECLARE @NetTotalPrice MONEY
	DECLARE @TransferTotalUnit INT
	DECLARE @TransferTotalPrice MONEY
	
	--PRINT @CloseDate

	SET @DateStart = @CloseDate
	SET @DateEnd = @CloseDate

	EXEC dbo.sp_Executive_ByProject @ProjectID = '', 
									@DateStart = @DateStart,
									@DateEnd = @DateEnd 


	--Check Existing Date 
	IF EXISTS(SELECT 1 FROM dbo.crm_ex_daily WITH(NOLOCK) WHERE CloseDate = @DateEnd)
	BEGIN

		PRINT '[+] Found Update'

		SELECT @TotalWalk = SUM(TotalWalk),
		@GrossTotalUnit = SUM([GrossTotalUnit]),
		@GrossTotalPrice = SUM([GrossTotalPrice]),
		@CancelTotalUnit = SUM([CancelTotalUnit]),
		@CancelTotalPrice = SUM([CancelTotalPrice]),
		@NetTotalUnit = SUM([NetTotalUnit]),
		@NetTotalPrice = SUM([NetTotalPrice]),
		@TransferTotalUnit= SUM([TransferTotalUnit]),
		@TransferTotalPrice= SUM([TransferTotalPrice])
		FROM ##temp_ex

		UPDATE dbo.crm_ex_daily
		SET TotalWalk = @TotalWalk,
		GrossTotalUnit = @GrossTotalUnit,
		GrossTotalPrice = @GrossTotalPrice,
		CancelTotalUnit = @CancelTotalUnit,
		CancelTotalPrice = @CancelTotalPrice,
		NetTotalUnit = @NetTotalUnit,
		NetTotalPrice = @NetTotalPrice,
		TransferTotalUnit = @TransferTotalUnit,
		TransferTotalPrice = @TransferTotalPrice,
		LastModifiedDTTM = SYSDATETIME()
		WHERE CloseDate = @DateStart
	END
	ELSE
	BEGIN
		PRINT '[+] Not Found Insert '
		INSERT INTO dbo.crm_ex_daily
		(
			TransID, CloseDate, Years, Quarters,
			Weeks,
			TotalWalk, GrossTotalUnit, GrossTotalPrice,
			CancelTotalUnit, CancelTotalPrice,
			NetTotalUnit, NetTotalPrice,
			TransferTotalUnit,TransferTotalPrice,
			LastModifiedDTTM
		)
		SELECT NEWID(), @DateEnd, DATEPART(YEAR, @DateEnd), DATEPART(QUARTER, @DateEnd), 
		(SELECT TOP 1 W
			FROM crmrevo.BI.Mst_Calendar_Week WITH(NOLOCK) WHERE Y = DATEPART(YEAR, @DateEnd) 
			AND @DateStart BETWEEN CAST(StartDate AS DATE) AND CAST(EndDate AS DATE)
		),
		SUM(TotalWalk),SUM([GrossTotalUnit]),SUM([GrossTotalPrice]),
		SUM([CancelTotalUnit]), SUM([CancelTotalPrice]),
		SUM([NetTotalUnit]) ,SUM([NetTotalPrice]) ,
		SUM([TransferTotalUnit]) ,SUM([TransferTotalPrice]),
		SYSDATETIME()
		FROM ##temp_ex
	END


	
END;



go

