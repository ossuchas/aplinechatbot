/****** Object:  UserDefinedFunction [dbo].[fn_AP_BI_GetDefectNumber]    Script Date: 03/12/2013 15:09:52 ******/

Create FUNCTION [dbo].[fn_AP_BI_GetUnitTransferDate_REVO]
(
	@ProductID nvarchar(50)
	,@UnitNumber nvarchar(50)
	
	
)
RETURNS datetime
AS
BEGIN
	DECLARE @TransferDate datetime
	
	
	
	set @TransferDate =(Select top 1  TransferUnit.ActualTransferDate From 
		[crmrevo].sal.Agreement as Agree  With(NoLock)
		Left Join [crmrevo].sal.[Transfer] as TransferUnit With(NoLock) ON (Agree.id = TransferUnit.AgreementID)  AND TransferUnit.IsDeleted = 0
		LEFT JOIN [crmrevo].prj.Unit u With(NoLock) ON agree.UnitID = u.id  AND u.IsDeleted = 0
		LEFT JOIN [crmrevo].prj.Project p With(NoLock) ON agree.ProjectID = p.id  AND p.IsDeleted = 0
		where Agree.IsCancel =0 
		AND p.ProjectNo =@ProductID AND u.UnitNo =@UnitNumber 
		AND Agree.IsDeleted = 0)
	
	
	RETURN @TransferDate
END
go

