CREATE VIEW [dbo].[vw_crm_line_userroleproj]
AS
--SELECT DISTINCT 
--c.user_empcode + a.ProjectCode AS rec_id,
--a.ProjectCode AS projectcode, p.Project AS project_name, 
--p.Project + ':' + a.ProjectCode AS display_project,
--p.PType AS bg, p.ProjectGroup AS subbg,
--c.user_empcode, c.user_token_Id
--FROM [DBLINK_SVR_CRMREP].db_iconcrm_fusion.dbo.[vw_UserRoleProject] a WITH(NOLOCK),
--[DBLINK_SVR_CRMREP].db_iconcrm_fusion.dbo.ICON_EntForms_Products p WITH(NOLOCK),
--[DBLINK_SVR_CRMREP].db_iconcrm_fusion.dbo.chatbot_mst_user c WITH(NOLOCK)
--WHERE 1=1
----AND a.EmpCode = 'AP003910'
----AND a.EmpCode = 'AP003910'
----AND a.ProjectCode IN ('10077','70028','60015','60018')
--AND a.ProjectCode = p.ProductID
--AND p.RTPExcusive = 1
--AND p.ptype IN ('1','2','3','4')
--AND p.project NOT LIKE '%ระงับใช้%'
--AND a.EmpCode = c.user_empcode
SELECT DISTINCT 
c.user_empcode + a.ProjectNo AS rec_id,
a.ProjectNo AS projectcode, p.ProjectNameTH AS project_name, 
p.ProjectNameTH + ':' + a.ProjectNo AS display_project,
SUBSTRING(p.[Group],1,1) AS bg, p.[Group] AS subbg,
c.user_empcode, c.user_token_Id
FROM dbo.vw_line_UserRoleProject a WITH(NOLOCK),
crmrevo.PRJ.Project p WITH(NOLOCK),
dbo.chatbot_mst_user c WITH(NOLOCK)
WHERE 1=1
--AND a.EmpCode = 'AP003910'
--AND a.EmpCode = 'AP003910'
--AND a.ProjectCode IN ('10077','70028','60015','60018')
AND a.ProjectNo = p.ProjectNo
AND p.IsActive = 1
AND p.IsDeleted = 0
AND SUBSTRING(p.[Group],1,1) IN ('1','2','3','4')
AND p.ProjectNameTH NOT LIKE '%ระงับใช้%'
AND a.EmpCode = c.user_empcode


go

