
Create FUNCTION [dbo].[fn_AP_BI_IsReceipt]
(
	@ProductID nvarchar(15),
	@UnitNumber nvarchar(15)
	
)
RETURNS int
AS
BEGIN
	DECLARE @IsReceipt int
	DECLARE @CountReceipt int
	set @IsReceipt =0
	set @CountReceipt =0
	
	set @CountReceipt =(
	
	--select Count( c.UnitNumber)  from [192.168.0.128].DefectLogs.dbo.ZReceiveUnit  c
	select Count( DISTINCT c.SerialNo)  from [DBLINK_SVR_DEFECT].[defecttracking].dbo.[vwCallDefectReceiveUnitDoc]  c With(NoLock) 
where 1=1
and c.ProjectNo= @ProductID
and c.SerialNo = @UnitNumber
and c.DocIsActive ='1'


	
	)
	
	
	if @CountReceipt > 0
		set @IsReceipt =1
		
		
	RETURN @IsReceipt
END
go

