Create FUNCTION [dbo].[fn_AP_BI_GetAmountDefect2]
(
	@ProductID nvarchar(15),
	@UnitNumber nvarchar(15)
	
)
RETURNS int
AS
BEGIN
	DECLARE @AmountDefect int
	
	set @AmountDefect =0
	
	set @AmountDefect =(
	Select top 1 RAuditNumOfTask
From [DBLINK_SVR_DEFECT].[defecttracking].[dbo].vwCallDefectRoundAudit  v
--From [Temp_vwCallDefectRoundAudit]  v With(NoLock)
where DocIsActive=1 --and ProjectNO in(Select PROJECT_CODE From SM_D_PROJECT Where BU_Code='3')
and ProjectNO=@ProductID and Unit=@UnitNumber
and RAuditDate>= '20150720' 
and rauditno=2 and docisactive=1
order by RAuditDate desc
	)
	
--	if(@AmountDefect is null)
--	set @AmountDefect =isnull((
	
--	Select
--top 1 defect_count


--From(
--Select
--tb.room_code,
--tb.defect_count,
--tb.check_date,
--row_number() over(partition by tb.room_code
--order by tb.check_date asc) as ListNo
 
--From(
--Select Distinct
--Room.room_code,
--dr.defect_count,
--dr.check_date

--	From
--	--[192.168.0.128].DefectLogs.dbo.tbl_defect_report as dr
--	--Left Join [192.168.0.128].DefectLogs.dbo.tbl_project as pj on (dr.project_id = pj.id)
--	--Left Join [192.168.0.128].DefectLogs.dbo.tbl_room as Room on (dr.room_id = Room.id)
--	[Temp_tbl_defect_report] as dr With(NoLock)
--	Left Join [Temp_tbl_project] as pj  With(NoLock)on (dr.project_id = pj.id)
--	Left Join [Temp_tbl_room] as Room  With(NoLock)on (dr.room_id = Room.id)
--	where pj.ProductID = @ProductID
--	and Room.room_code = @UnitNumber
--		and dr.status = '1'
--	 ) as tb) as tbAll
--	 where ListNo =2	
	
--	),0)
	
	
	
	RETURN @AmountDefect
END
go

