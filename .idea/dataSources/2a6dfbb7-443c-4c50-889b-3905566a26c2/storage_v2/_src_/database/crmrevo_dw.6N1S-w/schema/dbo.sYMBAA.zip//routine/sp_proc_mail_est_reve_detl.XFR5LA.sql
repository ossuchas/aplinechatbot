
CREATE PROCEDURE [dbo].[sp_proc_mail_est_reve_detl]
 @p_type AS VARCHAR(2),
 @p_option AS VARCHAR(5)
As

    SET NOCOUNT ON;

	DECLARE @head_curr_quarter    AS VARCHAR(100);
	
	DECLARE @head_est_d1      AS VARCHAR(100);
	DECLARE @head_est_d2      AS VARCHAR(100);
	DECLARE @head_est_d3      AS VARCHAR(100);
	DECLARE @head_est_d4      AS VARCHAR(100);
	DECLARE @head_est_d5      AS VARCHAR(100);

	DECLARE @i_count AS INT;

	DECLARE @val_date AS VARCHAR(20)

	DECLARE @month_no AS INT
	DECLARE @month_name AS VARCHAR(20);

	DECLARE @head_month_m1 AS VARCHAR(20);
	DECLARE @head_month_m2 AS VARCHAR(20);
	DECLARE @head_month_m3 AS VARCHAR(20);
	DECLARE @seqn_no AS INT;
	DECLARE @filter_option AS VARCHAR(10);

	DECLARE @ac_q1 AS FLOAT;
	DECLARE @ac_q2 AS FLOAT;
	DECLARE @ac_q3 AS FLOAT;
	DECLARE @ac_q4 AS FLOAT;
	DECLARE @est_curr_d1 AS FLOAT;
	DECLARE @est_curr_d2 AS FLOAT;
	DECLARE @est_curr_d3 AS FLOAT;
	DECLARE @est_curr_d4 AS FLOAT;
	DECLARE @est_curr_d5 AS FLOAT;

	DECLARE @ac_q1_ap_excl_jv_totl AS FLOAT;
	DECLARE @ac_q1_jv_100_totl AS FLOAT;
	DECLARE @ac_q1_ap_jv_totl AS FLOAT;

	IF @p_type = '1' BEGIN SET @seqn_no = 4; SET @filter_option = 'All'; END;
	IF @p_type = '2' BEGIN SET @seqn_no = 5; SET @filter_option = 'All'; END;
	IF @p_type = '3' BEGIN IF @p_option = 'AP' BEGIN SET @seqn_no = 6; SET @filter_option = 'AP'; END ELSE BEGIN SET @seqn_no = 8; SET @filter_option = 'JV'; END END;
	IF @p_type = '4' BEGIN IF @p_option = 'AP' BEGIN SET @seqn_no = 7; SET @filter_option = 'AP'; END ELSE BEGIN SET @seqn_no = 9; SET @filter_option = 'JV'; END END;

	IF (OBJECT_ID('tempdb..#temp1') IS NOT NULL) DROP TABLE #temp1;

	SELECT a.PType, a.ProjectType, a.Years, a.Quarters, 
	CASE WHEN a.isJVStatus = 0 THEN 'AP' ELSE 'JV' END AS AP_JV,
	SUM(a.NetPriceExclFD)/1000000 AS NetPriceExclFD 
	INTO #temp1
	FROM (
	SELECT TR.ProjectNo AS ProductID , 
			TR.BG AS PType,                                   
			TR.ProjectType,                                            
            TR.UnitNo AS UnitNumber,
            TR.ActualTransferDate AS TransferDateApprove,
			datepart(year, TR.ActualTransferDate) AS Years, 
			DATEPART(QUARTER, TR.ActualTransferDate) AS Quarters,
			TR.TotalPrice AS NetPrice,
			TR.FreeDownAmount AS FreeDownAmount,
			TR.NetPriceExclFD, TR.isJVStatus
	FROM dbo.vw_ActualTransfer TR WITH(NOLOCK)
	WHERE 1=1                                      
	AND DATEPART(YEAR, TR.ActualTransferDate) = DATEPART(YEAR, GETDATE())
	--AND DATEPART(QUARTER, TR.ActualTransferDate) = DATEPART(QUARTER, GETDATE())
	AND BG IN ('1','2','3','4')
	AND BG = @p_type
	) AS a
	GROUP BY a.PType, a.ProjectType, a.Years, a.Quarters, 
	CASE WHEN a.isJVStatus = 0 THEN 'AP' ELSE 'JV' END

	SELECT @ac_q1 = (SELECT NetPriceExclFD  FROM #temp1 WHERE ('All' = @filter_option OR AP_JV = @filter_option) AND Years = YEAR(GETDATE()) AND Quarters = 1)

	SELECT @ac_q2 = (SELECT NetPriceExclFD  FROM #temp1 WHERE ('All' = @filter_option OR AP_JV = @filter_option) AND Years = YEAR(GETDATE()) AND Quarters = 2)
	SELECT @ac_q3 = (SELECT NetPriceExclFD  FROM #temp1 WHERE ('All' = @filter_option OR AP_JV = @filter_option) AND Years = YEAR(GETDATE()) AND Quarters = 3)
	SELECT @ac_q4 = (SELECT NetPriceExclFD  FROM #temp1 WHERE ('All' = @filter_option OR AP_JV = @filter_option) AND Years = YEAR(GETDATE()) AND Quarters = 4)

	--Get Estimate next day 5
	SET @est_curr_d1 = 0
	SET @est_curr_d2 = 0
	SET @est_curr_d3 = 0
	SET @est_curr_d4 = 0
	SET @est_curr_d5 = 0

	SET @i_count = 1
	DECLARE db_cursor CURSOR
	FOR
			SELECT TOP 5 DateOfYear
			FROM crmrevo.BI.Mst_WorkDayCalendar WITH(NOLOCK)
			WHERE DateOfYear >= CAST(GETDATE() AS DATE) 
			AND SatSunDayFlag = 'N' AND HolidayFlag = 'N'
			ORDER BY DateOfYear

	OPEN db_cursor  
	FETCH NEXT FROM db_cursor INTO @val_date

	WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @i_count = 1
			BEGIN
			    --PRINT 'day1'
				IF (OBJECT_ID('tempdb..#temp2') IS NOT NULL) DROP TABLE #temp2;

				SELECT a.PType, a.ProjectType, CASE WHEN a.isJVStatus = 0 THEN 'AP' ELSE 'JV' END AS AP_JV,
				SUM(a.NetPriceExclFD)/1000000 AS NetPriceExclFD
				INTO #temp2
				FROM 
				(SELECT SUBSTRING(p.[Group],1,1) AS Ptype, 
				CASE WHEN SUBSTRING(p.[Group],1,1) = '1' THEN 'SDH'
				WHEN SUBSTRING(p.[Group],1,1) = '2' THEN 'TH'
				WHEN SUBSTRING(p.[Group],1,1) = '3' THEN 'CD1'
				WHEN SUBSTRING(p.[Group],1,1) = '4' THEN 'CD2'
				ELSE '' END AS ProjectType,
				P.ProjectNo, U.UnitNo, 
				ISNULL(TF.ScheduleTransferDate, U.PrepareTransferDate) AS TransferDate,
				UP.TotalPrice AS TotalSellingPrice, --ราคาบ้านสุทธิ
				up.FreedownDiscount, --ฟรีดาวน์
				up.TotalPrice - up.FreedownDiscount AS NetPriceExclFD, --ราคาบ้านสุทธิหลังหักฟรีดาวน์
				(	SELECT COUNT(*) 
					FROM crmrevo.PRJ.TransferProjectJV t WITH(NOLOCK) 
					WHERE CAST(t.EffectiveDate AS DATE) <= ISNULL(ISNULL(TF.ScheduleTransferDate, U.PrepareTransferDate),CAST(GETDATE() AS DATE))
					AND (t.ExpiredDate IS NULL OR CAST(t.ExpiredDate AS DATE) >= ISNULL(ISNULL(TF.ScheduleTransferDate, U.PrepareTransferDate),CAST(GETDATE() AS DATE)) ) 
					AND t.ProductID = p.ProjectNo) AS isJVStatus
				FROM crmrevo.PRJ.Unit U WITH(NOLOCK)
				LEFT OUTER JOIN crmrevo.PRJ.Project P WITH (NOLOCK) ON P.ID = U.ProjectID AND p.IsDeleted = 0 AND p.IsActive = 1
				LEFT OUTER JOIN crmrevo.SAL.Agreement A WITH (NOLOCK) ON A.ProjectID = P.ID AND A.UnitID = U.ID AND A.IsDeleted =0 AND a.IsCancel = 0
				LEFT OUTER JOIN crmrevo.SAL.Booking B WITH (NOLOCK) ON A.BookingID = B.ID AND B.IsDeleted =0 AND b.IsCancelled = 0
				LEFT OUTER JOIN crmrevo.SAL.Transfer TF WITH (NOLOCK) ON TF.AgreementID = A.ID AND TF.IsDeleted =0
				INNER JOIN crmrevo.SAL.UnitPrice  UP WITH (NOLOCK) ON UP.BookingID = A.BookingID AND UP.IsActive=1 AND UP.IsDeleted =0
				WHERE 1=1
				AND  CAST(U.PrepareTransferDate AS DATE) = @val_date
				AND U.IsPrepareTransfer =1
				AND u.IsDeleted = 0
				) AS a
				GROUP BY a.PType, a.ProjectType, CASE WHEN a.isJVStatus = 0 THEN 'AP' ELSE 'JV' END

				--SELECT * FROM #temp2

				SELECT @est_curr_d1 = NetPriceExclFD  FROM #temp2 WHERE ('All' = @filter_option OR AP_JV = @filter_option) AND PType = @p_type
				--SELECT @est_curr_d1
			END
			ELSE
			BEGIN
				IF (OBJECT_ID('tempdb..#temp3') IS NOT NULL) DROP TABLE #temp3;
				
				SELECT a.PType, a.ProjectType, CASE WHEN a.isJVStatus = 0 THEN 'AP' ELSE 'JV' END AS AP_JV,
				SUM(a.NetPriceExclFD)/1000000 AS NetPriceExclFD
				INTO #temp3
				FROM 
				(SELECT SUBSTRING(p.[Group],1,1) AS Ptype, 
				CASE WHEN SUBSTRING(p.[Group],1,1) = '1' THEN 'SDH'
				WHEN SUBSTRING(p.[Group],1,1) = '2' THEN 'TH'
				WHEN SUBSTRING(p.[Group],1,1) = '3' THEN 'CD1'
				WHEN SUBSTRING(p.[Group],1,1) = '4' THEN 'CD2'
				ELSE '' END AS ProjectType,
				P.ProjectNo, U.UnitNo, 
				ISNULL(TF.ScheduleTransferDate, U.PrepareTransferDate) AS TransferDate,
				UP.TotalPrice AS TotalSellingPrice, --ราคาบ้านสุทธิ
				up.FreedownDiscount, --ฟรีดาวน์
				up.TotalPrice - up.FreedownDiscount AS NetPriceExclFD, --ราคาบ้านสุทธิหลังหักฟรีดาวน์
				(	SELECT COUNT(*) 
					FROM crmrevo.PRJ.TransferProjectJV t WITH(NOLOCK) 
					WHERE CAST(t.EffectiveDate AS DATE) <= ISNULL(ISNULL(TF.ScheduleTransferDate, U.PrepareTransferDate),CAST(GETDATE() AS DATE))
					AND (t.ExpiredDate IS NULL OR CAST(t.ExpiredDate AS DATE) >= ISNULL(ISNULL(TF.ScheduleTransferDate, U.PrepareTransferDate),CAST(GETDATE() AS DATE)) ) 
					AND t.ProductID = p.ProjectNo) AS isJVStatus
				FROM crmrevo.PRJ.Unit U WITH(NOLOCK)
				LEFT OUTER JOIN crmrevo.PRJ.Project P WITH (NOLOCK) ON P.ID = U.ProjectID AND p.IsDeleted = 0 AND p.IsActive = 1
				LEFT OUTER JOIN crmrevo.SAL.Agreement A WITH (NOLOCK) ON A.ProjectID = P.ID AND A.UnitID = U.ID AND A.IsDeleted =0 AND a.IsCancel = 0
				LEFT OUTER JOIN crmrevo.SAL.Booking B WITH (NOLOCK) ON A.BookingID = B.ID AND B.IsDeleted =0 AND b.IsCancelled = 0
				LEFT OUTER JOIN crmrevo.SAL.Transfer TF WITH (NOLOCK) ON TF.AgreementID = A.ID AND TF.IsDeleted =0
				INNER JOIN crmrevo.SAL.UnitPrice  UP WITH (NOLOCK) ON UP.BookingID = A.BookingID AND UP.IsActive=1 AND UP.IsDeleted =0
				WHERE 1=1
				AND ISNULL(TF.ScheduleTransferDate, U.PrepareTransferDate) = @val_date
				--AND U.IsPrepareTransfer =1 --Modified by Suchat S. 2020-09-04 for checking Schedule Date
				AND u.IsDeleted = 0
				) AS a
				GROUP BY a.PType, a.ProjectType, CASE WHEN a.isJVStatus = 0 THEN 'AP' ELSE 'JV' END

			END

			IF @i_count = 2
			BEGIN
				--PRINT 'day2'
				SELECT @est_curr_d2 = NetPriceExclFD  FROM #temp3 WHERE ('All' = @filter_option OR AP_JV = @filter_option) AND PType = @p_type
			END
            
			IF @i_count = 3 
			BEGIN
			    --PRINT 'day3'
				SELECT @est_curr_d3 = NetPriceExclFD  FROM #temp3 WHERE ('All' = @filter_option OR AP_JV = @filter_option) AND PType = @p_type
			END

			IF @i_count = 4
			BEGIN
			    --PRINT 'day4'
				SELECT @est_curr_d4 = NetPriceExclFD  FROM #temp3 WHERE ('All' = @filter_option OR AP_JV = @filter_option) AND PType = @p_type
			END

			IF @i_count = 5
			BEGIN
			    --PRINT 'day5'
				SELECT @est_curr_d5 = NetPriceExclFD  FROM #temp3 WHERE ('All' = @filter_option OR AP_JV = @filter_option) AND PType = @p_type
			END
			
			SET @i_count = @i_count + 1
			FETCH NEXT FROM db_cursor INTO @val_date
		END 

	CLOSE db_cursor  
	DEALLOCATE db_cursor

	SELECT @est_curr_d1 AS est_d1, @est_curr_d2 AS est_d2, @est_curr_d3 AS est_d3, @est_curr_d4 AS est_d4, @est_curr_d5 AS est_d5

	--######################################
	--[1]
	UPDATE dbo.crm_mail_est_reve 
	SET ac_q1 = ISNULL(@ac_q1, 0), 
	ac_q2 = ISNULL(@ac_q2, 0),
	ac_q3 = ISNULL(@ac_q3, 0),
	ac_q4 = ISNULL(@ac_q4, 0),
	--qtd_curr_ac = ISNULL(@ac_q1, 0), --Modified by Suchat S. 2020-06-03 for add column Q1
	qtd_curr_ac = CASE WHEN DATEPART(QUARTER, GETDATE()) = 1 THEN  ISNULL(@ac_q1, 0)
					WHEN DATEPART(QUARTER, GETDATE()) = 2 THEN  ISNULL(@ac_q2, 0)
					WHEN DATEPART(QUARTER, GETDATE()) = 3 THEN  ISNULL(@ac_q3, 0)
					WHEN DATEPART(QUARTER, GETDATE()) = 4 THEN  ISNULL(@ac_q4, 0) ELSE 0 END,
	est_curr_d1 = ISNULL(@est_curr_d1,0),
	est_curr_d2 = ISNULL(@est_curr_d2,0),
	est_curr_d3 = ISNULL(@est_curr_d3,0),
	est_curr_d4 = ISNULL(@est_curr_d4,0),
	est_curr_d5 = ISNULL(@est_curr_d5,0)
	WHERE seqn_no = @seqn_no;

	--Sum QTD + Est Current Quarter and YTD + Est
	UPDATE dbo.crm_mail_est_reve 
	SET qtd_est_total = ISNULL(qtd_curr_ac,0) + ISNULL(est_curr_d1,0) + ISNULL(est_curr_d2,0) + ISNULL(est_curr_d3,0) + ISNULL(est_curr_d4,0) + ISNULL(est_curr_d5,0),
	ytd_est_ac = ISNULL(ac_q1,0) + ISNULL(ac_q2,0) + ISNULL(ac_q3,0) + ISNULL(ac_q4,0) + ISNULL(est_curr_d1,0) + ISNULL(est_curr_d2,0) + ISNULL(est_curr_d3,0) + ISNULL(est_curr_d4,0) + ISNULL(est_curr_d5,0)
	WHERE seqn_no = @seqn_no;


	--[2]Sum AP Excl JV
	UPDATE dbo.crm_mail_est_reve 
	SET ac_q1 = ISNULL((SELECT SUM(ac_q1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0),
	ac_q2 = ISNULL((SELECT SUM(ac_q2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0),
	ac_q3 = ISNULL((SELECT SUM(ac_q3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0),
	ac_q4 = ISNULL((SELECT SUM(ac_q4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0),
	--qtd_curr_ac = ISNULL((SELECT SUM(ac_q1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0), --Modified by Suchat S. 2020-06-03 for add column Q1
	qtd_curr_ac = CASE WHEN DATEPART(QUARTER, GETDATE()) = 1 THEN  ISNULL((SELECT SUM(ac_q1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
					WHEN DATEPART(QUARTER, GETDATE()) = 2 THEN  ISNULL((SELECT SUM(ac_q2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
					WHEN DATEPART(QUARTER, GETDATE()) = 3 THEN  ISNULL((SELECT SUM(ac_q3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
					WHEN DATEPART(QUARTER, GETDATE()) = 4 THEN  ISNULL((SELECT SUM(ac_q4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0) ELSE 0 END,
	est_curr_d1 = ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0),
	est_curr_d2 = ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0),
	est_curr_d3 = ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0),
	est_curr_d4 = ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0),
	est_curr_d5 = ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
	WHERE seqn_no = 1;

	--Sum QTD + Est Current Quarter and YTD + Est
	UPDATE dbo.crm_mail_est_reve 
	SET 
	qtd_est_total = 
	CASE 
		WHEN DATEPART(QUARTER, GETDATE()) = 1 THEN ISNULL((SELECT SUM(ac_q1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
		WHEN DATEPART(QUARTER, GETDATE()) = 2 THEN  ISNULL((SELECT SUM(ac_q2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
		WHEN DATEPART(QUARTER, GETDATE()) = 3 THEN  ISNULL((SELECT SUM(ac_q3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
		WHEN DATEPART(QUARTER, GETDATE()) = 4 THEN  ISNULL((SELECT SUM(ac_q4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
	ELSE 0 END
	+ ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0),
	ytd_est_ac = ISNULL((SELECT SUM(ac_q1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
	+ ISNULL((SELECT SUM(ac_q2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
	+ ISNULL((SELECT SUM(ac_q3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
	+ ISNULL((SELECT SUM(ac_q4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (4,5,6,7)),0)
	WHERE seqn_no = 1;
	
	--[3]Sum JV 100%
	UPDATE dbo.crm_mail_est_reve 
	SET ac_q1 = ISNULL((SELECT SUM(ac_q1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0),
	ac_q2 = ISNULL((SELECT SUM(ac_q2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0),
	ac_q3 = ISNULL((SELECT SUM(ac_q3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0),
	ac_q4 = ISNULL((SELECT SUM(ac_q4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0),
	--qtd_curr_ac = ISNULL((SELECT SUM(ac_q1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0), --Modified by Suchat S. 2020-06-03 for add column Q1
	qtd_curr_ac = CASE WHEN DATEPART(QUARTER, GETDATE()) = 1 THEN  ISNULL((SELECT SUM(ac_q1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
					WHEN DATEPART(QUARTER, GETDATE()) = 2 THEN  ISNULL((SELECT SUM(ac_q2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
					WHEN DATEPART(QUARTER, GETDATE()) = 3 THEN  ISNULL((SELECT SUM(ac_q3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
					WHEN DATEPART(QUARTER, GETDATE()) = 4 THEN  ISNULL((SELECT SUM(ac_q4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0) ELSE 0 END,
	est_curr_d1 = ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0),
	est_curr_d2 = ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0),
	est_curr_d3 = ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0),
	est_curr_d4 = ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0),
	est_curr_d5 = ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	WHERE seqn_no = 2;

	--Sum QTD + Est Current Quarter and YTD + Est
	UPDATE dbo.crm_mail_est_reve
	SET qtd_est_total = 
	CASE 
		WHEN DATEPART(QUARTER, GETDATE()) = 1 THEN  ISNULL((SELECT SUM(ac_q1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
		WHEN DATEPART(QUARTER, GETDATE()) = 2 THEN  ISNULL((SELECT SUM(ac_q2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
		WHEN DATEPART(QUARTER, GETDATE()) = 3 THEN  ISNULL((SELECT SUM(ac_q3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
		WHEN DATEPART(QUARTER, GETDATE()) = 4 THEN  ISNULL((SELECT SUM(ac_q4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	ELSE 0 END
	+ ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0),
	ytd_est_ac = ISNULL((SELECT SUM(ac_q1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(ac_q2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(ac_q3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(ac_q4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	WHERE seqn_no = 2;
	
	--[4]Sum Total AP + JV
	UPDATE dbo.crm_mail_est_reve 
	SET ac_q1 = ISNULL((SELECT SUM(ac_q1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0),
	ac_q2 = ISNULL((SELECT SUM(ac_q2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0),
	ac_q3 = ISNULL((SELECT SUM(ac_q3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0),
	ac_q4 = ISNULL((SELECT SUM(ac_q4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0),
	--qtd_curr_ac = ISNULL((SELECT SUM(ac_q1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0), --Modified by Suchat S. 2020-06-03 for add column Q1
	qtd_curr_ac = CASE WHEN DATEPART(QUARTER, GETDATE()) = 1 THEN  ISNULL((SELECT SUM(ac_q1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
					WHEN DATEPART(QUARTER, GETDATE()) = 2 THEN  ISNULL((SELECT SUM(ac_q2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
					WHEN DATEPART(QUARTER, GETDATE()) = 3 THEN  ISNULL((SELECT SUM(ac_q3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
					WHEN DATEPART(QUARTER, GETDATE()) = 4 THEN  ISNULL((SELECT SUM(ac_q4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0) ELSE 0 END,
	est_curr_d1 = ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (1,2)),0),
	est_curr_d2 = ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (1,2)),0),
	est_curr_d3 = ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (1,2)),0),
	est_curr_d4 = ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (1,2)),0),
	est_curr_d5 = ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
	WHERE seqn_no = 3;

	--Sum QTD + Est Current Quarter and YTD + Est
	UPDATE dbo.crm_mail_est_reve 
	SET qtd_est_total = 
	CASE 
		WHEN DATEPART(QUARTER, GETDATE()) = 1 THEN  ISNULL((SELECT SUM(ac_q1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
		WHEN DATEPART(QUARTER, GETDATE()) = 2 THEN  ISNULL((SELECT SUM(ac_q2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
		WHEN DATEPART(QUARTER, GETDATE()) = 3 THEN  ISNULL((SELECT SUM(ac_q3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
		WHEN DATEPART(QUARTER, GETDATE()) = 4 THEN  ISNULL((SELECT SUM(ac_q4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
	ELSE 0 END
	+ ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0),
	ytd_est_ac = ISNULL((SELECT SUM(ac_q1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
	+ ISNULL((SELECT SUM(ac_q2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
	+ ISNULL((SELECT SUM(ac_q3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
	+ ISNULL((SELECT SUM(ac_q4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
	+ ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve  WITH(NOLOCK) WHERE seqn_no IN (1,2)),0)
	WHERE seqn_no = 3;
	--######################################


go

