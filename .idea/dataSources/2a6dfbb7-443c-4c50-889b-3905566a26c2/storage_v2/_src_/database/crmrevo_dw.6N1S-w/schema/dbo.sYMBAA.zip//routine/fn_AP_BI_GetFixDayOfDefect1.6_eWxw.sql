Create FUNCTION [dbo].[fn_AP_BI_GetFixDayOfDefect1]
(
	@ProductID nvarchar(15),
	@UnitNumber nvarchar(15)
	
)
RETURNS int
AS
BEGIN
	DECLARE @NumberOfDefect int
	
	set @NumberOfDefect =0
	
	set @NumberOfDefect =(
	Select top 1 datediff(day,RAuditDate ,isnull(RAuditCloseDate,getdate()))
From [DBLINK_SVR_DEFECT].[defecttracking].[dbo].vwCallDefectRoundAudit  v
--From [Temp_vwCallDefectRoundAudit]  v With(NoLock)
where DocIsActive=1 --and ProjectNO in(Select PROJECT_CODE From SM_D_PROJECT Where BU_Code='3')
and ProjectNO=@ProductID and Unit=@UnitNumber
and RAuditDate>= '20150720'  and docisactive=1
order by RAuditDate desc
	)
	
	--if(@NumberOfDefect is null)
	--set @NumberOfDefect =(
	--Select top 1 datediff(day,dr.check_date ,isnull(dr.end_date,getdate()))
	--From
	----[192.168.0.128].DefectLogs.dbo.tbl_defect_report as dr
	----Left Join [192.168.0.128].DefectLogs.dbo.tbl_project as pj on (dr.project_id = pj.id)
	----Left Join [192.168.0.128].DefectLogs.dbo.tbl_room as Room on (dr.room_id = Room.id)
	--[Temp_tbl_defect_report] as dr With(NoLock)
	--Left Join [Temp_tbl_project] as pj  With(NoLock)on (dr.project_id = pj.id)
	--Left Join [Temp_tbl_room] as Room  With(NoLock)on (dr.room_id = Room.id)
	--where pj.ProductID = @ProductID
	--and Room.room_code = @UnitNumber
	--	and dr.status = '1'
	--Order by dr.check_date asc)
	
	
	
	RETURN @NumberOfDefect
END
go

