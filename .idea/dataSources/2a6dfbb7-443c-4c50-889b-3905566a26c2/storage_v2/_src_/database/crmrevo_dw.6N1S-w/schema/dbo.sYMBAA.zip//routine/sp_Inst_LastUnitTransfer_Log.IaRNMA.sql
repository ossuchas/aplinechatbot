

CREATE PROCEDURE [dbo].[sp_Inst_LastUnitTransfer_Log]
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @i_count INT;
    ---
    DECLARE @ProjectID UNIQUEIDENTIFIER;
    DECLARE @ProjectNo VARCHAR(50);
    DECLARE @LastUnitTransferDate DATETIME2(7);

	DECLARE @TotalUnit INT;
	DECLARE @TotalTransferUnit INT;

    DECLARE db_cursor CURSOR FOR

    --Check โอนห้องสุดท้าย
    SELECT p.ProjectID,
           p.ProjectNo
    FROM log_SendMail_FistLast_Project p WITH (NOLOCK), crmrevo.PRJ.Project pp WITH(NOLOCK)
    WHERE 1 = 1
          AND p.LastUnit_SendMailFlag = 'N'
		  AND p.LasttUnitTransferDate IS NULL
		  AND p.ProjectID = pp.ID
		  AND pp.IsDeleted = 0
		  AND pp.IsActive = 1
		  AND SUBSTRING(pp.[Group],3,1) <> '0'
		  ORDER BY p.ProjectNo

    SET @i_count = 1;
    OPEN db_cursor;
    FETCH NEXT FROM db_cursor
    INTO @ProjectID,
         @ProjectNo;

    WHILE @@FETCH_STATUS = 0
    BEGIN

		SELECT @TotalUnit = COUNT(*), @TotalTransferUnit = (
			SELECT COUNT(*) 
			FROM dbo.vw_UnitStatusBacklog bl1 WITH(NOLOCK)
			WHERE bl1.UnitStatus = 'TF'
			AND bl1.ProjectID = @ProjectID
		)
		FROM dbo.vw_UnitStatusBacklog bl0 WITH(NOLOCK)
		WHERE bl0.ProjectID = @ProjectID

		IF @TotalUnit = @TotalTransferUnit
		BEGIN
			
			--Get Max actual Transfer date
            SELECT @LastUnitTransferDate = MAX(ActualTransferDate)
            FROM dbo.vw_ActualTransfer WITH (NOLOCK)
            WHERE ProjectID = @ProjectID;

			UPDATE dbo.log_SendMail_FistLast_Project
			SET LastUnit_SendMailFlag = 'P', LasttUnitTransferDate = @LastUnitTransferDate
			WHERE ProjectID = @ProjectID

		    --PRINT '[+] Process' + CAST(@i_count AS VARCHAR(3)) + '|' + CAST(@ProjectID AS VARCHAR(50));
			PRINT '|' + CAST(@i_count AS VARCHAR(3)) + '|' + @ProjectNo + '|' + CAST(@TotalUnit AS VARCHAR(10)) + '|' + CAST(@TotalTransferUnit AS VARCHAR(10));
		END

        SET @i_count += 1;

        FETCH NEXT FROM db_cursor
        INTO @ProjectID,
             @ProjectNo;

    END;

    CLOSE db_cursor;
    DEALLOCATE db_cursor;


END;



go

