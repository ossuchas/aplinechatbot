



Create VIEW  [dbo].[vw_ZLCUnit]
AS
/*
นำเข้าข้อมูล LC โอน จากสัญญา ลงที่ Table ZLCUnit 
*/
--Insert Into ZLCUnit (ProductID,UnitNumber,UserID)
SELECT a.ProjectID,p.ProjectNo,a.UnitID,u.UnitNo,ISNULL(a.ProjectSaleUserID,a.SaleUserID) UserID
FROM [crmrevo].sal.Booking a
LEFT JOIN [crmrevo].prj.Project p ON a.ProjectID = p.id
LEFT JOIN [crmrevo].prj.Unit u ON u.id= a.UnitID
WHERE  a.IsCancelled = 0  AND a.IsDeleted = 0
AND a.ProjectID IN(SELECT id FROM [crmrevo].prj.Project WHERE IsActive=1 AND a.IsDeleted = 0)
--and Not Exists(Select * From ZLCUnit t Where a.ProductID=t.ProductID and a.UnitNumber=t.UnitNumber)
AND YEAR(a.Created)>=2013
AND ISNULL(a.ProjectSaleUserID,a.SaleUserID) IS NOT NULL
--Order by a.ProjectID,a.UnitID


go

