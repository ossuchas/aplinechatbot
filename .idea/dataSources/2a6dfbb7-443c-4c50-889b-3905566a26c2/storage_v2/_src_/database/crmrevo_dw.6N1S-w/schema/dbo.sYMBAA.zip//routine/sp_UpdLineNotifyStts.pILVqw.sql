
CREATE PROCEDURE [dbo].[sp_UpdLineNotifyStts]
    @Tran_ID INT ,
    @Send_Status VARCHAR(2) ,
    @ModifyBy VARCHAR(255) ,
    @Remarks VARCHAR(255) ,
    @ErrorMsg VARCHAR(255)
AS
    SET NOCOUNT ON;

    DECLARE @Send_Date DATETIME

    IF @Send_Status = 'S'
        SET @Send_Date = GETDATE()
    ELSE
        SET @Send_Date = NULL

    UPDATE  dbo.CRM_LineNotify
    SET     Send_Status = @Send_Status ,
            Send_Date = @Send_Date ,
            Error_Msg = @ErrorMsg ,
            --Remarks = @Remarks ,
            ModifyDate = GETDATE() ,
            ModifyBy = @ModifyBy
    WHERE   Tran_ID = @Tran_ID


go

