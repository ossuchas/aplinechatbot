

CREATE PROCEDURE [dbo].[sp_CheckCreate_SAPProj]
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @i_count INT;
    ---
    DECLARE @SAP_Id VARCHAR(50);
	DECLARE @ProjectNo VARCHAR(50);
	DECLARE @ProjectNameTH VARCHAR(200);
	DECLARE @CompanyCode VARCHAR(50);
	DECLARE @ProfitCenterCode VARCHAR(20);
	DECLARE @Plant VARCHAR(20);
	DECLARE @SapCode VARCHAR(20);
	DECLARE @SAPProjectId VARCHAR(50);
	DECLARE @ObjectNumber VARCHAR(50);
	DECLARE @SAPCreatedBy VARCHAR(50);
	DECLARE @SAPCreatedDate VARCHAR(10);

    DECLARE db_cursor CURSOR FOR
	SELECT PSPNR AS SAP_Id,
	   PSPID AS SAPProjectId,
       SUBSTRING(PRCTR, 2, LEN(PRCTR)) AS ProjectNo,
       POST1 AS ProjectNameTH,
	   OBJNR AS ObjectNumber,
       VBUKR AS CompanyCode,
       PRCTR AS ProfitCenterCode,
       WERKS AS Plant,
       SUBSTRING(WERKS, 1, 1) + '/' + SUBSTRING(WERKS, 2, LEN(WERKS)) AS SapCode,
	   ERNAM AS SAPCreatedBy,
	   ERDAT AS SAPCreatedDate
	FROM [DBLINK_SVR_STAGING].DB_AP_PRD.dbo.STG_PROJ WITH(NOLOCK);


    SET @i_count = 1;
    OPEN db_cursor;
    FETCH NEXT FROM db_cursor
    INTO @SAP_Id, @SAPProjectId, @ProjectNo, @ProjectNameTH, @ObjectNumber, @CompanyCode, @ProfitCenterCode, @Plant, @SapCode, @SAPCreatedBy, @SAPCreatedDate;

    WHILE @@FETCH_STATUS = 0
    BEGIN
		
		IF NOT EXISTS (
			SELECT 1 
			FROM dbo.SAP_Mst_Project WITH(NOLOCK) 
			WHERE Plant = @Plant 
			AND SapCode = @SapCode 
			AND ProfitCenterCode = @ProfitCenterCode
		)
		BEGIN
		    PRINT 'Not Existing Project Checking New.. => ' + @SAP_Id + '|' + @SapCode + '|' + @ProjectNameTH

			INSERT INTO dbo.SAP_Mst_Project
			(
			    ID,
			    SAP_Id,
			    SAPProjectId,
			    ProjectNo,
			    ProjectNameTH,
			    ObjectNumber,
			    CompanyCode,
			    ProfitCenterCode,
			    Plant,
			    SapCode,
			    SAPCreatedBy,
			    SAPCreatedDate,
			    SendMail_Create_Status,
			    SendMail_Create_Date,
			    ProjectName_Before_Change,
			    ProjectName_After_Change,
			    SendMail_Change_Status,
			    SendMail_Change_Date,
			    IsActive,
			    CreateBy,
			    CreatedDate,
			    ModifyBy,
			    ModifyDate
			)
			VALUES
			(   NEWID(),          -- ID - uniqueidentifier
			    @SAP_Id,           -- SAP_Id - nvarchar(24)
			    @SAPProjectId,           -- SAPProjectId - nvarchar(24)
			    @ProjectNo,           -- ProjectNo - nvarchar(10)
			    @ProjectNameTH,           -- ProjectNameTH - nvarchar(100)
			    @ObjectNumber,           -- ObjectNumber - nvarchar(22)
			    @CompanyCode,           -- CompanyCode - nvarchar(4)
			    @ProfitCenterCode,           -- ProfitCenterCode - nvarchar(10)
			    @Plant,           -- Plant - nvarchar(4)
			    @SapCode,           -- SapCode - nvarchar(6)
			    @SAPCreatedBy,           -- SAPCreatedBy - nvarchar(12)
			    @SAPCreatedDate,           -- SAPCreatedDate - nvarchar(8)
			    'Y',            -- SendMail_Create_Status - varchar(2)
			    NULL, -- SendMail_Create_Date - datetime2(7)
			    @ProjectNameTH,           -- ProjectName_Before_Change - nvarchar(100)
			    N'',           -- ProjectName_After_Change - nvarchar(100)
			    'N',            -- SendMail_Change_Status - varchar(2)
			    NULL, -- SendMail_Change_Date - datetime2(7)
			    1,          -- IsActive - bit
			    'CheckCreate_SAPProj',            -- CreateBy - varchar(7)
			    SYSDATETIME(), -- CreatedDate - datetime2(7)
			    'CheckCreate_SAPProj',            -- ModifyBy - varchar(7)
			    SYSDATETIME()  -- ModifyDate - datetime2(7)
			)
		END
        SET @i_count += 1;

        FETCH NEXT FROM db_cursor
        INTO @SAP_Id, @SAPProjectId, @ProjectNo, @ProjectNameTH, @ObjectNumber, @CompanyCode, @ProfitCenterCode, @Plant, @SapCode, @SAPCreatedBy, @SAPCreatedDate;

    END;

    CLOSE db_cursor;
    DEALLOCATE db_cursor;


END;



go

