
--SELECT * FROM [dbo].[fn_GetProjectAuthorised] ('AP000725')  
CREATE FUNCTION [dbo].[fn_GetProjectAuthorised]  
(  
  @EmpCode	AS NCHAR(50) = NULL 
)  
RETURNS @v TABLE (ProjectID uniqueidentifier)  
AS 
BEGIN  
  
	INSERT INTO @v
	SELECT DISTINCT a.ProjectID
	FROM [crmrevo].[USR].[UserAuthorizeProject] a WITH (NOLOCK)
	LEFT JOIN [crmrevo].[USR].[User] u WITH (NOLOCK) ON u.ID = a.UserID
	WHERE u.EmployeeNo = @EmpCode;
   
 RETURN;  

END
go

