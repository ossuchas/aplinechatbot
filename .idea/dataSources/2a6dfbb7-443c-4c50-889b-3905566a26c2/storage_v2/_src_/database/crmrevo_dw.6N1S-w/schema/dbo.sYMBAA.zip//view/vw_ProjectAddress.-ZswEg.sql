CREATE VIEW [dbo].[vw_ProjectAddress]
AS
SELECT p.ID AS ProjectID, p.ProjectNo, p.ProjectNameTH
,CASE WHEN ISNULL(ad.Moo,'') <> '' AND ISNULL(ad.Moo,'') <> '-' THEN ' ม.' + ad.Moo ELSE '' END AS Moo
,CASE WHEN ISNULL(ad.RoadTH,'') <> '' AND ISNULL(ad.RoadTH,'') <> '-' THEN ' ถ.' + ad.RoadTH ELSE '' END AS RoadTH
,CASE WHEN ISNULL(ad.SoiTH,'') <> '' AND ISNULL(ad.SoiTH,'') <> '-' THEN ' ซ.' + ad.SoiTH ELSE '' END AS SoiTH
,CASE WHEN (SELECT TOP 1 NameTH FROM crmrevo.MST.Province pv WHERE pv.id = ad.ProvinceID) LIKE '%กรุงเทพ%' 
	THEN 'แขวง' + (SELECT TOP 1 NameTH FROM crmrevo.MST.SubDistrict sd WHERE sd.DistrictID = ad.DistrictID AND sd.ID = ad.SubDistrictID)
	ELSE 'ตำบล' + (SELECT TOP 1 NameTH FROM crmrevo.MST.SubDistrict sd WHERE sd.DistrictID = ad.DistrictID AND sd.ID = ad.SubDistrictID) END SubDistrictName
,CASE WHEN (SELECT TOP 1 NameTH FROM crmrevo.MST.Province pv WHERE pv.id = ad.ProvinceID) LIKE '%กรุงเทพ%'
	THEN ' เขต' + (SELECT TOP 1 NameTH FROM crmrevo.MST.District dt WHERE dt.ProvinceID = ad.ProvinceID AND dt.ID = ad.DistrictID)
	ELSE ' อำเภอ' + (SELECT TOP 1 NameTH FROM crmrevo.MST.District dt WHERE dt.ProvinceID = ad.ProvinceID AND dt.ID = ad.DistrictID) END AS DistrictName
,(SELECT TOP 1 NameTH FROM crmrevo.MST.Province pv WHERE pv.id = ad.ProvinceID) AS ProvinceName
,(SELECT TOP 1 sd.PostalCode FROM crmrevo.MST.SubDistrict sd WHERE sd.DistrictID = ad.DistrictID) AS PostCode
FROM crmrevo.PRJ.Address ad, crmrevo.PRJ.Project p 
WHERE 1=1
AND ad.ProjectID = p.ID
AND p.IsDeleted = 0
AND p.IsActive = 1
AND ad.ProjectAddressTypeMasterCenterID = (
	SELECT mc.ID FROM crmrevo.MST.MasterCenter mc WHERE mc.MasterCenterGroupKey = 'ProjectAddressType' AND mc.[Order] = 1)
go

