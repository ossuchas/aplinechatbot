
CREATE PROCEDURE [dbo].[sp_crm_procline_refund]
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Msg AS VARCHAR(MAX);
    DECLARE @productid AS VARCHAR(15);
    DECLARE @project AS VARCHAR(255);
    DECLARE @unitnumber AS VARCHAR(10);
    DECLARE @fullname AS VARCHAR(255);
    DECLARE @amount AS VARCHAR(20);
    DECLARE @doc_sent_date AS VARCHAR(50);
    DECLARE @hyrf_id AS BIGINT;

    DECLARE db_cursor CURSOR FOR
    SELECT hyrf_id
    FROM [DBLINK_SVR_CRMREVO].crmrevo.RFN.crm_contact_refund WITH (NOLOCK)
    WHERE 1=1
	--AND ISNULL(line_sent_status, 'N') = 'N' -- Modified by Suchat S. 2020-10-21 for change log line notify
	AND ISNULL(doc_sent_status,'N') = 'Y'
	AND tran_status = 'A'
	AND hyrf_id NOT IN (SELECT hyrf_id FROM crmrevo_dw.dbo.log_refund_line_notify WITH(NOLOCK))

    OPEN db_cursor;
    FETCH NEXT FROM db_cursor
    INTO @hyrf_id;

    WHILE @@FETCH_STATUS = 0
    BEGIN

        SELECT @hyrf_id = S.hyrf_id,
               @productid = S.productid,
               @project = S.project,
               @unitnumber = S.unitnumber,
               @fullname = S.fullname,
               @amount = FORMAT(S.remainingtotalamount, '#,##0.00'),
               @doc_sent_date = FORMAT(S.doc_sent_date, 'dd/MM/yyyy HH:mm')
        FROM [DBLINK_SVR_CRMREVO].crmrevo.RFN.crm_contact_refund S WITH (NOLOCK)
        WHERE 1 = 1
              AND hyrf_id = @hyrf_id;

        SET @Msg
    = '
ProjectId: ' + ISNULL(@productid,'') + CHAR(10) + 
'Project Name: ' + ISNULL(@project,'') + CHAR(10) + 
'Unit No.: ' + ISNULL(@unitnumber,'') + CHAR(10) + 
'Name: ' + ISNULL(@fullname,'') + CHAR(10) + 
'Refund Amount: ' + ISNULL(@amount,'') + CHAR(10) + 
'Sent Doc.: '+ ISNULL(@doc_sent_date,'');

        --REFUND, PERSONAL
        EXEC crmrevo_dw.dbo.sp_InstLineNotifyMsg @LineToken = 'REFUND',
                                                                          @LineOwner = 'HAPPYREFUND',
                                                                          @LineMobile = @hyrf_id,
                                                                          @LineMsg = @Msg,
                                                                          @FilePath = '',
                                                                          @Remarks = '',
                                                                          @CreateBy = 'Suchat_S';
		
		--REFUNDTF01
        EXEC crmrevo_dw.dbo.sp_InstLineNotifyMsg @LineToken = 'REFUNDTF01',
                                                                          @LineOwner = 'HAPPYREFUND',
                                                                          @LineMobile = @hyrf_id,
                                                                          @LineMsg = @Msg,
                                                                          @FilePath = '',
                                                                          @Remarks = '',
                                                                          @CreateBy = 'Suchat_S';
		
		INSERT INTO dbo.log_refund_line_notify
		(
		    hyrf_id,
		    tran_status,
		    createby,
		    createdate,
		    modifyby,
		    modifydate
		)
		VALUES
		(   @hyrf_id,  
		    'N',       
		    'sp_crm_procline_refund',
		    GETDATE(), 
		    'sp_crm_procline_refund',
		    GETDATE()
		)
        
		--UPDATE [DBLINK_SVR_CRMREVO].crmrevo.RFN.crm_contact_refund
  --      SET line_sent_status = 'Y',
  --          line_sent_date = GETDATE()
  --      WHERE hyrf_id = @hyrf_id;


        FETCH NEXT FROM db_cursor
        INTO @hyrf_id;
    END;

    CLOSE db_cursor;
    DEALLOCATE db_cursor;

END;



go

