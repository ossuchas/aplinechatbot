

CREATE PROCEDURE [dbo].[sp_GetHRCommissionByLC]
    @flag AS VARCHAR(2)
AS
BEGIN
    SET NOCOUNT ON;

	DECLARE @PeriodYear INT;
	DECLARE @PeriodMonth INT;

	SELECT @PeriodYear = DATEPART(YEAR, GETDATE()),-- Current Year
	 @PeriodMonth = DATEPART(MONTH,DATEADD(mm, DATEDIFF(mm,0,getdate())-1, 0)) -- Last Month

	DECLARE @v TABLE(ProjectID uniqueidentifier, UserID uniqueidentifier, flag nvarchar(250));

	IF @flag = '1' --Project HighRise Sale
	BEGIN
	    --PRINT '1'
		--DECLARE @v TABLE(ProjectID uniqueidentifier, UserID uniqueidentifier, flag nvarchar(250));

		INSERT INTO @v
		SELECT DISTINCT P.ID, C.SaleUserID, N'พนง.ปิดการขาย --> ขายภายในเดือน'
		FROM crmrevo.[CMS].[CalculateHighRiseSale] C WITH (NOLOCK)
		LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON C.ProjectNo = P.ProjectNo
		WHERE 1=1
			AND C.PeriodYear = @PeriodYear
			AND C.PeriodMonth = @PeriodMonth
			AND ISNULL(C.IsDeleted,0) = 0
			AND C.SaleUserID IS NOT NULL
			AND NOT EXISTS(SELECT * FROM @v WHERE UserID = C.SaleUserID AND ProjectID = P.ID)

		INSERT INTO @v
		SELECT DISTINCT P.ID, ProjectSaleUserID, N'พนง.ประจำโครงการ --> ขายภายในเดือน'
		FROM crmrevo.[CMS].[CalculateHighRiseSale] C WITH (NOLOCK)
		LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON C.ProjectNo = P.ProjectNo
		WHERE 1=1
			AND C.PeriodYear = @PeriodYear
			AND C.PeriodMonth = @PeriodMonth
			AND ISNULL(C.IsDeleted,0) = 0
			AND C.ProjectSaleUserID IS NOT NULL
			AND NOT EXISTS(SELECT * FROM @v WHERE UserID = C.ProjectSaleUserID AND ProjectID = P.ID)


		INSERT INTO @v
		SELECT DISTINCT C.ProjectID, C.SaleUserID, N'พนง.โอน --> ค่าอื่น ค่าหัก'
		FROM crmrevo.[CMS].[CalculateIncreaseDeductMoney] C WITH (NOLOCK)
		LEFT OUTER JOIN crmrevo.[USR].[User] U WITH (NOLOCK) ON C.SaleUserID = U.ID
		LEFT OUTER JOIN crmrevo.[USR].[UserRole] UR WITH (NOLOCK) ON U.ID = UR.UserID
		LEFT OUTER JOIN crmrevo.[USR].[Role] R WITH (NOLOCK) ON UR.RoleID = R.ID
		LEFT OUTER JOIN crmrevo.PRJ.Project P WITH (NOLOCK) ON P.ID = C.ProjectID
		WHERE R.Code = 'LC'
			AND ISNULL(C.IsDeleted,0) = 0
			AND C.PeriodYear = @PeriodYear
			AND C.PeriodMonth = @PeriodMonth
			AND (C.IncreaseAmount > 0 OR C.DeductAmount > 0)
			AND C.SaleUserID IS NOT NULL
			AND NOT EXISTS(SELECT * FROM @v WHERE UserID = C.SaleUserID AND ProjectID = C.ProjectID)
			AND P.ProductTypeMasterCenterID = '51109061-FE6A-45FF-8732-314EE53F7C63'--แนวสูง

		---------------------------------------------------------------------------------------------------------------------------------



		SELECT	'BG' = BG.BGNo,
				'SUBBG' = SBG.SubBGNo,
				'ProjectNo' = P.ProjectNo,
				'ProjectName' = crmrevo.[dbo].[fn_GetProjectName](P.ProjectNo),
				'HCSName' = crmrevo.[dbo].[fn_GetHeadOfCS](P.ProjectNo,'S'),
				'UserID' = U.UserID,
				'EmployeeNo' = U.EmployeeNo,
				'DisplayName' = U.DisplayName,
				'CommSale' = ISNULL(S1.CommSale1,0) + ISNULL(S2.CommSale2,0),
				'NewLaunch' = ISNULL(S1.NewLaunch1,0) + ISNULL(S2.NewLaunch2,0),
				'LCCCommPaid' = 0,
				'SumOther' = ISNULL(O.SumOther,0),
				'SumAdjust' = ISNULL(O.SumAdjust,0),
				'TotalCommission' = ISNULL(S1.CommSale1,0) + ISNULL(S2.CommSale2,0) + 
									ISNULL(S1.NewLaunch1,0) + ISNULL(S2.NewLaunch2,0) +
									ISNULL(O.SumOther,0) - ISNULL(O.SumAdjust,0)
				--'flag' = U.flag			
		FROM 
				(
					SELECT DISTINCT V.ProjectID, V.UserID, US.EmployeeNo, US.DisplayName, V.flag
					FROM @v V 
					LEFT OUTER JOIN crmrevo.[USR].[User] US WITH (NOLOCK) ON V.UserID = US.ID
				) U
				LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON U.ProjectID = P.ID
				LEFT OUTER JOIN crmrevo.MST.BG BG WITH (NOLOCK) ON BG.ID = P.BGID
				LEFT OUTER JOIN crmrevo.MST.SubBG SBG WITH (NOLOCK) ON SBG.ID = P.SubBGID
				LEFT OUTER JOIN crmrevo.MST.MasterCenter M ON M.ID = P.ProductTypeMasterCenterID
				LEFT OUTER JOIN 
				(
					SELECT C.ProjectNo,C.SaleUserID, SUM(C.SaleUserSalePaid) AS CommSale1, 0 AS NewLaunch1
					FROM crmrevo.[CMS].[CalculateHighRiseSale] C WITH (NOLOCK)
					LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON C.ProjectNo = P.ProjectNo
					WHERE 1=1
						AND C.PeriodYear = @PeriodYear
						AND C.PeriodMonth = @PeriodMonth
						AND ISNULL(C.IsDeleted,0) = 0
					GROUP BY C.ProjectNo,C.SaleUserID
				) S1 ON U.UserID = S1.SaleUserID AND S1.ProjectNo = P.ProjectNo
				LEFT OUTER JOIN 
				(
					SELECT C.ProjectNo,C.ProjectSaleUserID, SUM(C.ProjectSaleSalePaid) AS CommSale2, 0 AS NewLaunch2
					FROM crmrevo.[CMS].[CalculateHighRiseSale] C WITH (NOLOCK)
					LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON C.ProjectNo = P.ProjectNo
					WHERE 1=1
						AND C.PeriodYear = @PeriodYear
						AND C.PeriodMonth = @PeriodMonth
						AND ISNULL(C.IsDeleted,0) = 0
					GROUP BY C.ProjectNo,C.ProjectSaleUserID
				) S2 ON U.UserID = S2.ProjectSaleUserID AND S2.ProjectNo = P.ProjectNo
				LEFT OUTER JOIN 
				(
					SELECT P.ProjectNo,C.SaleUserID, SUM(C.IncreaseAmount) AS SumOther, SUM(C.DeductAmount) AS SumAdjust
					FROM crmrevo.[CMS].[CalculateIncreaseDeductMoney] C WITH (NOLOCK)
					LEFT OUTER JOIN crmrevo.[USR].[User] U WITH (NOLOCK) ON C.SaleUserID = U.ID
					LEFT OUTER JOIN crmrevo.[USR].[UserRole] UR WITH (NOLOCK) ON U.ID = UR.UserID
					LEFT OUTER JOIN crmrevo.[USR].[Role] R WITH (NOLOCK) ON UR.RoleID = R.ID
					LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON P.ID = C.ProjectID
					WHERE R.Code = 'LC'
						AND ISNULL(C.IsDeleted,0) = 0
						AND C.PeriodYear = @PeriodYear
						AND C.PeriodMonth = @PeriodMonth
						AND (C.IncreaseAmount > 0 OR C.DeductAmount > 0)
						AND P.ProductTypeMasterCenterID = '51109061-FE6A-45FF-8732-314EE53F7C63'--แนวสูง
					GROUP BY P.ProjectNo,C.SaleUserID
				) O ON U.UserID = O.SaleUserID AND O.ProjectNo = P.ProjectNo
		WHERE	(ISNULL(S1.CommSale1,0)+ISNULL(S2.CommSale2,0) 
				+ ISNULL(S1.NewLaunch1,0)+ISNULL(S2.NewLaunch2,0)
				+ ISNULL(O.SumOther,0) - ISNULL(O.SumAdjust,0)) > 0
			AND M.[Key] = '2'

		ORDER BY BG.BGNo, P.ProjectNo, U.EmployeeNo;
		
	END
	ELSE
	BEGIN
	    IF @flag = '2' --Project HighRise Transfer
		BEGIN
		    --PRINT '2'

			DECLARE @v_tbl TABLE(ProductID UNIQUEIDENTIFIER, UserID UNIQUEIDENTIFIER, flag nvarchar(250));

			INSERT INTO @v_tbl
			SELECT DISTINCT P.ID,T.LCTransferID,'พนง.ประจำโครงการ --> โอนภายในเดือน'
			FROM crmrevo.CMS.CalculateHighRiseTransfer T
			LEFT JOIN crmrevo.PRJ.Project P ON P.ProjectNo = T.ProjectNo
			WHERE 1=1
				AND T.PeriodYear = @PeriodYear
				AND T.PeriodMonth = @PeriodMonth
				AND T.IsDeleted=0
				AND T.LCTransferID IS NOT NULL
				AND NOT EXISTS(SELECT * FROM @v_tbl WHERE UserID=LCTransferID AND ProductID = P.ID)

			INSERT INTO @v_tbl
			SELECT DISTINCT O.ProjectID,O.SaleUserID,'พนง.โอน --> ค่าอื่น ค่าหัก'
			FROM crmrevo.CMS.CalculateIncreaseDeductMoney O 
			LEFT JOIN crmrevo.PRJ.Project P ON P.ID = O.ProjectID
			LEFT JOIN crmrevo.USR.[User] usr ON usr.ID = O.SaleUserID
			LEFT JOIN crmrevo.USR.UserRole ur ON ur.UserID = usr.ID
			LEFT JOIN crmrevo.USR.Role r ON r.ID = ur.RoleID
			WHERE r.Code='LC'
				AND O.PeriodYear = @PeriodYear
				AND O.PeriodMonth = @PeriodMonth
				AND (O.IncreaseAmount > 0 OR O.DeductAmount > 0)
				AND O.SaleUserID IS NOT NULL
				AND NOT EXISTS(SELECT * FROM @v_tbl WHERE UserID=O.SaleUserID AND ProductID = O.ProjectID)

			---------------------------------------------------------------------------------------------------------------------------------

			SELECT 'BG' = BG.BGNo,
				'SUBBG' = SBG.SubBGNo,
				U.ProductID AS ProductID,
				crmrevo.[dbo].[fn_GetProjectName](U.ProductID) AS ProductName,
				crmrevo.[dbo].[fn_GetHeadOfCS](U.ProductID,'T') AS HCSName,
				U.UserID,
				U.EmployeeID,
				U.DisplayName,
				'CommTrans' = ISNULL(T2.CommTrans2,0),
				'LCCCommPaid' = 0,
				'SumOther' = ISNULL(O.SumOther,0),
				'SumAdjust' = ISNULL(O.SumAdjust,0),
				'TotalCommission' = ISNULL(T2.CommTrans2,0) +
						ISNULL(O.SumOther,0) - ISNULL(O.SumAdjust,0)
			
			FROM 
				(
					SELECT DISTINCT P.ProjectNo AS ProductID,V.UserID,US.EmployeeNo AS EmployeeID,US.DisplayName,
						V.flag,P.BGID,P.SubBGID,P.ProductTypeMasterCenterID,P.ProjectNo
					FROM @v_tbl V  
					LEFT OUTER JOIN	crmrevo.USR.[User] US ON V.UserID=US.ID 
					LEFT OUTER JOIN crmrevo.PRJ.Project P ON P.ID = V.ProductID	
				) U	
				LEFT OUTER JOIN crmrevo.MST.BG BG WITH (NOLOCK) ON BG.ID = U.BGID
				LEFT OUTER JOIN crmrevo.MST.SubBG SBG WITH (NOLOCK) ON SBG.ID = U.SubBGID
				LEFT OUTER JOIN crmrevo.MST.MasterCenter M ON M.ID = U.ProductTypeMasterCenterID
				LEFT OUTER JOIN 
				(
					SELECT P.ProjectNo, T.LCTransferID AS SaleHelperID,SUM(T.LCTransferPaid) AS CommTrans2
					FROM crmrevo.CMS.CalculateHighRiseTransfer T
					LEFT JOIN crmrevo.PRJ.Project P ON P.ProjectNo = T.ProjectNo
					WHERE 1=1
						AND T.PeriodYear = @PeriodYear
						AND T.PeriodMonth = @PeriodMonth
						AND T.IsDeleted=0
					GROUP BY  P.ProjectNo,T.LCTransferID
				) T2 ON U.UserID=T2.SaleHelperID AND T2.ProjectNo = U.ProjectNo
				LEFT OUTER JOIN 
				(
					SELECT  P.ProjectNo,O.SaleUserID,SUM(O.IncreaseAmount) AS SumOther,SUM(O.DeductAmount) AS SumAdjust
					FROM crmrevo.CMS.CalculateIncreaseDeductMoney O 
					LEFT JOIN crmrevo.PRJ.Project P ON P.ID = O.ProjectID
					LEFT JOIN crmrevo.USR.[User] usr ON usr.ID = O.SaleUserID
					LEFT JOIN crmrevo.USR.UserRole ur ON ur.UserID = usr.ID
					LEFT JOIN crmrevo.USR.Role r ON r.ID = ur.RoleID
					WHERE r.Code='LC'
						AND O.PeriodYear = @PeriodYear
						AND O.PeriodMonth = @PeriodMonth
						AND (O.IncreaseAmount > 0 OR O.DeductAmount > 0)
					GROUP BY  P.ProjectNo,O.SaleUserID
				) O ON U.UserID=O.SaleUserID AND O.ProjectNo = U.ProjectNo
	
			WHERE (ISNULL(T2.CommTrans2,0) + 			
				ISNULL(O.SumOther,0) - ISNULL(O.SumAdjust,0) ) > 0
				AND M.[Key] = '2'

			ORDER BY BG.BGNo, U.ProductID,U.EmployeeID;
			
		END
		ELSE --Project LowRise Sale-Transfer
        BEGIN
            --PRINT '3'

			DECLARE @v_tbl2 TABLE(ProjectID uniqueidentifier, UserID uniqueidentifier, flag int);

			INSERT INTO @v_tbl2
			SELECT P.ID, C.SaleUserID, 1
			FROM crmrevo.[CMS].[CalculateLowRiseSale] C WITH (NOLOCK)
			LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON C.ProjectNo = P.ProjectNo
			LEFT OUTER JOIN crmrevo.MST.MasterCenter M ON M.ID = P.ProductTypeMasterCenterID
			WHERE 1=1
				AND C.PeriodYear = @PeriodYear
				AND C.PeriodMonth = @PeriodMonth
				AND ISNULL(C.IsDeleted,0) = 0
				AND C.SaleUserID IS NOT NULL
				AND M.[Key] = '1'

			INSERT INTO @v_tbl2
			SELECT P.ID, C.ProjectSaleUserID, 1
			FROM crmrevo.[CMS].[CalculateLowRiseSale] C WITH (NOLOCK)
			LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON C.ProjectNo = P.ProjectNo
			WHERE 1=1
				AND C.PeriodYear = @PeriodYear
				AND C.PeriodMonth = @PeriodMonth
				AND ISNULL(C.IsDeleted,0) = 0
				AND C.ProjectSaleUserID IS NOT NULL

			INSERT INTO @v_tbl2	
			SELECT P.ID, C.SaleUserID, 2
			FROM crmrevo.[CMS].[CalculateLowRiseTransfer] C WITH (NOLOCK) 
			LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON C.ProjectNo = P.ProjectNo
			WHERE 1=1
				AND C.PeriodYear = @PeriodYear
				AND C.PeriodMonth = @PeriodMonth
				AND ISNULL(C.IsDeleted,0) = 0
				AND C.SaleUserID IS NOT NULL

			INSERT INTO @v_tbl2
			SELECT P.ID, C.ProjectSaleUserID, 2
			FROM crmrevo.[CMS].[CalculateLowRiseTransfer] C WITH (NOLOCK) 
			LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON C.ProjectNo = P.ProjectNo
			WHERE 1=1
				AND C.PeriodYear = @PeriodYear
				AND C.PeriodMonth = @PeriodMonth
				AND ISNULL(C.IsDeleted,0) = 0
				AND C.ProjectSaleUserID IS NOT NULL

			INSERT INTO @v_tbl2
			SELECT C.ProjectID, C.SaleUserID, 3
			FROM crmrevo.[CMS].[CalculateIncreaseDeductMoney] C WITH (NOLOCK)
			LEFT OUTER JOIN crmrevo.[USR].[User] U WITH (NOLOCK) ON C.SaleUserID = U.ID
			LEFT OUTER JOIN crmrevo.[USR].[UserRole] UR WITH (NOLOCK) ON U.ID = UR.UserID
			LEFT OUTER JOIN crmrevo.[USR].[Role] R WITH (NOLOCK) ON UR.RoleID = R.ID
			LEFT OUTER JOIN crmrevo.PRJ.Project P WITH (NOLOCK) ON P.ID = C.ProjectID
			WHERE R.Code = 'LC'
				AND ISNULL(C.IsDeleted,0) = 0
				AND C.PeriodYear = @PeriodYear
				AND C.PeriodMonth = @PeriodMonth
				AND (C.IncreaseAmount > 0 OR C.DeductAmount > 0)
				AND C.SaleUserID IS NOT NULL
				AND NOT EXISTS(SELECT * FROM @v_tbl2 WHERE UserID = C.SaleUserID)
				AND P.ProductTypeMasterCenterID = 'B23B99C8-7812-4B39-AFB3-BDFE224730DE'--แนวราบ


			SELECT	'BG' = BG.BGNo,
					'SUBBG' = SBG.SubBGNo,
					'ProjectNo' = P.ProjectNo,
					'ProjectName' = crmrevo.[dbo].[fn_GetProjectName](P.ProjectNo),
					'HCSName' = crmrevo.[dbo].[fn_GetHeadOfCS](P.ProjectNo,'S'),
					'UserID' = U.UserID,
					'EmployeeNo' = U.EmployeeNo,
					'DisplayName' = U.DisplayName,
					'CommSale' = ISNULL(S1.CommSale1,0) + ISNULL(S2.CommSale2,0),
					'CommTrans' = ISNULL(T1.CommTrans1,0) + ISNULL(T2.CommTrans2,0),
					'NewLaunch' = ISNULL(S1.NewLaunch1,0) + ISNULL(S2.NewLaunch2,0),
					'LCCCommPaid' = 0,
					'SumOther' = ISNULL(O.SumOther,0),
					'SumAdjust' = ISNULL(O.SumAdjust,0),
					'TotalCommission' = ISNULL(S1.CommSale1,0) + ISNULL(S2.CommSale2,0) + 
										ISNULL(T1.CommTrans1,0) + ISNULL(T2.CommTrans2,0) + 
										ISNULL(S1.NewLaunch1,0) + ISNULL(S2.NewLaunch2,0) +
										ISNULL(O.SumOther,0) - ISNULL(O.SumAdjust,0)			
			FROM 
					(
						SELECT DISTINCT V.ProjectID, V.UserID, US.EmployeeNo, US.DisplayName
						FROM @v_tbl2 V 
						LEFT OUTER JOIN crmrevo.[USR].[User] US WITH (NOLOCK) ON V.UserID = US.ID
					) U	
					LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON U.ProjectID = P.ID
					LEFT OUTER JOIN crmrevo.MST.BG BG WITH (NOLOCK) ON BG.ID = P.BGID
					LEFT OUTER JOIN crmrevo.MST.SubBG SBG WITH (NOLOCK) ON SBG.ID = P.SubBGID
					LEFT OUTER JOIN 
					(
						SELECT C.ProjectNo,C.SaleUserID, SUM(C.SaleUserSalePaid) AS CommSale1, SUM(C.SaleUserNewLaunchPaid) AS NewLaunch1
						FROM crmrevo.[CMS].[CalculateLowRiseSale] C WITH (NOLOCK)
						LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON C.ProjectNo = P.ProjectNo
						WHERE 1=1
							AND C.PeriodYear = @PeriodYear
							AND C.PeriodMonth = @PeriodMonth
							AND ISNULL(C.IsDeleted,0) = 0
						GROUP BY C.ProjectNo,C.SaleUserID
					) S1 ON U.UserID = S1.SaleUserID AND S1.ProjectNo = P.ProjectNo
					LEFT OUTER JOIN 
					(
						SELECT C.ProjectNo,C.ProjectSaleUserID, SUM(C.ProjectSaleSalePaid) AS CommSale2, SUM(C.ProjectSaleNewLaunchPaid) AS NewLaunch2
						FROM crmrevo.[CMS].[CalculateLowRiseSale] C WITH (NOLOCK)
						LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON C.ProjectNo = P.ProjectNo
						WHERE 1=1
							AND C.PeriodYear = @PeriodYear
							AND C.PeriodMonth = @PeriodMonth
							AND ISNULL(C.IsDeleted,0) = 0
						GROUP BY C.ProjectNo,C.ProjectSaleUserID
					) S2 ON U.UserID = S2.ProjectSaleUserID AND S2.ProjectNo = P.ProjectNo
					LEFT OUTER JOIN 
					(
						SELECT C.ProjectNo,C.SaleUserID, SUM(C.SaleUserSalePaid) AS CommTrans1
						FROM crmrevo.[CMS].[CalculateLowRiseTransfer] C WITH (NOLOCK) 
						LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON C.ProjectNo = P.ProjectNo
						WHERE 1=1
							AND C.PeriodYear = @PeriodYear
							AND C.PeriodMonth = @PeriodMonth
							AND ISNULL(C.IsDeleted,0) = 0
						GROUP BY C.ProjectNo,C.SaleUserID
					) T1 ON U.UserID = T1.SaleUserID AND T1.ProjectNo = P.ProjectNo
					LEFT OUTER JOIN 
					(
						SELECT C.ProjectNo,C.ProjectSaleUserID, SUM(C.ProjectSaleSalePaid) AS CommTrans2
						FROM crmrevo.[CMS].[CalculateLowRiseTransfer] C WITH (NOLOCK) 
						LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON C.ProjectNo = P.ProjectNo
						WHERE 1=1
							AND C.PeriodYear = @PeriodYear
							AND C.PeriodMonth = @PeriodMonth
							AND ISNULL(C.IsDeleted,0) = 0
						GROUP BY C.ProjectNo,C.ProjectSaleUserID
					) T2 ON U.UserID = T2.ProjectSaleUserID AND T2.ProjectNo = P.ProjectNo
					LEFT OUTER JOIN 
					(
						SELECT P.ProjectNo,C.SaleUserID, SUM(C.IncreaseAmount) AS SumOther, SUM(C.DeductAmount) AS SumAdjust
						FROM crmrevo.[CMS].[CalculateIncreaseDeductMoney] C WITH (NOLOCK)
						LEFT OUTER JOIN crmrevo.[USR].[User] U WITH (NOLOCK) ON C.SaleUserID = U.ID
						LEFT OUTER JOIN crmrevo.[USR].[UserRole] UR WITH (NOLOCK) ON U.ID = UR.UserID
						LEFT OUTER JOIN crmrevo.[USR].[Role] R WITH (NOLOCK) ON UR.RoleID = R.ID
						LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON P.ID = C.ProjectID
						WHERE R.Code = 'LC'
							AND ISNULL(C.IsDeleted,0) = 0
							AND C.PeriodYear = @PeriodYear
							AND C.PeriodMonth = @PeriodMonth
							AND (C.IncreaseAmount > 0 OR C.DeductAmount > 0)
							AND P.ProductTypeMasterCenterID = 'B23B99C8-7812-4B39-AFB3-BDFE224730DE' --แนวราบ
						GROUP BY P.ProjectNo,C.SaleUserID 
					) O ON U.UserID = O.SaleUserID	AND O.ProjectNo = P.ProjectNo
			WHERE	(ISNULL(S1.CommSale1,0)+ISNULL(S2.CommSale2,0) 
					+ ISNULL(T1.CommTrans1,0)+ISNULL(T2.CommTrans2,0)
					+ ISNULL(S1.NewLaunch1,0)+ISNULL(S2.NewLaunch2,0)
					+ ISNULL(O.SumOther,0) - ISNULL(O.SumAdjust,0)) > 0
			ORDER BY BG.BGNo, P.ProjectNo, U.EmployeeNo;
			
        END
	END
	



END;



go

