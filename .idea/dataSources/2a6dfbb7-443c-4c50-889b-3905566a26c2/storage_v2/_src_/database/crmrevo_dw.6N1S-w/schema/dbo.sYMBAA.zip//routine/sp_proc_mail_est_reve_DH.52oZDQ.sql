
CREATE PROCEDURE [dbo].[sp_proc_mail_est_reve_DH]
As

    SET NOCOUNT ON;

	DECLARE @head_curr_quarter    AS VARCHAR(100);
	DECLARE @head_previous_quarter    AS VARCHAR(100);
	
	DECLARE @head_est_d1      AS VARCHAR(100);
	DECLARE @head_est_d2      AS VARCHAR(100);
	DECLARE @head_est_d3      AS VARCHAR(100);
	DECLARE @head_est_d4      AS VARCHAR(100);
	DECLARE @head_est_d5      AS VARCHAR(100);

	DECLARE @i_count AS INT;

	DECLARE @val_date AS VARCHAR(20)

	DECLARE @month_no AS INT
	DECLARE @month_name AS VARCHAR(20);

	DECLARE @head_month_m1 AS VARCHAR(20);
	DECLARE @head_month_m2 AS VARCHAR(20);
	DECLARE @head_month_m3 AS VARCHAR(20);
	
	--SELECT FORMAT(GETDATE(), 'dd.MM.yyyy')

	SELECT @head_curr_quarter = 'Q' + CAST(DATEPART(QUARTER, GETDATE()) AS VARCHAR(5))
	SELECT @head_previous_quarter = 'Q' + CAST(DATEPART(QUARTER, DATEADD(qq, DATEDIFF(qq, 0, GETDATE()) - 1, 0)) AS VARCHAR(5)) --Get  previous quarter 

	SET @i_count = 1
	DECLARE db_cursor CURSOR
	FOR
			SELECT TOP 5 FORMAT(DateOfYear,'dd.MM.yyyy')
			FROM crmrevo.BI.Mst_WorkDayCalendar WITH(NOLOCK)
			WHERE DateOfYear >= CAST(GETDATE() AS DATE) 
			AND SatSunDayFlag = 'N' AND HolidayFlag = 'N'
			ORDER BY DateOfYear

	OPEN db_cursor  
	FETCH NEXT FROM db_cursor INTO @val_date

	WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @i_count = 1
			BEGIN
			    --PRINT 'day1'
				SET @head_est_d1 = @val_date;
			END

			IF @i_count = 2
			BEGIN
				--PRINT 'day2'
				SET @head_est_d2 = @val_date;
			END
            
			IF @i_count = 3 
			BEGIN
			    --PRINT 'day3'
				SET @head_est_d3 = @val_date;
			END

			IF @i_count = 4
			BEGIN
			    --PRINT 'day4'
				SET @head_est_d4 = @val_date;
			END

			IF @i_count = 5
			BEGIN
			    --PRINT 'day5'
				SET @head_est_d5 = @val_date;
			END
			
			SET @i_count = @i_count + 1
			FETCH NEXT FROM db_cursor INTO @val_date
		END 

	CLOSE db_cursor  
	DEALLOCATE db_cursor


	-- Get earch month for current quarter
	SET @i_count = 1
	DECLARE db_cursor CURSOR
	FOR
		SELECT DISTINCT m, SUBSTRING('Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec ', (m * 4) - 3, 3) month_name
		FROM crmrevo.BI.Mst_Calendar_Week WITH(NOLOCK)
		WHERE 1=1
		AND DATEPART(YEAR, StartDate) = DATEPART(YEAR,GETDATE())
		AND DATEPART(QUARTER, StartDate) = DATEPART(QUARTER,GETDATE())
		ORDER BY m

	OPEN db_cursor  
	FETCH NEXT FROM db_cursor INTO @month_no, @month_name

	WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @i_count = 1
			BEGIN
			    --PRINT 'Month 1'
				SET @head_month_m1 = @month_name;
			END

			IF @i_count = 2
			BEGIN
				--PRINT 'Month 2'
				SET @head_month_m2 = @month_name;
			END
            
			IF @i_count = 3 
			BEGIN
			    --PRINT 'Month 3'
				SET @head_month_m3 = @month_name;
			END
			
			SET @i_count = @i_count + 1
			FETCH NEXT FROM db_cursor INTO @month_no, @month_name
		END 

	CLOSE db_cursor  
	DEALLOCATE db_cursor

	SELECT @head_curr_quarter AS head_curr_quarter,
	 @head_est_d1 AS head_est_d1,
	 @head_est_d2 AS head_est_d2,
	 @head_est_d3 AS head_est_d3,
	 @head_est_d4 AS head_est_d4,
	 @head_est_d5 AS head_est_d5,
	 @head_month_m1 AS head_m1,
	 @head_month_m2 AS head_m2,
	 @head_month_m3 AS head_m3,
	 @head_previous_quarter AS head_previous_quarter



go

