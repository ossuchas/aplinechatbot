CREATE VIEW dbo.vw_Customer
as
 SELECT  
	v.ID
  ,'ContactNo'=v.ContactNo
  ,'TitleTH'=Isnull((Select TOP 1 t.Name From crmrevo.MST.MasterCenter t
									WHERE t.ID=v.ContactTitleTHMasterCenterID),v.TitleExtTH)
  ,'FirstNameTH'=ISNULL(v.FirstNameTH,'')  
  ,'LastNameTH'=ISNULL(v.LastNameTH,'')
  ,'FullNameTH'=ISNULL(v.FullNameTH,'')
  ,'NickName'=ISNULL(v.NickName,'')
  ,'Age'=DATEDIFF(yy,v.BirthDate,GETDATE())
  ,'BirthDate'=v.BirthDate
  ,'Gender'=ISNULL(gender.Name,'')
  ,v.IsVIP
  ,'IdentityPersonNumber'=v.CitizenIdentityNo
  ,v.IsThaiNationality
  ,'Nationality'=Isnull((Select TOP 1 PhoneNumber From crmrevo.MST.MasterCenter t
									WHERE t.ID=v.NationalMasterCenterID),'')
  ,'Email'=Isnull((Select TOP 1 Email From crmrevo.CTM.ContactEmail t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									ORDER BY t.IsMain Desc),'')  

  ,'MobileNumbers'=Isnull((Select TOP 1 PhoneNumber From crmrevo.CTM.ContactPhone t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.PhoneTypeMasterCenterID ='AEA43111-CC3C-4CA8-BAAA-F952C4C5594D' -- เบอร์มือถือ
									ORDER BY t.Created Desc),'')

	 ,'PhoneNumbers'=Isnull((Select TOP 1 PhoneNumber From crmrevo.CTM.ContactPhone t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.PhoneTypeMasterCenterID ='2EDAC6DE-A36C-429E-90A5-BBB2F323AABA' -- เบอร์บ้าน
									ORDER BY t.Created Desc),'')
  
  /*ที่อยู่ที่ติดต่อได้*/
  ,'ContactAddress_HouseNo'=Isnull((Select TOP 1 t.HouseNoTH From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='D98F7C94-4BA4-4E6A-B311-8A4CBB0C944F' -- ที่อยู่ที่ติดต่อได้
									ORDER BY t.Created Desc),'')
,'ContactAddress_Moo'=Isnull((Select TOP 1 MooTH From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='D98F7C94-4BA4-4E6A-B311-8A4CBB0C944F' -- ที่อยู่ที่ติดต่อได้
									ORDER BY t.Created Desc),'')
,'ContactAddress_Village'=Isnull((Select TOP 1 VillageTH From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='D98F7C94-4BA4-4E6A-B311-8A4CBB0C944F' -- ที่อยู่ที่ติดต่อได้
									ORDER BY t.Created Desc),'')
  ,'ContactAddress_Soi'=Isnull((Select TOP 1 SoiTH From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='D98F7C94-4BA4-4E6A-B311-8A4CBB0C944F' -- ที่อยู่ที่ติดต่อได้
									ORDER BY t.Created Desc),'')

,'ContactAddress_Road'=Isnull((Select TOP 1 RoadTH From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='D98F7C94-4BA4-4E6A-B311-8A4CBB0C944F' -- ที่อยู่ที่ติดต่อได้
									ORDER BY t.Created Desc),'')

  ,'ContactAddress_SubDistrict'=Isnull((Select TOP 1 a.NameTH From crmrevo.CTM.ContactAddress t
									LEFT JOIN crmrevo.MST.SubDistrict a ON t.SubDistrictID=a.ID
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='D98F7C94-4BA4-4E6A-B311-8A4CBB0C944F' -- ที่อยู่ที่ติดต่อได้
									ORDER BY t.Created Desc),'')
  ,'ContactAddress_District'=Isnull((Select TOP 1 a.NameTH From crmrevo.CTM.ContactAddress t
									LEFT JOIN crmrevo.MST.District a ON t.DistrictID=a.ID
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='D98F7C94-4BA4-4E6A-B311-8A4CBB0C944F' -- ที่อยู่ที่ติดต่อได้
									ORDER BY t.Created Desc),'')

  ,'ContactAddress_Province'=Isnull((Select TOP 1 a.NameTH From crmrevo.CTM.ContactAddress t
									LEFT JOIN crmrevo.MST.Province a ON t.ProvinceID=a.ID
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='D98F7C94-4BA4-4E6A-B311-8A4CBB0C944F' -- ที่อยู่ที่ติดต่อได้
									ORDER BY t.Created Desc),'')

,'ContactAddress_PostalCode'=Isnull((Select TOP 1 t.PostalCode From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='D98F7C94-4BA4-4E6A-B311-8A4CBB0C944F' -- ที่อยู่ที่ติดต่อได้
									ORDER BY t.Created Desc),'')

  ,'ContactAddress_Country'=Isnull((Select TOP 1 a.NameTH From crmrevo.CTM.ContactAddress t
									LEFT JOIN crmrevo.MST.Country a ON t.CountryID=a.ID
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='D98F7C94-4BA4-4E6A-B311-8A4CBB0C944F' -- ที่อยู่ที่ติดต่อได้
									ORDER BY t.Created Desc),'')
  /*ที่ทำงาน*/ 
  ,'OfficeAddress_HouseNo'=Isnull((Select TOP 1 t.HouseNoTH From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='0E28E898-064E-4E88-B5AC-15B6164F487D' --ที่ทำงาน
									ORDER BY t.Created Desc),'')

,'OfficeAddress_Moo'=Isnull((Select TOP 1 t.MooTH From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='0E28E898-064E-4E88-B5AC-15B6164F487D' --ที่ทำงาน
									ORDER BY t.Created Desc),'')

,'OfficeAddress_Village'=Isnull((Select TOP 1 t.VillageTH From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='0E28E898-064E-4E88-B5AC-15B6164F487D' --ที่ทำงาน
									ORDER BY t.Created Desc),'')

,'OfficeAddress_Soi'=Isnull((Select TOP 1 t.SoiTH From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='0E28E898-064E-4E88-B5AC-15B6164F487D' --ที่ทำงาน
									ORDER BY t.Created Desc),'')

,'OfficeAddress_Road'=Isnull((Select TOP 1 t.RoadTH From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='0E28E898-064E-4E88-B5AC-15B6164F487D' --ที่ทำงาน
									ORDER BY t.Created Desc),'')  

,'OfficeAddress_SubDistrict'=Isnull((Select TOP 1 a.NameTH From crmrevo.CTM.ContactAddress t
									LEFT JOIN crmrevo.MST.SubDistrict a ON t.SubDistrictID=a.ID
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='0E28E898-064E-4E88-B5AC-15B6164F487D' -- ที่ทำงาน
									ORDER BY t.Created Desc),'')

  ,'OfficeAddress_District'=Isnull((Select TOP 1 a.NameTH From crmrevo.CTM.ContactAddress t
									LEFT JOIN crmrevo.MST.District a ON t.DistrictID=a.ID
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='0E28E898-064E-4E88-B5AC-15B6164F487D' -- ที่ทำงาน
									ORDER BY t.Created Desc),'')

  ,'OfficeAddress_Province'=Isnull((Select TOP 1 a.NameTH From crmrevo.CTM.ContactAddress t
									LEFT JOIN crmrevo.MST.Province a ON t.ProvinceID=a.ID
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='0E28E898-064E-4E88-B5AC-15B6164F487D' -- ที่ทำงาน
									ORDER BY t.Created Desc),'')

,'OfficeAddress_PostalCode'=Isnull((Select TOP 1 t.PostalCode From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='0E28E898-064E-4E88-B5AC-15B6164F487D' --ที่ทำงาน
									ORDER BY t.Created Desc),'')
  
  ,'OfficeAddress_Country'=Isnull((Select TOP 1 a.NameTH From crmrevo.CTM.ContactAddress t
									LEFT JOIN crmrevo.MST.Country a ON t.CountryID=a.ID
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='0E28E898-064E-4E88-B5AC-15B6164F487D' -- ที่ทำงาน
									ORDER BY t.Created Desc),'')
  
 /*ที่อยู่ตามบัตรประชาชน*/
 ,'PersonalCardAddress_HouseNo'=Isnull((Select TOP 1 t.HouseNoTH From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='6AD2754B-ECDC-4296-9432-AC110D62656A' --ที่อยู่ตามบัตรประชาชน
									ORDER BY t.Created Desc),'')

,'PersonalCardAddress_Moo'=Isnull((Select TOP 1 t.MooTH From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='6AD2754B-ECDC-4296-9432-AC110D62656A' --ที่อยู่ตามบัตรประชาชน
									ORDER BY t.Created Desc),'')

,'PersonalCardAddress_Village'=Isnull((Select TOP 1 t.VillageTH From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='6AD2754B-ECDC-4296-9432-AC110D62656A' --ที่อยู่ตามบัตรประชาชน
									ORDER BY t.Created Desc),'')

,'PersonalCardAddress_Soi'=Isnull((Select TOP 1 t.SoiTH From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='6AD2754B-ECDC-4296-9432-AC110D62656A' --ที่อยู่ตามบัตรประชาชน
									ORDER BY t.Created Desc),'')

,'PersonalCardAddress_Road'=Isnull((Select TOP 1 t.RoadTH From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='6AD2754B-ECDC-4296-9432-AC110D62656A' --ที่อยู่ตามบัตรประชาชน
									ORDER BY t.Created Desc),'')  

,'PersonalCardAddress_SubDistrict'=Isnull((Select TOP 1 a.NameTH From crmrevo.CTM.ContactAddress t
									LEFT JOIN crmrevo.MST.SubDistrict a ON t.SubDistrictID=a.ID
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='6AD2754B-ECDC-4296-9432-AC110D62656A' -- ที่อยู่ตามบัตรประชาชน
									ORDER BY t.Created Desc),'')

  ,'PersonalCardAddress_District'=Isnull((Select TOP 1 a.NameTH From crmrevo.CTM.ContactAddress t
									LEFT JOIN crmrevo.MST.District a ON t.DistrictID=a.ID
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='6AD2754B-ECDC-4296-9432-AC110D62656A' -- ที่อยู่ตามบัตรประชาชน
									ORDER BY t.Created Desc),'')

  ,'PersonalCardAddress_Province'=Isnull((Select TOP 1 a.NameTH From crmrevo.CTM.ContactAddress t
									LEFT JOIN crmrevo.MST.Province a ON t.ProvinceID=a.ID
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='6AD2754B-ECDC-4296-9432-AC110D62656A' -- ที่อยู่ตามบัตรประชาชน
									ORDER BY t.Created Desc),'')

,'PersonalCardAddress_PostalCode'=Isnull((Select TOP 1 t.PostalCode From crmrevo.CTM.ContactAddress t
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='6AD2754B-ECDC-4296-9432-AC110D62656A' --ที่อยู่ตามบัตรประชาชน
									ORDER BY t.Created Desc),'')
  
  ,'PersonalCardAddress_Country'=Isnull((Select TOP 1 a.NameTH From crmrevo.CTM.ContactAddress t
									LEFT JOIN crmrevo.MST.Country a ON t.CountryID=a.ID
									WHERE t.IsDeleted=0 AND t.ContactID=v.ID
									AND t.ContactAddressTypeMasterCenterID ='6AD2754B-ECDC-4296-9432-AC110D62656A' -- ที่อยู่ตามบัตรประชาชน
									ORDER BY t.Created Desc),'')
 FROM crmrevo.CTM.Contact v WITH(NOLOCK)
 LEFT JOIN crmrevo.MST.Mastercenter gender ON v.GenderMasterCenterID=gender.ID
go

