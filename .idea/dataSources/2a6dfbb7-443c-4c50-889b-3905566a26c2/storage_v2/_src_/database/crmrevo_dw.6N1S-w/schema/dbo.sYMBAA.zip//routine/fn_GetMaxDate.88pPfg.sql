Create FUNCTION [dbo].[fn_GetMaxDate](
	@Date Datetime
)RETURNS Datetime
BEGIN
	RETURN
		(
			SELECT DateAdd(second,-1,DateAdd(day,1,@Date))
		)
END


go

