Create FUNCTION [dbo].[fn_AP_BI_GetCheckDateDefect1]
(
	@ProductID nvarchar(15),
	@UnitNumber nvarchar(15)
	
)
RETURNS Datetime
AS
BEGIN
	DECLARE @CheckDate Datetime
	
	set @CheckDate =0
	
	
	set @CheckDate =(
	Select top 1 RAuditDate
	From [DBLINK_SVR_DEFECT].[defecttracking].[dbo].vwCallDefectRoundAudit  
	where ProjectNo = @ProductID
	and Unit = @UnitNumber
	and rauditno=1 and docisactive=1
	Order by RAuditDate asc)
	
	
	
	RETURN @CheckDate
END

go

