/****** Object:  UserDefinedFunction [dbo].[fn_AP_BI_GetDefectNumber]    Script Date: 03/12/2013 15:09:52 ******/

Create FUNCTION [dbo].[fn_AP_BI_GetUnitReceiptDate]
(
	@ProductID nvarchar(15),
	@UnitNumber nvarchar(15)
	
	
)
RETURNS datetime
AS
BEGIN
	DECLARE @ReceiptDate datetime
	
	
	
	--set @ReceiptDate =(Select Top 1 end_date From [192.168.0.128].DefectLogs.dbo.tbl_defect_report as dr
	--	Left Join [192.168.0.128].DefectLogs.dbo.tbl_project as pj on (dr.project_id = pj.id)
	--	Left Join [192.168.0.128].DefectLogs.dbo.tbl_room as room on (dr.Room_id = room.id)
	--	where pj.ProductID = @ProductID
	--	and room.Room_Code =@UnitNumber
	--	Order by check_date desc)
	--set @ReceiptDate =(Select Top 1 ReceiveDate From [192.168.0.128].DefectLogs.dbo.ZReceiveUnit as ReceiveUnit 
	--set @ReceiptDate =(Select Top 1 ReceiveDate From [Temp_ZReceiveUnit] as ReceiveUnit  With(NoLock) 
	--	where ReceiveUnit.ProjectID = @ProductID
	--	and ReceiveUnit.UnitNumber = @UnitNumber
	--	and IsReceive =1
	--	and ReceiveDate<'20150720')	

--if(@ReceiptDate  is null)
--BEGIN
--set @ReceiptDate =(Select Top 1 DocReceiveUnitDate From [192.168.0.28].[defecttracking].[dbo].vwCallDefectReceiveUnitDoc as ReceiveUnit 
set @ReceiptDate =(Select Top 1 DocReceiveUnitDate From [DBLINK_SVR_DEFECT].[defecttracking].[dbo].vwCallDefectReceiveUnitDoc as ReceiveUnit  With(NoLock) 
		where ReceiveUnit.ProjectNo = @ProductID
		and ReceiveUnit.SerialNo = @UnitNumber
		and DocIsActive=1
		and DocReceiveUnitDate>='20150720')	

--END
	RETURN @ReceiptDate
END
go

