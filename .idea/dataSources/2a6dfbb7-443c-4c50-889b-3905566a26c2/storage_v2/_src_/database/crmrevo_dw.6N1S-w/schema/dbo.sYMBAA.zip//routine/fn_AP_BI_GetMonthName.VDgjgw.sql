Create FUNCTION [dbo].[fn_AP_BI_GetMonthName]
(
	@month int
	
	
)
RETURNS nvarchar(100)
AS
BEGIN
	DECLARE @ret nvarchar(100)
	set @ret = (
	Select
	case 
	when @month=1 then 'ม.ค.'
	when @month=2 then 'ก.พ.'
	when @month=3 then 'มี.ค.'
	when @month=4 then 'เม.ย.'
	when @month=5 then 'พ.ค.'
	when @month=6 then 'มิ.ย.'
	when @month=7 then 'ก.ค.'
	when @month=8 then 'ส.ค.'
	when @month=9 then 'ก.ย.'
	when @month=10 then 'ต.ค.'
	when @month=11 then 'พ.ย.'
	when @month=12 then 'ธ.ค.'
	else ''
	end
	)
	
	
	
	
	
	
	
	
	RETURN @ret
END



go

