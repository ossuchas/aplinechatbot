

CREATE PROC [dbo].[sp_vw_CRM_Freedown_V2]
as

IF(OBJECT_ID('tempdb..#temp1')IS NOT NULL)DROP TABLE #temp1

SELECT 
'BG'= e.[Name],'SubBG'=e.[Group],e.ProjectNo,e.id AS ProjectID,d.UnitNo
,'TotalPrice'=ISNULL(up.TotalPrice,0)
,'BookingFreeDownAmount'= ISNULL(up.FreedownDiscount,0)
,'ContractFreeDownAmount'= ISNULL(up.FreedownDiscount,0)
,'NetPrice'=(ISNULL(up.TotalPrice,0)- ISNULL(up.FreedownDiscount,0))
,'BookingNumber'= bk.BookingNo
,'BookingDate'= CONVERT(DATETIME,CONVERT(NVARCHAR(8),bk.BookingDate,112))
,'BookingCancelDate'= CONVERT(DATETIME,CONVERT(NVARCHAR(8),bk.CancelDate,112))
,'ContractNumber'= CONVERT(NVARCHAR(20),'')
,'ContractCancelDate'= CONVERT(DATETIME,NULL)
,'TransferDateApprove'  = CONVERT(DATETIME,NULL)
,'BookingType'=CASE WHEN h.BookingType IS NOT NULL THEN h.BookingType
					WHEN bk.ChangeFromBookingID IS NOT NULL THEN 'ย้ายแปลง'
					ELSE 'จองใหม่' END
,'OldBookingNumber'=CASE WHEN bk.ChangeFromBookingID IS NOT NULL THEN (SELECT t.BookingNo FROM [crmrevo].sal.Booking t WITH(NOLOCK) WHERE t.id=bk.ChangeFromBookingID AND t.IsDeleted = 0)
						ELSE h.BookingNumber END
,'OldBookingDate'=CASE WHEN  bk.ChangeFromBookingID  IS NOT NULL THEN (SELECT CONVERT(DATETIME,CONVERT(NVARCHAR(8),t.BookingDate,112)) FROM [crmrevo].sal.Booking t WITH(NOLOCK) WHERE t.id= bk.ChangeFromBookingID AND t.IsDeleted = 0 )
						ELSE h.BookingDate END
,'OldCancelDate'=CASE WHEN bk.ChangeFromBookingID  IS NOT NULL THEN (SELECT CONVERT(DATETIME,CONVERT(NVARCHAR(8),t.CancelDate,112)) FROM [crmrevo].sal.Booking t WITH(NOLOCK) WHERE t.id= bk.ChangeFromBookingID  AND t.IsDeleted = 0)
						ELSE h.CancelDate END
--,'OldBookingPrice'=CASE WHEN  bk.ChangeFromBookingID  IS NOT NULL THEN (SELECT ISNULL(t.TotalPrice,0) FROM (SELECT bk.id,up.TotalPrice FROM sal.Booking bk WITH(NOLOCK)
--																								LEFT JOIN (SELECT Up.BookingID,up.UnitPriceStageMasterCenterID,up.TotalPrice FROM dbo.vw_UnitPrice UP WITH (NOLOCK)
--																								INNER JOIN [MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '1') AS UP --1=จอง
--																					ON BK.ID = UP.BookingID AND bk.IsDeleted = 0 ) t
--																		WHERE t.id=bk.ChangeFromBookingID)
--						ELSE (SELECT   ISNULL(tt.TotalPrice,0) FROM (SELECT  bk.id,up.TotalPrice FROM sal.Booking bk
--																								LEFT JOIN (SELECT Up.BookingID,up.TotalPrice,up.UnitPriceStageMasterCenterID  FROM dbo.vw_UnitPrice UP WITH (NOLOCK)
--																								INNER JOIN [MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '1' ) AS UP --1=จอง
--																					ON BK.ID = UP.BookingID  AND bk.IsDeleted = 0) tt
--																		WHERE tt.id=bk.id) END
--,'CurrentStatus'= 
--CASE WHEN (bk.CancelDate IS NOT NULL) AND (bk.CancelType IN('2') ) THEN 'ยกเลิกย้ายแปลง'
--					+ '['+ISNULL((SELECT TOP 1 u.UnitNo FROM sal.Booking b WITH(NOLOCK)  LEFT JOIN prj.Unit u ON u.id = b.UnitID WHERE ChangeFromBookingID = bk.id AND b.IsDeleted = 0),'')+']'
--					+  CASE WHEN bk. id NOT IN ((SELECT bookingid FROM (SELECT Up.BookingID,up.UnitPriceStageMasterCenterID,up.TotalPrice  FROM dbo.vw_UnitPrice UP WITH (NOLOCK)
--																	INNER JOIN [MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '1' ) up
--														 WHERE up.BookingID = (SELECT TOP 1 id FROM sal.Booking WITH(NOLOCK) WHERE ChangeFromBookingID=bk.id AND IsDeleted = 0))) THEN ' No Freedown' ELSE '' END
--					WHEN bk.CancelDate IS NOT NULL THEN 'ยกเลิก'
--					WHEN bk.BookingNo IS NOT NULL THEN 'จอง'
--					END
,'OldBookingPrice'=CONVERT(DECIMAL(18,2),0)
,'CurrentStatus'=CONVERT(NVARCHAR(100),'')
,'BK_CancelDate'=bk.CancelDate
,'BK_CancelType'=bk.CancelType
,'BK_ID'=bk.id
,'BK_ChangeFromBookingID'=bk.ChangeFromBookingID
INTO #temp1
FROM (SELECT a.BookingID,a.UnitPriceStageMasterCenterID,a.TotalPrice,a.FreedownDiscount FROM [crmrevo].dbo.vw_UnitPrice a WITH (NOLOCK)
	INNER JOIN [crmrevo].[MST].[MasterCenter] MUP WITH (NOLOCK) ON a.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '1' ) UP --1=จอง						
INNER JOIN [crmrevo].sal.Booking bk WITH(NOLOCK) 	ON BK.ID = UP.BookingID AND bk.IsDeleted = 0
LEFT JOIN [crmrevo].prj.Unit d WITH(NOLOCK) ON d.id = bk.UnitID AND d.IsDeleted = 0
LEFT JOIN (SELECT p.BGID,p.id,bg.[Name],p.[Group],p.ProjectNo FROM [crmrevo].prj.Project p WITH(NOLOCK) INNER JOIN [crmrevo].mst.BG bg ON bg.id = p.BGID AND p.IsDeleted = 0 ) e  ON e.id=bk.ProjectID
LEFT JOIN [crmrevo].dbo.Temp_CRM_Freedown_Cancel h WITH(NOLOCK) ON h.NewBookingNumber=bk.BookingNo
WHERE 1=1 
AND bk.id NOT IN (SELECT BookingID FROM [crmrevo].sal.Agreement WHERE IsDeleted =0  )
AND FreedownDiscount>0 
	

	--------------------------/*TempUnitPrice*/  --------------------------------------------------
IF(OBJECT_ID('tempdb..#vw_UnitPrice')IS NOT NULL)DROP TABLE #vw_UnitPrice
SELECT Up.BookingID,up.UnitPriceStageMasterCenterID,up.TotalPrice  ,up.FreedownDiscount
INTO #vw_UnitPrice
FROM [crmrevo].dbo.vw_UnitPrice UP WITH (NOLOCK)
INNER JOIN [crmrevo].[MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '1'
--WHERE up.BookingID IN(SELECT BK_ID FROM #temp1)

IF(OBJECT_ID('tempdb..#ChangeFromBooking')IS NOT NULL)DROP TABLE #ChangeFromBooking
SELECT b.ID,b.ChangeFromBookingID,u.UnitNo
INTO #ChangeFromBooking
FROM [crmrevo].sal.Booking b WITH(NOLOCK)  
LEFT JOIN [crmrevo].prj.Unit u ON u.id = b.UnitID AND b.IsDeleted = 0
WHERE ChangeFromBookingID IS NOT NULL AND ChangeFromBookingID IN(SELECT BK_ID FROM #temp1) 

--------------------------------------Update #temp1-----------------------------------------------
UPDATE #temp1
SET CurrentStatus= 
CASE WHEN (BK_CancelDate IS NOT NULL) AND (BK_CancelType IN('2') ) THEN 'ยกเลิกย้ายแปลง'
					+ '['+ISNULL((SELECT TOP 1 UnitNo FROM #ChangeFromBooking WHERE ChangeFromBookingID = BK_ID ),'')+']'
					+  CASE WHEN BK_ID NOT IN ((SELECT bookingid 
												FROM #vw_UnitPrice up
												WHERE up.BookingID = (SELECT TOP 1 id FROM #ChangeFromBooking WITH(NOLOCK) WHERE ChangeFromBookingID=BK_ID))) THEN ' No Freedown' ELSE '' END
					WHEN BK_CancelType IS NOT NULL THEN 'ยกเลิก'
					WHEN BookingNumber IS NOT NULL THEN 'จอง'
					END
FROM #temp1 t


UPDATE #temp1
SET OldBookingPrice=CASE WHEN  BK_ChangeFromBookingID  IS NOT NULL THEN (SELECT ISNULL(t.TotalPrice,0) FROM (SELECT bk.id,up.TotalPrice 
																											FROM [crmrevo].sal.Booking bk WITH(NOLOCK)
																											LEFT JOIN #vw_UnitPrice AS UP ON BK.ID = UP.BookingID AND bk.IsDeleted = 0 ) t
																		WHERE t.id=BK_ChangeFromBookingID)
						ELSE (SELECT   ISNULL(tt.TotalPrice,0) FROM (SELECT  bk.id,up.TotalPrice FROM [crmrevo].sal.Booking bk
																								LEFT JOIN #vw_UnitPrice AS UP --1=จอง
																					ON BK.ID = UP.BookingID  AND bk.IsDeleted = 0) tt
																		WHERE tt.id=BK_id) END
FROM #temp1 t

------------------------------------------------Temp2------------------------------------------------

IF(OBJECT_ID('tempdb..#vw_UnitPriceAgree')IS NOT NULL)DROP TABLE #vw_UnitPriceAgree
SELECT a.BookingID,a.UnitPriceStageMasterCenterID ,a.TotalPrice,a.FreedownDiscount 
INTO #vw_UnitPriceAgree
FROM [crmrevo].dbo.vw_UnitPrice a WITH (NOLOCK)
INNER JOIN [crmrevo].[MST].[MasterCenter] MUP WITH (NOLOCK) ON a.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '2'
--AND a.BookingID IN (SELECT BookingID FROM sal.Agreement WHERE IsDeleted = 0)


IF(OBJECT_ID('tempdb..#temp2')IS NOT NULL)DROP TABLE #temp2

SELECT 'BG'= e.[Name],'SubBG'= e.[Group],e.ProjectNo,e.id AS ProjectID,d.UnitNo
,'TotalPrice'=ISNULL(up.TotalPrice,0)
,'BookingFreeDownAmount'=ISNULL(i.FreedownDiscount,0)
,'ContractFreeDownAmount'= ISNULL(up.FreedownDiscount,0)
,'NetPrice'=ISNULL(up.TotalPrice,0)
,'BookingNumber'=g.BookingNo
,'BookingDate'=g.BookingDate
,'BookingCancelDate'= g.CancelDate --CONVERT(DATETIME,CONVERT(NVARCHAR(8),g.CancelDate,112))
,'ContractNumber' = b.AgreementNo
,'ContractCancelDate'= CASE WHEN b.IsCancel = 1 THEN g.CancelDate END  --CONVERT(DATETIME,CONVERT(NVARCHAR(8),b.CancelDate,112))
,'TransferDateApprove'= f.ActualTransferDate
,'BookingType'=CASE WHEN h.BookingType IS NOT NULL THEN h.BookingType
					WHEN g.ChangeFromBookingID IS NOT NULL THEN 'ย้ายแปลง'
					ELSE 'จองใหม่' END
,'OldBookingNumber'=CASE WHEN g.ChangeFromBookingID IS NOT NULL THEN (SELECT t.BookingNo FROM [crmrevo].sal.Booking t WITH(NOLOCK)WHERE t.id=g.ChangeFromBookingID AND t.IsDeleted = 0)
						ELSE h.BookingNumber END
,'OldBookingDate'=CASE WHEN g.ChangeFromBookingID IS NOT NULL THEN (SELECT CONVERT(DATETIME,CONVERT(NVARCHAR(8),t.BookingDate,112)) FROM [crmrevo].sal.Booking t WITH(NOLOCK)WHERE t.id=g.ChangeFromBookingID AND t.IsDeleted = 0)
						ELSE h.BookingDate END
,'OldCancelDate'=CASE WHEN g.ChangeFromBookingID IS NOT NULL THEN (SELECT CONVERT(DATETIME,CONVERT(NVARCHAR(8),t.CancelDate,112)) FROM [crmrevo].sal.Booking t WITH(NOLOCK)WHERE t.id=g.ChangeFromBookingID AND t.IsDeleted = 0 )
						ELSE h.CancelDate END
--,'OldBookingPrice'=CASE WHEN  g.ChangeFromBookingID IS NOT NULL THEN (SELECT ISNULL(t.TotalPrice,0) FROM (SELECT bk.id,up.TotalPrice FROM sal.Booking bk LEFT JOIN (SELECT Up.TotalPrice,up.BookingID FROM vw_UnitPrice UP WITH (NOLOCK)
--																									INNER JOIN [MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '1') AS UP --1=จอง
--																					ON BK.ID = UP.BookingID AND bk.IsDeleted = 0 ) t
--																		WHERE t.id=g.ChangeFromBookingID)
--						ELSE (SELECT   ISNULL(tt.TotalPrice,0) FROM (SELECT  bk.*,u.TotalPrice FROM sal.Booking bk
--																								LEFT JOIN (SELECT Up.TotalPrice,up.BookingID  FROM vw_UnitPrice UP WITH (NOLOCK)
--																								INNER JOIN [MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '1') AS U --1=จอง
--																					ON BK.ID = U.BookingID AND bk.IsDeleted = 0 ) tt
--																		WHERE tt.BookingNo=h.BookingNumber)
--																		 END
--,'CurrentStatus'= 
--CASE WHEN (g.CancelDate IS NOT NULL )AND (g.CancelType IN(2) ) THEN 'ยกเลิกย้ายแปลง'
--					+ ' ['+ISNULL((SELECT TOP 1 UnitNumber FROM sal.Booking WITH(NOLOCK)WHERE ChangeFromBookingID=g.id),'')+']'
--					+ CASE WHEN NOT EXISTS((SELECT TOP 1 * FROM (SELECT Up.BookingID,up.TotalPrice  FROM vw_UnitPrice UP WITH (NOLOCK)
--																								INNER JOIN [MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '1') up
--														 WHERE up.BookingID = (SELECT TOP 1 id FROM sal.Booking WITH(NOLOCK)WHERE ChangeFromBookingID=g.id AND IsDeleted = 0))) THEN ' No Freedown' ELSE '' END
--					WHEN g.CancelDate IS NOT NULL  THEN 'ยกเลิก'
--					WHEN f.ActualTransferDate IS NOT NULL THEN 'โอน'
--					WHEN b.AgreementNo IS NOT NULL THEN 'สัญญา'
--					WHEN g.BookingNo IS NOT NULL THEN 'จอง'
--					END
,'OldBookingPrice'=CONVERT(DECIMAL(18,2),0)
,'CurrentStatus'=CONVERT(NVARCHAR(100),'')
,'AG_CancelDate'=g.CancelDate
,'AG_CancelType'=g.CancelType
,'AG_ID'=b.BookingID
,'AG_ChangeFromBookingID'=g.ChangeFromBookingID
,'AG_BookingNumber' = h.BookingNumber

INTO #temp2
FROM  #vw_UnitPriceAgree UP --สํญญา WITH(NOLOCK)
LEFT JOIN [crmrevo].sal.Agreement b WITH(NOLOCK) ON up.BookingID=b.BookingID AND b.IsDeleted = 0
LEFT JOIN [crmrevo].prj.Unit d WITH(NOLOCK) ON d.id = b.UnitID AND d.IsDeleted = 0
LEFT JOIN (SELECT p.BGID,p.id,bg.[Name],p.[Group],p.ProjectNo FROM [crmrevo].prj.Project p WITH(NOLOCK) INNER JOIN [crmrevo].mst.BG bg ON bg.id = p.BGID WHERE p.IsDeleted = 0 AND bg.IsDeleted = 0 )  e  ON e.id = b.ProjectID
LEFT JOIN [crmrevo].sal.[Transfer] f WITH(NOLOCK) ON f.AgreementID =b.id AND f.IsDeleted = 0
LEFT JOIN [crmrevo].sal.Booking g WITH(NOLOCK) ON g.id=b.BookingID AND g.IsDeleted = 0
LEFT JOIN [crmrevo].dbo.Temp_CRM_Freedown_Cancel h WITH(NOLOCK) ON h.NewBookingNumber=g.BookingNo
LEFT JOIN  (SELECT a.BookingID ,a.FreedownDiscount FROM #vw_UnitPrice a ) i  ON i.BookingID = b.BookingID 
WHERE 1=1 
AND ISNULL(up.FreedownDiscount,0) > 0


IF(OBJECT_ID('tempdb..#vw_UnitPrice2')IS NOT NULL)DROP TABLE #vw_UnitPrice2
SELECT Up.BookingID,up.UnitPriceStageMasterCenterID,up.TotalPrice  ,up.FreedownDiscount
INTO #vw_UnitPrice2
FROM [crmrevo].dbo.vw_UnitPrice UP WITH (NOLOCK)
INNER JOIN [crmrevo].[MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '1'
WHERE up.BookingID IN(SELECT AG_ID FROM #temp2)

-----------------------------------------Update Temp2---------------------------------------
UPDATE #temp2
SET OldBookingPrice =  (CASE WHEN  AG_ChangeFromBookingID  IS NOT NULL THEN (SELECT ISNULL(t.TotalPrice,0) 
																				FROM (SELECT bk.id,up.TotalPrice FROM [crmrevo].sal.Booking bk WITH (NOLOCK) LEFT JOIN  #vw_UnitPrice2 UP WITH (NOLOCK)	 ON BK.ID = UP.BookingID AND bk.IsDeleted = 0 ) t
																		WHERE t.id= aa.AG_ChangeFromBookingID)
						ELSE (SELECT   ISNULL(tt.TotalPrice,0) FROM (SELECT  bk.*,u.TotalPrice FROM [crmrevo].sal.Booking bk WITH (NOLOCK)
																								LEFT JOIN #vw_UnitPrice2 AS U --1=จอง
																					ON BK.ID = U.BookingID AND bk.IsDeleted = 0 ) tt
																		WHERE tt.BookingNo=aa.AG_BookingNumber) END )
,CurrentStatus =	CASE WHEN (aa.BookingCancelDate IS NOT NULL )AND (aa.AG_CancelType IN(2) ) THEN 'ยกเลิกย้ายแปลง'
					+ ' ['+ISNULL((SELECT TOP 1 UnitNo FROM [crmrevo].sal.Booking WITH(NOLOCK) WHERE ChangeFromBookingID=aa.AG_ID),'')+']'
					+ CASE WHEN NOT EXISTS((SELECT TOP 1 * FROM #vw_UnitPrice2 UP WITH (NOLOCK)
																							
														 WHERE up.BookingID = (SELECT TOP 1 id FROM [crmrevo].sal.Booking WITH(NOLOCK)WHERE ChangeFromBookingID=aa.AG_ID AND IsDeleted = 0))) THEN ' No Freedown' ELSE '' END
					WHEN aa.AG_CancelDate IS NOT NULL  THEN 'ยกเลิก'
					WHEN aa.TransferDateApprove IS NOT NULL THEN 'โอน'
					WHEN aa.ContractNumber IS NOT NULL THEN 'สัญญา'
					WHEN aa.BookingNumber IS NOT NULL THEN 'จอง'
					END
FROM #temp2 aa


IF(OBJECT_ID('tempdb..##vw_CRM_Freedown_V2')IS NOT NULL)DROP TABLE ##vw_CRM_Freedown_V2
SELECT *
INTO ##vw_CRM_Freedown_V2
FROM (SELECT BG,SubBG,ProjectNo,ProjectID,UnitNo,TotalPrice,BookingFreeDownAmount,ContractFreeDownAmount,NetPrice,BookingNumber
	,BookingDate,BookingCancelDate,ContractNumber,ContractCancelDate,TransferDateApprove,BookingType,OldBookingNumber,OldBookingDate
	,OldCancelDate,OldBookingPrice,CurrentStatus
	FROM #temp1
	UNION ALL
	SELECT BG,SubBG,ProjectNo,ProjectID,UnitNo,TotalPrice,BookingFreeDownAmount,ContractFreeDownAmount,NetPrice,BookingNumber
	,BookingDate,BookingCancelDate,ContractNumber,ContractCancelDate,TransferDateApprove,BookingType,OldBookingNumber,OldBookingDate
	,OldCancelDate,OldBookingPrice,CurrentStatus
	FROM #temp2 ) bb

	--SELECT * FROM ##vw_CRM_Freedown_V2 ORDER BY ProjectNo ,UnitNo
	--SELECT COUNT(*) FROM vw_CRM_Freedown_V2
	--SELECT * FROM #temp1 WHERE ProjectNo IS NULL
 --   SELECT * FROM #temp2 WHERE ProjectNo IS null

go

