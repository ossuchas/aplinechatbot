--exec AP_BI_UnitDetail_BG_NEW;1 NULL, N'40047', NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL

--exec [AP_BI_UnitDetail_BG_NEWCRM] '',N'10177', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL

CREATE proc [dbo].[AP_BI_UnitDetail_BG_NEW]
--declare

@BG nvarchar(15)=null,
@ProductID nvarchar(15)=null,
@STRLCID UNIQUEIDENTIFIER,
@FlagOverDue nvarchar(1)=null,
--@TransferYear nvarchar(4)=null,
--@TransferMonth nvarchar(4)=null,
@LetterStatus nvarchar(1)=null,
@DefectStatus nvarchar(1)=null,
@FlagBC nvarchar(1) =null,
@PayStatus nvarchar(1) =null,
@FlagWaitSale nvarchar(1)=null,
@TranferStatus nvarchar(1)=null,
@QAStatus nvarchar(1)=null,
@SaleStatus nvarchar(1)=null,
@Tower nvarchar(15)='',
@Floor nvarchar(15)='',
@Tower1 nvarchar(15)='',
@Floor1 nvarchar(15)=''
,@TransferStartDate datetime=null
,@TransferEnddate datetime=null

as
SET TRANSACTION ISOLATION LEVEL Read uncommitted;
--declare @BG nvarchar(15)
Set @BG = Isnull(@BG,'')
Set @ProductID=Isnull(@ProductID,'')
--Set @STRLCID=Isnull(@STRLCID,'')
Set @FlagOverDue=Isnull(@FlagOverDue,'')
--Set @TransferYear=Isnull(@TransferYear,'')
--Set @TransferMonth=Isnull(@TransferMonth,'')
Set @LetterStatus=Isnull(@LetterStatus,'')
Set @DefectStatus=Isnull(@DefectStatus,'')
Set @FlagBC=Isnull(@FlagBC,'')
Set @PayStatus=Isnull(@PayStatus,'')
Set @FlagWaitSale=Isnull(@FlagWaitSale,'')
Set @TranferStatus=Isnull(@TranferStatus,'')
Set @QAStatus=Isnull(@QAStatus,'')
Set @SaleStatus=Isnull(@SaleStatus,'')
Set @Tower=Isnull(@Tower,'')
Set @Floor=Isnull(@Floor,'')
Set @Tower1=Isnull(@Tower1,'')
Set @Floor1=Isnull(@Floor1,'')

if(@Tower1='' or @Tower1 is null)Set @Tower1=@Tower
if(@Floor1='' or @Floor1 is null )Set @Floor1=@Floor

If(Object_ID('Tempdb..#TWeek')is not null)Drop table #TWeek
select * 
,'Month_No'=Case when m=Month(Getdate()) then 1 when m=Month(Getdate())+1 then 2  else 3 end
,'Week_No'=row_number()over(partition by y,m order by w)
into #TWeek
From [crmrevo].bi.Mst_Calendar_Week where Y in(Year(getdate()),Year(getdate())+1) and M in(Month(Getdate()),Month(Getdate())+1,Month(Getdate())+2)

if(@TransferStartDate is null or @TransferStartDate = '' )Set @TransferStartDate='20000101'
if(@TransferEnddate is null or @TransferEnddate = '' )Set @TransferEnddate='70001231'

declare @LCID int

declare @IsOverDue int

declare @LetterStatus1 int
declare @LetterStatus2 int
declare @LetterStatus3 int 

declare @DefectStatus1 int
declare @DefectStatus2 int
declare @DefectStatus3 int
declare @DefectStatus4 int
declare @DefectStatus5 int 

declare @BCStatus int


declare @PayStatus1 int
declare @PayStatus2 int
declare @PayStatus3 int
declare @PayStatus4 int
declare @PayStatus5 int

declare @WaitSale int

if @FlagOverDue ='1'
Set @IsOverDue =1

if @LetterStatus ='1'
Set @LetterStatus1 =1


if @LetterStatus ='2'
Set @LetterStatus2 =1

if @LetterStatus ='3'
Set @LetterStatus3 =1

if @DefectStatus ='1'
set @DefectStatus1 =1

if @DefectStatus ='2'
set @DefectStatus2 =1

if @DefectStatus ='3'
set @DefectStatus3 =1

if @DefectStatus ='4'
set @DefectStatus4 =1

if @DefectStatus ='5'
set @DefectStatus5 =1

if @FlagBC ='1'
set @BCStatus =1

if @PayStatus ='1'
set @PayStatus1 =1

if @PayStatus ='2'
set @PayStatus2 =1

if @PayStatus ='3'
set @PayStatus3 =1

if @PayStatus ='4'
set @PayStatus4 =1

if @PayStatus ='5'
set @PayStatus5 =1

if @FlagWaitSale ='1'
set @WaitSale =1

----------------------------------Temp---------------------------------------
If(Object_ID('Tempdb..#MasterCenter')is not null)Drop table #MasterCenter
SELECT * INTO #MasterCenter FROM [crmrevo].mst.MasterCenter

If(Object_ID('Tempdb..#TUnit')is not null)Drop table #TUnit
SELECT u.* INTO #TUnit FROM [crmrevo].prj.Unit u LEFT JOIN [crmrevo].prj.Project p ON u.ProjectID = p.id AND p.IsDeleted = 0
WHERE u.IsDeleted = 0 AND @ProductID = p.ProjectNo

If(Object_ID('Tempdb..#Sal_Booking')is not null)Drop table #Sal_Booking
SELECT * INTO #Sal_Booking FROM [crmrevo].sal.Booking  With(NoLock) WHERE IsDeleted = 0 AND IsCancelled = 0 

If(Object_ID('Tempdb..#Sal_Agreement')is not null)Drop table #Sal_Agreement
SELECT * INTO #Sal_Agreement FROM [crmrevo].sal.Agreement With(NoLock) WHERE IsDeleted = 0 AND IsCancel = 0

If(Object_ID('Tempdb..#vw_UnitPrice')is not null)Drop table #vw_UnitPrice
SELECT a.*,m.[Key],b.BookingNo 
INTO #vw_UnitPrice
FROM [crmrevo].dbo.vw_UnitPrice a
INNER JOIN #MasterCenter m ON a.UnitPriceStageMasterCenterID = m.id 
LEFT JOIN #Sal_Booking b ON a.BookingID = b.id 
WHERE a.IsDeleted = 0

If(Object_ID('Tempdb..#vw_ZLCUnit')is not null)Drop table #vw_ZLCUnit
	Select LC.UnitNo ,b.BGNo,p.ProjectNo,lc.UserID
	INTO #vw_ZLCUnit
	 FROM [vw_ZLCUnit] LC  With(NoLock)
	Left join [crmrevo].prj.Project p With(NoLock) ON lc.ProjectID = p.id  AND p.IsDeleted = 0
	LEFT JOIN [crmrevo].mst.bg	b ON b.id = p.BGID  

IF(Object_ID('Tempdb..#BU3_Tranfer')is not null)Drop table #BU3_Tranfer
SELECT * INTO #BU3_Tranfer FROM [DBLINK_SVR_BI].[AP_DW].dbo.BU3_Tranfer

IF(Object_ID('Tempdb..#BU3_Remark')is not null)Drop table #BU3_Remark
SELECT * 
INTO #BU3_Remark 
FROM [DBLINK_SVR_BI].[AP_DW].dbo.BU3_Remark  --WHERE a.BookingNumber IN (SELECT BookingNo FROM #Sal_Booking b )

--SELECT * FROM #BU3_Remark WHERE ProjectID = '40044' AND UnitNumber ='i11'

IF(Object_ID('Tempdb..#TCreditBank')is not null)Drop table #TCreditBank
Select LoanAmount ,Creditbanking.BookingID , b.BookingNo
INTO #TCreditBank
FROM [crmrevo].sal.CreditBanking as Creditbanking With(NoLock)
--Left JOIN mst.Bank as Bank  With(NoLock)on (Creditbanking.BankID = Bank.id)
INNER JOIN #MasterCenter m ON m.id = Creditbanking.LoanStatusMasterCenterID
LEFT JOIN #Sal_Booking b ON Creditbanking.BookingID = b.id 
where 1=1 
and m.[Key] ='1' AND Creditbanking.IsDeleted = 0
and Creditbanking.IsUseBank = 1

IF(Object_ID('Tempdb..#SalePromotion')is not null)Drop table #SalePromotion
SELECT sp.*,b.BookingNo INTO #SalePromotion FROM  [crmrevo].PRM.SalePromotion sp With(NoLock) 
LEFT JOIN #Sal_Booking b ON sp.BookingID = b.id 
WHERE sp.IsDeleted = 0 AND sp.IsActive = 1 

IF(Object_ID('Tempdb..#TransferPromotion')is not null)Drop table #TransferPromotion
SELECT tp.*,b.BookingNo INTO #TransferPromotion FROM [crmrevo].PRM.TransferPromotion tp With(NoLock) 
LEFT JOIN #Sal_Booking b ON tp.BookingID = b.id 
WHERE tp.IsDeleted = 0 AND tp. IsActive = 1 

IF(Object_ID('Tempdb..#TransferLetter')is not null)Drop table #TransferLetter
SELECT a.*,b.AgreementNo ,aa.LetterStatusMasterCenterID
INTO #TransferLetter 
FROM (SELECT  AgreementID,MAX(ResponseDate)ResponseDate FROM [crmrevo].let.TransferLetter WHERE IsDeleted = 0  GROUP BY  AgreementID) a
LEFT JOIN [crmrevo].let.TransferLetter aa ON a.AgreementID = aa.AgreementID AND a.ResponseDate = aa.ResponseDate
LEFT JOIN #Sal_Agreement b ON a.AgreementID = b.id 
WHERE aa.IsDeleted = 0 

--IF(Object_ID('Tempdb..#STG_UNIT_STATUS_PTD_V2')is not null)Drop table #STG_UNIT_STATUS_PTD_V2
--SELECT * INTO #STG_UNIT_STATUS_PTD_V2 FROM [STG_UNIT_STATUS_PTD_V2] WHERE ProductID = @ProductID
	------------------------------------------------------------------------------------------
SELECT 
distinct tb.StartDate,
[ReportName]
--,dbo.fn_AP_BI_GetLetterStatus(tb.[ContractNumber],tb.[ProductID],tb.UnitNumber ) as vvvv
,Case
when isnull(tb.LetterAmountDays,0) > 0 Then '( '+CONVERT(VARCHAR(100),tb.LetterAmountDays)+' )'
else '( - )'
end strLetterAmountDays
--,Case 
--when tb.LCName is null then dbo.fn_AP_BI_GetLCName(tb.[ProductID],tb.UnitNumber )
--else tb.LCName
--end 
--as LCName
,'LCName' = tb.LCName
      ,[QC_BL_IND_1_15_PTD]
      ,[QC_BL_OVD_16_30_PTD]
      ,[QC_BL_OVD_30_PTD]
      ,[QC_BL_CRD_PTD]
      ,[NQC_BL_IND_1_15_PTD]
      ,[NQC_BL_OVD_16_30_PTD]
      ,[NQC_BL_OVD_30_PTD]
      ,[NQC_BL_CRD_PTD]
	  ,SUBSTRING(p.[Group],1,1) AS Ptype
      ,tb.[ProductID]
      ,[Proj_Name]
      ,tb.UnitNumber [UnitNumber]
      ,tb.[FloorID]
      ,[FloorName]
      ,[สถานะQIS]
      ,[IsQA]
      ,[IsWIP]
      ,[IsNoAct]
      ,tb.[ContractNumber]
      ,tb.[TransferDate]
      ,[TransferDateApprove]
      ,[OverDueDay]
      ,[ฉ1]
      ,[ฉ2]
      ,[ฉ.ยกเลิก]
      ,[ยังไม่ตรวจ]
      ,[Defect1]
      ,[Defect2]
       ,[Defect>2]
       , case
       when tb.DefectStatus = 1 and [NumberOfDefect] =1 then 1
       else 0 end as [D1]
       
       , case
       when tb.DefectStatus = 1 and [NumberOfDefect] =2 then 1
       else 0 end as [D2]
       
         , case
       when tb.DefectStatus = 1 and [NumberOfDefect] =3 then 1
       else 0 end as [D3]
         
      , case
       when tb.DefectStatus = 1 and [NumberOfDefect] >3 then 1
       else 0 end as [D>3]
         
      
      
      , case
       when tb.DefectStatus = 2 and [NumberOfDefect] =1 then 1
       else 0 end as [FCD1]
       
        , case
       when tb.DefectStatus = 2 and [NumberOfDefect] =2 then 1
       else 0 end as [FCD2]
       
       , case
       when tb.DefectStatus = 2 and [NumberOfDefect] =3 then 1
       else 0 end as [FCD3]
         
      , case
       when tb.DefectStatus = 2 and [NumberOfDefect] >3 then 1
       else 0 end as [FCD>3]
       
       
       ,tb.DefectStatus as DStatus
     
      ,[NumberOfDefect]
      ,[DefectName]
      ,[NumberOfDefectName]
      --,'('+CAST(dbo.fn_AP_BI_GetAmountDefect(ProductID,UnitNumber) as Nvarchar(3))+')' as NumberOfDefectName
      ,tb.[CheckDate]
      ,[AmountDefect]
      ,Case
		when ExpectDate = '1900-01-01 00:00:00.000' then dateadd(day,14,tb.CheckDate)
		when ExpectDate is null then dateadd(day,14,tb.CheckDate)
		else ExpectDate
		end as ExpectDate
--,ExpectDate
      
      ,[AmountDefect1]
      ,[CheckDateDefect1]
      ,[FixDayOfDefect1]
      ,[AmountDefect2]
      ,[CheckDateDefect2]
      ,[FixDayOfDefect2]
      ,[รับห้องแล้ว]
      --,
      --Case
      --when [รับห้องแล้ว] =1 then [สถานะซ่อม]
      --when (tb.AmountDefect = tb.AmountDefectComplete) or isnull(tb.AmountDefectComplete,1) = 0 then 'พร้อมตรวจ'
      --else [สถานะซ่อม] end as [สถานะซ่อม]
      
       , case tb.DefectStatus
		when 0 then 'ห้องว่าง'
		when 1 then 'ระหว่างซ่อม'
		when 2 then 'พร้อมตรวจ'
		when 3 then 'รอตรวจ'
		when 4 then 'รับห้องแล้ว'
		end as [สถานะซ่อม]
      
      ,Case tb.DefectStatus
      when 1 then 1
      else 0 end as [ระหว่างซ่อม] 
      
       ,Case tb.DefectStatus
      when 2 then 1
      else 0 end as [ซ่อมเสร็จ] 
      
       ,Case tb.DefectStatus
      when 3 then 1
      else 0 end as [รอตรวจ] 
      
         ,Case tb.DefectStatus
      when 4 then 1
      else 0 end as [รับห้องแล้ว] 
      
      
      ,[BC]
      ,[ยังไม่ยื่นกู้]
      ,[รออนุมัติเงินกู้]
       ,ISNULL([เงินกู้อนุมัติ],0) AS  [เงินกู้อนุมัติ]
      ,[เงินสด]
      ,[ห้องรอขาย]
      ,[CreditWait]
      ,[CreditPass]
      ,[Status]
      ,[UnitCRMว่าง]
      ,[QC_STK_PTD]
      ,[วันที่ฉ1]
      ,[วันที่ฉ2]
      ,[วันที่ฉ.ยกเลิก]
      ,[ฉพิเศษ]
      ,[วันที่ฉพิเศษ]
      ,[ฉเตือน1]
      ,[วันที่ฉเตือน1]
      ,[ฉเตือน2]
      ,[วันที่ฉเตือน2]
      ,[ฉยกเลิกพิเศษ]
      ,[วันที่ฉยกเลิกพิเศษ]
      ,[FullOwnerName]
      ,[FullPhone]
      ,'' as UnitDesc
      ,Case 
      when TransferDateApprove is not null then 1
      else 0
      end as isTransfer
      ,Isnull(r.Remark,'')Remark
      ,Book.SaleArea as [พื้นที่ในสัญญา]
      ,UnitDetail.SaleArea as [พื้นที่จริง]
      ,case when isnull(UnitDetail.SaleArea,0)>0 then isnull(UnitDetail.SaleArea,0)-isnull(Book.SaleArea ,0) else 0 end as [พื้นที่เพิ่มลด]
	  ,'ราคาขาย' = ISNULL(up.SellingPrice,0)
	  --ISNULL((SELECT up.SellingPrice FROM #vw_UnitPrice up WHERE up.bookingid = tb.bookingid AND up.IsActive = 1 ),0)
	  --,'ส่วนลดสัญญา'  = ISNULL(ps.ContractDiscount,0)
	  ,'ส่วนลดสัญญา'  = ISNULL(up.cashdiscount,0)
	  --,'ส่วนลดณวันโอน(ขาย)' = ISNULL(up.TransferDiscount,0)   
	   ,'ส่วนลดณวันโอน(ขาย)' = ISNULL((SELECT ISNULL(aa.TransferDiscount,0) FROM #vw_UnitPrice aa WHERE aa.BookingNo = tb.bookingnumber AND aa.[Key] = '1'),0)
	  --,'ราคาสัญญา2'
	--  ,'ส่วนลดณวันโอน(โอน)' = ISNULL(pt.TransferDiscount,0)
	,'ส่วนลดณวันโอน(โอน)' = ISNULL((SELECT ISNULL(aa.TransferDiscount,0) FROM #vw_UnitPrice aa WHERE aa.BookingNo = tb.bookingnumber AND aa.[Key] = '4'),0)
	  ,'Promotionขาย'=  ISNULL( ps.TotalAmount ,0)
	  ,'Promotionโอน' =  ISNULL(( SELECT (ISNULL(ExpensePromotionAmount,0)+ISNULL(FeePromotionAmount,0)+ ISNULL(TransferDiscount,0)) FROM #vw_UnitPrice a WHERE  a.[Key]='4'  AND  a.BookingNo = tb.BookingNumber),0)
	  ,'ราคาขายสุทธิ'= ISNULL( up.TotalPrice ,0)
      , [มูลค่าหน้าสัญญา] = ISNULL(up.AgreementPrice,0)
      ,Agree.AreaPricePerUnit as [มูลค่าต่อตารางเมตร]
      ,case when isnull(UnitDetail.SaleArea,0)>0 then (isnull(UnitDetail.SaleArea,0)-isnull(Book.SaleArea,0))*isnull(Agree.AreaPricePerUnit,0) else 0 end as [มูลค่าเพิ่มลด]
      ,UnitDetail.HouseNo as [บ้านเลขที่]
      ,NotiTranfer.ResponseDate as [วันที่ตอบรับจดหมายนัดโอน]
      ,'สถานะการตอบรับ' = (SELECT TOP 1  m.[Name] FROM #MasterCenter m WHERE m.id = NotiTranfer.LetterStatusMasterCenterID )
      ,Case
      when (tb.AmountDefect = tb.AmountDefectComplete) or tb.AmountDefectComplete=0  then 'พร้อมตรวจ'
      else '' end as [สถานะDefect]
       ,Case
      when (tb.AmountDefect = tb.AmountDefectComplete) or tb.AmountDefectComplete=0 then tb.EndDateDefectComplete
      else null end as [วันที่Defectเสร็จจริง]
      ,tb.BankName
      ,tb.AdBankName
      ,Case
      when [เงินสด] = 1 then 'เงินสด'
      else tb.BankList
      end as BankList
      
      ,tb.Letter1
      ,tb.Letter2
      ,tb.LetterCancel
      ,tb.Letter4
      ,tb.Letter5
      ,tb.Letter6
      ,tb.Letter7
      --,dbo.fn_AP_BI_GetLetterStatus(tb.[ContractNumber]) as LetterStatus
      ,tb.LetterStatus
	  ,r.AppointmentsDate
	  ,r.CheckDelay
	  ,r.AppointmentsQa
	  ,r.NewAppointmentsDate
	  ,isnull(r.MissAppointmentDesc,'0') as MissAppointmentDesc
	  , case 
	  when isnull(r.MissAppointmentDesc,'0') ='0' then ''
	  when isnull(r.MissAppointmentDesc,'0') ='1' then 'ลูกค้าเลื่อนนัด'
	  when isnull(r.MissAppointmentDesc,'0') ='2' then 'ติดเรื่องงาน DF ยังไม่เสร็จ'
	  when isnull(r.MissAppointmentDesc,'0') ='3' then 'ติดต่อลูกค้าไม่ได้'
	  when isnull(r.MissAppointmentDesc,'0') ='4' then 'ส่งจดหมายหาลูกค้า แต่ลูกค้าไม่ได้รับ'
	  end as strMissAppointmentDesc
	  ,isnull(r.ContactFailure,0) as ContactFailure
      ,dbo.fn_AP_BI_GetMonthName(datepart(month,Getdate())) as M1
       ,dbo.fn_AP_BI_GetMonthName(datepart(month,DATEADD(month,1,getdate()))) as M2
     ,dbo.fn_AP_BI_GetMonthName(datepart(month,DATEADD(month,2,getdate()))) as M3
     
     ,datepart(year,Getdate() ) as CY
     
     ,dbo.fn_AP_BI_GetMonthName(datepart(month,DATEADD (month , -1 , Getdate() ) )) as PM
     ,datepart(year,DATEADD (month , -1 , Getdate() ) ) as PY

     ,dbo.fn_AP_BI_GetMonthName(datepart(month,DATEADD (month , 1 , Getdate() ) )) as NM
     ,datepart(year,DATEADD (month , 1 , Getdate() ) ) as NY


     ,tb.DefectStatus
     --,isnull(tb.BankReject,0) as BankReject
	 ,'BankReject' = (CASE WHEN tb.[เงินกู้อนุมัติ] >=0 OR tb.CreditPass > 0 OR tb.[เงินสด] = 1  OR tb.[ยังไม่ยื่นกู้] = 1 OR tb.[รออนุมัติเงินกู้] = 1 THEN null ELSE tb.BankReject END)
    --,'BankReject'=Case When Not Exists(Select * from [192.168.0.75].db_iconcrm_fusion.dbo.ICON_EntForms_Creditbanking b Where b.ContractNumber=Agree.Contractnumber)
				--			or Exists(Select * from [192.168.0.75].db_iconcrm_fusion.dbo.ICON_EntForms_Creditbanking b Where b.ContractNumber=Agree.Contractnumber and Isnull(Status,3)<>2 ) 
				--	    Then 0 Else 1 End
	,isnull(tb.LetterAmountDays,0) as LetterAmountDays
	,tb.[SEName]
,tb.[BookingDate]
,tb.[ContractDate]
,tb.[LoanDueDate]
,tb.[LoadDate]
,tb.[LoadApproveDate]
,tb.[PromotionSale]
,tb.[PromotionTransfer]
,tb.[AcceptUnitDate]
,'TransferDueDate'= (Select Top 1 DueDate From #BU3_Tranfer t Where t.projectid=tb.ProductID and t.UnitNumber=tb.UnitNumber  AND tb.bookingdate <= t.duedate)
,'TransferGrade'=Isnull((Select top 1 Grade From #BU3_Remark t Where t.ProjectID=tb.ProductID and t.UnitNumber=tb.UnitNumber AND t.BookingNumber = tb.BookingNumber),'')
--,'Status' = (case when TransferDateApprove is not null then 'โอนแล้ว'
--				when Agree.approvedate is not null then 'ทำสัญญาแล้ว'
--				When book.bookingdate is not null then 'จองแล้ว'
--				else 'ห้องว่าง'
--			end  )
,'Floor'=Isnull(f.NameTH,'')
,'Tower'=Isnull(t.TowerNoTH,'')
,'Year_1'=Convert(nvarchar(100),(Select Top 1 Y From #TWeek Where Month_No=1))
,'Month_1'=Convert(nvarchar(100),(Select Top 1 M From #TWeek Where Month_No=1))
,'Week_1_1'='W'+Convert(nvarchar(100),(Select Top 1 W From #TWeek Where Month_No=1 and Week_No=1))
,'Week_1_2'='W'+Convert(nvarchar(100),(Select Top 1 W From #TWeek Where Month_No=1 and Week_No=2))
,'Week_1_3'='W'+Convert(nvarchar(100),(Select Top 1 W From #TWeek Where Month_No=1 and Week_No=3))
,'Week_1_4'='W'+Convert(nvarchar(100),(Select Top 1 W From #TWeek Where Month_No=1 and Week_No=4))
,'Week_1_5'='W'+Convert(nvarchar(100),(Select Top 1 W From #TWeek Where Month_No=1 and Week_No=5))
,'Year_2'=Convert(nvarchar(100),(Select Top 1 Y From #TWeek Where Month_No=2))
,'Month_2'=Convert(nvarchar(100),(Select Top 1 M From #TWeek Where Month_No=2))
,'Week_2_1'='W'+Convert(nvarchar(100),(Select Top 1 W From #TWeek Where Month_No=2 and Week_No=1))
,'Week_2_2'='W'+Convert(nvarchar(100),(Select Top 1 W From #TWeek Where Month_No=2 and Week_No=2))
,'Week_2_3'='W'+Convert(nvarchar(100),(Select Top 1 W From #TWeek Where Month_No=2 and Week_No=3))
,'Week_2_4'='W'+Convert(nvarchar(100),(Select Top 1 W From #TWeek Where Month_No=2 and Week_No=4))
,'Week_2_5'='W'+Convert(nvarchar(100),(Select Top 1 W From #TWeek Where Month_No=2 and Week_No=5))
,'Year_3'=Convert(nvarchar(100),(Select Top 1 Y From #TWeek Where Month_No=3))
,'Month_3'=Convert(nvarchar(100),(Select Top 1 M From #TWeek Where Month_No=3))
,'Week_3_1'='W'+Convert(nvarchar(100),(Select Top 1 W From #TWeek Where Month_No=3 and Week_No=1))
,'Week_3_2'='W'+Convert(nvarchar(100),(Select Top 1 W From #TWeek Where Month_No=3 and Week_No=2))
,'Week_3_3'='W'+Convert(nvarchar(100),(Select Top 1 W From #TWeek Where Month_No=3 and Week_No=3))
,'Week_3_4'='W'+Convert(nvarchar(100),(Select Top 1 W From #TWeek Where Month_No=3 and Week_No=4))
,'Week_3_5'='W'+Convert(nvarchar(100),(Select Top 1 W From #TWeek Where Month_No=3 and Week_No=5))

,'Show_1_1'=Case When Exists(Select * From #BU3_Tranfer t Inner Join #TWeek w on t.Input_Year=w.Y and t.W=w.W 
							Where tb.[ProductID]=t.ProjectID and tb.UnitNumber=t.UnitNumber and w.Month_No=1 and w.Week_No=1) Then 'X'Else ''End
,'Show_1_2'=Case When Exists(Select * From #BU3_Tranfer t Inner Join #TWeek w on t.Input_Year=w.Y and t.W=w.W 
							Where tb.[ProductID]=t.ProjectID and tb.UnitNumber=t.UnitNumber and w.Month_No=1 and w.Week_No=2) Then 'X'Else ''End
,'Show_1_3'=Case When Exists(Select * From #BU3_Tranfer t Inner Join #TWeek w on t.Input_Year=w.Y and t.W=w.W 
							Where tb.[ProductID]=t.ProjectID and tb.UnitNumber=t.UnitNumber and w.Month_No=1 and w.Week_No=3) Then 'X'Else ''End
,'Show_1_4'=Case When Exists(Select * From #BU3_Tranfer t Inner Join #TWeek w on t.Input_Year=w.Y and t.W=w.W 
							Where tb.[ProductID]=t.ProjectID and tb.UnitNumber=t.UnitNumber and w.Month_No=1 and w.Week_No=4) Then 'X'Else ''End
,'Show_1_5'=Case When Exists(Select * From #BU3_Tranfer t Inner Join #TWeek w on t.Input_Year=w.Y and t.W=w.W 
							Where tb.[ProductID]=t.ProjectID and tb.UnitNumber=t.UnitNumber and w.Month_No=1 and w.Week_No=5) Then 'X'Else ''End
,'Show_2_1'=Case When Exists(Select * From #BU3_Tranfer t Inner Join #TWeek w on t.Input_Year=w.Y and t.W=w.W 
							Where tb.[ProductID]=t.ProjectID and tb.UnitNumber=t.UnitNumber and w.Month_No=2 and w.Week_No=1) Then 'X'Else ''End
,'Show_2_2'=Case When Exists(Select * From #BU3_Tranfer t Inner Join #TWeek w on t.Input_Year=w.Y and t.W=w.W 
							Where tb.[ProductID]=t.ProjectID and tb.UnitNumber=t.UnitNumber and w.Month_No=2 and w.Week_No=2) Then 'X'Else ''End
,'Show_2_3'=Case When Exists(Select * From #BU3_Tranfer t Inner Join #TWeek w on t.Input_Year=w.Y and t.W=w.W 
							Where tb.[ProductID]=t.ProjectID and tb.UnitNumber=t.UnitNumber and w.Month_No=2 and w.Week_No=3) Then 'X'Else ''End
,'Show_2_4'=Case When Exists(Select * From #BU3_Tranfer t Inner Join #TWeek w on t.Input_Year=w.Y and t.W=w.W 
							Where tb.[ProductID]=t.ProjectID and tb.UnitNumber=t.UnitNumber and w.Month_No=2 and w.Week_No=4) Then 'X'Else ''End
,'Show_2_5'=Case When Exists(Select * From #BU3_Tranfer t Inner Join #TWeek w on t.Input_Year=w.Y and t.W=w.W 
							Where tb.[ProductID]=t.ProjectID and tb.UnitNumber=t.UnitNumber and w.Month_No=2 and w.Week_No=5) Then 'X'Else ''End
,'Show_3_1'=Case When Exists(Select * From #BU3_Tranfer t Inner Join #TWeek w on t.Input_Year=w.Y and t.W=w.W 
							Where tb.[ProductID]=t.ProjectID and tb.UnitNumber=t.UnitNumber and w.Month_No=3 and w.Week_No=1) Then 'X'Else ''End
,'Show_3_2'=Case When Exists(Select * From #BU3_Tranfer t Inner Join #TWeek w on t.Input_Year=w.Y and t.W=w.W 
							Where tb.[ProductID]=t.ProjectID and tb.UnitNumber=t.UnitNumber and w.Month_No=3 and w.Week_No=2) Then 'X'Else ''End
,'Show_3_3'=Case When Exists(Select * From #BU3_Tranfer t Inner Join #TWeek w on t.Input_Year=w.Y and t.W=w.W 
							Where tb.[ProductID]=t.ProjectID and tb.UnitNumber=t.UnitNumber and w.Month_No=3 and w.Week_No=3) Then 'X'Else ''End
,'Show_3_4'=Case When Exists(Select * From #BU3_Tranfer t Inner Join #TWeek w on t.Input_Year=w.Y and t.W=w.W 
							Where tb.[ProductID]=t.ProjectID and tb.UnitNumber=t.UnitNumber and w.Month_No=3 and w.Week_No=4) Then 'X'Else ''End
,'Show_3_5'=Case When Exists(Select * From #BU3_Tranfer t Inner Join #TWeek w on t.Input_Year=w.Y and t.W=w.W 
							Where tb.[ProductID]=t.ProjectID and tb.UnitNumber=t.UnitNumber and w.Month_No=3 and w.Week_No=5) Then 'X'Else ''End

,'NotCheckCause'=Case  Isnull(r.MissAppointmentDesc,0)When 1 Then'ติดต่อไม่ได้'
					When 2 Then'ลูกค้าฝากขาย'
					When 3 Then'นัดตรวจแต่ไม่ระบุวัน'
					When 4 Then'ยังติดงานแก้ไข'
					When 5 Then'ลูกค้าอยู่ต่างประเทศ'
					When 6 Then'ลูกค้าอยู่ต่างจังหวัด'
					When 7 Then'ลูกค้าไม่ให้ความร่วมมือ'
					Else '' End
					,@Floor Floor,@Floor1 Floor1
,'a'= 0,
--ISNULL((
--								Select Count(UnitNumber) From #STG_UNIT_STATUS_PTD_V2 bb
--					where isnull(bb.BK_PTD,0) <> 1
--					and bb.ProductID = tb.ProductID	
--					and bb.UnitNumber = tb.UnitNumber	
--					and bb.QC_STK_PTD =1
--								),0) ,
'b'= 0
--ISNULL((
--			Select  Count(UnitNumber)  From #STG_UNIT_STATUS_PTD_V2 aa
--where aa.ProductID = tb.ProductID		
--and aa.UnitNumber = tb.UnitNumber	
--and aa.WIP_PTD =1
--and isnull(aa.BK_PTD,0) =0
--			),0)
,tb.EndDate
,ISNULL(up.FreedownDiscount,0) AS freedownamount
,CONVERT(DATETIME,agree.SignAgreementDate) AS ApproveDate

  FROM [dbo].BU3_AP_BI_UnitDetail_NEW tb  			
  Left Join #TUnit as UnitDetail With(NoLock) on tb.UnitNumber = UnitDetail.UnitNo 
  Left join  [crmrevo].PRJ.Project p With(NoLock)   ON  tb.ProductID = p.ProjectNo
  LEFT JOIN [crmrevo].prj.Tower t ON p.id = t.ProjectID AND t.IsDeleted = 0
  LEFT JOIN [crmrevo].prj.[Floor] f ON f.ProjectID = p.id  AND t.id = f.TowerID AND f.IsDeleted =0
  left join #Sal_Booking as Book With(NoLock) ON  book.BookingNo = TB.BookingNumber  
  Left Join #Sal_Agreement as Agree With(NoLock) ON agree.AgreementNo = tb.ContractNumber 
  Left Join #BU3_Remark r on tb.ProductID=r.ProjectID and tb.UnitNumber=r.UnitNumber	and tb.BookingNumber = r.BookingNumber
  --LEFT OUTER JOIN dbo.ZPROM_TransferPromotion TP With(NoLock) ON TP.ContractNumber = Agree.ContractNumber AND ISNULL(TP.IsCancel,0) = 0
  LEFT JOIN #vw_UnitPrice up ON up.BookingNo = tb.BookingNumber AND up.IsActive = 1 
  Left Join #TransferLetter as NotiTranfer With(NoLock) on NotiTranfer.AgreementID = agree.id 
  LEFT JOIN  #SalePromotion ps on ps.BookingNo = tb.BookingNumber 
  LEFT JOIN #TransferPromotion pt on pt.BookingNo = tb.BookingNumber 
  LEFT Join  [crmrevo].PRJ.WaiveQC QC_WAVE  With(NoLock) on (tb.UnitID = QC_WAVE.UnitID  )
--  left join 
--  (	select * from #BU3_Remark
--			SELECT  ZS.DocumentID,SUM(ZD.PricePerUnit*ZS.Amount) AS ItemPrice
--			FROM	dbo.ZPROM_SalePromotionDetail ZS With(NoLock)
--					LEFT OUTER JOIN dbo.ZPROM_PromotionDetail ZD With(NoLock) ON ZD.PromotionID = ZS.PromotionID AND ZD.ItemID = ZS.ItemID
--			GROUP BY ZS.DocumentID		
--		)ZD ON ZD.DocumentID = CASE WHEN Agree.ContractNumber IS NULL THEN Book.BookingNumber ELSE Agree.ContractNumber END 
--  left join 
--  	(	
--			SELECT  DocumentID,SUM(CASE PromotionFeeID WHEN '15' THEN Amount / 2 ELSE 
--						CASE WHEN Charge='H' THEN Amount / 2 ELSE Amount END END) AS PayPrice
--			FROM	dbo.ZPROM_SalePromotionFee With(NoLock)
--			WHERE   ((PromotionFeeID = '15' AND Charge='N')
--					OR (PromotionFeeID IN ('00','01','02','17','2G','37','000') AND (Charge='N' OR Charge='H')))
----			WHERE	Charge IN (''N'',''H'')
--			GROUP BY DocumentID		
--		)ZF ON ZF.DocumentID = CASE WHEN Agree.ContractNumber IS NULL THEN Book.BookingNumber ELSE Agree.ContractNumber END 
--		LEFT OUTER JOIN 
--		(	
--			SELECT  ZP.TransferPromotionID,SUM(ZD.PricePerUnit*ZP.Amount) AS ItemPrice
--			FROM	dbo.ZPROM_TransferPromotionDetail ZP With(NoLock)
--					LEFT OUTER JOIN dbo.ZPROM_PromotionDetail ZD With(NoLock) ON ZD.PromotionID = ZP.PromotionID AND ZD.ItemID = ZP.ItemID
--			WHERE ISNULL(ZP.IsSelected,0) = 1
--			GROUP BY ZP.TransferPromotionID		
--		)ZP ON ZP.TransferPromotionID = TP.TransferPromotionID
--		LEFT OUTER JOIN 
--		(	
--			SELECT  TransferPromotionID,SUM(CASE PromotionFeeID WHEN '15' THEN Amount / 2 ELSE Amount END) AS PayPrice ---,SUM(Amount) AS PayPrice
--			FROM	dbo.ZPROM_TransferPromotionFee With(NoLock)
--			WHERE   ((PromotionFeeID = '15' AND Charge='N')
--					OR (PromotionFeeID IN ('00','01','02','17','2G','37') AND (Charge='N' OR Charge='H')))
----			WHERE	Charge IN (''N'',''H'')
--			GROUP BY TransferPromotionID		
--		)TF ON TF.TransferPromotionID = TP.TransferPromotionID 
--		LEFT JOIN crm_freedown cr ON ISNULL(Agree.ContractNumber , book.BookingNumber )=cr.documentid 
  where 1=1
 
  AND (ISNULL(@BG,'')='' or SUBSTRING(p.[Group],1,1)=@BG)
  --and tb.ProductID =isnull(@ProductID,'')--@ProductID --and TransferDateApprove is null
  and (Isnull(@ProductID,'')='' Or tb.ProductID In(SELECT * FROM [dbo].[fn_SplitString](@ProductID,',')))
and (Isnull(@Floor,'')='' or right('000'+Isnull(f.NameTH,''),3)between right('000'+Isnull(@Floor,''),3)and right('000'+Isnull(@Floor1,''),3) or Isnull(f.NameTH,'')=Isnull(@Floor,'') )
and (Isnull(@Tower,'')='' or Isnull(t.TowerCode,'')=Isnull(@Tower,'') or Isnull(t.TowerCode,'')between Isnull(@Tower,'')and Isnull(@Tower1,''))
and ((tb.TransferDate Between @TransferStartDate and @TransferEndDate)
		or (@TransferStartDate='20000101' and @TransferEndDate='70001231'))

and ( @STRLCID is null
		  OR tb.UnitNumber in (
		Select LC.UnitNo From #vw_ZLCUnit LC  					 
		where 1=1 
		and  (ISNULL(@BG,'')='' or LC.BGNo =@BG)
		and (Isnull(@ProductID,'')='' Or LC.ProjectNo In(SELECT * FROM [dbo].[fn_SplitString](@ProductID,',')))
		--and  LC.ProductId = isnull(@ProductID,'')
		and LC.UserID = @STRLCID or @STRLCID is null
		))
and (isnull(@IsOverDue,'') ='' or isnull(@IsOverDue,0) =0 or  datediff(day,tb.TransferDate,isnull(dbo.fn_AP_BI_GetUnitTransferDate_REVO(tb.ProductID,tb.UnitNumber),Getdate())) >0  )
and (isnull(@LetterStatus1,'') ='' or isnull(@LetterStatus1,0) =0 or tb.ฉ1 = @LetterStatus1)
and (isnull(@LetterStatus2,'') ='' or isnull(@LetterStatus2,0) =0 or tb.ฉ2 = @LetterStatus2)
and (isnull(@LetterStatus3,'') ='' or isnull(@LetterStatus3,0) =0 or tb.[ฉ.ยกเลิก] = @LetterStatus3)
and (isnull(@DefectStatus1,'') ='' or isnull(@DefectStatus1,0) =0 or (Case 
									when tb.DefectStatus =3  then 1
									else 0
									end ) = @DefectStatus1)
and (isnull(@DefectStatus2,'') ='' or isnull(@DefectStatus2,0) =0 or (@DefectStatus2=1 and (tb.Defect1 = 1 or tb.Defect2=1 or tb.[Defect>2]=1)))		
and (isnull(@DefectStatus3,'') ='' or isnull(@DefectStatus3,0) =0 or (Case
									when (tb.DefectEndDateNotNull - tb.DefectEndDateNull) = 1 Then 1
									else 0
									end) = @DefectStatus3)
and (isnull(@LetterStatus1,'') ='' or isnull(@LetterStatus1,'') ='' or isnull(@BCStatus,0) =0 or (Case 
								when tb.Status =7 then 1
								else 0 
								end) = @BCStatus)	
and (isnull(@PayStatus1,'') ='' or isnull(@PayStatus1,0) =0 or (Case 
								when tb.Status is null then 1
								else 0 
								end) = @PayStatus1)		
and (isnull(@PayStatus2,'') ='' or isnull(@PayStatus2,0) =0 or (Case
								when  (tb.Status is Not null) and (tb.CreditWait >0) and (tb.CreditPass <=0) then 1
								else 0
								end) = @PayStatus2)			
and (isnull(@PayStatus3,'') ='' or isnull(@PayStatus3,0) =0 or (case
								when (Select Top 1 LoanAmount   from #TCreditBank Creditbanking With(NoLock)
									where 1=1 AND (Creditbanking.bookingNo =tb.BookingNumber )) is null then 0
								else 1
								end	) = @PayStatus3)
and (isnull(@PayStatus4,'') ='' or isnull(@PayStatus4,0) =0 or (Case 
								when tb.Status =1 then 1
								else 0 
								end) = @PayStatus4)		
and (isnull(@PayStatus5,'') ='' or isnull(@PayStatus5,0) =0 or (Case 
								when tb.BankReject >=1 then 1
								else 0 
								end) = @PayStatus5)		
and (isnull(@WaitSale,'') ='' or isnull(@WaitSale,0) =0 or (Case 
								When (tb.[UnitCRMว่าง] >0) and (tb.QC_STK_PTD =1) then 1
								else 0 
							end)  = @WaitSale)	
and (isnull(@TranferStatus,'') ='' or isnull(@TranferStatus,'0') ='0' or (Case
										when isnull(@TranferStatus,'0') ='1' then ( Case 
																					  when TransferDateApprove is not null then 1
																					  else 0
																					  end
																					  )
										
										
										when isnull(@TranferStatus,'0') ='2' then (Case
																					when tb.TransferDateApprove IS  NULL AND (tb.BookingDate IS NOT NULL OR tb.BookingNumber IS NOT NULL) then 1
																					 else 0
																					  end
																				    )
										
										when isnull(@TranferStatus,'0') ='3' then (
																					--CASE
																					--when
																					--  (
																					--	isnull((
																					--				Select Count(UnitNumber) From #STG_UNIT_STATUS_PTD_V2 bb
																					--	where isnull(bb.BK_PTD,0) <> 1
																					--	and bb.ProductID = tb.ProductID	
																					--	and bb.UnitNumber = tb.UnitNumber	
																					--	and bb.QC_STK_PTD =1
																					--				),0) +
																					--	isnull((
																					--				Select  Count(UnitNumber)  From #STG_UNIT_STATUS_PTD_V2 aa
																					--	where aa.ProductID = tb.ProductID		
																					--    and aa.UnitNumber = tb.UnitNumber	
																					--	and aa.WIP_PTD =1
																					--	and isnull(aa.BK_PTD,0) =0
																					--				),0)
			
																					  
																					--  )  >0 then 1
																					-- else 0
																					--  end
																					CASE WHEN tb.BookingDate IS NULL OR tb.BookingNumber IS NULL THEN 1 ELSE 0 end
																				    )
																				    
										
										
										else 0 end ) = 1 )
										
and (isnull(@QAStatus,'') ='' or isnull(@QAStatus,'0') ='0' or  (Case
										when isnull(@QAStatus,'0') ='1' then ( Case 
																					  when isnull(tb.IsQA,0) =1 then 1
																					  else 0
																					  end
																					  )
										when isnull(@QAStatus,'0') ='2' then ( Case 
																					  when isnull(tb.IsWIP,0) =1 then 1
																					  else 0
																					  end
																					  )
										when isnull(@QAStatus,'0') ='3' then ( Case 
																					  when QC_WAVE.WaiveQCDate is not null then 1
																					  else 0
																					  end
																					  )
										else 0
										end) = 1)
										
										
										
and (isnull(@SaleStatus,'') ='' or isnull(@SaleStatus,'0') ='0' or (Case
																				
										when isnull(@SaleStatus,'0') ='1' then (
																				--CASE
																				--	when isnull(tb.QC_BL_IND_1_15_PTD,0)+
																				--			isnull(tb.QC_BL_OVD_16_30_PTD,0)+
																				--			isnull(tb.QC_BL_OVD_30_PTD,0)+
																				--			isnull(tb.NQC_BL_OVD_16_30_PTD,0)+
																				--			isnull(tb.NQC_BL_OVD_30_PTD,0)+
																				--			isnull(tb.NQC_BL_IND_1_15_PTD,0) >0 then 1
																				--	 else 0
																				--	  end
																				Case
																					when tb.TransferDateApprove IS NOT NULL AND (tb.BookingDate IS NOT NULL OR tb.BookingNumber IS NOT NULL)  then 1
																					 else 0
																					  end
																				    )
										
										when isnull(@SaleStatus,'0') ='2' then (
																				--CASE
																				--	when
																				--	  (
																				--		isnull((
																				--					Select Count(UnitNumber) From #STG_UNIT_STATUS_PTD_V2 bb
																				--		where isnull(bb.BK_PTD,0) <> 1
																				--		and bb.ProductID = tb.ProductID	
																				--		and bb.UnitNumber = tb.UnitNumber	
																				--		and bb.QC_STK_PTD =1
																				--					),0) +
																				--		isnull((
																				--					Select  Count(UnitNumber)  From #STG_UNIT_STATUS_PTD_V2 aa
																				--		WHERE aa.ProductID = tb.ProductID		
																				--	    and aa.UnitNumber = tb.UnitNumber	
																				--		and aa.WIP_PTD =1
																				--		and ISNULL(aa.BK_PTD,0) =0
																				--					),0)
			
																					  
																				--	  )  >0 then 1
																				--	 else 0
																				--	  end
																				CASE WHEN tb.BookingDate IS NULL OR tb.BookingNumber IS NULL THEN 1 ELSE 0 end
																				    )
																				    
										
										
										else 0 end ) = 1 )
										
																					  

order by tb.ProductID,tb.UnitNumber


--print(@SaleStatus)
go

