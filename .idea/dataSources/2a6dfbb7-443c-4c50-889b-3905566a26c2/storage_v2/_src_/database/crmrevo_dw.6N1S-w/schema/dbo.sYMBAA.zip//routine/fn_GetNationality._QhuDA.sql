CREATE FUNCTION [dbo].[fn_GetNationality]
(
    @NationalityUnClean VARCHAR(1000)
)
RETURNS NVARCHAR(1000)
AS
BEGIN

    DECLARE @result NVARCHAR(1000);
	DECLARE @i_count INT;

	IF ISNULL(@NationalityUnClean,'') = ''
	BEGIN
	    SET @result = ''
	END
	ELSE
	BEGIN
	    SELECT @i_count = COUNT(*)
		FROM dbo.crm_nationality_mapping WITH(NOLOCK)
		WHERE Nationality_Unclean = @NationalityUnClean;

		IF @i_count > 0
		BEGIN
			SELECT TOP 1 @result = Nationality_cleanup
			FROM dbo.crm_nationality_mapping WITH(NOLOCK)
			WHERE Nationality_Unclean = @NationalityUnClean;
		END
		ELSE
		BEGIN
			SET @result = 'Unknown'
		END
	END

    RETURN @result;
END;



go

