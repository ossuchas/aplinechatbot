
CREATE FUNCTION [dbo].[fn_AP_BI_GetLetter1_REVO]
(	
	@ContractNumber nvarchar(20)
	
)
RETURNS nvarchar(1000)
AS
BEGIN
	DECLARE @LetterDate nvarchar(100)
	DECLARE @LetterRespondDate nvarchar(100)
	DECLARE @LetterBackword nvarchar(100)
	
	DECLARE @ret nvarchar(1000)
	
	--SET @ContractNumber = ISNULL(@ContractNumber,'')
	set @LetterDate =''
	set @LetterRespondDate =''
	set @LetterBackword =''
	
	
	IF ISNULL(@ContractNumber,'') <> ''
	BEGIN

	set @LetterDate =(
	Select top 1  isnull( CONVERT(VARCHAR(10),TransferLetterDate,103),'') 
	From [crmrevo].let.TransferLetter as Letter With(NoLock)
	INNER JOIN [crmrevo].mst.MasterCenter m With(NoLock) ON Letter.TransferLetterTypeMasterCenterID = m.id 
	LEFT JOIN [crmrevo].sal.Agreement a ON a.id = Letter.AgreementID AND a.IsDeleted = 0
	where a.AgreementNo = @ContractNumber
	and  m.[KEY] = '1' AND Letter.IsDeleted = 0 )
	
	set @LetterRespondDate =(
	Select top 1  isnull( CONVERT(VARCHAR(10),ResponseDate,103),'') 
	From [crmrevo].let.TransferLetter as Letter With(NoLock)
	INNER JOIN [crmrevo].mst.MasterCenter m With(NoLock) ON Letter.TransferLetterTypeMasterCenterID = m.id 
	LEFT JOIN [crmrevo].sal.Agreement a ON a.id = Letter.AgreementID AND a.IsDeleted = 0
	where a.AgreementNo = @ContractNumber
	and  m.[KEY] = '1' AND Letter.IsDeleted = 0 )
	
	set @LetterBackword =(
	Select top 1  isnull( mm.[Name],'') 
	FROM (SELECT Letter.* ,m.[Key] FROM  [crmrevo].let.TransferLetter as Letter With(NoLock)
		INNER JOIN [crmrevo].mst.MasterCenter m With(NoLock) ON Letter.TransferLetterTypeMasterCenterID = m.id 
		LEFT JOIN [crmrevo].sal.Agreement a ON a.id = Letter.AgreementID AND a.IsDeleted = 0
		WHERE   m.[KEY] = '1' AND Letter.IsDeleted = 0 
		AND a.AgreementNo = @ContractNumber ) aa
	INNER JOIN [crmrevo].mst.MasterCenter mm With(NoLock) ON aa.LetterStatusMasterCenterID = mm.id 
	--LEFT JOIN [crmrevo].sal.Agreement a ON a.id = aa.AgreementID
	)	
	
	
	if(@LetterDate <> '')
		begin
			if(@LetterRespondDate<>'')
				set @ret ='('+@LetterDate+') ('+@LetterBackword+') ('+@LetterRespondDate+')'				
			else
				set @ret ='('+@LetterDate+')'
		end		
	else
		set @ret =''
	

	END 
	ELSE 
		set @ret =''
	RETURN @ret
END



go

