
CREATE PROCEDURE [dbo].[sp_proc_mail_llbw_all]
AS
	--EXEC [dbo].[sp_proc_mail_llbw_D]
	--EXEC [dbo].[sp_proc_mail_llbw_D_TH]
	--EXEC [dbo].[sp_proc_mail_llbw_DJV]
	--EXEC [dbo].[sp_proc_mail_llbw_DJV_PRE]
	--EXEC [dbo].[sp_proc_mail_llbw_DCD]

    SET NOCOUNT ON;
	DECLARE @subject_no AS INT;
	DECLARE @ptype AS VARCHAR(10);

	PRINT '##### <sp_proc_mail_llbw_D> #####'
	DECLARE db_cursor_1 CURSOR
	FOR
		SELECT DISTINCT subject_no, ptype
		  FROM [dbo].[crm_mail_ll_data] WITH(NOLOCK)
		  WHERE ptype IN ('1','2','3','4')
		  AND subject_no NOT IN (8,9)

	OPEN db_cursor_1
	FETCH NEXT FROM db_cursor_1 INTO @subject_no, @ptype

	WHILE @@FETCH_STATUS = 0
		BEGIN
			--PRINT @subject_no
			EXEC [dbo].[sp_proc_mail_llbw_D] @p_parm = @subject_no, @p_bg = @ptype, @p_th_option = '' 
			FETCH NEXT FROM db_cursor_1 INTO @subject_no, @ptype
		END 

	CLOSE db_cursor_1 
	DEALLOCATE db_cursor_1

	PRINT '##### <sp_proc_mail_llbw_D_TH> #####'
	DECLARE db_cursor_1 CURSOR
	FOR
		SELECT DISTINCT subject_no, REPLACE(subject_type,'TH-','') AS ptype
		FROM dbo.crm_mail_ll_data WHERE subject_type like '%TH-%'

	OPEN db_cursor_1
	FETCH NEXT FROM db_cursor_1 INTO @subject_no, @ptype

	WHILE @@FETCH_STATUS = 0
		BEGIN
			EXEC [dbo].[sp_proc_mail_llbw_D_TH] @p_parm = @subject_no, @p_bg = '2', @p_th_option = @ptype

			FETCH NEXT FROM db_cursor_1 INTO @subject_no, @ptype
		END 

	CLOSE db_cursor_1 
	DEALLOCATE db_cursor_1

	PRINT '##### <sp_proc_mail_llbw_DJV> #####'
	EXEC [dbo].[sp_proc_mail_llbw_DJV] @p_parm = 9, @p_bg = '3', @p_option = 'TF' 
	EXEC [dbo].[sp_proc_mail_llbw_DJV] @p_parm = 9, @p_bg = '4', @p_option = 'TF'

	EXEC [dbo].[sp_proc_mail_llbw_DJV_PRE] @p_parm = 9, @p_bg = '3', @p_option = 'PRE'
	EXEC [dbo].[sp_proc_mail_llbw_DJV_PRE] @p_parm = 9, @p_bg = '4', @p_option = 'PRE'

	PRINT '##### <sp_proc_mail_llbw_DCD> #####'
	EXEC [dbo].[sp_proc_mail_llbw_DCD] @p_parm = 8, @p_bg = '3', @p_option = 'CD1'
	EXEC [dbo].[sp_proc_mail_llbw_DCD] @p_parm = 8, @p_bg = '4', @p_option = 'CD2'



go

