Create FUNCTION [dbo].[fn_AP_BI_GetAmountDefectComplete]
(
	@ProductID nvarchar(15),
	@UnitNumber nvarchar(15)
	
)
RETURNS int
AS
BEGIN
	DECLARE @AmountDefect int
	
	set @AmountDefect =0
	
	
	set @AmountDefect =(
	--Select top 1 dr.defect_complete
	----From
	----[192.168.0.128].DefectLogs.dbo.tbl_defect_report as dr
	----Left Join [192.168.0.128].DefectLogs.dbo.tbl_project as pj on (dr.project_id = pj.id)
	----Left Join [192.168.0.128].DefectLogs.dbo.tbl_room as Room on (dr.room_id = Room.id)
	--From
	--[Temp_tbl_defect_report] as dr With(NoLock)
	--Left Join [Temp_tbl_project] as pj  With(NoLock)on (dr.project_id = pj.id)
	--Left Join [Temp_tbl_room] as Room  With(NoLock)on (dr.room_id = Room.id)
	--where pj.ProductID = @ProductID
	--and Room.room_code = @UnitNumber
	--	and dr.status = '1'
	--Order by dr.check_date DESC
	SELECT COUNT(RAuditNo)
	FROM [DBLINK_SVR_DEFECT].[defecttracking].[dbo].vwCallDefectRoundAudit
	WHERE ProjectNo = @ProductID
	AND Unit = @UnitNumber 
	AND DocIsActive = 1 AND RAuditCloseDate IS NOT NULL
	GROUP BY unit
--	order by RAuditNo desc
	)
	

	
	RETURN @AmountDefect
END


go

