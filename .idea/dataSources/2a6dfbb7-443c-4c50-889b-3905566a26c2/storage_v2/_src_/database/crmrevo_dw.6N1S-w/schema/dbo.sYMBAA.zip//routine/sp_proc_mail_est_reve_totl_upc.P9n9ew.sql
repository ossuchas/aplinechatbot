
CREATE PROCEDURE [dbo].[sp_proc_mail_est_reve_totl_upc]
As

    SET NOCOUNT ON;

	--Get Lead Lag Target
	IF (OBJECT_ID('tempdb..#temp_tg') IS NOT NULL)
    DROP TABLE #temp_tg;

	SELECT a.PType, CASE WHEN a.isJVStatus = 0 THEN 'AP' ELSE 'JV' END AS AP_JV, SUM(a.Target) AS Target
	INTO #temp_tg
	FROM (
	SELECT SUBSTRING(p.[Group],1,1) AS PType, a.ProjectID, a.Target,
	(SELECT COUNT(*) FROM crmrevo.PRJ.TransferProjectJV t WITH(NOLOCK) 
	WHERE CAST(t.EffectiveDate AS DATE) <= CAST(GETDATE() AS DATE)
	AND (t.ExpiredDate IS NULL OR CAST(t.ExpiredDate AS DATE) >= CAST(GETDATE() AS DATE)) 
	AND t.ProductID = p.ProjectNo) AS isJVStatus
	FROM dbo.RPT_LeadIndicator a WITH(NOLOCK), crmrevo.PRJ.Project p WITH(NOLOCK)
	WHERE a.y = DATEPART(YEAR, GETDATE())
	AND a.q = DATEPART(QUARTER, GETDATE()) 
	AND a.RecType = 'TransferAmount'
	AND a.ProjectID = p.ProjectNo
	AND p.IsDeleted = 0
	AND p.IsActive = 1 
	AND SUBSTRING(p.[Group], 3, 1) <> '0'
	AND p.ProjectNameTH NOT LIKE '%ระงับ%'
	AND p.IsUpCountry = 1) AS a
	GROUP BY a.PType,CASE WHEN a.isJVStatus = 0 THEN 'AP' ELSE 'JV' END
	ORDER BY 1

	-- Update SDH
	UPDATE dbo.crm_mail_est_reve_totl
	SET ll_curr_q_tg = ISNULL((SELECT SUM(Target) FROM #temp_tg WHERE PType = '1' AND AP_JV = 'AP'),0),
	qtd_ac = ISNULL((SELECT SUM(qtd_curr_ac) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 10),0),
	est_curr_totl = ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 11),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 10),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 10),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 10),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 10),0),
	qtd_est_totl = ISNULL((SELECT SUM(qtd_curr_ac) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 10),0)
	+ ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 10),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 10),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 10),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 10),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 10),0)
	WHERE seqn_no = 8;

	-- Update TH
	UPDATE dbo.crm_mail_est_reve_totl
	SET ll_curr_q_tg = ISNULL((SELECT SUM(Target) FROM #temp_tg WHERE PType = '2' AND AP_JV = 'AP'),0),
	qtd_ac = ISNULL((SELECT SUM(qtd_curr_ac) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 11),0),
	est_curr_totl = ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 11),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 11),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 11),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 11),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 11),0),
	qtd_est_totl = ISNULL((SELECT SUM(qtd_curr_ac) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 11),0)
	+ ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 11),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 11),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 11),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 11),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 11),0)
	WHERE seqn_no = 9;

	--Final Balance Diff
	UPDATE dbo.crm_mail_est_reve_totl
	SET qtd_est_diff_ll_curr_q_tg = ISNULL(qtd_est_totl,0) - ISNULL(ll_curr_q_tg,0),
	modifyby = 'batch_reve_totl_upc',
	modifydate = GETDATE()



go

