

CREATE PROCEDURE [dbo].[sp_InstCRM2LOS_Transfer_Log]
    @FilePath VARCHAR(MAX),
    @Remarks VARCHAR(255),
    @CreateBy VARCHAR(255)
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO dbo.CRM2LOS_Transfer_Log
    (
        ProductID,
        UnitNumber,
        PersonalID,
		TransferID,
        TransferDateApprove,
        ContractNumber,
        ContactID,
        SendLOSFlag,
        SendLOSFileName,
        CreateBy,
        CreateDate,
        ModifyBy,
        ModifyDate
    )
    SELECT p.ProjectNo AS ProductID,
	u.UnitNo AS UnitNumber,
	c.IdentityPersonNumber AS PersonalID,
	tr.ID,
	tr.ActualTransferDate AS TransferDateApprove,
	a.AgreementNo AS ContractNumber,
	c.ContactNo AS ContactID,
	'Y' AS SendLOSFlag,
	@FilePath,
	@CreateBy,
	GETDATE() AS CreateDate,
	@CreateBy,
	GETDATE() AS ModifyDate
	FROM  crmrevo.SAL.Transfer tr WITH(NOLOCK)       
	LEFT JOIN crmrevo.SAL.Agreement a WITH(NOLOCK) ON a.ID = tr.AgreementID AND a.IsDeleted = 0
	LEFT JOIN crmrevo.sal.AgreementOwner ao WITH(NOLOCK) ON ao.AgreementID = a.ID AND ao.IsMainOwner = 1 AND ao.IsDeleted = 0
	LEFT JOIN dbo.vw_Customer c WITH(NOLOCK) ON ao.FromContactID = c.ID AND ao.ContactNo = c.ContactNo
	LEFT JOIN crmrevo.SAL.Booking b WITH(NOLOCK) ON a.BookingID = b.ID AND b.IsDeleted = 0
	LEFT JOIN crmrevo.PRJ.Project p WITH (NOLOCK) ON p.ID = a.ProjectID AND p.IsActive = 1 AND p.IsDeleted = 0
	LEFT JOIN crmrevo.PRJ.Unit u WITH(NOLOCK) ON u.ID = a.UnitID AND a.ProjectID = u.ProjectID AND u.IsDeleted = 0
	LEFT JOIN crmrevo.prj.Model m WITH(NOLOCK) ON u.ModelID = m.ID AND m.IsDeleted = 0
	LEFT JOIN crmrevo.PRJ.Tower tw WITH(NOLOCK) ON u.TowerID = tw.ID AND tw.IsDeleted = 0
	LEFT JOIN crmrevo.PRJ.Floor fl WITH(NOLOCK) ON u.FloorID = fl.ID AND fl.TowerID = tw.ID AND fl.ProjectID = p.ID AND tw.IsDeleted = 0
	LEFT JOIN crmrevo.PRJ.TitledeedDetail td WITH(NOLOCK) ON td.UnitID = u.ID AND td.IsDeleted = 0 AND td.ProjectID = p.ID
	WHERE 1=1
	AND tr.IsDeleted = 0
	AND tr.ActualTransferDate IS NOT NULL                                       
	AND tr.ID NOT IN (SELECT TransferID FROM dbo.CRM2LOS_Transfer_Log WITH(NOLOCK))
	ORDER BY p.ProjectNo, u.UnitNo

END;



go

