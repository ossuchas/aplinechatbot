CREATE PROCEDURE [dbo].[sp_JobHelpDeskCRMTracking]
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN

    --DECLARE @ProductID Varchar(50) = '10164'
    --DECLARE @UnitNumber Varchar(50) = ''
	SET NOCOUNT ON;
    DECLARE @RequestId AS INT;
    DECLARE @RequestId_Line AS INT;
    DECLARE @TicketNo AS VARCHAR(50);
    DECLARE @RequestDate AS VARCHAR(20);
    DECLARE @RequestBy AS VARCHAR(20);
    DECLARE @Department AS VARCHAR(50);
    DECLARE @Status AS VARCHAR(20);
    DECLARE @RequestSubject AS VARCHAR(MAX);
    DECLARE @Msg AS VARCHAR(MAX);

    IF OBJECT_ID('tempdb..#tmpSession') IS NOT NULL
        DROP TABLE #tmpSession;
    SELECT WfDocPrimaryId,
           ActualEventId,
           W.ResponsibleUserValueText
    INTO #tmpSession
    FROM [DBLINK_SVR_EMAIL].[Workflow].[dbo].[WFResponsibleSession] W
    WHERE W.ActualEventId =
    (
        SELECT MAX(F.ActualEventId)
        FROM [DBLINK_SVR_EMAIL].[Workflow].[dbo].[WFResponsibleSession] F
        WHERE F.WfDocPrimaryId = W.WfDocPrimaryId
    );

    IF OBJECT_ID('tempdb..#tmpSLA') IS NOT NULL
        DROP TABLE #tmpSLA;
    SELECT RequestId,
           'SLA-DIFF' = CONVERT(DECIMAL, DATEDIFF(SECOND, EndTime, StartTime))
                        / CONVERT(DECIMAL, DATEDIFF(SECOND, EstimateTime, StartTime))
    INTO #tmpSLA
    FROM [DBLINK_SVR_EMAIL].ITHelpDesk_Test.dbo.TRequestDoc
    WHERE DATEDIFF(SECOND, EstimateTime, StartTime) <> 0
          AND DATEDIFF(SECOND, EstimateTime, StartTime) IS NOT NULL
          AND DATEDIFF(SECOND, EndTime, StartTime) IS NOT NULL;

    SELECT TOP 1
        @RequestId = T.RequestId,
        @TicketNo = T.TicketNumber,
        --@RequestDate = CONVERT(VARCHAR(20), T.RequestDate, 103) ,
        @RequestDate = FORMAT(T.RequestDate, 'dd/MM/yyyy hh:mm'),
        @RequestBy = VWUser.FullName,
        @Department = ISNULL(VWEmp.Devision, 'N/A'),
        @Status = st.MasterDescription,
        @RequestSubject = T.RequestSubject
    FROM [DBLINK_SVR_EMAIL].ITHelpDesk_Test.dbo.TRequestDoc T WITH (NOLOCK)
        INNER JOIN [DBLINK_SVR_EMAIL].ITHelpDesk_Test.dbo.MMaster S WITH (NOLOCK)
            ON T.SysId = S.MasterCode
        LEFT JOIN #tmpSession Tmp
            ON Tmp.WfDocPrimaryId = T.RequestId
        LEFT JOIN #tmpSLA SLA
            ON T.RequestId = SLA.RequestId
        LEFT JOIN [DBLINK_SVR_EMAIL].ITHelpDesk_Test.dbo.MCategories MC WITH (NOLOCK)
            ON MC.CategoryId = T.CategoryId
        LEFT JOIN [DBLINK_SVR_EMAIL].ITHelpDesk_Test.dbo.MMaster MType WITH (NOLOCK)
            ON MType.MasterCode = T.JobTypeId
        LEFT JOIN [DBLINK_SVR_EMAIL].ITHelpDesk_Test.dbo.MMaster st WITH (NOLOCK)
            ON T.RequestStatusId = st.MasterCode
        LEFT JOIN [DBLINK_SVR_EMAIL].ITHelpDesk_Test.dbo.vw_UserAll VWUser
            ON VWUser.UserID = T.RequestUserId
        LEFT JOIN [DBLINK_SVR_EMAIL].ITHelpDesk_Test.dbo.vw_Employee VWEmp
            ON VWEmp.EmpID = VWUser.UserName
    WHERE S.MasterCode NOT IN ( 'SYS-ESS', 'SYS-FingerScan' )
          AND S.MasterCode IN ('SYS-CRM','SYS-BI','SYS-MIS','SYS-STOCK','SYS-Tableau','SYS-GP Simulation','SYS-Gross Margin')
          AND CAST(T.RequestDate AS DATE) > '2020-01-01'
          AND ISNULL(T.IsDelete, 0) <> 1
    --AND mc.CategoryId IN (2,84) --2 =Bug, 84 = Report slowly
    ORDER BY T.RequestId DESC;


    SELECT TOP 1
        @RequestId_Line = CAST(Line_MobileNoOwner AS INT)
    FROM dbo.CRM_LineNotify
    WHERE Line_Owner = 'CRM'
    ORDER BY Tran_ID DESC;

    IF @RequestId > @RequestId_Line
    BEGIN
        --PRINT '>';
        SET @Msg
            = '
TicketNo: ' + @TicketNo + CHAR(10) + 
'RequestDate: ' + @RequestDate + CHAR(10) + 
'RequestBy: ' + @RequestBy + CHAR(10) + 
'Dept: ' + @Department + CHAR(10) + 
'Subject: ' + @RequestSubject;

        EXEC dbo.sp_InstLineNotifyMsg @LineToken = 'CRM',       -- varchar(255)
                                      @LineOwner = 'CRM',       -- varchar(255)
                                      @LineMobile = @RequestId, -- varchar(255)
                                      @LineMsg = @Msg,          -- varchar(max)
                                      @FilePath = '',           -- varchar(max)
                                      @Remarks = '',            -- varchar(255)
                                      @CreateBy = 'Suchat_S';   -- varchar(255)
    END;
    ELSE
    BEGIN
        PRINT '<=';
    END;


END;



go

