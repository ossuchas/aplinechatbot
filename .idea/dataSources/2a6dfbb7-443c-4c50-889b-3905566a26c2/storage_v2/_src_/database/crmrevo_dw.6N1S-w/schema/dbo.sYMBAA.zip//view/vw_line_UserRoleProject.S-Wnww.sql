CREATE VIEW [dbo].[vw_line_UserRoleProject] AS 
SELECT DISTINCT a.ProjectCode AS ProjectNo,a.ProjectName AS ProjectNameTH,a.EmpCode,a.FullName,a.Email,a.PositionName, u.user_token_Id
FROM [crmrevo].[dbo].[vw_UserRoleProject] a WITH (NOLOCK),
[crmrevo].prj.Project p WITH (NOLOCK),
crmrevo_dw.dbo.chatbot_mst_user u WITH(NOLOCK)
WHERE 1=1
--AND (RoleCode IN ('LCM','VP_Sale','LC','HOCS','PM','VP_Marking') OR a.PositionName LIKE '%Marketing Strategist')
AND a.ProjectCode = p.ProjectNo
AND p.IsActive = 1
AND p.IsDeleted = 0
--and a.ProjectCode = '60010'
--AND a.EmpCode = 'AP001094'
--AND u.user_token_Id = 'U80a30a5bad4ea0f5f7995e5050ab8d7e'
AND a.EmpCode = u.user_empcode
AND u.user_status = 'A'
AND u.user_token_Id <> '999999999999999999999999999999999'
--and a.ProjectCode = '60016'
--ORDER BY ProjectCode,PositionName


--SELECT * FROM dbo.chatbot_mst_user
go

