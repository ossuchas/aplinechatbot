CREATE VIEW [dbo].[vw_chatbot_mst_project]
AS
SELECT ProjectNo AS productid, ProjectNameTH AS projectname 
FROM crmrevo.PRJ.Project WITH(NOLOCK)
WHERE IsActive = 1 AND IsDeleted = 0
go

