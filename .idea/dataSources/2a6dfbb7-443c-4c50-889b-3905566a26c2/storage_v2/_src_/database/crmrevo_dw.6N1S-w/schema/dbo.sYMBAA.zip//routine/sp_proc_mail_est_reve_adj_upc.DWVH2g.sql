
CREATE PROCEDURE [dbo].[sp_proc_mail_est_reve_adj_upc]
As

    SET NOCOUNT ON;

	DECLARE @ac_q1_adj	FLOAT;
	DECLARE @ac_q2_adj	FLOAT;
	DECLARE @ac_q3_adj	FLOAT;
	DECLARE @ac_q4_adj	FLOAT;
	DECLARE @qtd_curr_ac_adj	FLOAT;
	DECLARE @est_curr_d1_adj	FLOAT;
	DECLARE @est_curr_d2_adj	FLOAT;
	DECLARE @est_curr_d3_adj	FLOAT;
	DECLARE @est_curr_d4_adj	FLOAT;
	DECLARE @est_curr_d5_adj	FLOAT;
	DECLARE @qtd_est_total_adj	FLOAT;
	DECLARE @ytd_est_ac_adj	FLOAT;

	--SDH 
	SET @ac_q1_adj = (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 4) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 10)
	SET @ac_q2_adj = (SELECT ISNULL(ac_q2, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 4) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 10)
	SET @ac_q3_adj = (SELECT ISNULL(ac_q3, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 4) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 10)
	SET @ac_q4_adj = (SELECT ISNULL(ac_q4, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 4) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 10)
	SET @qtd_curr_ac_adj = (SELECT ISNULL(qtd_curr_ac, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 4) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 10)
	SET @est_curr_d1_adj = (SELECT ISNULL(est_curr_d1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 4) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 10)
	SET @est_curr_d2_adj = (SELECT ISNULL(est_curr_d2, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 4) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 10)
	SET @est_curr_d3_adj = (SELECT ISNULL(est_curr_d3, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 4) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 10)
	SET @est_curr_d4_adj = (SELECT ISNULL(est_curr_d4, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 4) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 10)
	SET @est_curr_d5_adj = (SELECT ISNULL(est_curr_d5, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 4) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 10)
	SET @qtd_est_total_adj = (SELECT ISNULL(qtd_est_total, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 4) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 10)
	SET @ytd_est_ac_adj = (SELECT ISNULL(ytd_est_ac, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 4) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 10)

	-- Update SDH
	UPDATE crm_mail_est_reve
	SET ac_q1	=	@ac_q1_adj,
	ac_q2	=	@ac_q2_adj,
	ac_q3	=	@ac_q3_adj,
	ac_q4	=	@ac_q4_adj,
	qtd_curr_ac	=	@qtd_curr_ac_adj,
	est_curr_d1	=	@est_curr_d1_adj,
	est_curr_d2	=	@est_curr_d2_adj,
	est_curr_d3	=	@est_curr_d3_adj,
	est_curr_d4	=	@est_curr_d4_adj,
	est_curr_d5	=	@est_curr_d5_adj,
	qtd_est_total	=	@qtd_est_total_adj,
	ytd_est_ac	=	@ytd_est_ac_adj
	WHERE seqn_no = 4;

	--TH
	SET @ac_q1_adj = (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 5) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 11)
	SET @ac_q2_adj = (SELECT ISNULL(ac_q2, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 5) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 11)
	SET @ac_q3_adj = (SELECT ISNULL(ac_q3, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 5) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 11)
	SET @ac_q4_adj = (SELECT ISNULL(ac_q4, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 5) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 11)
	SET @qtd_curr_ac_adj = (SELECT ISNULL(qtd_curr_ac, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 5) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 11)
	SET @est_curr_d1_adj = (SELECT ISNULL(est_curr_d1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 5) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 11)
	SET @est_curr_d2_adj = (SELECT ISNULL(est_curr_d2, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 5) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 11)
	SET @est_curr_d3_adj = (SELECT ISNULL(est_curr_d3, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 5) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 11)
	SET @est_curr_d4_adj = (SELECT ISNULL(est_curr_d4, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 5) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 11)
	SET @est_curr_d5_adj = (SELECT ISNULL(est_curr_d5, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 5) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 11)
	SET @qtd_est_total_adj = (SELECT ISNULL(qtd_est_total, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 5) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 11)
	SET @ytd_est_ac_adj = (SELECT ISNULL(ytd_est_ac, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 5) - (SELECT ISNULL(ac_q1, 0) FROM dbo.crm_mail_est_reve WHERE seqn_no = 11)

	-- Update SDH
	UPDATE crm_mail_est_reve
	SET ac_q1	=	@ac_q1_adj,
	ac_q2	=	@ac_q2_adj,
	ac_q3	=	@ac_q3_adj,
	ac_q4	=	@ac_q4_adj,
	qtd_curr_ac	=	@qtd_curr_ac_adj,
	est_curr_d1	=	@est_curr_d1_adj,
	est_curr_d2	=	@est_curr_d2_adj,
	est_curr_d3	=	@est_curr_d3_adj,
	est_curr_d4	=	@est_curr_d4_adj,
	est_curr_d5	=	@est_curr_d5_adj,
	qtd_est_total	=	@qtd_est_total_adj,
	ytd_est_ac	=	@ytd_est_ac_adj
	WHERE seqn_no = 5;

go

