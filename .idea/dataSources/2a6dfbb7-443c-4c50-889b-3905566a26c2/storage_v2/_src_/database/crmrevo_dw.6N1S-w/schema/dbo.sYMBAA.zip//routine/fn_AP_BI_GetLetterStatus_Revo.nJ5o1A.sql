CREATE FUNCTION [dbo].[fn_AP_BI_GetLetterStatus_Revo]
(	
	@ContractNumber nvarchar(20),
	@ProductID nvarchar(15),
	@UnitNumber nvarchar(15)
	
	
)
RETURNS nvarchar(1000)
AS
BEGIN
	DECLARE @LetterDate nvarchar(100)	
	DECLARE @LetterRespondDate nvarchar(100)
	DECLARE @BackWord nvarchar(100)
	
	
	DECLARE @LetterBackword nvarchar(100)
	DECLARE @ListNo int
	DECLARE @AmountDay int	
	DECLARE @StrAmountDay nvarchar(100)
	
	
	DECLARE @TranferDate datetime
	set @TranferDate=null
	
	
	set @LetterDate =''	
	set @LetterRespondDate =''
	set @LetterBackword =''
	set @AmountDay =0
	
	IF ISNULL(@ContractNumber,'') <> ''
	BEGIN
	set @LetterDate =(
	Select top 1 isnull( CONVERT(VARCHAR(10),TransferLetterDate,3),'') as LetterDate 
	From [crmrevo].let.TransferLetter as Letter 
	INNER JOIN [crmrevo].mst.MasterCenter m ON m.id = Letter.TransferLetterTypeMasterCenterID
	LEFT JOIN [crmrevo].sal.Agreement a ON Letter.AgreementID = a.id AND a.IsDeleted = 0 
	where a.AgreementNo = @ContractNumber AND Letter.IsDeleted = 0 
	Order by m.[Key] desc
	)
	END 
	ELSE 
	SET @LetterDate = ''

	IF ISNULL(@ContractNumber,'') <> ''
	BEGIN
	set @LetterRespondDate =(
	Select TOP 1 isnull( CONVERT(VARCHAR(10),ResponseDate,3),'') as RespondDate 
	From  [crmrevo].let.TransferLetter as Letter 
	INNER JOIN [crmrevo].mst.MasterCenter m ON m.id = Letter.TransferLetterTypeMasterCenterID
	LEFT JOIN [crmrevo].sal.Agreement a ON Letter.AgreementID = a.id  AND a.IsDeleted = 0
	where a.AgreementNo = @ContractNumber  AND Letter.IsDeleted = 0 
	Order by m.[Key] desc
	)
	END 
	ELSE 
	SET @LetterRespondDate = ''

	IF ISNULL(@ContractNumber,'') <> ''
	BEGIN
	set @BackWord =(
	Select top 1 isnull(m.[Name],'') as Backword 
	From  [crmrevo].let.TransferLetter as Letter 
	LEFT JOIN [crmrevo].mst.MasterCenter m ON m.id = Letter.LetterStatusMasterCenterID
	LEFT JOIN [crmrevo].sal.Agreement a ON Letter.AgreementID = a.id  AND a.IsDeleted = 0
	where a.AgreementNo = @ContractNumber  AND Letter.IsDeleted = 0 
	Order by m.[Key] desc
	)
	END 
	ELSE 
	SET @BackWord = ''
	
	
	IF ISNULL(@ContractNumber,'') <> ''
	BEGIN
	set @ListNo = (
	Select top 1 m.[KEY] as ListNo	
	From  [crmrevo].let.TransferLetter as Letter 
	INNER JOIN [crmrevo].mst.MasterCenter m ON m.id = Letter.TransferLetterTypeMasterCenterID
	LEFT JOIN [crmrevo].sal.Agreement a ON Letter.AgreementID = a.id  AND a.IsDeleted = 0
	where  a.AgreementNo = @ContractNumber  AND Letter.IsDeleted = 0  
	Order by m.[KEY] desc	
	)
	END 
	ELSE 
	SET @ListNo = ''
	
	
	set @TranferDate=(	Select top 1  T.ScheduleTransferDate
	 From 	[crmrevo].sal.Agreement as Agree
		Left Join [crmrevo].sal.[Transfer] as t ON Agree.id = t.AgreementID AND t.IsDeleted = 0
		LEFT JOIN [crmrevo].prj.Project  p ON agree.ProjectID = p.id  AND p.IsDeleted = 0
		LEFT JOIN [crmrevo].prj.Unit u ON u.id = Agree.UnitID  AND u.IsDeleted = 0
		where Agree.IsCancel =0 AND p.ProjectNo =@ProductID AND u.UnitNo =@UnitNumber AND Agree.IsDeleted = 0)
		
	
	
		
	
	--set @AmountDay =(
	--Select top 1
	--Datediff(day,NotificationDate,isnull(RespondDate,getdate())) as AmountDay
	--From [192.168.0.75].db_iconcrm_fusion.dbo.ICON_EntForms_NotificationTranfer as Letter
	--where Letter.ContractNumber = @ContractNumber
	--Order by Letter.timeofNotification desc
	--)
	
	
	--CONVERT(VARCHAR(10),@AmountDay)
	
	--DECLARE db_cursor CURSOR FOR
	--Select top 1 isnull( CONVERT(VARCHAR(10),NotificationDate,103),'') as LetterDate ,
	--Letter.timeofNotification as ListNo,
	--isnull( CONVERT(VARCHAR(10),isnull(RespondDate,Getdate()),103),'')  as ConfirmDate,
	--DATEDIFF(day,NotificationDate,isnull( CONVERT(VARCHAR(10),isnull(RespondDate,Getdate()),103),'') ) as AmountDay
	--From [192.168.0.75].db_iconcrm_fusion.dbo.ICON_EntForms_NotificationTranfer as Letter
	--where Letter.ContractNumber = @ContractNumber
	--Order by Letter.timeofNotification desc
	
	
	--Select NotificationDate,RespondDate,Backword,DateInLetter,timeofNotification
	--From [192.168.0.75].db_iconcrm_fusion.dbo.ICON_EntForms_NotificationTranfer as Letter
	--where Letter.ContractNumber = '10065AA00624'
	--Order by Letter.timeofNotification desc
	
	--(วันที่ส่ง)(ตอบรับ วันที่ตอบรับ)
	
	
	
	
	
	set @AmountDay =0
	DECLARE @RespondDate datetime	
	
	set @RespondDate=null

	
	--DECLARE db_cursor CURSOR FOR  
	
 --   Select RespondDate
	--From [192.168.0.75].db_iconcrm_fusion.dbo.ICON_EntForms_NotificationTranfer as Letter
	--where Letter.ContractNumber = @ContractNumber
	--Order by Letter.timeofNotification desc
    
 --   OPEN db_cursor   
	--FETCH NEXT FROM db_cursor INTO @RespondDate

	--WHILE @@FETCH_STATUS = 0   
	--BEGIN   
	--   if @TranferDate is not null 
	--	begin
	--		if @RespondDate is not null
	--			SET @AmountDay = @AmountDay +	Datediff(day,@RespondDate,@TranferDate)		
	--	end
	    
      
 --      FETCH NEXT FROM db_cursor INTO @RespondDate
	--END   

	--CLOSE db_cursor   
	--DEALLOCATE db_cursor
	
	
	--if @AmountDay >0
	--	set @StrAmountDay =CONVERT(VARCHAR(100),@AmountDay)
	--else
	--	set @StrAmountDay =' - '
		
   DECLARE @strBackWord nvarchar(100)	
	set @strBackWord =''
	if 	@LetterRespondDate <> ''
		set @strBackWord = ' ( '+@BackWord+' '+@LetterRespondDate+' )'
	
	if @ListNo =1
				SET @LetterBackword = 'ฉ.1' + ' ( ' +@LetterDate+' )'+@strBackWord
			else if @ListNo ='2'
				SET @LetterBackword = 'ฉ.2' + ' ( ' +@LetterDate+' )'+@strBackWord
			else if @ListNo ='3'
				SET @LetterBackword = 'ฉ.ยกเลิก' + ' ( ' +@LetterDate+' )'+@strBackWord
			else if @ListNo ='4'
				SET @LetterBackword = 'ฉ.พิเศษ' + ' ( ' +@LetterDate+' )'+@strBackWord
			else if @ListNo ='5'
				SET @LetterBackword = 'ฉ.เตือน 1' + ' ( ' +@LetterDate+' )'+@strBackWord
			else if @ListNo ='6'
				SET @LetterBackword = 'ฉ.เตือน 2' + ' ( ' +@LetterDate+' )'+@strBackWord
			else if @ListNo ='7'
				SET @LetterBackword = 'ฉ.ยกเลิก(พิเศษ)' + ' ( ' +@LetterDate+' )'+@strBackWord
				
	
	
	
	
	RETURN @LetterBackword
END



go

