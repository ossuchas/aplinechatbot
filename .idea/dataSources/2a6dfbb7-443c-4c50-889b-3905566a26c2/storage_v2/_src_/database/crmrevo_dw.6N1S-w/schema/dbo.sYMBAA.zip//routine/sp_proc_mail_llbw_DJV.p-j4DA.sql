
CREATE PROCEDURE [dbo].[sp_proc_mail_llbw_DJV]
 @p_parm AS INT,
 @p_bg AS VARCHAR(2),
 @p_option AS VARCHAR(50)
As

    SET NOCOUNT ON;
	-- Parameter Description
	--##### p_parm
	-- 9 : JV Projects
	--##### p_bg
	-- 3 : CD1
	-- 4 : CD2
	--##### p_option
	-- TF : Transfer
	-- PRE : Presale

	DECLARE @curr_q_q1tg		AS FLOAT;
	DECLARE @curr_q_q2tg		AS FLOAT;
	DECLARE @curr_q_q3tg		AS FLOAT;
	DECLARE @curr_q_total		AS FLOAT;

	DECLARE @qtd_curr_w_tg		AS FLOAT;
	DECLARE @qtd_curr_w_ac		AS FLOAT;
	DECLARE @qtd_curr_w_flag		AS VARCHAR(50);
	DECLARE @qtd_curr_w_diff		AS FLOAT;
	
	DECLARE @qtg_val		AS FLOAT;
	
	DECLARE @curr_m_w1_tg		AS FLOAT;
	DECLARE @curr_m_w1_ac		AS FLOAT;
	DECLARE @curr_m_w1_flag		AS VARCHAR(50);
	DECLARE @curr_m_w2_tg		AS FLOAT;
	DECLARE @curr_m_w2_ac		AS FLOAT;
	DECLARE @curr_m_w2_flag		AS VARCHAR(50);
	DECLARE @curr_m_w3_tg		AS FLOAT;
	DECLARE @curr_m_w3_ac		AS FLOAT;
	DECLARE @curr_m_w3_flag		AS VARCHAR(50);
	DECLARE @curr_m_w4_tg		AS FLOAT;
	DECLARE @curr_m_w4_ac		AS FLOAT;
	DECLARE @curr_m_w4_flag		AS VARCHAR(50);
	DECLARE @curr_m_w5_tg		AS FLOAT;
	DECLARE @curr_m_w5_ac		AS FLOAT;
	DECLARE @curr_m_w5_flag		AS VARCHAR(50);

	DECLARE @full_month_tg		AS FLOAT;
	DECLARE @full_month_ac		AS FLOAT;
	DECLARE @full_month_flag		AS VARCHAR(50);
	DECLARE @full_month_dff		AS FLOAT;

    DECLARE @sub_group AS VARCHAR(255);
	DECLARE @sub_type AS VARCHAR(255);
	DECLARE @rectype AS VARCHAR(255);

	DECLARE @i_count AS INT;
	DECLARE @w_text AS VARCHAR(10);
	DECLARE @w_int AS INT;
	DECLARE @sum_target AS FLOAT;
	DECLARE @sum_actual AS FLOAT;

	IF @p_parm = 9 
	BEGIN 
		SET @sub_group = 'JVPROJECT';
		IF @p_option = 'TF'
		BEGIN
		   -- PRINT 'Transfer'
			SET @rectype = 'TransferAmount'; 
			SET @sub_type = 'TRANSFER'
		END
		ELSE
		BEGIN
		    --PRINT 'Presale'
			SET @rectype = 'NetPresalesAmount'
			SET @sub_type = 'PRESALE'
		END
	END;

	IF (OBJECT_ID('tempdb..#tbl_actual_tran') IS NOT NULL) DROP TABLE #tbl_actual_tran

	SELECT  CASE WHEN a.isJVStatus = 0 THEN 'AP' ELSE 'JV' END AS AP_JV,
	a.ProductID, a.PType, a.y, a.q, a.m, a.w, SUM(a.actual) AS actual 
	INTO #tbl_actual_tran
	FROM (
	SELECT TR.ProjectNo AS ProductID, BG AS PType, 
	w.Y,w.q,w.m,w.w 
	---------------------Modified by Apichaya 2020-09-08
	  -- (SELECT w FROM crmrevo.BI.Mst_Calendar_Week WITH(NOLOCK) WHERE CAST(TR.ActualTransferDate AS DATE) BETWEEN CAST(StartDate AS DATE) AND CAST(EndDate AS DATE)) AS w,
	  -- datepart(year, TR.ActualTransferDate) AS y, 
			--DATEPART(QUARTER, TR.ActualTransferDate) AS q,
			--DATEPART(MONTH, TR.ActualTransferDate) AS m,
			,TR.NetPriceExclFD AS actual, TR.isJVStatus
    FROM    dbo.vw_ActualTransfer TR WITH(NOLOCK)
	LEFT JOIN crmrevo.BI.Mst_Calendar_Week w  WITH(NOLOCK) ON CAST(tr.ActualTransferDate AS DATE) BETWEEN CAST(w.StartDate AS DATE) AND CAST(w.EndDate AS DATE)
    WHERE   1=1                                                            
	AND DATEPART(YEAR, TR.ActualTransferDate) = DATEPART(YEAR, GETDATE())
	AND DATEPART(QUARTER, TR.ActualTransferDate) = DATEPART(QUARTER, GETDATE())
	AND BG = @p_bg
	) AS a
	WHERE CASE WHEN a.isJVStatus = 0 THEN 'AP' ELSE 'JV' END = 'JV'
	GROUP BY CASE WHEN a.isJVStatus = 0 THEN 'AP' ELSE 'JV' END,
	a.ProductID, a.PType, a.y, a.q, a.m, a.w

	--SELECT * FROM #tbl_actual_tran

	IF (OBJECT_ID('tempdb..#tbl_curr_q') IS NOT NULL) DROP TABLE #tbl_curr_q

	SELECT a.PType, a.q, a.minus, a.m, a.w, a.RecType, a.SortKey, 
	a.AP_JV, SUM(a.actual) AS actual, SUM(a.target) AS target 
	INTO #tbl_curr_q
	FROM (
	SELECT @p_bg AS PType, a.q, 
	CASE WHEN a.q = 1 THEN 0 
	WHEN a.q = 2 THEN 1
	WHEN a.q = 3 THEN 2
	WHEN a.q = 4 THEN 3
	END AS minus,a.m, a.w, a.RecType, a.SortKey, 
	ISNULL(b.AP_JV,'AP') AS AP_JV,
	ISNULL(SUM(b.actual)/1000000,0) AS actual
	, 0.00 AS target
	FROM dbo.RPT_LeadIndicator a WITH(NOLOCK) LEFT JOIN #tbl_actual_tran b ON 
	 a.y = b.y
		  AND a.q = b.q
		  --AND a.m = b.m --Modified by Suchat S. 2020-09-08 
		  AND a.w = b.w
		  AND a.ProjectID = b.ProductID
		  AND b.PType = @p_bg
    WHERE a.Y = DATEPART(YEAR, GETDATE())
          AND a.q = DATEPART(QUARTER,GETDATE())
		  AND a.RecType = @rectype
	GROUP BY a.q, a.m, a.w, a.RecType, a.SortKey, b.AP_JV ) AS a
	GROUP BY a.PType, a.q, a.minus, a.m, a.w, a.RecType, a.SortKey, a.AP_JV

	IF (OBJECT_ID('tempdb..#tbl_curr_q_tg') IS NOT NULL) DROP TABLE #tbl_curr_q_tg

	SELECT a.PType, a.q, a.minus, a.m, a.w, a.RecType, a.SortKey, 
	a.AP_JV, SUM(a.actual) AS actual, SUM(a.target) AS target 
	INTO #tbl_curr_q_tg
	FROM (
	SELECT @p_bg AS PType, a.q, 
	CASE WHEN a.q = 1 THEN 0 
	WHEN a.q = 2 THEN 1
	WHEN a.q = 3 THEN 2
	WHEN a.q = 4 THEN 3
	END AS minus,a.m, a.w, a.RecType, a.SortKey, 
	ISNULL(b.AP_JV,'AP') AS AP_JV,
	ISNULL(SUM(b.actual)/1000000,0) AS actual, SUM(a.Target) AS target
	FROM dbo.RPT_LeadIndicator a WITH(NOLOCK) LEFT JOIN #tbl_actual_tran b ON 
	 a.y = b.y
		  AND a.q = b.q
		  --AND a.m = b.m --Modified by Suchat S. 2020-09-08 
		  AND a.w = b.w
		  AND a.ProjectID = b.ProductID
		  AND b.PType = @p_bg
    WHERE a.Y = DATEPART(YEAR, GETDATE())
          AND a.q = DATEPART(QUARTER,GETDATE())
		  AND a.RecType = @rectype
		  AND a.ProjectID IN (SELECT DISTINCT b.ProductID FROM #tbl_actual_tran b)
	GROUP BY a.q, a.m, a.w, a.RecType, a.SortKey, b.AP_JV ) AS a
	GROUP BY a.PType, a.q, a.minus, a.m, a.w, a.RecType, a.SortKey, a.AP_JV

	update #tbl_curr_q
	SET target = ISNULL(b.target,0)
	FROM #tbl_curr_q a, #tbl_curr_q_tg b
	WHERE a.PType = b.PType
	AND a.Q = b.Q
	--AND a.m = b.M Modified by Suchat S. 2020-09-08
	AND a.w = b.W
	AND a.AP_JV = b.AP_JV
	
	--SELECT * FROM #tbl_curr_q

	-- [1] Section Current Quarter
	SELECT @curr_q_q1tg = SUM(target) FROM #tbl_curr_q WHERE m-(3*minus)=1 -- First Quarter
	SELECT @curr_q_q2tg = SUM(target) FROM #tbl_curr_q WHERE m-(3*minus)=2 -- Second Quarter
	SELECT @curr_q_q3tg = SUM(target) FROM #tbl_curr_q WHERE m-(3*minus)=3 -- Third Quarter

	SET @curr_q_total = ISNULL(@curr_q_q1tg,0.00) + ISNULL(@curr_q_q2tg,0.00) + ISNULL(@curr_q_q3tg,0.00)

	-- [2] Section QTD Current Week	
	--SELECT  @qtd_curr_w_tg = SUM(target), @qtd_curr_w_ac = SUM(actual), @qtd_curr_w_diff = SUM(actual)-SUM(target) FROM #tbl_curr_q

	SELECT @qtd_curr_w_tg = SUM(target), 
	@qtd_curr_w_ac = SUM(actual),  
	@qtd_curr_w_diff = SUM(actual)-SUM(target) 
	FROM #tbl_curr_q 
	WHERE 1=1
      AND Q = DATEPART(QUARTER, GETDATE())
	  AND W < ( SELECT W FROM crmrevo.BI.Mst_Calendar_Week WITH (NOLOCK) WHERE CAST(GETDATE() AS DATE) BETWEEN CAST(StartDate AS DATE) AND CAST(EndDate AS DATE) )

	-- [2.1] Set Color
	IF @qtd_curr_w_ac < @qtd_curr_w_tg*0.8 SET @qtd_curr_w_flag	= 'bgcolor="#FF0000"' ELSE IF @qtd_curr_w_ac >= @qtd_curr_w_tg	SET @qtd_curr_w_flag = 'bgcolor="#00FF00"' ELSE SET @qtd_curr_w_flag = 'bgcolor="#FFFF00"'
	--IF ISNULL(@qtd_curr_w_tg, 0.00) = 0 SET @qtd_curr_w_flag = ''

	-- [3] QTG
	SET @qtg_val = ISNULL(@curr_q_total,0.00) - ISNULL(@qtd_curr_w_ac,0.00)

	-- [4] for each week by month
	SET @i_count = 1
	DECLARE db_cursor CURSOR
	FOR
		SELECT w, SUM(target), SUM(actual) FROM #tbl_curr_q WHERE m = DATEPART(MONTH, GETDATE()) GROUP BY w order by w

	OPEN db_cursor  
	FETCH NEXT FROM db_cursor INTO @w_int, @sum_target, @sum_actual

	WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @i_count = 1
			BEGIN
			    --PRINT 'week1'
				SET @curr_m_w1_tg = @sum_target;
				SET @curr_m_w1_ac = @sum_actual;
				SET @curr_m_w1_flag = 'N'
				
				IF @curr_m_w1_ac < @curr_m_w1_tg*0.8 SET @curr_m_w1_flag	= 'bgcolor="#FF0000"' ELSE IF @curr_m_w1_ac >= @curr_m_w1_tg	SET @curr_m_w1_flag = 'bgcolor="#00FF00"' ELSE SET @curr_m_w1_flag = 'bgcolor="#FFFF00"'
				--IF ISNULL(@curr_m_w1_tg, 0.00) = 0 SET @curr_m_w1_flag = ''
			END

			IF @i_count = 2
			BEGIN
				--PRINT 'week2'
				SET @curr_m_w2_tg = @sum_target;
				SET @curr_m_w2_ac = @sum_actual;
				IF @curr_m_w2_ac < @curr_m_w2_tg*0.8 SET @curr_m_w2_flag	= 'bgcolor="#FF0000"' ELSE IF @curr_m_w2_ac >= @curr_m_w2_tg	SET @curr_m_w2_flag = 'bgcolor="#00FF00"' ELSE SET @curr_m_w2_flag = 'bgcolor="#FFFF00"'
				--IF ISNULL(@curr_m_w2_tg, 0.00) = 0 SET @curr_m_w2_flag = ''
			END
            
			IF @i_count = 3 
			BEGIN
			    --PRINT 'week3'
				SET @curr_m_w3_tg = @sum_target;
				SET @curr_m_w3_ac = @sum_actual;
				IF @curr_m_w3_ac < @curr_m_w3_tg*0.8 SET @curr_m_w3_flag	= 'bgcolor="#FF0000"' ELSE IF @curr_m_w3_ac >= @curr_m_w3_tg	SET @curr_m_w3_flag = 'bgcolor="#00FF00"' ELSE SET @curr_m_w3_flag = 'bgcolor="#FFFF00"'
				--IF ISNULL(@curr_m_w3_tg, 0.00) = 0 SET @curr_m_w3_flag = ''
			END

			IF @i_count = 4
			BEGIN
			    --PRINT 'week4'
				SET @curr_m_w4_tg = @sum_target;
				SET @curr_m_w4_ac = @sum_actual;
				IF @curr_m_w4_ac < @curr_m_w4_tg*0.8 SET @curr_m_w4_flag	= 'bgcolor="#FF0000"' ELSE IF @curr_m_w4_ac >= @curr_m_w4_tg	SET @curr_m_w4_flag = 'bgcolor="#00FF00"' ELSE SET @curr_m_w4_flag = 'bgcolor="#FFFF00"'
				--IF ISNULL(@curr_m_w4_tg, 0.00) = 0 SET @curr_m_w4_flag = ''
			END

			IF @i_count = 5
			BEGIN
			    --PRINT 'week5'
				SET @curr_m_w5_tg = @sum_target;
				SET @curr_m_w5_ac = @sum_actual;
				IF @curr_m_w5_ac < @curr_m_w5_tg*0.8 SET @curr_m_w5_flag	= 'bgcolor="#FF0000"' ELSE IF @curr_m_w5_ac >= @curr_m_w5_tg	SET @curr_m_w5_flag = 'bgcolor="#00FF00"' ELSE SET @curr_m_w5_flag = 'bgcolor="#FFFF00"'
				--IF ISNULL(@curr_m_w5_tg, 0.00) = 0 SET @curr_m_w5_flag = ''
			END
			
			SET @i_count = @i_count + 1
			FETCH NEXT FROM db_cursor INTO @w_int, @sum_target, @sum_actual
		END 

	CLOSE db_cursor  
	DEALLOCATE db_cursor


	SELECT @full_month_tg = SUM(tbl.target), 
	@full_month_ac = SUM(tbl.new_actual),
	@full_month_dff = SUM(tbl.new_actual) - SUM(tbl.target)
	FROM (
	SELECT target,
	CASE WHEN w >= (SELECT w FROM crmrevo.BI.Mst_Calendar_Week WITH(NOLOCK) WHERE CAST(GETDATE() AS DATE) BETWEEN CAST(StartDate AS DATE) AND CAST(EndDate AS DATE)) THEN target ELSE actual END AS new_actual
	FROM #tbl_curr_q 
	WHERE m = DATEPART(MONTH, GETDATE()) ) AS tbl

	-- [5.1] Set Color
	IF @full_month_ac < @full_month_tg*0.8 SET @full_month_flag	= 'bgcolor="#FF0000"' ELSE IF @full_month_ac >= @full_month_tg	SET @full_month_flag = 'bgcolor="#00FF00"' ELSE SET @full_month_flag = 'bgcolor="#FFFF00"'
	--IF ISNULL(@full_month_tg, 0.00) = 0 SET @full_month_flag = ''

	-- Color
	-- Red -> bgcolor="#FF0000" 
	-- Green -> bgcolor="#00FF00"
	-- Yellow -> bgcolor="#FFFF00"
	-- Update Table 
	UPDATE dbo.crm_mail_ll_data
	SET curr_q_q1tg = ISNULL(@curr_q_q1tg, 0.00),
	curr_q_q2tg = ISNULL(@curr_q_q2tg, 0.00),
	curr_q_q3tg = ISNULL(@curr_q_q3tg, 0.00),
	curr_q_total = ISNULL(@curr_q_total, 0.00),
	--Section [2]
	qtd_curr_w_tg = ISNULL(@qtd_curr_w_tg, 0.00),
	qtd_curr_w_ac = ISNULL(@qtd_curr_w_ac, 0.00),
	qtd_curr_w_flag = ISNULL(@qtd_curr_w_flag, ''),
	qtd_curr_w_diff = ISNULL(@qtd_curr_w_diff, 0.00),
	--Section [3]
	qtg_val = ISNULL(@qtg_val, 0.00),
	--Section [4]
	curr_m_w1_tg = ISNULL(@curr_m_w1_tg, 0.00),
	curr_m_w1_ac = ISNULL(@curr_m_w1_ac, 0.00),
	curr_m_w1_flag = ISNULL(@curr_m_w1_flag, ''),
	curr_m_w2_tg = ISNULL(@curr_m_w2_tg, 0.00),
	curr_m_w2_ac = ISNULL(@curr_m_w2_ac, 0.00),
	curr_m_w2_flag = ISNULL(@curr_m_w2_flag, ''),
	curr_m_w3_tg = ISNULL(@curr_m_w3_tg, 0.00),
	curr_m_w3_ac = ISNULL(@curr_m_w3_ac, 0.00),
	curr_m_w3_flag = ISNULL(@curr_m_w3_flag, ''),
	curr_m_w4_tg = ISNULL(@curr_m_w4_tg, 0.00),
	curr_m_w4_ac = ISNULL(@curr_m_w4_ac, 0.00),
	curr_m_w4_flag = ISNULL(@curr_m_w4_flag, ''),
	curr_m_w5_tg = ISNULL(@curr_m_w5_tg, 0.00),
	curr_m_w5_ac = ISNULL(@curr_m_w5_ac, 0.00),
	curr_m_w5_flag = ISNULL(@curr_m_w5_flag, ''),
	--Section [5]
	full_month_tg = ISNULL(@full_month_tg, 0.00),
	full_month_ac = ISNULL(@full_month_ac, 0.00),
	full_month_flag = ISNULL(@full_month_flag, ''),
	full_month_dff = ISNULL(@full_month_dff, 0.00),
	modifyby = 'batch_mail_llbw_D',
	modifydate = GETDATE()
	WHERE subject_group = @sub_group
	AND ptype = @p_bg
	AND subject_type LIKE @sub_type + 'CD%'

	-- Update Total
	--Update Sumary Total
	SELECT @curr_q_q1tg     = SUM(curr_q_q1tg)
	,@curr_q_q2tg     = SUM(curr_q_q2tg)
	,@curr_q_q3tg     = SUM(curr_q_q3tg)
	,@curr_q_total    = SUM(curr_q_total)
	,@qtd_curr_w_tg   = SUM(qtd_curr_w_tg)
	,@qtd_curr_w_ac   = SUM(qtd_curr_w_ac)
	,@qtd_curr_w_diff = SUM(qtd_curr_w_diff)
	,@qtg_val         = SUM(qtg_val)
	,@curr_m_w1_tg    = SUM(curr_m_w1_tg)
	,@curr_m_w1_ac    = SUM(curr_m_w1_ac)
	,@curr_m_w2_tg    = SUM(curr_m_w2_tg)
	,@curr_m_w2_ac    = SUM(curr_m_w2_ac)
	,@curr_m_w3_tg    = SUM(curr_m_w3_tg)
	,@curr_m_w3_ac    = SUM(curr_m_w3_ac)
	,@curr_m_w4_tg    = SUM(curr_m_w4_tg)
	,@curr_m_w4_ac    = SUM(curr_m_w4_ac)
	,@curr_m_w5_tg    = SUM(curr_m_w5_tg)
	,@curr_m_w5_ac    = SUM(curr_m_w5_ac)
	,@full_month_tg   = SUM(full_month_tg)
	,@full_month_ac   = SUM(full_month_ac)
	,@full_month_dff  = SUM(full_month_dff)
	FROM dbo.crm_mail_ll_data WITH(NOLOCK)
	WHERE subject_no = 9 
	AND subject_type LIKE @sub_type + 'CD%'
	
	-- [2.1] Set Color
	IF @qtd_curr_w_ac < @qtd_curr_w_tg*0.8 SET @qtd_curr_w_flag	= 'bgcolor="#FF0000"' ELSE IF @qtd_curr_w_ac >= @qtd_curr_w_tg	SET @qtd_curr_w_flag = 'bgcolor="#00FF00"' ELSE SET @qtd_curr_w_flag = 'bgcolor="#FFFF00"'
	--IF ISNULL(@qtd_curr_w_tg, 0.00) = 0 SET @qtd_curr_w_flag = ''

	-- [4.1-w1] Set Color
	IF @curr_m_w1_ac < @curr_m_w1_tg*0.8 SET @curr_m_w1_flag	= 'bgcolor="#FF0000"' ELSE IF @curr_m_w1_ac >= @curr_m_w1_tg	SET @curr_m_w1_flag = 'bgcolor="#00FF00"' ELSE SET @curr_m_w1_flag = 'bgcolor="#FFFF00"'
	--IF ISNULL(@curr_m_w1_tg, 0.00) = 0 SET @curr_m_w1_flag = ''

	-- [4.1-w2] Set Color
	IF @curr_m_w2_ac < @curr_m_w2_tg*0.8 SET @curr_m_w2_flag	= 'bgcolor="#FF0000"' ELSE IF @curr_m_w2_ac >= @curr_m_w2_tg	SET @curr_m_w2_flag = 'bgcolor="#00FF00"' ELSE SET @curr_m_w2_flag = 'bgcolor="#FFFF00"'
	--IF ISNULL(@curr_m_w2_tg, 0.00) = 0 SET @curr_m_w2_flag = ''

	-- [4.1-w3] Set Color
	IF @curr_m_w3_ac < @curr_m_w3_tg*0.8 SET @curr_m_w3_flag	= 'bgcolor="#FF0000"' ELSE IF @curr_m_w3_ac >= @curr_m_w3_tg	SET @curr_m_w3_flag = 'bgcolor="#00FF00"' ELSE SET @curr_m_w3_flag = 'bgcolor="#FFFF00"'
	--IF ISNULL(@curr_m_w3_tg, 0.00) = 0 SET @curr_m_w3_flag = ''

	-- [4.1-w4] Set Color
	IF @curr_m_w4_ac < @curr_m_w4_tg*0.8 SET @curr_m_w4_flag	= 'bgcolor="#FF0000"' ELSE IF @curr_m_w4_ac >= @curr_m_w4_tg	SET @curr_m_w4_flag = 'bgcolor="#00FF00"' ELSE SET @curr_m_w4_flag = 'bgcolor="#FFFF00"'
	--IF ISNULL(@curr_m_w4_tg, 0.00) = 0 SET @curr_m_w4_flag = ''

	-- [4.1-w5] Set Color
	IF @curr_m_w5_ac < @curr_m_w5_tg*0.8 SET @curr_m_w5_flag	= 'bgcolor="#FF0000"' ELSE IF @curr_m_w5_ac >= @curr_m_w5_tg	SET @curr_m_w5_flag = 'bgcolor="#00FF00"' ELSE SET @curr_m_w5_flag = 'bgcolor="#FFFF00"'
	--IF ISNULL(@curr_m_w5_tg, 0.00) = 0 SET @curr_m_w5_flag = ''

	-- [5.1] Set Color
	IF @full_month_ac < @full_month_tg*0.8 SET @full_month_flag	= 'bgcolor="#FF0000"' ELSE IF @full_month_ac >= @full_month_tg	SET @full_month_flag = 'bgcolor="#00FF00"' ELSE SET @full_month_flag = 'bgcolor="#FFFF00"'
	--IF ISNULL(@full_month_tg, 0.00) = 0 SET @full_month_flag = ''

	-- Update Table Total
	UPDATE dbo.crm_mail_ll_data
	SET curr_q_q1tg = ISNULL(@curr_q_q1tg, 0.00),
	curr_q_q2tg = ISNULL(@curr_q_q2tg, 0.00),
	curr_q_q3tg = ISNULL(@curr_q_q3tg, 0.00),
	curr_q_total = ISNULL(@curr_q_total, 0.00),
	--Section [2]
	qtd_curr_w_tg = ISNULL(@qtd_curr_w_tg, 0.00),
	qtd_curr_w_ac = ISNULL(@qtd_curr_w_ac, 0.00),
	qtd_curr_w_flag = ISNULL(@qtd_curr_w_flag, ''),
	qtd_curr_w_diff = ISNULL(@qtd_curr_w_diff, 0.00),
	--Section [3]
	qtg_val = ISNULL(@qtg_val, 0.00),
	--Section [4]
	curr_m_w1_tg = ISNULL(@curr_m_w1_tg, 0.00),
	curr_m_w1_ac = ISNULL(@curr_m_w1_ac, 0.00),
	curr_m_w1_flag = ISNULL(@curr_m_w1_flag, ''),
	curr_m_w2_tg = ISNULL(@curr_m_w2_tg, 0.00),
	curr_m_w2_ac = ISNULL(@curr_m_w2_ac, 0.00),
	curr_m_w2_flag = ISNULL(@curr_m_w2_flag, ''),
	curr_m_w3_tg = ISNULL(@curr_m_w3_tg, 0.00),
	curr_m_w3_ac = ISNULL(@curr_m_w3_ac, 0.00),
	curr_m_w3_flag = ISNULL(@curr_m_w3_flag, ''),
	curr_m_w4_tg = ISNULL(@curr_m_w4_tg, 0.00),
	curr_m_w4_ac = ISNULL(@curr_m_w4_ac, 0.00),
	curr_m_w4_flag = ISNULL(@curr_m_w4_flag, ''),
	curr_m_w5_tg = ISNULL(@curr_m_w5_tg, 0.00),
	curr_m_w5_ac = ISNULL(@curr_m_w5_ac, 0.00),
	curr_m_w5_flag = ISNULL(@curr_m_w5_flag, ''),
	--Section [5]
	full_month_tg = ISNULL(@full_month_tg, 0.00),
	full_month_ac = ISNULL(@full_month_ac, 0.00),
	full_month_flag = ISNULL(@full_month_flag, ''),
	full_month_dff = ISNULL(@full_month_dff, 0.00),
	modifyby = 'batch_mail_llbw_D',
	modifydate = GETDATE()
	WHERE subject_no = 9 
	AND subject_type = @sub_type



go

