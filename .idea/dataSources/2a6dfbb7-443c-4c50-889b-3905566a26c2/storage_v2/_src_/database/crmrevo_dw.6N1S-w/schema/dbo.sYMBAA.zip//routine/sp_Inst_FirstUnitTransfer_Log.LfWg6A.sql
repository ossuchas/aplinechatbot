

CREATE PROCEDURE [dbo].[sp_Inst_FirstUnitTransfer_Log]
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @i_count INT;
    ---
    DECLARE @ProjectID UNIQUEIDENTIFIER;
    DECLARE @ProjectNo VARCHAR(50);
    DECLARE @FirstUnitTransferDate DATETIME2(7);

    DECLARE db_cursor CURSOR FOR

    --Check โอนห้องแรก
    SELECT p.ID AS ProjectID,
           p.ProjectNo
    FROM crmrevo.PRJ.Project p WITH (NOLOCK)
    WHERE 1 = 1
          AND p.ID NOT IN (
                              SELECT ProjectID
                              FROM dbo.log_SendMail_FistLast_Project WITH (NOLOCK)
                              WHERE FirstUnitTransferDate IS NOT NULL
                                    AND FirstUnit_SendMailFlag = 'Y'
                          )
          AND p.IsDeleted = 0
          AND p.IsActive = 1
          AND p.ProjectNameTH NOT LIKE '%ระงับ%'
          --AND p.ProjectNo = '60016'
          AND ISNULL(p.FirstUnitTransferDate, '') = '';

    SET @i_count = 1;
    OPEN db_cursor;
    FETCH NEXT FROM db_cursor
    INTO @ProjectID,
         @ProjectNo;

    WHILE @@FETCH_STATUS = 0
    BEGIN

        --Check Existing Table Actual Transfer
        IF EXISTS (SELECT 1 FROM dbo.vw_ActualTransfer WITH (NOLOCK) WHERE ProjectID = @ProjectID AND ProjectID NOT IN (SELECT ProjectID FROM dbo.log_SendMail_FistLast_Project WITH(NOLOCK)))
        BEGIN

            --Get Min actual Transfer date
            SELECT @FirstUnitTransferDate = MIN(ActualTransferDate)
            FROM dbo.vw_ActualTransfer WITH (NOLOCK)
            WHERE ProjectID = @ProjectID;

            PRINT 'Found vw_ActualTransfer Existing... FirstUnitTransferDate = '
                  + CAST(@FirstUnitTransferDate AS VARCHAR(50));

            INSERT INTO dbo.log_SendMail_FistLast_Project
            (
                ProjectID, ProjectNo, FirstUnitTransferDate, LasttUnitTransferDate,
                FirstUnit_SendMailFlag, FirstUnit_SendMailDate, FirstUnit_SendMailBy,
                LastUnit_SendMailFlag, LastUnit_SendMailDate, LasttUnit_SendMailBy
            )
            VALUES
            (@ProjectID, @ProjectNo, @FirstUnitTransferDate, NULL, 'N', NULL, '', 'N', NULL, '');
        END;
        ELSE
        BEGIN
            PRINT 'Not Found Existing vw_ActualTransfer Table... ' + CAST(@i_count AS VARCHAR(3)) + '|'
                  + CAST(@ProjectID AS VARCHAR(50));
        END;

        SET @i_count += 1;

        FETCH NEXT FROM db_cursor
        INTO @ProjectID,
             @ProjectNo;

    END;

    CLOSE db_cursor;
    DEALLOCATE db_cursor;


END;



go

