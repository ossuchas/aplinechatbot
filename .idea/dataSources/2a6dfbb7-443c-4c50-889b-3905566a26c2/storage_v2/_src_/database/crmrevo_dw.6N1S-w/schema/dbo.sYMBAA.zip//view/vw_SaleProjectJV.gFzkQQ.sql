CREATE VIEW [dbo].[vw_SaleProjectJV]
AS
SELECT p.ID AS ProjectID,
       p.ProjectNo,
       p.ProjectNameTH,
       SUBSTRING(p.[Group], 1, 1) AS BG,
       j.BU_CODE,
       j.BU_DESC,
       j.PERSON_CODE,
       j.PERSON_DESC,
       j.PROJECT_CODE,
       j.PROJECT_NAME,
       j.SORTKEY
FROM [DBLINK_SVR_BI].AP_DW.dbo.PROJECT_DIM_C_JV j WITH (NOLOCK),
     crmrevo.PRJ.Project p WITH (NOLOCK)
WHERE 1 = 1
      AND j.PROJECT_CODE = p.ProjectNo;



go

