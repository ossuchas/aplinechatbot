
CREATE PROCEDURE [dbo].[sp_proc_mail_est_reve_totl]
As

    SET NOCOUNT ON;

	--Get Lead Lag Target
	IF (OBJECT_ID('tempdb..#temp_tg') IS NOT NULL)
    DROP TABLE #temp_tg;

	SELECT a.PType, CASE WHEN a.isJVStatus = 0 THEN 'AP' ELSE 'JV' END AS AP_JV, SUM(a.Target) AS Target
	INTO #temp_tg
	FROM (
	SELECT SUBSTRING(p.[Group],1,1) AS PType, a.ProjectID, a.Target,
	(SELECT COUNT(*) FROM crmrevo.PRJ.TransferProjectJV t WITH(NOLOCK) 
	WHERE CAST(t.EffectiveDate AS DATE) <= CAST(GETDATE() AS DATE)
	AND (t.ExpiredDate IS NULL OR CAST(t.ExpiredDate AS DATE) >= CAST(GETDATE() AS DATE)) 
	AND t.ProductID = p.ProjectNo) AS isJVStatus
	FROM dbo.RPT_LeadIndicator a WITH(NOLOCK), crmrevo.PRJ.Project p WITH(NOLOCK)
	WHERE a.y = DATEPART(YEAR, GETDATE())
	AND a.q = DATEPART(QUARTER, GETDATE()) 
	AND a.RecType = 'TransferAmount'
	AND a.ProjectID = p.ProjectNo
	AND p.IsDeleted = 0
	AND p.IsActive = 1 ) AS a
	GROUP BY a.PType,CASE WHEN a.isJVStatus = 0 THEN 'AP' ELSE 'JV' END
	ORDER BY 1

	-- Update SDH
	UPDATE dbo.crm_mail_est_reve_totl
	SET ll_curr_q_tg = ISNULL((SELECT SUM(Target) FROM #temp_tg WHERE PType = '1' AND AP_JV = 'AP'),0),
	qtd_ac = ISNULL((SELECT SUM(qtd_curr_ac) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 4),0),
	est_curr_totl = ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 4),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 4),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 4),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 4),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 4),0),
	qtd_est_totl = ISNULL((SELECT SUM(qtd_curr_ac) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 4),0)
	+ ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 4),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 4),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 4),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 4),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 4),0)
	WHERE seqn_no = 1;

	-- Update TH
	UPDATE dbo.crm_mail_est_reve_totl
	SET ll_curr_q_tg = ISNULL((SELECT SUM(Target) FROM #temp_tg WHERE PType = '2' AND AP_JV = 'AP'),0),
	qtd_ac = ISNULL((SELECT SUM(qtd_curr_ac) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 5),0),
	est_curr_totl = ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 5),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 5),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 5),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 5),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 5),0),
	qtd_est_totl = ISNULL((SELECT SUM(qtd_curr_ac) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 5),0)
	+ ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 5),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 5),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 5),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 5),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no = 5),0)
	WHERE seqn_no = 2;

	-- Update CD_AP
	UPDATE dbo.crm_mail_est_reve_totl
	SET ll_curr_q_tg = ISNULL((SELECT SUM(Target) FROM #temp_tg WHERE PType IN ('3','4') AND AP_JV = 'AP'),0),
	qtd_ac = ISNULL((SELECT SUM(qtd_curr_ac) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (6,7)),0),
	est_curr_totl = ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (6,7)),0),
	qtd_est_totl = ISNULL((SELECT SUM(qtd_curr_ac) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (6,7)),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (6,7)),0)
	WHERE seqn_no = 3;

	-- Update CD_JV
	UPDATE dbo.crm_mail_est_reve_totl
	SET ll_curr_q_tg = ISNULL((SELECT SUM(Target) FROM #temp_tg WHERE PType IN ('3','4') AND AP_JV = 'JV'),0),
	qtd_ac = ISNULL((SELECT SUM(qtd_curr_ac) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (8,9)),0),
	est_curr_totl = ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (8,9)),0),
	qtd_est_totl = ISNULL((SELECT SUM(qtd_curr_ac) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d1) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d2) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d3) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d4) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	+ ISNULL((SELECT SUM(est_curr_d5) FROM dbo.crm_mail_est_reve WITH(NOLOCK) WHERE seqn_no IN (8,9)),0)
	WHERE seqn_no = 4;

	-- Update AP_EXCL_JV
	UPDATE dbo.crm_mail_est_reve_totl
	SET ll_curr_q_tg = ISNULL((SELECT SUM(ll_curr_q_tg) FROM dbo.crm_mail_est_reve_totl WITH(NOLOCK) WHERE seqn_no IN (1,2,3)),0),
	qtd_ac = ISNULL((SELECT SUM(qtd_ac) FROM dbo.crm_mail_est_reve_totl WITH(NOLOCK) WHERE seqn_no IN (1,2,3)),0),
	est_curr_totl = ISNULL((SELECT SUM(est_curr_totl) FROM dbo.crm_mail_est_reve_totl WITH(NOLOCK) WHERE seqn_no IN (1,2,3)),0),
	qtd_est_totl = ISNULL((SELECT SUM(qtd_ac) FROM dbo.crm_mail_est_reve_totl WITH(NOLOCK) WHERE seqn_no IN (1,2,3)),0)
	+ ISNULL((SELECT SUM(est_curr_totl) FROM dbo.crm_mail_est_reve_totl WITH(NOLOCK) WHERE seqn_no IN (1,2,3)),0)
	WHERE seqn_no = 5;

	-- Update JV_100
	UPDATE dbo.crm_mail_est_reve_totl
	SET ll_curr_q_tg = ISNULL((SELECT SUM(ll_curr_q_tg) FROM dbo.crm_mail_est_reve_totl WITH(NOLOCK) WHERE seqn_no IN (4)),0),
	qtd_ac = ISNULL((SELECT SUM(qtd_ac) FROM dbo.crm_mail_est_reve_totl WITH(NOLOCK) WHERE seqn_no IN (4)),0),
	est_curr_totl = ISNULL((SELECT SUM(est_curr_totl) FROM dbo.crm_mail_est_reve_totl WITH(NOLOCK) WHERE seqn_no IN (4)),0),
	qtd_est_totl = ISNULL((SELECT SUM(qtd_ac) FROM dbo.crm_mail_est_reve_totl WITH(NOLOCK) WHERE seqn_no IN (4)),0)
	+ ISNULL((SELECT SUM(est_curr_totl) FROM dbo.crm_mail_est_reve_totl WITH(NOLOCK) WHERE seqn_no IN (4)),0)
	WHERE seqn_no = 6;

	-- Update AP_JV_TOTL
	UPDATE dbo.crm_mail_est_reve_totl
	SET ll_curr_q_tg = ISNULL((SELECT SUM(ll_curr_q_tg) FROM dbo.crm_mail_est_reve_totl WITH(NOLOCK) WHERE seqn_no IN (5,6)),0),
	qtd_ac = ISNULL((SELECT SUM(qtd_ac) FROM dbo.crm_mail_est_reve_totl WITH(NOLOCK) WHERE seqn_no IN (5,6)),0),
	est_curr_totl = ISNULL((SELECT SUM(est_curr_totl) FROM dbo.crm_mail_est_reve_totl WITH(NOLOCK) WHERE seqn_no IN (5,6)),0),
	qtd_est_totl = ISNULL((SELECT SUM(qtd_ac) FROM dbo.crm_mail_est_reve_totl WITH(NOLOCK) WHERE seqn_no IN (5,6)),0)
	+ ISNULL((SELECT SUM(est_curr_totl) FROM dbo.crm_mail_est_reve_totl WITH(NOLOCK) WHERE seqn_no IN (5,6)),0)
	WHERE seqn_no IN (7,10);

	--Final Balance Diff
	UPDATE dbo.crm_mail_est_reve_totl
	SET qtd_est_diff_ll_curr_q_tg = ISNULL(qtd_est_totl,0) - ISNULL(ll_curr_q_tg,0),
	modifyby = 'batch_reve_totl',
	modifydate = GETDATE()



go

