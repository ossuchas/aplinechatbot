CREATE FUNCTION [dbo].[fn_AP_BI_GetLetterAmountDays_Revo]
(	
	@ContractNumber nvarchar(20)	
	
)
RETURNS int
AS
BEGIN
	
	DECLARE @Amount int
	DECLARE @SumAmount int
	set @Amount =0
	set @SumAmount =0
	


	IF ISNULL(@ContractNumber,'') <> ''
	begin
	DECLARE db_cursor CURSOR FOR

	Select 	isnull(Datediff(day,ResponseDate,AppointmentTransferDate),0) as AmountDays	
	From  [crmrevo].let.TransferLetter as Letter With(NoLock)
	INNER JOIN [crmrevo].mst.MasterCenter m With(NoLock) ON m.id = Letter.TransferLetterTypeMasterCenterID
	LEFT JOIN [crmrevo].sal.Agreement a With(NoLock) ON Letter.AgreementID = a.id AND a.IsDeleted = 0
	where a.AgreementNo = @ContractNumber AND Letter.IsDeleted = 0
	Order by m.[Key] desc
	
	OPEN db_cursor   
	FETCH NEXT FROM db_cursor INTO @Amount
	
	WHILE @@FETCH_STATUS = 0 
	BEGIN 
		if @Amount > 0
			set @SumAmount = @SumAmount+@Amount
		FETCH NEXT FROM db_cursor INTO @Amount
	End
	
	CLOSE db_cursor 
	DEALLOCATE db_cursor

	END 
	ELSE 
	SET @Amount = 0
	--(วันที่ส่ง)(ตอบรับ วันที่ตอบรับ)
	
	
	
	
	

	
	--DECLARE db_cursor CURSOR FOR  
	
 --   Select RespondDate
	--From [192.168.0.75].db_iconcrm_fusion.dbo.ICON_EntForms_NotificationTranfer as Letter
	--where Letter.ContractNumber = @ContractNumber
	--Order by Letter.timeofNotification desc
    
 --   OPEN db_cursor   
	--FETCH NEXT FROM db_cursor INTO @RespondDate

	--WHILE @@FETCH_STATUS = 0   
	--BEGIN   
	--   if @TranferDate is not null 
	--	begin
	--		if @RespondDate is not null
	--			SET @AmountDay = @AmountDay +	Datediff(day,@RespondDate,@TranferDate)		
	--	end
	    
      
 --      FETCH NEXT FROM db_cursor INTO @RespondDate
	--END   

	--CLOSE db_cursor   
	--DEALLOCATE db_cursor
	
	
	--if @AmountDay >0
	--	set @StrAmountDay =CONVERT(VARCHAR(100),@AmountDay)
	--else
	--	set @StrAmountDay =' - '
		
  
	
	RETURN @SumAmount
END



go

