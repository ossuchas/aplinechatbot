
CREATE PROCEDURE [dbo].[sp_proc_mail_llbw_D_TH]
 @p_parm AS INT,
 @p_bg AS VARCHAR(2),
 @p_th_option AS VARCHAR(10)
As

    SET NOCOUNT ON;
	-- Parameter Description
	--##### p_parm
	-- 1 : Pre-sales
	-- 2 : Walk
	-- 3 : 2nd Walk
	-- 4 : Transfer
	-- 5 : ห้องผ่าน QC
	-- 6 : ลูกค้าเข้าตรวจ
	-- 7 : ลูกค้ารับห้อง
	-- 8 : Condo Transfer
	-- 9 : JV Projects
	--##### p_bg
	-- 1 : BG1
	-- 2 : BG2
	-- 3 : CD1
	-- 4 : CD2
	--##### p_th_option
	-- BKM : บ้านกลางเมือง
	-- Pleno : Brand Pleno

	DECLARE @curr_q_q1tg		AS FLOAT;
	DECLARE @curr_q_q2tg		AS FLOAT;
	DECLARE @curr_q_q3tg		AS FLOAT;
	DECLARE @curr_q_total		AS FLOAT;

	DECLARE @qtd_curr_w_tg		AS FLOAT;
	DECLARE @qtd_curr_w_ac		AS FLOAT;
	DECLARE @qtd_curr_w_flag		AS VARCHAR(50);
	DECLARE @qtd_curr_w_diff		AS FLOAT;
	
	DECLARE @qtg_val		AS FLOAT;
	
	DECLARE @curr_m_w1_tg		AS FLOAT;
	DECLARE @curr_m_w1_ac		AS FLOAT;
	DECLARE @curr_m_w1_flag		AS VARCHAR(50);
	DECLARE @curr_m_w2_tg		AS FLOAT;
	DECLARE @curr_m_w2_ac		AS FLOAT;
	DECLARE @curr_m_w2_flag		AS VARCHAR(50);
	DECLARE @curr_m_w3_tg		AS FLOAT;
	DECLARE @curr_m_w3_ac		AS FLOAT;
	DECLARE @curr_m_w3_flag		AS VARCHAR(50);
	DECLARE @curr_m_w4_tg		AS FLOAT;
	DECLARE @curr_m_w4_ac		AS FLOAT;
	DECLARE @curr_m_w4_flag		AS VARCHAR(50);
	DECLARE @curr_m_w5_tg		AS FLOAT;
	DECLARE @curr_m_w5_ac		AS FLOAT;
	DECLARE @curr_m_w5_flag		AS VARCHAR(50);

	DECLARE @full_month_tg		AS FLOAT;
	DECLARE @full_month_ac		AS FLOAT;
	DECLARE @full_month_flag		AS VARCHAR(50);
	DECLARE @full_month_dff		AS FLOAT;

    DECLARE @sub_group AS VARCHAR(255);
	DECLARE @rectype AS VARCHAR(255);

	DECLARE @i_count AS INT;
	DECLARE @w_text AS VARCHAR(10);
	DECLARE @w_int AS INT;
	DECLARE @sum_target AS FLOAT;
	DECLARE @sum_actual AS FLOAT;

	IF @p_parm = 1 BEGIN SET @sub_group = 'PRESALE'; SET @rectype = 'NetPresalesAmount'; END;
	IF @p_parm = 2 BEGIN SET @sub_group = 'WALK'; SET @rectype = 'Walk'; END;
	IF @p_parm = 3 BEGIN SET @sub_group = 'WALK2'; SET @rectype = 'Walk2';	   END;
	IF @p_parm = 4 BEGIN SET @sub_group = 'TRANSFER'; SET @rectype = 'TransferAmount';   END;
	IF @p_parm = 5 BEGIN SET @sub_group = 'QCPASS';	SET @rectype = 'QCPass';   END;
	IF @p_parm = 6 BEGIN SET @sub_group = 'CHECKUNIT'; SET @rectype = 'CheckUnit';  END;
	IF @p_parm = 7 BEGIN SET @sub_group = 'ACCEPTUNIT'; SET @rectype = 'AcceptUnit'; END;
	IF @p_parm = 8 BEGIN SET @sub_group = 'CDTRANSFER'; SET @rectype = 'TransferAmount'; END;
	IF @p_parm = 9 BEGIN SET @sub_group = 'JVPROJECT'; SET @rectype = 'xxx';  END;
	
	IF (OBJECT_ID('tempdb..#tbl_curr_q') IS NOT NULL) DROP TABLE #tbl_curr_q

	SELECT SUBSTRING(b.[Group],1,1) AS PType, a.q, 
	CASE WHEN a.q = 1 THEN 0 
	WHEN a.q = 2 THEN 1
	WHEN a.q = 3 THEN 2
	WHEN a.q = 4 THEN 3
	END AS minus,
	--CASE WHEN b.Project LIKE '%บ้านกลางเมือง%' THEN 'BKM' WHEN UPPER(b.Project) LIKE '%PLENO%' THEN 'PLENO' ELSE 'BKM' END AS project_type,
	a.m, a.w, a.RecType, a.SortKey, SUM(a.Actual) actual, SUM(a.Target) AS target
	INTO #tbl_curr_q
    FROM dbo.RPT_LeadIndicator a WITH(NOLOCK)
        LEFT JOIN crmrevo.PRJ.Project b WITH(NOLOCK) ON a.ProjectID = b.ProjectNo
    WHERE a.Y = DATEPART(YEAR, GETDATE())
          AND q = DATEPART(QUARTER,GETDATE())
		  AND a.RecType = @rectype
		  AND b.IsActive = 1
		  AND b.IsDeleted = 0
		  --AND (b.Project LIKE '%บ้านกลางเมือง%' OR UPPER(b.Project) LIKE '%PLENO%')
		  AND SUBSTRING(b.[Group],1,1) = @p_bg
		  --AND CASE WHEN b.Project LIKE '%บ้านกลางเมือง%' THEN 'BKM' WHEN UPPER(b.Project) LIKE '%PLENO%' THEN 'PLENO' ELSE 'BKM' END = @p_th_option
		  AND a.ProjectID IN (SELECT DISTINCT RTRIM(LTRIM(PROJECT_CODE)) 
			FROM [DBLINK_SVR_BI].AP_DW.dbo.PROJECT_D_C_BRAND
			WHERE BU_CODE IN( 2,3) AND UPPER(BRAND_NAME) = @p_th_option)  --'PLENO',--BKM
    GROUP BY SUBSTRING(b.[Group],1,1), a.q, a.m, a.w, a.RecType, a.SortKey
	--,CASE WHEN b.Project LIKE '%บ้านกลางเมือง%' THEN 'BKM' WHEN UPPER(b.Project) LIKE '%PLENO%' THEN 'PLENO' ELSE 'BKM' END
    ORDER BY a.SortKey;

	-- [1] Section Current Quarter
	SELECT @curr_q_q1tg = SUM(target) FROM #tbl_curr_q WHERE m-(3*minus)=1 -- First Quarter
	SELECT @curr_q_q2tg = SUM(target) FROM #tbl_curr_q WHERE m-(3*minus)=2 -- Second Quarter
	SELECT @curr_q_q3tg = SUM(target) FROM #tbl_curr_q WHERE m-(3*minus)=3 -- Third Quarter

	SET @curr_q_total = ISNULL(@curr_q_q1tg,0.00) + ISNULL(@curr_q_q2tg,0.00) + ISNULL(@curr_q_q3tg,0.00)

	-- [2] Section QTD Current Week	
	--SELECT  @qtd_curr_w_tg = SUM(target), @qtd_curr_w_ac = SUM(actual), @qtd_curr_w_diff = SUM(actual)-SUM(target) FROM #tbl_curr_q
	
	  SELECT @qtd_curr_w_tg = SUM(target), 
	  @qtd_curr_w_ac = SUM(actual),  
	  @qtd_curr_w_diff = SUM(actual)-SUM(target) 
	  FROM #tbl_curr_q 
	  WHERE 1=1
      AND Q = DATEPART(QUARTER, GETDATE())
	  AND W < ( SELECT W FROM crmrevo.BI.Mst_Calendar_Week WITH (NOLOCK) WHERE CAST(GETDATE() AS DATE) BETWEEN CAST(StartDate AS DATE) AND CAST(EndDate AS DATE))

	-- [2.1] Set Color
	IF @qtd_curr_w_ac < @qtd_curr_w_tg*0.8 SET @qtd_curr_w_flag	= 'bgcolor="#FF0000"' ELSE IF @qtd_curr_w_ac >= @qtd_curr_w_tg	SET @qtd_curr_w_flag = 'bgcolor="#00FF00"' ELSE SET @qtd_curr_w_flag = 'bgcolor="#FFFF00"'
	--IF ISNULL(@qtd_curr_w_tg, 0.00) = 0 SET @qtd_curr_w_flag = ''

	-- [3] QTG
	SET @qtg_val = ISNULL(@curr_q_total,0.00) - ISNULL(@qtd_curr_w_ac,0.00)

	-- [4] for each week by month
	SET @i_count = 1
	DECLARE db_cursor CURSOR
	FOR
		SELECT w, SUM(target), SUM(actual) FROM #tbl_curr_q WHERE m = DATEPART(MONTH, GETDATE()) GROUP BY w order by w

	OPEN db_cursor  
	FETCH NEXT FROM db_cursor INTO @w_int, @sum_target, @sum_actual

	WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @i_count = 1
			BEGIN
			    --PRINT 'week1'
				SET @curr_m_w1_tg = @sum_target;
				SET @curr_m_w1_ac = @sum_actual;
				SET @curr_m_w1_flag = 'N'
				
				IF @curr_m_w1_ac < @curr_m_w1_tg*0.8 SET @curr_m_w1_flag	= 'bgcolor="#FF0000"' ELSE IF @curr_m_w1_ac >= @curr_m_w1_tg	SET @curr_m_w1_flag = 'bgcolor="#00FF00"' ELSE SET @curr_m_w1_flag = 'bgcolor="#FFFF00"'
				--IF ISNULL(@curr_m_w1_tg, 0.00) = 0 SET @curr_m_w1_flag = ''
			END

			IF @i_count = 2
			BEGIN
				--PRINT 'week2'
				SET @curr_m_w2_tg = @sum_target;
				SET @curr_m_w2_ac = @sum_actual;
				IF @curr_m_w2_ac < @curr_m_w2_tg*0.8 SET @curr_m_w2_flag	= 'bgcolor="#FF0000"' ELSE IF @curr_m_w2_ac >= @curr_m_w2_tg	SET @curr_m_w2_flag = 'bgcolor="#00FF00"' ELSE SET @curr_m_w2_flag = 'bgcolor="#FFFF00"'
				--IF ISNULL(@curr_m_w2_tg, 0.00) = 0 SET @curr_m_w2_flag = ''
			END
            
			IF @i_count = 3 
			BEGIN
			    --PRINT 'week3'
				SET @curr_m_w3_tg = @sum_target;
				SET @curr_m_w3_ac = @sum_actual;
				IF @curr_m_w3_ac < @curr_m_w3_tg*0.8 SET @curr_m_w3_flag	= 'bgcolor="#FF0000"' ELSE IF @curr_m_w3_ac >= @curr_m_w3_tg	SET @curr_m_w3_flag = 'bgcolor="#00FF00"' ELSE SET @curr_m_w3_flag = 'bgcolor="#FFFF00"'
				--IF ISNULL(@curr_m_w3_tg, 0.00) = 0 SET @curr_m_w3_flag = ''
			END

			IF @i_count = 4
			BEGIN
			    --PRINT 'week4'
				SET @curr_m_w4_tg = @sum_target;
				SET @curr_m_w4_ac = @sum_actual;
				IF @curr_m_w4_ac < @curr_m_w4_tg*0.8 SET @curr_m_w4_flag	= 'bgcolor="#FF0000"' ELSE IF @curr_m_w4_ac >= @curr_m_w4_tg	SET @curr_m_w4_flag = 'bgcolor="#00FF00"' ELSE SET @curr_m_w4_flag = 'bgcolor="#FFFF00"'
				--IF ISNULL(@curr_m_w4_tg, 0.00) = 0 SET @curr_m_w4_flag = ''
			END

			IF @i_count = 5
			BEGIN
			    --PRINT 'week5'
				SET @curr_m_w5_tg = @sum_target;
				SET @curr_m_w5_ac = @sum_actual;
				IF @curr_m_w5_ac < @curr_m_w5_tg*0.8 SET @curr_m_w5_flag	= 'bgcolor="#FF0000"' ELSE IF @curr_m_w5_ac >= @curr_m_w5_tg	SET @curr_m_w5_flag = 'bgcolor="#00FF00"' ELSE SET @curr_m_w5_flag = 'bgcolor="#FFFF00"'
				--IF ISNULL(@curr_m_w5_tg, 0.00) = 0 SET @curr_m_w5_flag = ''
			END
			
			SET @i_count = @i_count + 1
			FETCH NEXT FROM db_cursor INTO @w_int, @sum_target, @sum_actual
		END 

	CLOSE db_cursor  
	DEALLOCATE db_cursor

	-- [5] Full Current Month
	--SELECT @full_month_tg = SUM(target), @full_month_ac = SUM(actual), @full_month_dff = SUM(actual)-SUM(target) FROM #tbl_curr_q WHERE m = DATEPART(MONTH, GETDATE())
	
	--Modified by Suchat S. 2020-01-29 for change Sum Full Month actual before current week and sum target this week
	--SELECT @full_month_tg = SUM(target), 
	--@full_month_ac = SUM(CASE WHEN actual = 0 THEN target ELSE actual END), 
	--@full_month_dff = SUM(CASE WHEN actual = 0 THEN target ELSE actual END) - SUM(target)
	--FROM #tbl_curr_q 
	--WHERE m = DATEPART(MONTH, GETDATE())

	SELECT @full_month_tg = SUM(tbl.target), 
	@full_month_ac = SUM(tbl.new_actual),
	@full_month_dff = SUM(tbl.new_actual) - SUM(tbl.target)
	FROM (
	SELECT target,
	CASE WHEN w >= (SELECT w FROM crmrevo.BI.Mst_Calendar_Week WITH(NOLOCK) WHERE CAST(GETDATE() AS DATE) BETWEEN CAST(StartDate AS DATE) AND CAST(EndDate AS DATE)) THEN target ELSE actual END AS new_actual
	FROM #tbl_curr_q 
	WHERE m = DATEPART(MONTH, GETDATE()) ) AS tbl

	-- [5.1] Set Color
	IF @full_month_ac < @full_month_tg*0.8 SET @full_month_flag	= 'bgcolor="#FF0000"' ELSE IF @full_month_ac >= @full_month_tg	SET @full_month_flag = 'bgcolor="#00FF00"' ELSE SET @full_month_flag = 'bgcolor="#FFFF00"'
	--IF ISNULL(@full_month_tg, 0.00) = 0 SET @full_month_flag = ''

	-- Red -> bgcolor="#FF0000"
	-- Green -> bgcolor="#00FF00"
	-- Yellow -> bgcolor="#FFFF00"

	-- Update Table 
	UPDATE dbo.crm_mail_ll_data
	SET curr_q_q1tg = ISNULL(@curr_q_q1tg, 0.00),
	curr_q_q2tg = ISNULL(@curr_q_q2tg, 0.00),
	curr_q_q3tg = ISNULL(@curr_q_q3tg, 0.00),
	curr_q_total = ISNULL(@curr_q_total, 0.00),
	--Section [2]
	qtd_curr_w_tg = ISNULL(@qtd_curr_w_tg, 0.00),
	qtd_curr_w_ac = ISNULL(@qtd_curr_w_ac, 0.00),
	qtd_curr_w_flag = ISNULL(@qtd_curr_w_flag, ''),
	qtd_curr_w_diff = ISNULL(@qtd_curr_w_diff, 0.00),
	--Section [3]
	qtg_val = ISNULL(@qtg_val, 0.00),
	--Section [4]
	curr_m_w1_tg = ISNULL(@curr_m_w1_tg, 0.00),
	curr_m_w1_ac = ISNULL(@curr_m_w1_ac, 0.00),
	curr_m_w1_flag = ISNULL(@curr_m_w1_flag, ''),
	curr_m_w2_tg = ISNULL(@curr_m_w2_tg, 0.00),
	curr_m_w2_ac = ISNULL(@curr_m_w2_ac, 0.00),
	curr_m_w2_flag = ISNULL(@curr_m_w2_flag, ''),
	curr_m_w3_tg = ISNULL(@curr_m_w3_tg, 0.00),
	curr_m_w3_ac = ISNULL(@curr_m_w3_ac, 0.00),
	curr_m_w3_flag = ISNULL(@curr_m_w3_flag, ''),
	curr_m_w4_tg = ISNULL(@curr_m_w4_tg, 0.00),
	curr_m_w4_ac = ISNULL(@curr_m_w4_ac, 0.00),
	curr_m_w4_flag = ISNULL(@curr_m_w4_flag, ''),
	curr_m_w5_tg = ISNULL(@curr_m_w5_tg, 0.00),
	curr_m_w5_ac = ISNULL(@curr_m_w5_ac, 0.00),
	curr_m_w5_flag = ISNULL(@curr_m_w5_flag, ''),
	--Section [5]
	full_month_tg = ISNULL(@full_month_tg, 0.00),
	full_month_ac = ISNULL(@full_month_ac, 0.00),
	full_month_flag = ISNULL(@full_month_flag, ''),
	full_month_dff = ISNULL(@full_month_dff, 0.00),
	modifyby = 'batch_mail_llbw_D',
	modifydate = GETDATE()
	WHERE subject_group = @sub_group
	AND ptype LIKE @p_bg + '%'
	AND subject_type LIKE '%' + @p_th_option + '%'



go

