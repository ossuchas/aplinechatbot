
CREATE PROCEDURE [dbo].[sp_proc_mail_llbw_H]
 @p_parm AS INT
As

    SET NOCOUNT ON;
	-- 0 : Pre-sales
	-- 1 : Walk
	-- 2 : 2nd Walk
	-- 3 : Transfer
	-- 4 : ห้องผ่าน QC
	-- 5 : ลูกค้าเข้าตรวจ
	-- 6 : ลูกค้ารับห้อง
	-- 7 : JV Projects

	DECLARE @head_curr_quarter    AS VARCHAR(100);
	DECLARE @head_curr_quarter_m1 AS VARCHAR(100);
	DECLARE @head_curr_quarter_m2 AS VARCHAR(100);
	DECLARE @head_curr_quarter_m3 AS VARCHAR(100);
	DECLARE @head_curr_qtd_w      AS VARCHAR(100);
	DECLARE @head_curr_month      AS VARCHAR(100);
	DECLARE @head_curr_month_w1   AS VARCHAR(100);
	DECLARE @head_curr_month_w2   AS VARCHAR(100);
	DECLARE @head_curr_month_w3   AS VARCHAR(100);
	DECLARE @head_curr_month_w4   AS VARCHAR(100);
	DECLARE @head_curr_month_w5   AS VARCHAR(100);
	DECLARE @w_text AS VARCHAR(10);
	DECLARE @w_int AS INT;
	DECLARE @i_count AS INT;

    DECLARE @head_subject              AS VARCHAR(255);

	IF @p_parm = 0 SET @head_subject = 'Pre-sales'
	IF @p_parm = 1 SET @head_subject = 'Walk'
	IF @p_parm = 2 SET @head_subject = '2nd Walk'
	IF @p_parm = 3 SET @head_subject = 'Transfer'
	IF @p_parm = 4 SET @head_subject = 'ห้องผ่าน QC'
	IF @p_parm = 5 SET @head_subject = 'ลูกค้าเข้าตรวจ'
	IF @p_parm = 6 SET @head_subject = 'ลูกค้ารับห้อง'
	IF @p_parm = 7 SET @head_subject = 'JV Projects'

	If(Object_Id('tempdb..#tbl_qm')Is Not Null)Drop Table #tbl_qm
	
	SELECT DISTINCT 'Q' + CAST(q AS VARCHAR(2)) Quarter, 
	SUBSTRING('Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec ', (m * 4) - 3, 3) m_name,m,
	CASE WHEN q = 1 THEN 0 
	WHEN q = 2 THEN 1
	WHEN q = 3 THEN 2
	WHEN q = 4 THEN 3
	END AS minus
	INTO #tbl_qm
		FROM crmrevo.BI.Mst_Calendar_Week WITH(NOLOCK)
		WHERE 1=1
		AND DATEPART(YEAR, StartDate) = DATEPART(YEAR,GETDATE())
		AND DATEPART(QUARTER, StartDate) = DATEPART(QUARTER,GETDATE())
	
	SELECT @head_curr_quarter_m1 = m_name FROM #tbl_qm WHERE m-(3*minus)=1
	SELECT @head_curr_quarter_m2 = m_name FROM #tbl_qm WHERE m-(3*minus)=2
	SELECT @head_curr_quarter_m3 = m_name FROM #tbl_qm WHERE m-(3*minus)=3

	SET @head_curr_quarter = (SELECT TOP 1 Quarter FROM #tbl_qm)

	-- Get List Week Current Month
	If(Object_Id('tempdb..#tbl_qmw') IS NOT NULL) DROP TABLE #tbl_qmw
	SELECT 'WK' + CAST(w AS VARCHAR(2)) AS w_text, w, StartDate, EndDate
	INTO #tbl_qmw
	FROM crmrevo.BI.Mst_Calendar_Week WITH(NOLOCK)
	WHERE 1=1
	--AND m = DATEPART(MONTH,DATEADD(dd, -7, GETDATE())) --Modified by Suchat S. 2020-04-02
	AND m = CASE WHEN DATEPART(MONTH,DATEADD(dd, -7, GETDATE())) <> DATEPART(MONTH,GETDATE()) THEN DATEPART(MONTH,GETDATE()) ELSE DATEPART(MONTH,DATEADD(dd, -7, GETDATE())) END
	AND DATEPART(YEAR, StartDate) = DATEPART(YEAR,GETDATE())
	AND DATEPART(QUARTER, StartDate) = DATEPART(QUARTER,GETDATE())
	ORDER BY q,w

	SET @i_count = 1
	DECLARE db_cursor CURSOR
	FOR
		SELECT w_text, w FROM #tbl_qmw ORDER BY w

	OPEN db_cursor  
	FETCH NEXT FROM db_cursor INTO @w_text, @w_int

	WHILE @@FETCH_STATUS = 0
		BEGIN
			
			IF @i_count = 1 SET @head_curr_month_w1 = @w_text
			IF @i_count = 2 SET @head_curr_month_w2 = @w_text
			IF @i_count = 3 SET @head_curr_month_w3 = @w_text
			IF @i_count = 4 SET @head_curr_month_w4 = @w_text
			IF @i_count = 5 SET @head_curr_month_w5 = @w_text
			
			SET @i_count = @i_count + 1
			FETCH NEXT FROM db_cursor INTO @w_text, @w_int
		END 

	CLOSE db_cursor  
	DEALLOCATE db_cursor

	-- Get Current Month and Week
	SELECT @head_curr_month = SUBSTRING('Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec ', (m * 4) - 3, 3),
	--@head_curr_qtd_w = 'QTD WK' + CAST(w AS VARCHAR(2))
	@head_curr_qtd_w = 'QTD WK' + CAST(w-1 AS VARCHAR(2)) -- Modified by Suchat S. 2020-01-29 for Change to Last week
	FROM crmrevo.BI.Mst_Calendar_Week WITH(NOLOCK)
	WHERE 1=1
	AND CAST(GETDATE() AS DATE) BETWEEN CAST(StartDate AS DATE) AND CAST(EndDate AS DATE)
	AND DATEPART(YEAR, StartDate) = DATEPART(YEAR,GETDATE())
	AND DATEPART(QUARTER, StartDate) = DATEPART(QUARTER,GETDATE())

	SELECT @head_subject AS head_subject,
	@head_curr_quarter AS head_curr_quarter,
	@head_curr_quarter_m1 AS head_curr_quarter_m1,
	@head_curr_quarter_m2 AS head_curr_quarter_m2,
	@head_curr_quarter_m3 AS head_curr_quarter_m3,
	@head_curr_qtd_w      AS head_curr_qtd_w,
	@head_curr_month      AS head_curr_month,
	@head_curr_month_w1   AS head_curr_month_w1,
	@head_curr_month_w2   AS head_curr_month_w2,
	@head_curr_month_w3   AS head_curr_month_w3,
	@head_curr_month_w4   AS head_curr_month_w4,
	@head_curr_month_w5   AS head_curr_month_w5



go

