CREATE VIEW [dbo].[vw_crm_line_actual_income] AS 
SELECT 
a.ProductID + FORMAT(a.TransferDateApprove,'yyyyMMdd') AS keys_id,
CASE WHEN a.isJVStatus = 0 THEN 'AP' ELSE 'JV' END AS AP_JV,
a.PType, a.ProjectType, a.ProductID, a.ProjectName,  FORMAT(a.TransferDateApprove,'yyyyMMdd') AS TransferDateApprove,	
	COUNT(a.UnitNumber) AS TotalUnit, SUM(a.NetPrice) AS NetPrice,
	SUM(a.FreeDownAmount) AS FreeDownAmount, 
	SUM(a.NetPriceExclFD) AS NetPriceExclFD 
	FROM (
SELECT p.ProjectNo AS ProductID , 
p.ProjectNameTH AS ProjectName,
SUBSTRING(p.[Group],1,1) AS PType,                                    
crmrevo.dbo.fn_GetValueStatusByID('ProjectType', p.ProjectTypeMasterCenterID) AS ProjectType  ,                                      
 u.UnitNo AS UnitNumber,
 CAST(tr.ActualTransferDate AS DATE) TransferDateApprove,
datepart(year, tr.ActualTransferDate) AS Years, 
DATEPART(QUARTER, tr.ActualTransferDate) AS Quarters                
 ,up.TotalPrice AS NetPrice
,up.FreedownDiscount AS FreeDownAmount,
 up.TotalPrice - up.FreedownDiscount AS NetPriceExclFD
,(SELECT COUNT(*) FROM crmrevo.PRJ.TransferProjectJV t WITH(NOLOCK) WHERE CAST(t.EffectiveDate AS DATE) <= CAST(Tr.ActualTransferDate AS DATE)
			AND (t.ExpiredDate IS NULL OR CAST(t.ExpiredDate AS DATE) >= CAST(tr.ActualTransferDate AS DATE) ) 
			AND t.ProductID = p.ProjectNo) AS isJVStatus
FROM    crmrevo.SAL.Transfer tr WITH(NOLOCK)       
        LEFT JOIN crmrevo.SAL.Agreement a WITH(NOLOCK) ON a.ID = tr.AgreementID AND a.IsDeleted = 0
	LEFT JOIN crmrevo.SAL.Booking b WITH(NOLOCK) ON a.BookingID = b.ID AND b.IsDeleted = 0
	LEFT JOIN crmrevo.SAL.UnitPrice up WITH(NOLOCK) ON up.BookingID = b.ID AND up.IsDeleted = 0 
		AND crmrevo.dbo.fn_GetValueStatusByID('UnitPriceStage', up.UnitPriceStageMasterCenterID) = 'โอน'
        LEFT JOIN crmrevo.PRJ.Project p WITH (NOLOCK) ON p.ID = a.ProjectID AND p.IsActive = 1 AND p.IsDeleted = 0
	LEFT JOIN crmrevo.PRJ.Unit u WITH(NOLOCK) ON u.ID = a.UnitID AND a.ProjectID = u.ProjectID AND u.IsDeleted = 0
WHERE   1=1               
AND TR.IsDeleted = 0                                              
AND CAST(TR.ActualTransferDate AS DATE) >= CAST(GETDATE()-7 AS DATE) ) AS a
GROUP BY a.ProductID, a.ProjectName, a.PType, a.ProjectType, a.TransferDateApprove, 
CASE WHEN a.isJVStatus = 0 THEN 'AP' ELSE 'JV' END
go

