Create FUNCTION [dbo].[fn_AP_BI_GetExpectDateOfDefect]
(
	@ProductID nvarchar(15),
	@UnitNumber nvarchar(15)
	
)
RETURNS datetime
AS
BEGIN
	DECLARE @expect_date datetime
	

	set @expect_date =(
	Select top 1 RAuditCloseDueDate
From [DBLINK_SVR_DEFECT].[defecttracking].[dbo].vwCallDefectRoundAudit  v
--From [Temp_vwCallDefectRoundAudit]  v With(NoLock)
where DocIsActive=1 --and ProjectNO in(Select PROJECT_CODE From SM_D_PROJECT Where BU_Code='3')
and ProjectNO=@ProductID and Unit=@UnitNumber
and RAuditDate>= '20150720' and docisactive=1
and RAuditCloseDueDate is not null
order by RAuditCloseDueDate desc


	)
	
	--if(@expect_date is null)
	--set @expect_date =(
	
	--select top 1 a.expect_date
	--	--from [192.168.0.128].DefectLogs.dbo.tbl_defect_report a 
	--	--inner join [192.168.0.128].DefectLogs.dbo.tbl_room b on a.room_id=b.id
	--	--inner Join [192.168.0.128].DefectLogs.dbo.tbl_project as pj on (a.project_id = pj.id)
	--	from [Temp_tbl_defect_report] a  With(NoLock)
	--	inner join [Temp_tbl_room] b  With(NoLock)on a.room_id=b.id
	--	inner Join [Temp_tbl_project] as pj  With(NoLock)on (a.project_id = pj.id)
	--	where  1=1
	--	and pj.ProductID = @ProductID
	--	and b.room_code= @UnitNumber
	--	and check_date < '20150720' 
	--	and a.status = '1'

	--order by a.room_id asc,a.check_no asc

	--)
	
	RETURN @expect_date
END
go

