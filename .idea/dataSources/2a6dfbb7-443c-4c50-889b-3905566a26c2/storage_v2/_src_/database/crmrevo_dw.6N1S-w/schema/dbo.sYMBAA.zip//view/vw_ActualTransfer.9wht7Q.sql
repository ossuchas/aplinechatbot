CREATE VIEW [dbo].[vw_ActualTransfer] AS 
SELECT tr.ID AS TransferID, tr.TransferNo, tr.AgreementID, b.id AS BookingID, a.AgreementNo, p.ID AS ProjectID, p.ProjectNo , 
p.ProjectNameTH,
SUBSTRING(p.[Group],1,1) AS BG,
CASE WHEN SUBSTRING(p.[Group],1,1) = '1' THEN 'SDH'
WHEN SUBSTRING(p.[Group],1,1) = '2' THEN 'TH'
WHEN SUBSTRING(p.[Group],1,1) = '3' THEN 'CD1'
WHEN SUBSTRING(p.[Group],1,1) = '4' THEN 'CD2'
ELSE '' END AS ProjectType,
p.[Group] AS ProjectGroup,
u.ID AS UnitID,
u.UnitNo AS UnitNo,
u.HouseNo,
c.ContactNo AS ContactID,
tro.FullnameTH AS MajorContactName, --ชื่อลูกค้าผู้รับโอนคนหลัก
tr.ScheduleTransferDate, --วันที่นัดโอนกรรมสิทธิ
tr.ActualTransferDate, --วันที่โอนจริง
(SELECT TOP 1 wk.W FROM crmrevo.BI.Mst_Calendar_Week wk WITH(NOLOCK) WHERE wk.Y = DATEPART(YEAR, tr.ActualTransferDate) AND CAST(tr.ActualTransferDate AS DATE) BETWEEN CAST(wk.StartDate AS DATE) AND CAST(wk.EndDate AS DATE) ORDER BY wk.EndDate desc) AS WeekFI,
tr.TransferSaleUserID,
dbo.fn_GetUserFullName(tr.TransferSaleUserID,'EmpCode') AS SaleEmpCode,
dbo.fn_GetUserFullName(tr.TransferSaleUserID,'FullName') AS SaleFullName,
up.TotalPrice AS TotalPrice, --ราคาบ้านสุทธิ
up.FreedownDiscount AS FreeDownAmount, --ฟรีดาวน์
up.TotalPrice - up.FreedownDiscount AS NetPriceExclFD, 
tr.APChangeAmount, --ยอดเงินคงเหลือคืนลูกค้า
crmrevo.dbo.fn_GetValueStatusByID('CreditBankingType',b.CreditBankingTypeMasterCenterID) AS LoanStatus, --สถานะการขอสินเชื่อ
(SELECT COUNT(*) FROM crmrevo.PRJ.TransferProjectJV t WITH(NOLOCK) WHERE CAST(t.EffectiveDate AS DATE) <= CAST(Tr.ActualTransferDate AS DATE)
AND (t.ExpiredDate IS NULL OR CAST(t.ExpiredDate AS DATE) >= CAST(tr.ActualTransferDate AS DATE) ) 
AND t.ProductID = p.ProjectNo) AS isJVStatus,
p.IsUpCountry --UpCountry  Project Modified by Suchat S. 2020-12-10 for Check Up-Country Project
FROM    crmrevo.SAL.Transfer tr WITH(NOLOCK)       
LEFT JOIN crmrevo.sal.TransferOwner tro WITH(NOLOCK) ON tro.TransferID = tr.ID AND tro.[Order] = 1
LEFT JOIN crmrevo.CTM.Contact c WITH(NOLOCK) ON tro.FromContactID = c.ID
LEFT JOIN crmrevo.SAL.Agreement a WITH(NOLOCK) ON a.ID = tr.AgreementID AND a.IsDeleted = 0
LEFT JOIN crmrevo.SAL.Booking b WITH(NOLOCK) ON a.BookingID = b.ID AND b.IsDeleted = 0
LEFT JOIN crmrevo.SAL.UnitPrice up WITH(NOLOCK) ON up.BookingID = b.ID AND up.IsDeleted = 0 AND crmrevo.dbo.fn_GetValueStatusByID('UnitPriceStage', up.UnitPriceStageMasterCenterID) = 'โอน'
LEFT JOIN crmrevo.PRJ.Project p WITH (NOLOCK) ON p.ID = a.ProjectID AND p.IsActive = 1 AND p.IsDeleted = 0 AND p.ProjectNo <> '99907' AND SUBSTRING(p.[Group],3,1) <> '0' AND p.ProjectNameTH NOT LIKE '%ระงับ%'
LEFT JOIN crmrevo.PRJ.Unit u WITH(NOLOCK) ON u.ID = a.UnitID AND a.ProjectID = u.ProjectID AND u.IsDeleted = 0
WHERE 1=1
AND TR.IsDeleted = 0
AND TR.ActualTransferDate IS NOT NULL
--AND CAST(TR.ActualTransferDate AS DATE) >= CAST(GETDATE()-7 AS DATE)


go

