

CREATE PROCEDURE [dbo].[sp_proc_line_gross_income]
AS
BEGIN
    SET NOCOUNT ON;
	PRINT 'Gross Income'
	EXEC crmrevo.dbo.sp_ExecutiveReport_Adjust ---------เรียก vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract

	IF (OBJECT_ID('tempdb..#vw_RPTAP2_ExV4Booking') IS NOT NULL) DROP TABLE #vw_RPTAP2_ExV4Booking
	SELECT * INTO #vw_RPTAP2_ExV4Booking FROM [crmrevo].dbo.vw_RPTAP2_ExV4Booking

	IF (OBJECT_ID('tempdb..#tbl_booking') IS NOT NULL) DROP TABLE #tbl_booking;

	SELECT	p.ProjectNo ProductID, SUBSTRING([Group],1,1) ptype , b.BookingDate
	,DATEPART(QUARTER, b.BookingDate) AS Quarters
	,ISNULL(SUM(B.UnitAmt),0) AS TotalUnit, ISNULL(Sum(B.BKPrice),0)  AS TotalPrice
	,(SELECT COUNT(*) 
	FROM [crmrevo].prj.TransferProjectJV t WITH(NOLOCK) 
	WHERE t.EffectiveDate <= B.BookingDate
	AND (t.ExpiredDate IS NULL OR t.ExpiredDate >= B.BookingDate) AND t.ProductID = p.ProjectNo) AS isJVStatus
	INTO #tbl_booking
	FROM	#vw_RPTAP2_ExV4Booking B WITH(NOLOCK), [crmrevo].prj.project p
	WHERE	1=1 
    AND DATEPART(YEAR, B.BookingDate) = DATEPART(YEAR, GETDATE())
	AND B.ProjectID = p.id
	AND p.IsActive = 1 
	GROUP BY B.ProjectID,b.BookingDate,SUBSTRING([Group],1,1),p.ProjectNo


	IF (OBJECT_ID('tempdb..#tbl_g_booking') IS NOT NULL) DROP TABLE #tbl_g_booking;
	SELECT CASE WHEN isJVStatus = 0 THEN 'AP' ELSE 'JV' END AS AP_JV
	,Ptype, Quarters, SUM(TotalUnit) AS TotalUnit, SUM(TotalPrice) AS TotalPrice 
	INTO #tbl_g_booking
	FROM #tbl_booking 
	GROUP BY CASE WHEN isJVStatus = 0 THEN 'AP' ELSE 'JV' END, Ptype, Quarters

	--Subtract
	IF (OBJECT_ID('tempdb..#tbl_sub_booking') IS NOT NULL) DROP TABLE #tbl_sub_booking;
	SELECT B.projectNO AS ProductID
	,SUBSTRING([Group],1,1) AS PType
     ,B.BookingDate
	,DATEPART(QUARTER, b.BookingDate) AS Quarters
	,Sum(B.SubtractGrossBookingAmount) AS SubtractGrossBookingAmount
	,Sum(B.SubtractGrossBookingUnit) AS SubtractGrossBookingUnit
	,(SELECT COUNT(*) 
	FROM [crmrevo].prj.TransferProjectJV t WITH(NOLOCK) 
	WHERE t.EffectiveDate <= B.BookingDate
	AND (t.ExpiredDate IS NULL OR t.ExpiredDate >= B.BookingDate) AND t.ProductID = B.projectNO) AS isJVStatus
	INTO #tbl_sub_booking
	FROM ##ExecutiveReport_Adjust B With(NoLock),[crmrevo].prj.project p
	WHERE 1=1 
	AND DATEPART(YEAR, B.BookingDate) = DATEPART(YEAR, GETDATE())
	AND B.projectNO = P.ProjectNo
	AND P.IsActive = 1
	Group by B.projectNO, SUBSTRING([Group],1,1), B.BookingDate

	SELECT * FROM ##ExecutiveReport_Adjust

	IF (OBJECT_ID('tempdb..#tbl_g_sub_booking') IS NOT NULL) DROP TABLE #tbl_g_sub_booking;
	SELECT CASE WHEN isJVStatus = 0 THEN 'AP' ELSE 'JV' END AS AP_JV
	,ptype, Quarters, SUM(SubtractGrossBookingAmount) AS SubTotalPrice, 
	SUM(SubtractGrossBookingUnit) AS SubTotalUnit 
	INTO #tbl_g_sub_booking
	FROM #tbl_sub_booking
	GROUP BY CASE WHEN isJVStatus = 0 THEN 'AP' ELSE 'JV' END, ptype, Quarters

	--Update Total Unit and Total Price adjust by Subtract Data.
	UPDATE #tbl_g_booking
	SET TotalUnit = ISNULL(a.TotalUnit,0) - ISNULL(b.SubTotalUnit,0),
	TotalPrice = ISNULL(a.TotalPrice,0) - ISNULL(b.SubTotalPrice,0)
	FROM  #tbl_g_booking a, #tbl_g_sub_booking b
	WHERE 1=1
	AND a.AP_JV = b.AP_JV
	AND a.Ptype = b.ptype
	AND a.Quarters = b.Quarters

	
	-- Update Data by Quarter and by AP/JV
	UPDATE dbo.crm_line_gross_income
	SET ap_bg1_q1 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'AP' AND Quarters = 1 AND ptype = '1'),0)
	,ap_bg2_q1 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'AP' AND Quarters = 1 AND ptype = '2'),0)
	,ap_bg3_q1 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'AP' AND Quarters = 1 AND ptype = '3'),0)
	,ap_bg4_q1 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'AP' AND Quarters = 1 AND ptype = '4'),0)
	,jv_bg3_q1 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'JV' AND Quarters = 1 AND ptype = '3'),0)
	,jv_bg4_q1 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'JV' AND Quarters = 1 AND ptype = '4'),0)
	--Q2
	,ap_bg1_q2 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'AP' AND Quarters = 2 AND ptype = '1'),0)
	,ap_bg2_q2 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'AP' AND Quarters = 2 AND ptype = '2'),0)
	,ap_bg3_q2 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'AP' AND Quarters = 2 AND ptype = '3'),0)
	,ap_bg4_q2 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'AP' AND Quarters = 2 AND ptype = '4'),0)
	,jv_bg3_q2 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'JV' AND Quarters = 2 AND ptype = '3'),0)
	,jv_bg4_q2 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'JV' AND Quarters = 2 AND ptype = '4'),0)
	--Q3
	,ap_bg1_q3 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'AP' AND Quarters = 3 AND ptype = '1'),0)
	,ap_bg2_q3 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'AP' AND Quarters = 3 AND ptype = '2'),0)
	,ap_bg3_q3 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'AP' AND Quarters = 3 AND ptype = '3'),0)
	,ap_bg4_q3 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'AP' AND Quarters = 3 AND ptype = '4'),0)
	,jv_bg3_q3 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'JV' AND Quarters = 3 AND ptype = '3'),0)
	,jv_bg4_q3 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'JV' AND Quarters = 3 AND ptype = '4'),0)
	--Q4
	,ap_bg1_q4 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'AP' AND Quarters = 4 AND ptype = '1'),0)
	,ap_bg2_q4 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'AP' AND Quarters = 4 AND ptype = '2'),0)
	,ap_bg3_q4 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'AP' AND Quarters = 4 AND ptype = '3'),0)
	,ap_bg4_q4 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'AP' AND Quarters = 4 AND ptype = '4'),0)
	,jv_bg3_q4 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'JV' AND Quarters = 4 AND ptype = '3'),0)
	,jv_bg4_q4 = ISNULL((SELECT TotalPrice FROM #tbl_g_booking WHERE AP_JV = 'JV' AND Quarters = 4 AND ptype = '4'),0)
	WHERE trans_id = 1

	-- Update Total Sub Group by Quarter and by AP/JV
	UPDATE dbo.crm_line_gross_income
	SET ap_bg1_total = ap_bg1_q1 + ap_bg1_q2 + ap_bg1_q3 + ap_bg1_q4
	,ap_bg2_total = ap_bg2_q1 + ap_bg2_q2 + ap_bg2_q3 + ap_bg2_q4
	,ap_bg3_total = ap_bg3_q1 + ap_bg3_q2 + ap_bg3_q3 + ap_bg3_q4
	,ap_bg4_total = ap_bg4_q1 + ap_bg4_q2 + ap_bg4_q3 + ap_bg4_q4
	,ap_total_q4 = ap_bg1_q4 + ap_bg2_q4 + ap_bg3_q4 + ap_bg4_q4
	--,ap_total = ap_total_q1 + ap_total_q2 + ap_total_q3 + (ap_bg1_q4 + ap_bg2_q4 + ap_bg3_q4 + ap_bg4_q4)
	,jv_bg3_total = jv_bg3_q1 + jv_bg3_q2 + jv_bg3_q3 + jv_bg3_q4
	,jv_bg4_total = jv_bg4_q1 + jv_bg4_q2 + jv_bg4_q3 + jv_bg4_q4
	,jv_total_q4 = jv_bg3_q4 + jv_bg4_q4
	--,jv_total = jv_total_q1 + jv_total_q2 + jv_total_q3 + (jv_bg3_q4 + jv_bg4_q4)
	WHERE trans_id = 1

	
	--Update by Company Group AP/JV by Quarter
	UPDATE dbo.crm_line_gross_income
	SET ap_total_q1 = ap_bg1_q1 + ap_bg2_q1 + ap_bg3_q1 + ap_bg4_q1,
	ap_total_q2 = ap_bg1_q2 + ap_bg2_q2 + ap_bg3_q2 + ap_bg4_q2,
	ap_total_q3 = ap_bg1_q3 + ap_bg2_q3 + ap_bg3_q3 + ap_bg4_q3,
	ap_total_q4 = ap_bg1_q4 + ap_bg2_q4 + ap_bg3_q4 + ap_bg4_q4,
	jv_total_q1 = jv_bg3_q1 + jv_bg4_q1,
	jv_total_q2 = jv_bg3_q2 + jv_bg4_q2,
	jv_total_q3 = jv_bg3_q3 + jv_bg4_q3,
	jv_total_q4 = jv_bg3_q4 + jv_bg4_q4
	WHERE trans_id = 1


	--Update by Company Group AP/JV
	UPDATE dbo.crm_line_gross_income
	SET ap_total = ap_total_q1 + ap_total_q2 + ap_total_q3 + ap_total_q4
	,jv_total = jv_total_q1 + jv_total_q2 + jv_total_q3 + jv_total_q4
	WHERE trans_id = 1

	-- Update Grand Total
	UPDATE dbo.crm_line_gross_income
	SET grant_total_q1 = ap_total_q1 + jv_total_q1
	,grant_total_q2 = ap_total_q2 + jv_total_q2
	,grant_total_q3 = ap_total_q3 + jv_total_q3
	,grant_total_q4 = ap_total_q4 + jv_total_q4
	,grant_total = ap_total + jv_total
	,modifyby = 'batch', modifydate = GETDATE()
	WHERE trans_id = 1

END;



go

