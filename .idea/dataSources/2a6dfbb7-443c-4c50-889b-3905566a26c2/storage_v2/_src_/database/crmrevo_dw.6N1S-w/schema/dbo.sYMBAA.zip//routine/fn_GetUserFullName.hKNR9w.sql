
CREATE FUNCTION [dbo].[fn_GetUserFullName]
(
    @UserGUID UNIQUEIDENTIFIER,
	@UserType VARCHAR(20)
)
RETURNS VARCHAR(255)
AS
BEGIN
    DECLARE @UserFullName VARCHAR(255);
	DECLARE @EmpCode VARCHAR(50);
	DECLARE @Email VARCHAR(50)
	DECLARE @Return_Val VARCHAR(50)


    SELECT TOP 1 @EmpCode = a.EmpCode, @UserFullName = a.FullName, @Email = a.Email 
	FROM (
	SELECT EmpCode
	-- FullName
	,'FullName' = (firstname+' '+lastname)
	, Email 
	FROM crmrevo.dbo.vw_User WITH(NOLOCK)
	WHERE UserGUID = @UserGUID
	UNION ALL
    SELECT NameTH AS EmpCode, NameTH AS FullName, NameTH AS Email
	FROM crmrevo.MST.Agent WITH(NOLOCK)
	WHERE ID = @UserGUID
	) AS a

	IF @UserType = 'EmpCode' OR @UserType LIKE 'E%'
	BEGIN
	    --PRINT '@EmpCode'
		SET @Return_Val = @EmpCode
	END
	ELSE
	BEGIN
	    IF @UserType = 'FullName' OR @UserType LIKE 'F%'
		BEGIN
		    --PRINT 'Full Name'
			SET @Return_Val = @UserFullName
		END
		ELSE
		BEGIN
		    --PRINT 'Email'
			SET @Return_Val = @Email
		END
	END

    RETURN @Return_Val;

END;


go

