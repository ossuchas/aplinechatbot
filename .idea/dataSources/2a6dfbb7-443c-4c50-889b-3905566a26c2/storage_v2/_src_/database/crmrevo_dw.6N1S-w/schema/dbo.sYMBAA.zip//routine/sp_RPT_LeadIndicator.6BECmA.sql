--EXEC  [dbo].[sp_RPT_LeadIndicator] 2020,53,'All'
CREATE proc [dbo].[sp_RPT_LeadIndicator]

@Y int
,@W INT
,@ProjectID nvarchar(10) -- is ProjectNo

as
SET NOCOUNT ON

--SET @Y = 2020
--SET @w = 40 
--SET @ProjectID = 'ALL'
PRINT '[*] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: Start Process sp_RPT_LeadIndicator'

DECLARE @ProjectID_UNIQ UNIQUEIDENTIFIER

SELECT @ProjectID_UNIQ = ID FROM [crmrevo].PRJ.Project WITH(NOLOCK) WHERE ProjectNo = @ProjectID

--Print ('Y='+Convert(NVarchar(50),@y)+' W='+Convert(NVarchar(50),@W)+'/')
SET Datefirst 1
DECLARE @currentY int,@currentW int,@currentM int
DECLARE @Q nvarchar(10),@M nvarchar(10),@StartDate DateTime,@EndDate Datetime,@CurrentDate DateTime,@CurrentWeek int
SELECT @Q=Q,@M=M,@StartDate=StartDate,@EndDate=EndDate FROM [crmrevo].BI.Mst_Calendar_Week WITH(NOLOCK) WHERE Y=@Y and W=@W 


IF(Year(Getdate())<>@Y) SET @CurrentDate=Convert(nvarchar(40),@Y)+'1231'
else SET @CurrentDate=Getdate()
SET @CurrentDate=convert(datetime,convert(nvarchar(8),@CurrentDate,112)+' 23:59:59')

SELECT @CurrentWeek=W FROM [crmrevo].BI.Mst_Calendar_Week WITH(NOLOCK) WHERE @CurrentDate between StartDate and convert(datetime,convert(nvarchar(8),EndDate,112)+' 23:59:59') 
SELECT @currentY=Y,@currentW=W,@currentM=M FROM [crmrevo].BI.Mst_Calendar_Week WITH(NOLOCK) WHERE @CurrentDate between startdate and convert(datetime,convert(nvarchar(8),EndDate,112)+' 23:59:59')

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: Before Prepare Table'

EXEC crmrevo.dbo.sp_ExecutiveReport_Adjust ----------------------------- รัน store แทน vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: exec vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract'
--Clears Temp DB
BEGIN
	IF(OBJECT_ID('tempdb..#ICON_EntForms_Booking')IS NOT NULL)DROP TABLE #ICON_EntForms_Booking
	IF(OBJECT_ID('tempdb..#ICON_EntForms_Transfer')IS NOT NULL)DROP TABLE #ICON_EntForms_Transfer
	IF(OBJECT_ID('tempdb..#ICON_EntForms_Agreement')IS NOT NULL)DROP TABLE #ICON_EntForms_Agreement
	IF(OBJECT_ID('tempdb..#vw_RPTAP2_ExV4Booking')IS NOT NULL)DROP TABLE #vw_RPTAP2_ExV4Booking
	IF(OBJECT_ID('tempdb..#vw_RPTAP2_ExV4BookingCancel')IS NOT NULL)DROP TABLE #vw_RPTAP2_ExV4BookingCancel
	IF(OBJECT_ID('tempdb..#vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract')IS NOT NULL)DROP TABLE #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract
	IF(OBJECT_ID('tempdb..#ZTEMP_Booking')IS NOT NULL)DROP TABLE #ZTEMP_Booking
	IF(OBJECT_ID('tempdb..#vw_CRM_Walk_1')IS NOT NULL)DROP TABLE #vw_CRM_Walk_1
	IF(OBJECT_ID('tempdb..#CRM_Opportunities')IS NOT NULL)DROP TABLE #CRM_Opportunities
	IF(OBJECT_ID('tempdb..#CRM_Activity')IS NOT NULL)DROP TABLE #CRM_Activity
	IF(OBJECT_ID('tempdb..#Tvw')IS NOT NULL)DROP TABLE #Tvw
	IF(OBJECT_ID('tempdb..#vwCallDefectReceiveUnitDoc')IS NOT NULL)DROP TABLE #vwCallDefectReceiveUnitDoc
	IF(OBJECT_ID('tempdb..#vwCallDefectRoundAudit')IS NOT NULL)DROP TABLE #vwCallDefectRoundAudit
	IF(OBJECT_ID('tempdb..#ICON_EntForms_Products')IS NOT NULL)DROP TABLE #ICON_EntForms_Products
	IF(OBJECT_ID('tempdb..#ICON_EntForms_Unit')IS NOT NULL)DROP TABLE #ICON_EntForms_Unit
	IF(OBJECT_ID('tempdb..#CreditBanking')IS NOT NULL)DROP TABLE #CreditBanking
	IF(OBJECT_ID('tempdb..#Mst_LeadIndicator_Target')IS NOT NULL)DROP TABLE #Mst_LeadIndicator_Target
	IF(OBJECT_ID('tempdb..#DocumentChecklist')IS NOT NULL)DROP TABLE #DocumentChecklist
	IF(OBJECT_ID('tempdb..#TempTrans')IS NOT NULL)DROP TABLE #TempTrans
	IF(OBJECT_ID('tempdb..#TempBankapprove')IS NOT NULL)DROP TABLE #TempBankapprove


	PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + '   -> Before Prepare Table B,A,T'
	SELECT * INTO #ICON_EntForms_Booking FROM [crmrevo].sal.Booking WITH(NOLOCK) WHERE IsDeleted = 0
	SELECT * INTO #ICON_EntForms_Transfer FROM [crmrevo].sal.[Transfer] WITH(NOLOCK) WHERE IsDeleted = 0
	SELECT * INTO #ICON_EntForms_Agreement FROM [crmrevo].sal.Agreement WITH(NOLOCK) WHERE IsDeleted = 0
	PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + '   -> After Prepare Table B,A,T'
	
	SELECT * INTO #vw_RPTAP2_ExV4Booking FROM [crmrevo].[dbo].[vw_RPTAP2_ExV4Booking] WITH(NOLOCK) WHERE BookingDate Between @StartDate and @EndDate --Modified by Suchat S. 2020-07-11
	SELECT * INTO #vw_RPTAP2_ExV4BookingCancel FROM [crmrevo].[dbo].[vw_RPTAP2_ExV4BookingCancel] WITH(NOLOCK) WHERE  CancelDate BETWEEN @StartDate and @EndDate --Modified by Suchat S. 2020-07-11
	SELECT * INTO #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract FROM ##ExecutiveReport_Adjust WITH(NOLOCK) --WHERE (BookingDate between @StartDate and @EndDate OR BookingCancelDate between @StartDate and @EndDate ) --Modified by Suchat S. 2020-07-11,-------ใช้ ##ExecutiveReport_Adjust แทน vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract
	PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + '   -> After Prepare Table View ExV4Booking, Cancel, Sub'
	SELECT * INTO #ZTEMP_Booking FROM (SELECT a.id,a.ProjectID,a.UnitID,a.BookingDate,uu.AgreementPrice,uu.CashDiscount,uu.TransferDiscount,uu.TotalPrice,b.[Name]
									 FROM [crmrevo].sal.Booking a WITH(NOLOCK) INNER JOIN [crmrevo].mst.MasterCenter b WITH(NOLOCK) ON a.CreateBookingFROMMasterCenterID = b.id AND b.[Key] = '2' 
									INNER JOIN (SELECT c.BookingID,c.AgreementPrice,c.CashDiscount,c.TransferDiscount,c.TotalPrice FROM  [crmrevo].sal.UnitPrice c WITH(NOLOCK)  INNER JOIN [crmrevo].mst.MasterCenter cc WITH(NOLOCK) ON cc.id = c.UnitPriceStageMasterCenterID AND cc.[Key] = '1' AND c.IsDeleted = 0) uu ON a.id = uu.BookingID 
									WHERE a.ConfirmDate IS NULL  AND a.IsDeleted = 0 AND a.IsCancelled = 0 )aa
	SELECT * INTO #vw_CRM_Walk_1 FROM [crmrevo].[dbo].vw_CRM_Walk_1 WITH(NOLOCK) WHERE year(CreateDate)=@Y 
	SELECT * INTO #CRM_Opportunities FROM [crmrevo].ctm.Opportunity WITH(NOLOCK) WHERE IsDeleted = 0
	SELECT * INTO #CRM_Activity FROM [crmrevo].ctm.RevisitActivity WITH(NOLOCK) WHERE IsDeleted = 0
	PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + '   -> After Prepare Table Opportunities, Activity'
	SELECT * INTO #vwCallDefectRoundAudit FROM [DBLINK_SVR_DEFECT].[defecttracking].[dbo].vwCallDefectRoundAudit WITH(NOLOCK) WHERE RAuditDate>='20150601' and DocIsActive=1
	SELECT * INTO #vwCallDefectReceiveUnitDoc FROM    [DBLINK_SVR_DEFECT].[defecttracking].[dbo].vwCallDefectReceiveUnitDoc WITH(NOLOCK)  WHERE DocReceiveUnitDate>='20150601'
	SELECT p.* INTO #ICON_EntForms_Products FROM [crmrevo].prj.project p WITH(NOLOCK) WHERE p.IsActive = 1 AND ('All' = @ProjectID OR p.ProjectNo = @ProjectID ) AND   p.IsDeleted = 0
	SELECT * INTO #ICON_EntForms_Unit FROM (SELECT a.*,b.[Key] FROM [crmrevo].prj.Unit a WITH(NOLOCK) INNER JOIN [crmrevo].mst.MasterCenter b WITH(NOLOCK) ON b.id = a.AsSETTypeMasterCenterID AND a.IsDeleted = 0) aa
	SELECT *  INTO #CreditBanking FROM (SELECT a.*,m.[Name]  FROM [crmrevo].sal.CreditBanking a WITH(NOLOCK) INNER JOIN [crmrevo].mst.MasterCenter m WITH(NOLOCK) ON a.LoanStatusMasterCenterID = m.id   WHERE a.IsDeleted = 0 AND m.[Key] = '1') aa
	SELECT a.*,m.[Key] INTO #DocumentChecklist FROM #ICON_EntForms_Booking a WITH(NOLOCK) INNER JOIN [crmrevo].mst.MasterCenter m WITH(NOLOCK) ON a.CreditBankingTypeMasterCenterID = m.id 
	SELECT * INTO #Tvw FROM (SELECT a.*,mup.[Key],mup.[Name] FROM [crmrevo].dbo.vw_UnitPrice a WITH(NOLOCK) INNER JOIN [crmrevo].[MST].[MasterCenter] MUP WITH (NOLOCK) ON a.UnitPriceStageMasterCenterID = MUP.ID ) UP
	SELECT a.y,a.q,a.m,a.w,a.ProjectID ,b.Amount,b.Unit,a.RecType,p.ProjectNo
	INTO #Mst_LeadIndicator_Target
	FROM (SELECT MAX(Updated)Updated , y,q,m,w,ProjectID,RecType
		FROM [crmrevo].bi.Mst_LeadIndicator_Target  		
		--WHERE  y = 2020 AND q = 4 AND ProjectID = '507F3DF5-C8A3-48F3-AFCE-07961592442E'  AND RecType IN ('Projection')
		GROUP BY y,q,m,w,ProjectID,RecType ) a
LEFT JOIN [crmrevo].bi.Mst_LeadIndicator_Target  b ON CONVERT(VARCHAR(50),a.Updated,120) = CONVERT(VARCHAR(50),b.Updated,120)AND a.y = b.y AND a.w = b.w AND a.ProjectID = b.ProjectID AND a.RecType = b.RecType
INNER JOIN #ICON_EntForms_Products p ON a.ProjectID = p.id  
WHERE p.IsDeleted = 0
--ORDER BY ProjectID,w

	SELECT a.BookingID, ISNULL(a.TotalPrice,0) AS  TotalPrice , ISNULL(a.FreedownDiscount,0) AS FreedownDiscount,p.ProjectNo,tt.ActualTransferDate 
	INTO #TempTrans 
	FROM #Tvw a inner join #ICON_EntForms_Agreement b WITH(NOLOCK) on a.BookingID = b.BookingID
					INNER JOIN #ICON_EntForms_Transfer tt WITH(NOLOCK) ON tt.AgreementID = b.id 
					LEFT JOIN #ICON_EntForms_Products p WITH(NOLOCK) on b.ProjectID = p.id
					WHERE 1=1 AND a.[Key] = '3'
					and b.IsCancel = 0 
	SELECT a.BookingID,a.AgreementNo,a.UnitID,tr.ActualTransferDate,p.ProjectNo,DC.[key],dc.CreditBankingDate,cb.ResultDate
	INTO #TempBankapprove
					FROM  #ICON_EntForms_Agreement a WITH(NOLOCK)
				LEFT JOIN #ICON_EntForms_Unit uu WITH(NOLOCK) ON a.UnitID = uu.id
				LEFT JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON a.ProjectID = p.id 
				LEFT JOIN #CreditBanking CB WITH(NOLOCK) ON a.BookingID = cb.BookingID
				LEFT JOIN #DocumentChecklist   dc ON a.BookingID = DC.id
				LEFT JOIN #ICON_EntForms_Transfer tr WITH(NOLOCK) ON tr.AgreementID = a.id
	WHERE a.IsCancel = 0 AND A.ContractDate IS NOT NULL AND  uu.[Key] Not In('4','3')
END

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Prepare Table'
------------------------------------------------------------------------------------------------
--DELETE FROM RPT_LeadIndicator WHERE @Y= Y and @W = W AND ('All' = @ProjectID OR ProjectID = @ProjectID)


IF EXISTS (SELECT 1 FROM RPT_LeadIndicator WHERE @Y = Y AND @W = W)
BEGIN
	If(Object_Id('tempdb..#tbl_RPT_LeadIndicator') IS NOT NULL) DROP TABLE #tbl_RPT_LeadIndicator
	SELECT ProjectID, RecType, Actual, [Target] 
	INTO #tbl_RPT_LeadIndicator
	FROM RPT_LeadIndicator WITH(NOLOCK) 
	WHERE @Y = Y AND @W = W
	AND ('All' = @ProjectID OR ProjectID = @ProjectID)

    DELETE FROM RPT_LeadIndicator WHERE @Y = Y AND @W = W AND ('All' = @ProjectID OR ProjectID = @ProjectID)

	INSERT INTO RPT_LeadIndicator (Y,Q,M,W,ProjectID,RecType,Target,Actual,AsOfWeek,CreateDate,ModifyDate)
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'TransferAmount'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'TransferAmount') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'TransferAmount') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'TransferUnit'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'TransferUnit') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'TransferUnit') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'QCPass'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'QCPass') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'QCPass') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'CheckUnit'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'CheckUnit') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'CheckUnit') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'AcceptUnit'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'AcceptUnit') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'AcceptUnit') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'BankApprove'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'BankApprove') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'BankApprove') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'BC'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'BC') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'BC') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'GrossPresalesAmount'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'GrossPresalesAmount') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'GrossPresalesAmount') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'GrossPresalesUnit'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'GrossPresalesUnit') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'GrossPresalesUnit') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'NetPresalesAmount'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'NetPresalesAmount') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'NetPresalesAmount') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'NetPresalesUnit'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'NetPresalesUnit') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'NetPresalesUnit') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'Walk'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'Walk') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'Walk') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'Walk2'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'Walk2') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'Walk2') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'Conversion'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'Conversion') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'Conversion') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'GrossPresales'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'GrossPresales') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'GrossPresales') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'Div'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'Div') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'Div') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'PreCancelUnit'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'PreCancelUnit') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'PreCancelUnit') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'PreCancelAmount'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'PreCancelAmount') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'PreCancelAmount') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'NetPresales_PreCancelUnit'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'NetPresales_PreCancelUnit') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'NetPresales_PreCancelUnit') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'NetPresales_PreCancelAmount'RecType,
	(SELECT bb.Target FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'NetPresales_PreCancelAmount') AS [Target],
	(SELECT bb.Actual FROM #tbl_RPT_LeadIndicator bb WITH(NOLOCK) WHERE 1=1 AND a.ProjectNo = @ProjectID AND bb.RecType = 'NetPresales_PreCancelAmount') as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
END
ELSE
BEGIN
    --PRINT 'Not Found'
	
	INSERT INTO RPT_LeadIndicator (Y,Q,M,W,ProjectID,RecType,Target,Actual,AsOfWeek,CreateDate,ModifyDate)
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'TransferAmount'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'TransferUnit'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'QCPass'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'CheckUnit'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'AcceptUnit'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'BankApprove'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'BC'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'GrossPresalesAmount'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'GrossPresalesUnit'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'NetPresalesAmount'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'NetPresalesUnit'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'Walk'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'Walk2'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'Conversion'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'GrossPresales'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'Div'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'PreCancelUnit'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'PreCancelAmount'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'NetPresales_PreCancelUnit'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
	UNION ALL
	SELECT @Y Y,@Q Q,@M M,@W W,a.ProjectNo,'NetPresales_PreCancelAmount'RecType,
	0 AS [Target],
	0 as Actual,
	0 AsOfWeek,GetDate() CreateDate,GetDate() ModifyDate
	FROM #ICON_EntForms_Products a WITH(NOLOCK)
	--WHERE a.ProjectNo Not IN (SELECT ProjectID FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE b.Y=@Y and b.W=@W)
	WHERE ('All' = @ProjectID OR a.ProjectNo = @ProjectID)
END

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in RPT_LeadIndicator'

--UPDATE Sort Key by Rec_Type
UPDATE RPT_LeadIndicator
SET SortKey = Case RecType When 'TransferAmount' Then 1
							When 'TransferUnit' Then 2
							When 'QCPass' Then 3
							When 'CheckUnit' Then 4
							When 'AcceptUnit' Then 5
							When 'BankApprove' Then 6
							When 'BC' Then 7
							When 'GrossPresalesAmount' Then 8
							When 'GrossPresalesUnit' Then 9
							When 'NetPresalesAmount' Then 10
							When 'NetPresalesUnit' Then 11
							When 'Walk' Then 12 
							When 'Walk2' Then 13
							When 'Conversion' Then 14 
							When 'GrossPresales' Then 15
							When 'Div' Then 16 
							When 'PreCancelUnit' Then 17
							When 'PreCancelAmount' Then 18
							When 'NetPresales_PreCancelUnit' Then 19
							When 'NetPresales_PreCancelAmount' Then 20 END
                            
------------ TransferAmount -----------------------

-- print('TransferAmount')
UPDATE RPT_LeadIndicator
SET  [Target]=ISNULL((SELECT SUM(ISNULL(Amount,0)) FROM #Mst_LeadIndicator_Target a WITH(NOLOCK) 
WHERE RecType='Projection' and a.ProjectNo=t.ProjectID and t.Y=a.Y and t.W=a.W),0)/1000000
,Actual = (ISNULL((SELECT  (ISNULL(SUM(tt.TotalPrice),0) -  ISNULL(SUM(tt.FreedownDiscount),0))
					FROM  #TempTrans tt
					WHERE 1=1 
					and tt.ProjectNo = t.ProjectID
					and tt.ActualTransferDate Between @StartDate and @EndDate
					),0)
				)/1000000
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='TransferAmount' 
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)
PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in TransferAmount'
-------------- TransferUnit -----------------------
-- print('TransferUnit')
UPDATE RPT_LeadIndicator
SET  [Target]=ISNULL((SELECT Sum(ISNULL(Unit,0)) FROM #Mst_LeadIndicator_Target a WITH(NOLOCK) WHERE RecType='Projection' and a.ProjectNo=t.ProjectID and t.Y=a.Y and t.W=a.W),0)
,Actual= ISNULL((SELECT count(a.TransferNo)
				FROM #ICON_EntForms_Transfer a WITH(NOLOCK)
				LEFT JOIN #ICON_EntForms_Agreement b WITH(NOLOCK) on a.AgreementID = b.ID and a.IsDeleted = 0 AND b.IsCancel = 0 
				LEFT JOIN #ICON_EntForms_Products p WITH(NOLOCK) on b.ProjectID = p.id
				WHERE 1=1
				and p.ProjectNo = t.ProjectID
				and a.ActualTransferDate Between @StartDate and @EndDate
				),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='TransferUnit'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)
PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in TransferUnit'
---------------- QCPass -----------------------
--print('QCPass')
--------------------------------------------------------------------------------------------------------------------------------------
DECLARE @TQCPass Table(Unit int,ProjectCRMCode nvarchar(50))
INSERT INTO @TQCPass
SELECT Count(u.unitnumber ),u.ProjectCRMCode
FROM   DBLINK_SVR_QISV2.[db_QIS_V2].[dbo].[vw_EndProduct] u WITH(NOLOCK)
LEFT JOIN  #ICON_EntForms_Unit  uu WITH(NOLOCK) on u.wbs=uu.SAPWBSNo
LEFT JOIN #ICON_EntForms_Booking b WITH(NOLOCK) on b.UnitID=uu.id  and b.IsDeleted = 0 AND b.IsCancelled = 0
LEFT JOIN #ICON_EntForms_Agreement e WITH(NOLOCK) on e.BookingID = b.id and e.IsDeleted = 0 AND e.IsCancel = 0
LEFT JOIN #ICON_EntForms_Transfer f WITH(NOLOCK) on f.AgreementID=e.id
WHERE	1=1
--u.ProjectCRMCode=t.ProjectID 
and ((u.EndProductDate<=ISNULL(f.ActualTransferDate ,@CurrentDate))
		or (f.ActualTransferDate IS NOT NULL and Year(u.EndProductDate)=Year(f.ActualTransferDate)
			and (SELECT W FROM [crmrevo].BI.Mst_Calendar_Week v WITH(NOLOCK) WHERE u.EndProductDate Between v.StartDate and v.EndDate)=(SELECT W FROM [crmrevo].BI.Mst_Calendar_Week v WITH(NOLOCK) WHERE f.ActualTransferDate Between v.StartDate and v.EndDate))
		)
and uu.[key] Not In('4','3')  and u.EndProductDate Between @StartDate and convert(datetime,convert(nvarchar(8),@EndDate,112)+' 23:59:59') and u.EndProductDate<>'20130930'
group by u.ProjectCRMCode


INSERT INTO @TQCPass
SELECT Count(u.unitnumber ),u.ProjectCRMCode
FROM   [DBLINK_SVR_CMIS].[db_QIS_H].[dbo].[vw_EndProduct] u WITH(NOLOCK)
LEFT JOIN  #ICON_EntForms_Unit  uu WITH(NOLOCK) on u.wbs=uu.SAPWBSNo
LEFT JOIN #ICON_EntForms_Booking b WITH(NOLOCK) on b.UnitID=uu.id  and b.IsDeleted = 0 AND b.IsCancelled = 0
LEFT JOIN #ICON_EntForms_Agreement e WITH(NOLOCK) on e.BookingID = b.id and e.IsDeleted = 0 AND e.IsCancel = 0
LEFT JOIN #ICON_EntForms_Transfer f WITH(NOLOCK) on f.AgreementID=e.id
WHERE	1=1
--u.ProjectCRMCode=t.ProjectID 
and ((u.EndProductDate<=ISNULL(f.ActualTransferDate ,@CurrentDate))
		or (f.ActualTransferDate IS NOT NULL and Year(u.EndProductDate)=Year(f.ActualTransferDate)
			and (SELECT W FROM [crmrevo].BI.Mst_Calendar_Week v WITH(NOLOCK) WHERE u.EndProductDate Between v.StartDate and v.EndDate)=(SELECT W FROM [crmrevo].BI.Mst_Calendar_Week v WITH(NOLOCK) WHERE f.ActualTransferDate Between v.StartDate and v.EndDate))
		)
and uu.[key] Not In('4','3') and u.EndProductDate Between @StartDate and convert(datetime,convert(nvarchar(8),@EndDate,112)+' 23:59:59') and u.EndProductDate<>'20130930'
group by u.ProjectCRMCode

------------------------------------------------------------------------------------------------------------------------------------------
DECLARE @TQCPassAsOfWeek Table(Unit int,ProjectCRMCode nvarchar(50))
INSERT INTO @TQCPassAsOfWeek
SELECT Count(u.unitnumber ),u.ProjectCRMCode
FROM   DBLINK_SVR_QISV2.[db_QIS_V2].[dbo].[vw_EndProduct] u WITH(NOLOCK)
LEFT JOIN  #ICON_EntForms_Unit  uu WITH(NOLOCK) on u.wbs=uu.SAPWBSNo
LEFT JOIN #ICON_EntForms_Booking b WITH(NOLOCK) on b.UnitID=uu.id  and b.IsDeleted = 0 AND b.IsCancelled = 0
LEFT JOIN #ICON_EntForms_Agreement e WITH(NOLOCK) on e.BookingID = b.id and e.IsDeleted = 0 AND e.IsCancel = 0
LEFT JOIN #ICON_EntForms_Transfer f WITH(NOLOCK) on f.AgreementID=e.id
WHERE   uu.[key] Not In('4','3') and f.ActualTransferDate Is Null
group by u.ProjectCRMCode


INSERT INTO @TQCPassAsOfWeek
SELECT Count(u.unitnumber ),u.ProjectCRMCode
FROM   [DBLINK_SVR_CMIS].[db_QIS_H].[dbo].[vw_EndProduct] u WITH(NOLOCK)
LEFT JOIN  #ICON_EntForms_Unit  uu WITH(NOLOCK) on u.wbs=uu.SAPWBSNo
LEFT JOIN #ICON_EntForms_Booking b WITH(NOLOCK) on b.UnitID=uu.id  and b.IsDeleted = 0 AND b.IsCancelled = 0
LEFT JOIN #ICON_EntForms_Agreement e WITH(NOLOCK) on e.BookingID = b.id and e.IsDeleted = 0 AND e.IsCancel = 0
LEFT JOIN #ICON_EntForms_Transfer f WITH(NOLOCK) on f.AgreementID=e.id
WHERE   uu.[key] Not In('4','3') AND f.ActualTransferDate Is Null
group by u.ProjectCRMCode

------------------------------------------------------------------------------------------------------------------------------------------
UPDATE RPT_LeadIndicator
SET [Target]=ISNULL((SELECT Sum(ISNULL(Unit,0)) FROM #Mst_LeadIndicator_Target a WITH(NOLOCK) WHERE RecType='QCpass' and a.ProjectNO=t.ProjectID and t.Y=a.Y and t.W=a.W),0)
,Actual=ISNULL((SELECT Unit FROM @TQCPass tt WHERE tt.ProjectCRMCode=t.ProjectID),0)			
,AsOfWeek=ISNULL((SELECT Unit FROM @TQCPassAsOfWeek tt WHERE tt.ProjectCRMCode=t.ProjectID),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='QCPass'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in QCPass'

---------------- CheckUnit -----------------------
-- print('CheckUnit')
DECLARE @Defect Table(Unit int,ProductID nvarchar(50))
INSERT INTO @Defect
SELECT	Count(v.UnitNumber) AS Unit,v.ProductID
FROM	(
			SELECT Distinct convert(datetime,(convert(nvarchar(8),RAuditDate,112)))Check_Date,Unit UnitNumber,ProjectNo ProductID 
			FROM #vwCallDefectRoundAudit WITH(NOLOCK)
		) v
LEFT JOIN (SELECT a.*,b.UnitNo AS UnitNumber,p.ProjectNo AS ProductID FROM #ICON_EntForms_Booking a WITH(NOLOCK) INNER JOIN #ICON_EntForms_Unit b WITH(NOLOCK) ON a.UnitID = b.id  INNER JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON a.ProjectID = p.id WHERE a.IsDeleted = 0 AND a.IsCancelled = 0 ) b on b.UnitNumber=v.UnitNumber and b.ProductID=v.ProductID 
LEFT JOIN #ICON_EntForms_Agreement e WITH(NOLOCK) on e.BookingID = b.ID AND e.IsDeleted = 0 AND e.IsCancel = 0
LEFT JOIN #ICON_EntForms_Transfer f WITH(NOLOCK) ON f.AgreementID=e.id
WHERE	 Check_Date Between @StartDate and @EndDate and v.Check_Date<>'20130930'
and ((Check_Date<=ISNULL(f.ActualTransferDate ,@CurrentDate))
		or (f.ActualTransferDate IS NOT NULL and Year(Check_Date)=Year(f.ActualTransferDate)
			and (SELECT W FROM [crmrevo].BI.Mst_Calendar_Week v WITH(NOLOCK) WHERE Check_Date Between v.StartDate and v.EndDate)=(SELECT W FROM [crmrevo].BI.Mst_Calendar_Week v WITH(NOLOCK) WHERE f.ActualTransferDate Between v.StartDate and v.EndDate))
		)
group by v.ProductID

DECLARE @DefectAsOfWeek Table(Unit int,ProductID nvarchar(50))
INSERT INTO @DefectAsOfWeek
SELECT	Count(v.UnitNumber) AS Walk,v.ProductID
				FROM	(
							SELECT Distinct convert(datetime,(convert(nvarchar(8),RAuditDate,112)))Check_Date,Unit UnitNumber,ProjectNo ProductID 
							FROM #vwCallDefectRoundAudit WITH(NOLOCK)
						) v
			LEFT JOIN (SELECT a.*,b.UnitNo AS UnitNumber,p.ProjectNo AS ProductID FROM #ICON_EntForms_Booking a WITH(NOLOCK) INNER JOIN #ICON_EntForms_Unit b WITH(NOLOCK) ON a.UnitID = b.id  INNER JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON a.ProjectID = p.id WHERE a.IsDeleted = 0 AND a.IsCancelled = 0 ) b on b.UnitNumber=v.UnitNumber and b.ProductID=v.ProductID 
			LEFT JOIN #ICON_EntForms_Agreement e WITH(NOLOCK) on e.BookingID = b.ID AND e.IsDeleted = 0 AND e.IsCancel = 0
			LEFT JOIN #ICON_EntForms_Transfer f WITH(NOLOCK) ON f.AgreementID=e.id
			LEFT JOIN #ICON_EntForms_Unit uu WITH(NOLOCK) ON uu.id = b.UnitID
				WHERE	 Check_Date Between @StartDate and @EndDate and v.Check_Date<>'20130930'
				and  uu.[key] Not In('4','3') 
				and ((Check_Date<=ISNULL(f.ActualTransferDate ,@CurrentDate))
						or (f.ActualTransferDate IS NOT NULL and Year(Check_Date)=Year(f.ActualTransferDate)
							and (SELECT W FROM [crmrevo].BI.Mst_Calendar_Week v WITH(NOLOCK) WHERE Check_Date Between v.StartDate and v.EndDate)=(SELECT W FROM [crmrevo].BI.Mst_Calendar_Week v WITH(NOLOCK) WHERE f.ActualTransferDate Between v.StartDate and v.EndDate))
						)
group by v.ProductID


UPDATE RPT_LeadIndicator
SET [Target]=ISNULL((SELECT Sum(ISNULL(Unit,0)) FROM #Mst_LeadIndicator_Target a WITH(NOLOCK) WHERE RecType='Defect' and a.ProjectNo=t.ProjectID and t.Y=a.Y and t.W=a.W),0)
,Actual=ISNULL((SELECT Unit FROM @Defect tt WHERE tt.ProductID=t.ProjectID),0)
,AsOfWeek=ISNULL((SELECT Unit FROM @DefectAsOfWeek tt WHERE tt.ProductID=t.ProjectID),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='CheckUnit'
AND t.ProjectID in(SELECT p.ProjectNo FROM #ICON_EntForms_Products p WITH(NOLOCK) INNER JOIN [crmrevo].mst.MasterCenter m WITH(NOLOCK) ON p.ProductTypeMasterCenterID = m.id  WHERE m.[KEY] = '2')
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

Delete FROM @Defect
Delete FROM @DefectAsOfWeek
INSERT INTO @Defect
SELECT	Count(v.UnitNumber) AS Walk,v.ProductID
				FROM	(
							SELECT Min (convert(nvarchar(8),RAuditDate,112))Check_Date,Unit UnitNumber,ProjectNo ProductID 
							FROM #vwCallDefectRoundAudit WITH(NOLOCK) --WHERE RAuditDate>='20150601' and DocIsActive=1
							Group by Unit,ProjectNo
						)v
				LEFT JOIN (SELECT a.*,b.UnitNo AS UnitNumber,p.ProjectNo AS ProductID FROM #ICON_EntForms_Booking a WITH(NOLOCK) INNER JOIN #ICON_EntForms_Unit b WITH(NOLOCK) ON a.UnitID = b.id  INNER JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON a.ProjectID = p.id WHERE a.IsDeleted = 0 AND a.IsCancelled = 0 ) b on b.UnitNumber=v.UnitNumber and b.ProductID=v.ProductID 
				LEFT JOIN #ICON_EntForms_Agreement e WITH(NOLOCK) ON e.BookingID = b.ID AND e.IsDeleted = 0 AND e.IsCancel = 0
				LEFT JOIN #ICON_EntForms_Transfer f WITH(NOLOCK) ON f.AgreementID=e.id
				WHERE	 Check_Date Between @StartDate and @EndDate and v.Check_Date<>'20130930'
				and v.productID  in(SELECT p.ProjectNo FROM #ICON_EntForms_Products p WITH(NOLOCK) INNER JOIN [crmrevo].mst.MasterCenter m WITH(NOLOCK) ON p.ProductTypeMasterCenterID = m.id  WHERE m.[KEY] = '1')
				and ((Check_Date<=ISNULL(f.ActualTransferDate ,@CurrentDate))
						or (f.ActualTransferDate IS NOT NULL and Year(Check_Date)=Year(f.ActualTransferDate)
							and (SELECT W FROM [crmrevo].BI.Mst_Calendar_Week v WITH(NOLOCK) WHERE Check_Date Between v.StartDate and v.EndDate)=(SELECT W FROM [crmrevo].BI.Mst_Calendar_Week v WITH(NOLOCK) WHERE f.ActualTransferDate Between v.StartDate and v.EndDate))
						)
group by v.ProductID

INSERT INTO @DefectAsOfWeek
SELECT	Count(v.UnitNumber) AS Walk,v.ProductID
				FROM	(
							SELECT distinct (convert(nvarchar(8),RAuditDate,112))Check_Date,Unit UnitNumber,ProjectNo ProductID 
							FROM #vwCallDefectRoundAudit WITH(NOLOCK) --WHERE RAuditDate>='20150601' and DocIsActive=1
						)v
				LEFT JOIN (SELECT a.*,b.UnitNo AS UnitNumber,p.ProjectNo AS ProductID FROM #ICON_EntForms_Booking a WITH(NOLOCK) INNER JOIN #ICON_EntForms_Unit b WITH(NOLOCK) ON a.UnitID = b.id  INNER JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON a.ProjectID = p.id WHERE a.IsDeleted = 0 AND a.IsCancelled = 0 ) b on b.UnitNumber=v.UnitNumber and b.ProductID=v.ProductID 
				LEFT JOIN #ICON_EntForms_Agreement e WITH(NOLOCK) ON e.BookingID = b.ID AND e.IsDeleted = 0 AND e.IsCancel = 0
				LEFT JOIN #ICON_EntForms_Transfer f WITH(NOLOCK) ON f.AgreementID=e.id
				WHERE	 Check_Date Between @StartDate and @EndDate and v.Check_Date<>'20130930'
				and v.productID  in(SELECT p.ProjectNo FROM #ICON_EntForms_Products p WITH(NOLOCK) INNER JOIN [crmrevo].mst.MasterCenter m WITH(NOLOCK) ON p.ProductTypeMasterCenterID = m.id  WHERE m.[KEY] = '1')--and v.Check_Date>='20140701'
				and ((Check_Date<=ISNULL(f.ActualTransferDate ,@CurrentDate))
						or (f.ActualTransferDate IS NOT NULL and Year(Check_Date)=Year(f.ActualTransferDate)
							and (SELECT W FROM [crmrevo].BI.Mst_Calendar_Week v WITH(NOLOCK) WHERE Check_Date Between v.StartDate and v.EndDate)=(SELECT W FROM [crmrevo].BI.Mst_Calendar_Week v WITH(NOLOCK) WHERE f.ActualTransferDate Between v.StartDate and v.EndDate))
						)				
group by v.ProductID

UPDATE RPT_LeadIndicator
SET [Target]=ISNULL((SELECT Sum(ISNULL(Unit,0)) FROM #Mst_LeadIndicator_Target a WITH(NOLOCK) WHERE RecType='Defect' and a.ProjectNo=t.ProjectID and t.Y=a.Y and t.W=a.W),0)
,Actual=ISNULL((SELECT unit FROM @Defect tt WHERE tt.ProductID=t.ProjectID),0)
,AsOfWeek=ISNULL((SELECT unit FROM @DefectAsOfWeek tt WHERE tt.ProductID=t.ProjectID),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='CheckUnit'
AND t.ProjectID IN (SELECT p.ProjectNo FROM #ICON_EntForms_Products p WITH(NOLOCK) INNER JOIN [crmrevo].mst.MasterCenter m WITH(NOLOCK) ON p.ProductTypeMasterCenterID = m.id  WHERE m.[KEY] = '1')
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in CheckUnit'

---------------- AcceptUnit -----------------------
Delete FROM @Defect
Delete FROM @DefectAsOfWeek
INSERT INTO @Defect
SELECT	Count(Distinct v.UnitNumber) AS Walk,v.ProjectID
				FROM	(
							SELECT distinct (convert(nvarchar(8),DocReceiveUnitDate,112))ReceiveDate,SerialNO UnitNumber,ProjectNo ProjectID 
							FROM #vwCallDefectReceiveUnitDoc WITH(NOLOCK)
						) v				
				LEFT JOIN (SELECT a.*,b.UnitNo AS UnitNumber,p.ProjectNo AS ProductID FROM #ICON_EntForms_Booking a WITH(NOLOCK) INNER JOIN #ICON_EntForms_Unit b WITH(NOLOCK) ON a.UnitID = b.id  INNER JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON a.ProjectID = p.id WHERE a.IsDeleted = 0 AND a.IsCancelled = 0 ) b on b.UnitNumber=v.UnitNumber and b.ProductID=v.ProjectID 
				LEFT JOIN #ICON_EntForms_Agreement e WITH(NOLOCK) on e.BookingID = b.ID AND e.IsDeleted = 0 AND e.IsCancel = 0
				LEFT JOIN #ICON_EntForms_Transfer f WITH(NOLOCK) on f.AgreementID=e.id
				WHERE	v.ReceiveDate Between @StartDate and  @EndDate and v.ReceiveDate<>'20130930'
				and ((v.ReceiveDate<=ISNULL(f.ActualTransferDate ,@CurrentDate))
						or (f.ActualTransferDate IS NOT NULL and Year(v.ReceiveDate)=Year(f.ActualTransferDate)
							and (SELECT Q FROM [crmrevo].BI.Mst_Calendar_Week vv WITH(NOLOCK) WHERE v.ReceiveDate Between vv.StartDate and vv.EndDate)=(SELECT Q FROM [crmrevo].BI.Mst_Calendar_Week v WITH(NOLOCK) WHERE f.ActualTransferDate Between v.StartDate and v.EndDate))
						)
group by v.ProjectID

INSERT INTO @DefectAsOfWeek
SELECT	Count(Distinct v.UnitNumber) AS Walk,v.ProjectID
				FROM	(
							SELECT distinct (convert(nvarchar(8),DocReceiveUnitDate,112))ReceiveDate,SerialNO UnitNumber,ProjectNo ProjectID 
							FROM #vwCallDefectReceiveUnitDoc WITH(NOLOCK)
						) v
					LEFT JOIN (SELECT a.*,b.UnitNo AS UnitNumber,p.ProjectNo AS ProductID FROM #ICON_EntForms_Booking a WITH(NOLOCK) INNER JOIN #ICON_EntForms_Unit b WITH(NOLOCK) ON a.UnitID = b.id  INNER JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON a.ProjectID = p.id WHERE a.IsDeleted = 0 AND a.IsCancelled = 0 ) b on b.UnitNumber=v.UnitNumber and b.ProductID=v.ProjectID 
					LEFT JOIN #ICON_EntForms_Agreement e WITH(NOLOCK) ON e.BookingID = b.ID AND e.IsDeleted = 0 AND e.IsCancel = 0
					LEFT JOIN #ICON_EntForms_Transfer f WITH(NOLOCK) on f.AgreementID=e.id
					LEFT JOIN #ICON_EntForms_Unit uu WITH(NOLOCK) on uu.id = b.UnitID
				WHERE uu.[key] Not In('4','3')  and f.ActualTransferDate Is Null
group by v.ProjectID

UPDATE RPT_LeadIndicator
SET [Target]=ISNULL((SELECT Sum(ISNULL(Unit,0)) FROM #Mst_LeadIndicator_Target a WITH(NOLOCK) WHERE RecType='Getroom' and a.ProjectNo=t.ProjectID and t.Y=a.Y and t.W=a.W),0)
,Actual=ISNULL((SELECT unit FROM @Defect tt WHERE tt.productid=t.projectid),0)
,AsOfWeek=ISNULL((SELECT unit FROM @DefectAsOfWeek tt WHERE tt.productid=t.projectid),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='AcceptUnit'
AND t.ProjectID in(SELECT p.ProjectNo FROM #ICON_EntForms_Products p WITH(NOLOCK) INNER JOIN [crmrevo].mst.MasterCenter m WITH(NOLOCK) ON p.ProductTypeMasterCenterID = m.id  WHERE m.[KEY] = '2')
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)



Delete FROM @Defect
Delete FROM @DefectAsOfWeek
INSERT INTO @Defect
SELECT	Count(Distinct v.UnitNumber) AS Walk,v.ProjectID
				FROM	(
							SELECT distinct (convert(nvarchar(8),DocReceiveUnitDate,112))ReceiveDate,SerialNO UnitNumber,ProjectNo ProjectID 
							FROM #vwCallDefectReceiveUnitDoc  a WITH(NOLOCK)
						) v
				LEFT JOIN (SELECT a.*,b.UnitNo AS UnitNumber,p.ProjectNo AS ProductID FROM #ICON_EntForms_Booking a WITH(NOLOCK) INNER JOIN #ICON_EntForms_Unit b WITH(NOLOCK) ON a.UnitID = b.id  INNER JOIN #ICON_EntForms_Products p  WITH(NOLOCK)ON a.ProjectID = p.id WHERE a.IsDeleted = 0 AND a.IsCancelled = 0 ) b on b.UnitNumber=v.UnitNumber and b.ProductID=v.ProjectID 
				LEFT JOIN #ICON_EntForms_Agreement e WITH(NOLOCK) on e.BookingID = b.ID AND e.IsDeleted = 0 AND e.IsCancel = 0
				LEFT JOIN #ICON_EntForms_Transfer f WITH(NOLOCK) on f.AgreementID=e.id			
				WHERE	v.ReceiveDate BETWEEN @StartDate and  @EndDate and v.ReceiveDate<>'20130930' 
				and v.ProjectID  in(SELECT p.ProjectNo FROM #ICON_EntForms_Products p WITH(NOLOCK) INNER JOIN [crmrevo].mst.MasterCenter m WITH(NOLOCK) ON p.ProductTypeMasterCenterID = m.id  WHERE m.[KEY] = '1')
				and ((v.ReceiveDate<=ISNULL(f.ActualTransferDate ,@CurrentDate))
						or (f.ActualTransferDate IS NOT NULL and Year(v.ReceiveDate)=Year(f.ActualTransferDate)
							and (SELECT Q FROM [crmrevo].BI.Mst_Calendar_Week vv WITH(NOLOCK) WHERE v.ReceiveDate Between vv.StartDate and vv.EndDate)=(SELECT Q FROM [crmrevo].BI.Mst_Calendar_Week v WITH(NOLOCK) WHERE f.ActualTransferDate Between v.StartDate and v.EndDate))
						)
group by v.ProjectID

INSERT INTO @DefectAsOfWeek
SELECT	Count(Distinct v.UnitNumber) AS Walk,v.ProjectID
				FROM	(
							SELECT distinct (convert(nvarchar(8),DocReceiveUnitDate,112))ReceiveDate,SerialNO UnitNumber,ProjectNo ProjectID 
							FROM #vwCallDefectReceiveUnitDoc a WITH(NOLOCK)
						) v
					LEFT JOIN (SELECT a.*,b.UnitNo AS UnitNumber,p.ProjectNo AS ProductID FROM #ICON_EntForms_Booking a WITH(NOLOCK) INNER JOIN #ICON_EntForms_Unit b WITH(NOLOCK) ON a.UnitID = b.id  INNER JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON a.ProjectID = p.id WHERE a.IsDeleted = 0 AND a.IsCancelled = 0 ) b on b.UnitNumber=v.UnitNumber and b.ProductID=v.ProjectID 
					LEFT JOIN #ICON_EntForms_Agreement e WITH(NOLOCK) ON e.BookingID = b.ID AND e.IsDeleted = 0 AND e.IsCancel = 0
					LEFT JOIN #ICON_EntForms_Transfer f WITH(NOLOCK) ON f.AgreementID=e.id			
					LEFT JOIN #ICON_EntForms_Unit uu WITH(NOLOCK) on uu.id = b.UnitID
				WHERE	 uu.[key] Not In('4','3')  and f.ActualTransferDate Is Null
group by v.ProjectID

UPDATE RPT_LeadIndicator
SET [Target]=ISNULL((SELECT Sum(ISNULL(Unit,0)) FROM #Mst_LeadIndicator_Target a WITH(NOLOCK) WHERE RecType='Getroom' and a.ProjectNo=t.ProjectID and t.Y=a.Y and t.W=a.W),0)
,Actual=ISNULL((SELECT unit FROM @Defect tt WHERE tt.productid=t.projectid),0)
,AsOfWeek=ISNULL((SELECT unit FROM @DefectAsOfWeek tt WHERE tt.productid=t.projectid),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='AcceptUnit'
AND t.ProjectID IN (SELECT p.ProjectNo FROM #ICON_EntForms_Products p WITH(NOLOCK) INNER JOIN [crmrevo].mst.MasterCenter m  WITH(NOLOCK) ON p.ProductTypeMasterCenterID = m.id  WHERE m.[KEY] = '1')
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in AcceptUnit'

-- print('BankApprove')
UPDATE RPT_LeadIndicator
SET [Target]=ISNULL((SELECT Sum(ISNULL(Unit,0)) FROM #Mst_LeadIndicator_Target a WITH(NOLOCK) WHERE RecType='BankApprove' and a.ProjectNo=t.ProjectID and t.Y=a.Y and t.W=a.W),0)
,Actual=ISNULL((Case When @W<@CurrentWeek Then ISNULL((SELECT Count(Distinct aa.AgreementNo)
				FROM  #TempBankapprove aa WITH(NOLOCK)		
				WHERE ((ISNULL(aa.[key],4) IN (2,3)  and aa.ResultDate Between @StartDate and convert(datetime,convert(nvarchar(8),@EndDate,112)+' 23:59:59') )or(ISNULL(aa.[key],4) IN (1)
				AND aa.CreditBankingDate Between @StartDate and convert(datetime,convert(nvarchar(8),@EndDate,112)+' 23:59:59')
				))					
					and aa.ProjectNo = t.ProjectID 
					),0)
		Else 0 END)	,0)
,AsOfWeek=Case When @W<@CurrentWeek Then ISNULL((SELECT Count(Distinct aa.AgreementNo)
				FROM  #TempBankapprove aa WITH(NOLOCK)		
				WHERE ((ISNULL(aa.[key],4) IN (2,3) ) OR(ISNULL(aa.[key],4)  IN (1)))
					and aa.ProjectNo = t.ProjectID 
					AND aa.ActualTransferDate IS NULL),0)
			Else 0 END
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W  
AND RecType='BankApprove'
AND t.ProjectID in(SELECT p.ProjectNo FROM #ICON_EntForms_Products p WITH(NOLOCK) INNER JOIN [crmrevo].mst.MasterCenter m WITH(NOLOCK) ON p.ProductTypeMasterCenterID = m.id  WHERE m.[KEY] = '1')
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

UPDATE RPT_LeadIndicator
SET [Target]=ISNULL((SELECT Sum(ISNULL(Unit,0)) FROM #Mst_LeadIndicator_Target a WITH(NOLOCK) WHERE RecType='BankApprove' and a.ProjectNo=t.ProjectID and t.Y=a.Y and t.W=a.W),0)
-------------ใช้สูตรเป็นยอดสะสม----------------------------------
,Actual=ISNULL((Case When @W<@CurrentWeek Then ISNULL((SELECT Count(Distinct a.AgreementNo)
				 FROM  #ICON_EntForms_Agreement a WITH(NOLOCK)
				LEFT JOIN #ICON_EntForms_Unit uu WITH(NOLOCK) ON a.UnitID = uu.id
				LEFT JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON a.ProjectID = p.id 
				LEFT JOIN #CreditBanking CB WITH(NOLOCK) ON a.BookingID = cb.BookingID
				LEFT JOIN #DocumentChecklist   dc ON a.BookingID = DC.id
				LEFT JOIN #ICON_EntForms_Transfer tr WITH(NOLOCK) ON tr.AgreementID = a.id AND tr.ActualTransferDate <=@EndDate
				WHERE a.IsCancel = 0 AND A.ContractDate IS NOT NULL AND  uu.[Key] Not In('4','3')
				and ((ISNULL(dc.[key],4) IN (2,3)  and cb.ResultDate <= convert(datetime,convert(nvarchar(8),@EndDate,112)+' 23:59:59')  )or(ISNULL(dc.[key],4) IN (1)
				AND dc.CreditBankingDate <= convert(datetime,convert(nvarchar(8),@EndDate,112)+' 23:59:59') ))			
					and p.ProjectNo = t.ProjectID  AND tr.agreementid  IS null
				),0)
 Else 0 END),0)
,AsOfWeek=Case When @W<@CurrentWeek Then ISNULL((SELECT Count(Distinct aa.AgreementNo)
				FROM  #TempBankapprove aa
				WHERE ((ISNULL(aa.[key],4) IN (2,3) )or(ISNULL(aa.[key],4) IN (1)))
					and aa.ProjectNo = t.ProjectID 
					AND aa.ActualTransferDate IS NULL),0)
			Else 0 END
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND @W<@CurrentWeek and RecType='BankApprove'
AND t.ProjectID in(SELECT p.ProjectNo FROM #ICON_EntForms_Products p WITH(NOLOCK) INNER JOIN [crmrevo].mst.MasterCenter m WITH(NOLOCK) ON p.ProductTypeMasterCenterID = m.id  WHERE m.[KEY] = '2')
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

UPDATE RPT_LeadIndicator
SET [Target]=ISNULL((SELECT Sum(ISNULL(Unit,0)) FROM #Mst_LeadIndicator_Target a WITH(NOLOCK) WHERE RecType='BankApprove' and a.ProjectNo=t.ProjectID and t.Y=a.Y and t.W=a.W),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='BankApprove'
AND t.ProjectID in(SELECT p.ProjectNo FROM #ICON_EntForms_Products p WITH(NOLOCK) INNER JOIN [crmrevo].mst.MasterCenter m WITH(NOLOCK) ON p.ProductTypeMasterCenterID = m.id  WHERE m.[KEY] = '2')
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

UPDATE RPT_LeadIndicator
SET AsOfWeek=ISNULL((SELECT top 1 AsOfWeek FROM RPT_LeadIndicator tt WITH(NOLOCK) WHERE tt.Y=@Y and tt.W=@CurrentWeek-1 and RecType='BankApprove'and tt.ProjectID=t.ProjectID ),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W and @W<@CurrentWeek 
AND RecType='BankApprove'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in BankApprove'

------------ BC -----------------------
-- print('BC')
UPDATE RPT_LeadIndicator
SET [Target]=ISNULL((SELECT Sum(ISNULL(Unit,0)) FROM #Mst_LeadIndicator_Target a WITH(NOLOCK) WHERE RecType='BC_Target' and a.ProjectNo=t.ProjectID and t.Y=a.Y and t.W=a.W),0)
,Actual=ISNULL((SELECT Sum(ISNULL(Unit,0)) FROM #Mst_LeadIndicator_Target a WITH(NOLOCK) WHERE RecType='BC_Actual' and a.ProjectNo=t.ProjectID and t.Y=a.Y and t.W=a.W),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='BC'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in BC'

-------------- Gross PresalesAmount -----------------------
-- print('GrossPresalesAmount')
DECLARE @Booking Table (UnitAmt Int,BKPrice Money,Project nvarchar(100),BookingDate DateTime)
	INSERT INTO @Booking (UnitAmt,BKPrice,Project,BookingDate)
	SELECT	ISNULL(SUM(B.UnitAmt),0) AS TotalUnit,ISNULL(Sum(B.BKPrice),0)  AS TotalPrice,p.ProjectNo ,b.BookingDate
	FROM	#vw_RPTAP2_ExV4Booking B WITH(NOLOCK)
	LEFT JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON b.ProjectID = p.id 
	WHERE	1=1 
	GROUP BY p.ProjectNo,b.BookingDate

--------------------------------vw_RPTAP2_ExV4BookingCancel----------------
DECLARE @BookingCancel Table (UnitAmt Int,BKPrice Money,Project nvarchar(100),CancelDate DateTime)
INSERT INTO @BookingCancel (UnitAmt,BKPrice,Project,CancelDate)
SELECT	ISNULL(SUM(B.UnitAmt),0) AS TotalUnit,ISNULL(Sum(B.BKPrice),0) AS TotalPrice,p.ProjectNo ProductID,CancelDate
FROM	#vw_RPTAP2_ExV4BookingCancel B WITH(NOLOCK)
LEFT JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON b.ProjectID = p.id
WHERE	1=1 
GROUP BY p.ProjectNo ,CancelDate

-----------------------------------#Temp_Subtract---------------------------------------------
IF(OBJECT_ID('tempdb..#Temp_Subtract')IS NOT NULL)DROP TABLE #Temp_Subtract
SELECT ProjectNo
,'SubtractGrossBookingAmount'=Sum(SubtractGrossBookingAmount) ,'SubtractGrossBookingUnit'=Sum(SubtractGrossBookingUnit)
,'SubtractCancelAmount'=Sum(SubtractCancelAmount) ,'SubtractCancelUnit'=Sum(SubtractCancelUnit)
INTO #Temp_Subtract
FROM #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract WITH(NOLOCK)
WHERE 1=1 
	and BookingDate between @StartDate and @EndDate
Group by ProjectNo

IF(OBJECT_ID('tempdb..#Temp_Subtract_Cancel')IS NOT NULL)DROP TABLE #Temp_Subtract_Cancel
SELECT ProjectNo,'SubtractCancelAmount'=Sum(SubtractCancelAmount) ,'SubtractCancelUnit'=Sum(SubtractCancelUnit) 
INTO #Temp_Subtract_Cancel 
FROM(
	SELECT ProjectNo
	,'SubtractCancelAmount'=Sum(SubtractCancelAmount) ,'SubtractCancelUnit'=Sum(1)
	FROM #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract WITH(NOLOCK)
	WHERE 1=1 
	and ((Convert(nvarchar(8),BookingDate,112) between @StartDate and @EndDate and BookingType='จองพิเศษ'))
	Group by ProjectNo
	UNION
	SELECT ProjectNo
	,'SubtractCancelAmount'=Sum(SubtractCancelAmount) ,'SubtractCancelUnit'=Sum(SubtractCancelUnit)
	FROM #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract a WITH(NOLOCK)
	WHERE 1=1 
		and ( (Convert(nvarchar(8),BookingCancelDate,112) between @StartDate and @EndDate and CurrentStatus='ยกเลิก'))
		and (BookingDate>=@StartDate or BookingType<>'จองพิเศษ')
		and not exists(SELECT *
				FROM #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract b WITH(NOLOCK)
				WHERE 1=1 
					and ((Convert(nvarchar(8),BookingDate,112) between @StartDate and @EndDate and BookingType='จองพิเศษ'))
					and a.BookingNumber=b.BookingNumber)
	Group by ProjectNo
)t
Group by ProjectNo


UPDATE RPT_LeadIndicator
SET  [Target]=0
,Actual=((ISNULL((SELECT Sum(ISNULL(B.BKPrice,0))
						  FROM @Booking B
						  WHERE 1=1 AND B.BookingDate Between @StartDate and @EndDate
						  AND b.Project = t.ProjectID
						  GROUP BY B.Project),0)
					-
					ISNULL((SELECT sum(SubtractGrossBookingAmount) 
							FROM #Temp_Subtract aa WITH(NOLOCK)
							WHERE aa.ProjectNo=t.ProjectID
							 GROUP BY aa.ProjectNo),0) ) 
				+
				ISNULL((SELECT sum((b.AgreementPrice - ISNULL(CashDiscount,0)) -ISNULL(b.TransferDiscount,0))AS BookingOfflinePrice_NotConfirm
				FROM #ZTEMP_Booking b WITH(NOLOCK)
				LEFT JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON b.ProjectID = p.id 
				WHERE p.projectno = t.ProjectID
					and dbo.fn_ClearTime(BookingDate) Between @StartDate and @EndDate and BookingDate<>'20130930'
				GROUP BY ProjectID ),0)			
				)/1000000
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='GrossPresalesAmount'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in GrossPresalesAmount'

-------------- Gross PresalesUnit -----------------------
-- print('GrossPresalesUnit')
UPDATE RPT_LeadIndicator
SET  [Target]=0
,Actual=(ISNULL((SELECT SUM(ISNULL(B.UnitAmt,0))
						  FROM @Booking B
						  WHERE 1=1 AND B.BookingDate Between @StartDate and @EndDate 
						    AND b.Project = t.ProjectID
						  GROUP BY B.Project),0)
				- ISNULL((SELECT (SubtractGrossBookingUnit) FROM #Temp_Subtract aa WITH(NOLOCK) WHERE aa.ProjectNo=t.ProjectID),0) )
				+
				ISNULL((SELECT COUNT(unitID)
				FROM #ZTEMP_Booking b WITH(NOLOCK)
				LEFT JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON b.ProjectID = p.id 
				WHERE  p.projectNO  =t.ProjectID 
					and dbo.fn_ClearTime(BookingDate) Between @StartDate and @EndDate and BookingDate<>'20130930'
				GROUP BY ProjectID ),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='GrossPresalesUnit'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in GrossPresalesUnit'

-------------- PreCancelAmount 
-- print('PreCancelAmount')
UPDATE RPT_LeadIndicator
SET [Target]=0
,Actual= ISNULL((SELECT SUM(Amount)/1000000 FROM [DBLINK_SVR_BI].[AP_STG].dbo.RPT_PreCancel_V2 tt  WITH(NOLOCK) WHERE tt.ProductID=t.ProjectID and tt.Y=t.Y and tt.W=t.W and status='Revert'),0)
+ISNULL((SELECT SUM(Amount)/1000000 FROM [DBLINK_SVR_BI].[AP_STG].dbo.RPT_PreCancel_V2 tt WITH(NOLOCK) WHERE tt.ProductID=t.ProjectID and tt.Y=t.Y and tt.W=t.W and status='PreCancel'),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND t.RecType='PreCancelAmount'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in PreCancelAmount'

-------------- PreCancelUnit 
-- print('PreCancelUnit')
UPDATE RPT_LeadIndicator
SET [Target]=0
,Actual=ISNULL((SELECT Count(Amount) FROM [DBLINK_SVR_BI].[AP_STG].dbo.RPT_PreCancel_V2 tt WITH(NOLOCK) WHERE tt.ProductID=t.ProjectID and tt.Y=t.Y and tt.W=t.W and status='Revert'),0)
- ISNULL((SELECT Count(Amount) FROM [DBLINK_SVR_BI].[AP_STG].dbo.RPT_PreCancel_V2 tt WITH(NOLOCK) WHERE tt.ProductID=t.ProjectID and tt.Y=t.Y and tt.W=t.W and status='PreCancel'),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND t.RecType='PreCancelUnit'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

UPDATE RPT_LeadIndicator 
SET AsOfWeek=0
WHERE rectype in('precancelunit','precancelamount')

UPDATE RPT_LeadIndicator 
SET AsOfWeek=ISNULL((SELECT count(*) FROM [DBLINK_SVR_BI].[AP_STG].dbo.RPT_PreCancel_V2 tt WITH(NOLOCK) WHERE isprecancel=1 and tt.productid=t.projectid),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@currentY and t.W=@currentW 
AND t.rectype='precancelunit'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

UPDATE RPT_LeadIndicator 
SET AsOfWeek=ISNULL((SELECT sum(amount)/1000000 FROM [DBLINK_SVR_BI].[AP_STG].dbo.RPT_PreCancel_V2 tt WITH(NOLOCK) WHERE isprecancel=1 and tt.productid=t.projectid),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@currentY and t.W=@currentW 
AND t.rectype='precancelamount' 
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in PreCancelUnit'

-------------- Net PresalesAmount -----------------------
-- print('NetPresalesAmount')
UPDATE RPT_LeadIndicator
SET [Target]=ISNULL((SELECT Sum(ISNULL(Amount,0)) FROM #Mst_LeadIndicator_Target a WITH(NOLOCK) WHERE RecType='Presales' and a.ProjectNo=t.ProjectID and t.Y=a.Y and t.W=a.W),0)/1000000
,Actual=(
				ISNULL((Select Sum(b.Actual) From RPT_LeadIndicator b Where  b.ProjectID=t.ProjectID AND b.RecType = 'GrossPresalesAmount' AND b.y = t.y AND b.w = t.w),0)
				-
				((ISNULL((SELECT ISNULL(Sum(BC.BKPrice),0)
								FROM	@BookingCancel BC
								WHERE	1=1	AND BC.CancelDate Between @StartDate and @EndDate
								 AND bc.Project = t.ProjectID
								GROUP BY BC.Project),0)
					-
					ISNULL((SELECT sum(SubtractCancelAmount) FROM #Temp_Subtract_Cancel aa WITH(NOLOCK) WHERE aa.ProjectNo=t.ProjectID),0))
				+
				ISNULL((SELECT sum(ISNULL(b.TotalPrice,0)) AS BookingOfflinePrice_NotConfirm
				FROM #ZTEMP_Booking b WITH(NOLOCK)
				LEFT JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON b.ProjectID = p.id 
				WHERE  p.projectNO  =t.ProjectID 
					and dbo.fn_ClearTime(BookingDate) Between @StartDate and @EndDate and BookingDate<>'20130930'
				GROUP BY ProjectID  ),0))/1000000
				)
FROM RPT_LeadIndicator t
WHERE t.Y=@Y and t.W=@W 
AND RecType='NetPresalesAmount'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in NetPresalesAmount'

-------------- Net PresalesUnit -----------------------
-- print('NetPresalesUnit')
UPDATE RPT_LeadIndicator
SET [Target]=ISNULL((SELECT Sum(ISNULL(Unit,0)) FROM #Mst_LeadIndicator_Target a WITH(NOLOCK) WHERE RecType='Presales'  AND a.ProjectNo = t.ProjectID and t.Y=a.Y and t.W=a.W),0)
,Actual=(
  
				ISNULL((SELECT Sum(b.Actual) FROM RPT_LeadIndicator b WITH(NOLOCK) WHERE  b.ProjectID=t.ProjectID AND b.RecType = 'GrossPresalesUnit' AND b.y = t.y AND b.w = t.w),0)
				-
				(ISNULL((	SELECT	'TotalUnit'=ISNULL(SUM(BC.UnitAmt),0)
						FROM	@BookingCancel BC
						WHERE	1=1	AND BC.CancelDate Between @StartDate and @EndDate
						  AND bc.Project = t.ProjectID
						GROUP BY BC.Project),0)
					- ISNULL((SELECT sum(ISNULL(SubtractCancelUnit,0)) FROM #Temp_Subtract_Cancel aa WITH(NOLOCK) WHERE aa.ProjectNo=t.ProjectID),0))
				+
				ISNULL((SELECT COUNT(UnitID)
			FROM #ZTEMP_Booking b WITH(NOLOCK)
				LEFT JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON b.ProjectID = p.id 
				WHERE  p.projectNO  = t.ProjectID 
				and dbo.fn_ClearTime(BookingDate) Between @StartDate and @EndDate and BookingDate<>'20130930'
				GROUP BY ProjectID  ),0)
				 )
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='NetPresalesUnit'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in NetPresalesUnit'

---------------- NetPresales_PreCancelUnit -----------------------
UPDATE RPT_LeadIndicator
SET [Target]=0
,Actual=ISNULL((SELECT Actual FROM	RPT_LeadIndicator v WITH(NOLOCK) WHERE v.ProjectID=t.ProjectID and RecType='NetPresalesUnit' and t.Y=v.Y and t.W=v.W),0)
+ ISNULL((SELECT Actual FROM	RPT_LeadIndicator v WITH(NOLOCK) WHERE	v.ProjectID=t.ProjectID and RecType='PreCancelUnit' and t.Y=v.Y and t.W=v.W),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='NetPresales_PreCancelUnit'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in NetPresales_PreCancelUnit'

---------------- NetPresales_PreCancelAmount -----------------------
UPDATE RPT_LeadIndicator
SET [Target]=0
,Actual=ISNULL((SELECT	Actual FROM	RPT_LeadIndicator v WITH(NOLOCK) WHERE	v.ProjectID=t.ProjectID and RecType='NetPresalesAmount' and t.Y=v.Y and t.W=v.W),0)
+ ISNULL((SELECT Actual FROM RPT_LeadIndicator v WITH(NOLOCK) WHERE	v.ProjectID=t.ProjectID and RecType='PreCancelAmount' and t.Y=v.Y and t.W=v.W),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='NetPresales_PreCancelAmount'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in NetPresales_PreCancelAmount'

---------------- Walk -----------------------
-- print('Walk')
DECLARE @Tmp Table(Project nvarchar(50),Walk int)

INSERT INTO @Tmp
SELECT	Project,Sum(WalkAmt) AS Walk
FROM	(SELECT Project,ContactNo,Min(CreateDate)CreateDate,1 WalkAmt FROM #vw_CRM_Walk_1  WITH(NOLOCK) GROUP by Project,ContactNo) v 
WHERE	v.CreateDate<>'20130930'
and dbo.fn_ClearTime(v.CreateDate) Between @StartDate and @EndDate
Group by Project

UPDATE RPT_LeadIndicator
SET [Target]=ISNULL((SELECT Sum(ISNULL(Unit,0)) FROM #Mst_LeadIndicator_Target a WITH(NOLOCK) WHERE RecType='Walk' and a.ProjectNo =t.ProjectID and t.Y=a.Y and t.W=a.W),0)
,Actual=ISNULL((SELECT	Walk FROM	@tmp v WHERE	v.Project=t.ProjectID),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='Walk'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in Walk'

---------------- Walk2 -----------------------
-- print('Walk2')
Delete FROM @Tmp

INSERT INTO @Tmp -- หา Revisit
SELECT DISTINCT ta.Projectid,COUNT(*) AS Revisit
FROM #CRM_Opportunities TA WITH(NOLOCK)
INNER JOIN #CRM_Activity AC WITH(NOLOCK) ON TA.id =  AC.OpportunityID  AND ta.IsDeleted = 0 AND ac.IsDeleted = 0
WHERE dbo.fn_ClearTime(ISNULL(AC.UPDATEd,AC.Created))<>'20130930'
and dbo.fn_ClearTime(ISNULL(AC.ActualDate,AC.Created)) Between @StartDate and @EndDate
Group by ta.Projectid

UPDATE RPT_LeadIndicator
SET [Target]=ISNULL((SELECT Sum(ISNULL(Unit,0)) FROM #Mst_LeadIndicator_Target a WITH(NOLOCK) WHERE RecType='Revisit' and a.ProjectNo=t.ProjectID and t.Y=a.Y and t.W=a.W),0)
,Actual=ISNULL((SELECT	Sum(Walk) FROM	@tmp v LEFT JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON v.Project = p.id  WHERE	p.ProjectNo=t.ProjectID),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='Walk2'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in Walk2'

----------------Conversion---------------------------
-- print('Conversion')
UPDATE RPT_LeadIndicator
SET [Target]=Case When ISNULL((SELECT Sum([Target]) FROM RPT_LeadIndicator tt WITH(NOLOCK) WHERE RecType='NetPresalesUnit' and tt.ProjectID=t.ProjectID and t.Y=tt.Y and t.W=tt.W),0)<>0 
				Then (ISNULL((SELECT Sum([Target]) FROM RPT_LeadIndicator tt WITH(NOLOCK) WHERE RecType='Walk' and tt.ProjectID=t.ProjectID and t.Y=tt.Y and t.W=tt.W),0)
				+ ISNULL((SELECT Sum([Target]) FROM RPT_LeadIndicator tt WITH(NOLOCK) WHERE RecType='Walk2' and tt.ProjectID=t.ProjectID and t.Y=tt.Y and t.W=tt.W),0))
					/ISNULL((SELECT Sum([Target]) FROM RPT_LeadIndicator tt WITH(NOLOCK) WHERE RecType='NetPresalesUnit' and tt.ProjectID=t.ProjectID and t.Y=tt.Y and t.W=tt.W),0)
				Else 0 End
,Actual=Case When ISNULL((SELECT Sum(Actual) FROM RPT_LeadIndicator tt WITH(NOLOCK) WHERE RecType='NetPresalesUnit' and tt.ProjectID=t.ProjectID and t.Y=tt.Y and t.W=tt.W),0)<>0 
				Then (ISNULL((SELECT Sum(Actual) FROM RPT_LeadIndicator tt WITH(NOLOCK) WHERE RecType='Walk' and tt.ProjectID=t.ProjectID and t.Y=tt.Y and t.W=tt.W),0)
				+ ISNULL((SELECT Sum(Actual) FROM RPT_LeadIndicator tt WITH(NOLOCK) WHERE RecType='Walk2' and tt.ProjectID=t.ProjectID and t.Y=tt.Y and t.W=tt.W),0))
					/ISNULL((SELECT Sum(Actual) FROM RPT_LeadIndicator tt WITH(NOLOCK) WHERE RecType='NetPresalesUnit' and tt.ProjectID=t.ProjectID and t.Y=tt.Y and t.W=tt.W),0)
				Else 0 END
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='Conversion'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in Conversion'

-- print('GrossPresales')
UPDATE RPT_LeadIndicator
SET [Target]=0
,Actual=(ISNULL((SELECT COUNT(unitID)
				FROM #ICON_EntForms_Booking BK WITH(NOLOCK)
				LEFT JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON p.id = bk.ProjectID
				WHERE ((ISNULL(BK.IsFROMChangeUnit, 0) = 0) AND (ISNULL(BK.CancelType, 0) = 0) 
			  OR ((ISNULL(BK.CancelType, 0) = 2) AND (BK.ChangeFROMBookingID IS NULL))
			  OR ((ISNULL(BK.IsFROMChangeUnit, 0) = 0) AND (ISNULL(BK.CancelType, 0) IN (3, 1)) AND (BK.ChangeFROMBookingID IS NULL)))
				  and dbo.fn_ClearTime(BK.BookingDate) Between @StartDate and @EndDate and BookingDate <> '20130930'
				  and p. proJectNO =t.ProjectID
				GROUP BY BK.projectID),0)   
				+
				ISNULL((SELECT COUNT(UnitID)
			FROM #ZTEMP_Booking b WITH(NOLOCK)
				LEFT JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON b.ProjectID = p.id 
				WHERE  p.projectNO  = t.ProjectID 
				and dbo.fn_ClearTime(BookingDate) Between @StartDate and @EndDate and BookingDate <>'20130930'
				GROUP BY ProjectID  ),0))
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W 
AND RecType='GrossPresales'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in GrossPresales'

-- print('Div')
UPDATE RPT_LeadIndicator
SET [Target]=ISNULL((SELECT Sum([Target])[Target] FROM RPT_LeadIndicator a WITH(NOLOCK) WHERE a.ProjectID=t.ProjectID and a.Y=@Y and a.W=@W and a.RecType='NetPresalesUnit'),0)
,Actual=ISNULL((SELECT Sum(Actual)Actual FROM RPT_LeadIndicator a WITH(NOLOCK) WHERE a.ProjectID=t.ProjectID and a.Y=@Y and a.W=@W and a.RecType='NetPresalesUnit'),0)
FROM RPT_LeadIndicator t WITH(NOLOCK)
WHERE t.Y=@Y and t.W=@W and RecType='Div'
AND ('All' = @ProjectID OR t.ProjectID = @ProjectID)

PRINT '[+] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: After Update Value in Div'

IF(ISNULL((SELECT Max(W) FROM [crmrevo].BI.Mst_Calendar_Week WITH(NOLOCK) WHERE Y=@Y) ,0)=@W) SET @currentW=@currentW+1 -- สำหรับกรณี week สุดท้ายของปี


UPDATE RPT_LeadIndicator
SET Actual2=Case When a.W=(SELECT Min(W) FROM [crmrevo].BI.Mst_Calendar_Week b WITH(NOLOCK) WHERE a.Y=b.Y and a.M=b.M)
Then ISNULL((SELECT Sum(Actual) 
		FROM RPT_LeadIndicator b WITH(NOLOCK)
		WHERE a.projectid=b.projectid and a.Y=b.Y and a.RecType=b.RecType
		and a.M=b.M and a.W<=b.W and b.W<@currentW),0)
		+
	ISNULL((SELECT Sum(b.Target) 
		FROM RPT_LeadIndicator b WITH(NOLOCK)
		WHERE a.projectid=b.projectid and a.Y=b.Y and a.RecType=b.RecType
		and a.M=b.M and b.W>=@currentW),0)
Else 0 END
FROM RPT_LeadIndicator a WITH(NOLOCK)
WHERE @currentY=Y


UPDATE RPT_LeadIndicator
SET YQ=convert(nvarchar(10),Y)+right('0'+convert(nvarchar(10),Q),2) 
,YM=convert(nvarchar(10),Y)+right('0'+convert(nvarchar(10),M),2)
,YW=convert(nvarchar(10),Y)+right('0'+convert(nvarchar(10),W),2)
FROM RPT_LeadIndicator a WITH(NOLOCK)


PRINT '[*] ' + FORMAT(CURRENT_TIMESTAMP ,'dd.MM.yy HH:mm:ss') + ':: End Process sp_RPT_LeadIndicator'


go

