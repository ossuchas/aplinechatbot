Create FUNCTION [dbo].[fn_AP_BI_GetFixDayOfDefect]
(
	@ProductID nvarchar(15),
	@UnitNumber nvarchar(15)
	
)
RETURNS int
AS
BEGIN
	DECLARE @NumberOfDefect int
	
	set @NumberOfDefect =0
	
	
	set @NumberOfDefect =(
	
SELECT DATEDIFF(day,b.RAuditDate ,isnull(b.RAuditCloseDate,getdate()))
	From (SELECT MAX(RAuditNo)RAuditNo, ProjectNo,Unit FROM [DBLINK_SVR_DEFECT].[defecttracking].[dbo].vwCallDefectRoundAudit WHERE   docisactive=1 GROUP BY ProjectNo,Unit  ) a
	LEFT JOIN [DBLINK_SVR_DEFECT].[defecttracking].[dbo].vwCallDefectRoundAudit b ON a.ProjectNo = b.ProjectNo AND a.Unit = b.Unit AND a.RAuditNo = b.RAuditNo
	where a.ProjectNo = @ProductID
	and a.Unit = @UnitNumber
	and docisactive=1)
	
	
	
	RETURN @NumberOfDefect
END
go

