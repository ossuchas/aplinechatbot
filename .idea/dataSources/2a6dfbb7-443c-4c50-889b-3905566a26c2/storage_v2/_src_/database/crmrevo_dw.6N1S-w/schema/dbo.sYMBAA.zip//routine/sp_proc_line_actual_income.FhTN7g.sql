

CREATE PROCEDURE [dbo].[sp_proc_line_actual_income]
AS
BEGIN
    SET NOCOUNT ON;
	
	--PRINT 'Actual Income'
	
	IF (OBJECT_ID('tempdb..#temp1') IS NOT NULL)
    DROP TABLE #temp1;

	SELECT a.PType, a.ProjectType, a.Years, a.Quarters, 
	CASE WHEN a.isJVStatus = 0 THEN 'AP' ELSE 'JV' END AS AP_JV,
	SUM(a.NetPriceExclFD) AS NetPriceExclFD 
	INTO #temp1
	FROM (
	SELECT p.ProjectNo AS ProductID , 
	p.ProjectNameTH AS ProjectName,
	SUBSTRING(p.[Group],1,1) AS PType,                                    
	crmrevo.dbo.fn_GetValueStatusByID('ProjectType', p.ProjectTypeMasterCenterID) AS ProjectType  ,                                      
	 u.UnitNo AS UnitNumber,
	 CAST(tr.ActualTransferDate AS DATE) TransferDateApprove,
	datepart(year, tr.ActualTransferDate) AS Years, 
	DATEPART(QUARTER, tr.ActualTransferDate) AS Quarters                
	 ,up.TotalPrice AS NetPrice
	,up.FreedownDiscount AS FreeDownAmount,
	 up.TotalPrice - up.FreedownDiscount AS NetPriceExclFD
	,(SELECT COUNT(*) FROM crmrevo.PRJ.TransferProjectJV t WITH(NOLOCK) WHERE CAST(t.EffectiveDate AS DATE) <= CAST(Tr.ActualTransferDate AS DATE)
				AND (t.ExpiredDate IS NULL OR CAST(t.ExpiredDate AS DATE) >= CAST(tr.ActualTransferDate AS DATE) ) 
				AND t.ProductID = p.ProjectNo) AS isJVStatus
	FROM    crmrevo.SAL.Transfer tr WITH(NOLOCK)       
			LEFT JOIN crmrevo.SAL.Agreement a WITH(NOLOCK) ON a.ID = tr.AgreementID AND a.IsDeleted = 0
		LEFT JOIN crmrevo.SAL.Booking b WITH(NOLOCK) ON a.BookingID = b.ID AND b.IsDeleted = 0
		LEFT JOIN crmrevo.SAL.UnitPrice up WITH(NOLOCK) ON up.BookingID = b.ID AND up.IsDeleted = 0 
			AND crmrevo.dbo.fn_GetValueStatusByID('UnitPriceStage', up.UnitPriceStageMasterCenterID) = 'โอน'
			LEFT JOIN crmrevo.PRJ.Project p WITH (NOLOCK) ON p.ID = a.ProjectID AND p.IsActive = 1 AND p.IsDeleted = 0 AND p.ProjectNo <> '99907' -- Project ซื้อคืน
		LEFT JOIN crmrevo.PRJ.Unit u WITH(NOLOCK) ON u.ID = a.UnitID AND a.ProjectID = u.ProjectID AND u.IsDeleted = 0
	WHERE   1=1               
	AND TR.IsDeleted = 0                                              
	AND TR.ActualTransferDate >= DATEADD(yy, DATEDIFF(yy, 0, GETDATE()), 0) ) AS a
	GROUP BY a.PType, a.ProjectType, a.Years, a.Quarters, 
	CASE WHEN a.isJVStatus = 0 THEN 'AP' ELSE 'JV' END

	--SELECT * FROM #temp1
	--SELECT NetPriceExclFD FROM #temp1 WHERE ProjectType = 'SH' AND years = 2019 AND Quarters = 4 AND AP_JV = 'AP'

	-- Update Data by Quarter and by AP/JV
	UPDATE dbo.crm_line_actual_income
	SET ap_bg1_q1 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE ProjectType = 'SH' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 1 AND AP_JV = 'AP'),0)
	,ap_bg2_q1 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE ProjectType = 'TH' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 1 AND AP_JV = 'AP'),0)
	,ap_bg3_q1 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE PType = 3 AND ProjectType = 'CD' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 1 AND AP_JV = 'AP'),0)
	,ap_bg4_q1 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE PType = 4 AND ProjectType = 'CD' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 1 AND AP_JV = 'AP'),0)
	,jv_bg3_q1 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE PType = 3 AND ProjectType = 'CD' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 1 AND AP_JV = 'JV'),0)
	,jv_bg4_q1 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE PType = 4 AND ProjectType = 'CD' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 1 AND AP_JV = 'JV'),0)
	--Q2
	,ap_bg1_q2 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE ProjectType = 'SH' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 2 AND AP_JV = 'AP'),0)
	,ap_bg2_q2 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE ProjectType = 'TH' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 2 AND AP_JV = 'AP'),0)
	,ap_bg3_q2 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE PType = 3 AND ProjectType = 'CD' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 2 AND AP_JV = 'AP'),0)
	,ap_bg4_q2 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE PType = 4 AND ProjectType = 'CD' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 2 AND AP_JV = 'AP'),0)
	,jv_bg3_q2 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE PType = 3 AND ProjectType = 'CD' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 2 AND AP_JV = 'JV'),0)
	,jv_bg4_q2 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE PType = 4 AND ProjectType = 'CD' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 2 AND AP_JV = 'JV'),0)
	--Q3
	,ap_bg1_q3 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE ProjectType = 'SH' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 3 AND AP_JV = 'AP'),0)
	,ap_bg2_q3 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE ProjectType = 'TH' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 3 AND AP_JV = 'AP'),0)
	,ap_bg3_q3 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE PType = 3 AND ProjectType = 'CD' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 3 AND AP_JV = 'AP'),0)
	,ap_bg4_q3 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE PType = 4 AND ProjectType = 'CD' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 3 AND AP_JV = 'AP'),0)
	,jv_bg3_q3 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE PType = 3 AND ProjectType = 'CD' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 3 AND AP_JV = 'JV'),0)
	,jv_bg4_q3 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE PType = 4 AND ProjectType = 'CD' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 3 AND AP_JV = 'JV'),0)
	--Q4
	,ap_bg1_q4 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE ProjectType = 'SH' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 4 AND AP_JV = 'AP'),0)
	,ap_bg2_q4 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE ProjectType = 'TH' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 4 AND AP_JV = 'AP'),0)
	,ap_bg3_q4 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE PType = 3 AND ProjectType = 'CD' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 4 AND AP_JV = 'AP'),0)
	,ap_bg4_q4 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE PType = 4 AND ProjectType = 'CD' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 4 AND AP_JV = 'AP'),0)
	,jv_bg3_q4 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE PType = 3 AND ProjectType = 'CD' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 4 AND AP_JV = 'JV'),0)
	,jv_bg4_q4 = ISNULL((SELECT NetPriceExclFD FROM #temp1 WHERE PType = 4 AND ProjectType = 'CD' AND years = DATEPART(YEAR,GETDATE()) AND Quarters = 4 AND AP_JV = 'JV'),0)
	WHERE trans_id = 1

	-- Update Total Sub Group by Quarter and by AP/JV
	UPDATE dbo.crm_line_actual_income
	SET ap_bg1_total = ap_bg1_q1 + ap_bg1_q2 + ap_bg1_q3 + ap_bg1_q4
	,ap_bg2_total = ap_bg2_q1 + ap_bg2_q2 + ap_bg2_q3 + ap_bg2_q4
	,ap_bg3_total = ap_bg3_q1 + ap_bg3_q2 + ap_bg3_q3 + ap_bg3_q4
	,ap_bg4_total = ap_bg4_q1 + ap_bg4_q2 + ap_bg4_q3 + ap_bg4_q4
	,ap_total_q4 = ap_bg1_q4 + ap_bg2_q4 + ap_bg3_q4 + ap_bg4_q4
	,jv_bg3_total = jv_bg3_q1 + jv_bg3_q2 + jv_bg3_q3 + jv_bg3_q4
	,jv_bg4_total = jv_bg4_q1 + jv_bg4_q2 + jv_bg4_q3 + jv_bg4_q4
	,jv_total_q4 = jv_bg3_q4 + jv_bg4_q4
	WHERE trans_id = 1

	
	--Update by Company Group AP/JV by Quarter
	UPDATE dbo.crm_line_actual_income
	SET ap_total_q1 = ap_bg1_q1 + ap_bg2_q1 + ap_bg3_q1 + ap_bg4_q1,
	ap_total_q2 = ap_bg1_q2 + ap_bg2_q2 + ap_bg3_q2 + ap_bg4_q2,
	ap_total_q3 = ap_bg1_q3 + ap_bg2_q3 + ap_bg3_q3 + ap_bg4_q3,
	ap_total_q4 = ap_bg1_q4 + ap_bg2_q4 + ap_bg3_q4 + ap_bg4_q4,
	jv_total_q1 = jv_bg3_q1 + jv_bg4_q1,
	jv_total_q2 = jv_bg3_q2 + jv_bg4_q2,
	jv_total_q3 = jv_bg3_q3 + jv_bg4_q3,
	jv_total_q4 = jv_bg3_q4 + jv_bg4_q4
	WHERE trans_id = 1


	--Update by Company Group AP/JV
	UPDATE dbo.crm_line_actual_income
	SET ap_total = ap_total_q1 + ap_total_q2 + ap_total_q3 + ap_total_q4
	,jv_total = jv_total_q1 + jv_total_q2 + jv_total_q3 + jv_total_q4
	WHERE trans_id = 1

	-- Update Grand Total
	UPDATE dbo.crm_line_actual_income
	SET grant_total_q1 = ap_total_q1 + jv_total_q1
	,grant_total_q2 = ap_total_q2 + jv_total_q2
	,grant_total_q3 = ap_total_q3 + jv_total_q3
	,grant_total_q4 = ap_total_q4 + jv_total_q4
	,grant_total = ap_total + jv_total
	,modifyby = 'batch', modifydate = GETDATE()
	WHERE trans_id = 1

END;



go

