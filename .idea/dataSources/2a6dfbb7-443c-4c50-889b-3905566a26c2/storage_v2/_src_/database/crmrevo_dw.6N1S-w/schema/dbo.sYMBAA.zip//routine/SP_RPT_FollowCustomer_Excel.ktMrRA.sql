CREATE PROCEDURE [dbo].[SP_RPT_FollowCustomer_Excel] @ProductID uniqueidentifier,
	@DateStart2 Datetime,-- actual date วันที่ทำจริง
	@DateEnd2 Datetime,
	@LCByProduct nvarchar(50)=''
	,@Username nvarchar(100)=''
	,@Disqualify nvarchar(10) = '1'  
	,@Lead nvarchar(10) = '1'  
	,@FirstWalk nvarchar(10) = '1'  
	,@Revisit nvarchar(10) = '1'  
	,@TaskLead1 nvarchar(10) = '1'  
	,@TaskLead2 nvarchar(10) = '1'  
	,@TaskLead3 nvarchar(10) = '1'  
	,@TaskLead4 nvarchar(10) = '1'  
	,@TaskWalk1 nvarchar(10) = '1'  
	,@TaskWalk2 nvarchar(10) = '1'  
	,@TaskWalk3 nvarchar(10) = '1'  
	,@TaskWalk4 nvarchar(10) = '1'  
	,@TaskWalk5 nvarchar(10) = '1'  
	,@TaskWalk6 nvarchar(10) = '1'  
	,@TaskRevisit1 nvarchar(10) = '1'  
	,@TaskRevisit2 nvarchar(10) = '1'  
	,@TaskRevisit3 nvarchar(10) = '1'  
	,@TaskRevisit4 nvarchar(10) = '1'  
	,@SessionID nvarchar(50)=''
	,@TaskWalkEnd nvarchar(10) = '1'  
AS

--DECLARE	@ProductID uniqueidentifier='BD7FA4B1-9D8F-4142-8F90-27634139B195'
--	,@DateStart2 Datetime ='20200927'-- actual date วันที่ทำจริง
--	,@DateEnd2 Datetime ='20200927'
--	,@LCByProduct nvarchar(50)=NULL
--	,@Username nvarchar(100)='TEST_FI'
--	,@Disqualify nvarchar(10) = '' 
--	,@Lead nvarchar(10)=''
--	,@FirstWalk nvarchar(10)='1'
--	,@Revisit nvarchar(10)='1'
--	,@TaskLead1 nvarchar(10)=''
--	,@TaskLead2 nvarchar(10)=''
--	,@TaskLead3 nvarchar(10)=''
--	,@TaskLead4 nvarchar(10)=''
--	,@TaskWalk1 nvarchar(10)='1'
--	,@TaskWalk2 nvarchar(10)='1'
--	,@TaskWalk3 nvarchar(10)='1'
--	,@TaskWalk4 nvarchar(10)='1'
--	,@TaskWalk5 nvarchar(10)='1'
--	,@TaskWalk6 nvarchar(10)='1'
--	,@TaskRevisit1 nvarchar(10)='1'
--	,@TaskRevisit2 nvarchar(10)='1'
--	,@TaskRevisit3 nvarchar(10)='1'
--	,@TaskRevisit4 nvarchar(10)='1'
--	,@SessionID nvarchar(50)=''
--	,@TaskWalkEnd nvarchar(10)=''
--Return ;
/*
IssuedStatus = Web,Call,First walk  :  Web,Call=>From Lead    First walk=>From Opp not have lead

*/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
Set @Lead = Isnull(@Lead,'')
Set @FirstWalk = Isnull(@FirstWalk,'')
Set @Revisit = Isnull(@Revisit,'')
Set @TaskLead1 = Isnull(@TaskLead1,'')
Set @TaskLead2 = Isnull(@TaskLead2,'')
Set @TaskLead3 = Isnull(@TaskLead3,'')
Set @TaskLead4 = Isnull(@TaskLead4,'')
Set @TaskWalk1 = Isnull(@TaskWalk1,'')
Set @TaskWalk2 = Isnull(@TaskWalk2,'')
Set @TaskWalk3 = Isnull(@TaskWalk3,'')
Set @TaskWalk4 = Isnull(@TaskWalk4,'')
Set @TaskWalk5 = Isnull(@TaskWalk5,'')
Set @TaskWalk6 = Isnull(@TaskWalk6,'')
Set @TaskWalkEnd = Isnull(@TaskWalkEnd,'1')
Set @TaskRevisit1 = Isnull(@TaskRevisit1,'')
Set @TaskRevisit2 = Isnull(@TaskRevisit2,'')
Set @TaskRevisit3 = Isnull(@TaskRevisit3,'')
Set @TaskRevisit4 = Isnull(@TaskRevisit4,'')
Set @Disqualify = Isnull(@Disqualify,'')

/* กรณี User เลือก Lead แต่ไม่ได้ติ๊ก Check Box ให้ Default ออกข้อมูลของ Lead ทั้งหมด*/
IF (@Lead <> '' AND @FirstWalk = '' AND @Revisit = '' AND @TaskLead1 = '' AND @TaskLead2 = '' AND @TaskLead3 = '' AND @TaskLead4 ='' )
Begin
set @TaskLead1 ='1'
set @TaskLead2 ='1'
set @TaskLead3 ='1'
set @TaskLead4 ='1';
End

/* กรณี User เลือก FirstWalk แต่ไม่ได้ติ๊ก Check Box ให้ Default ออกข้อมูลของ FirstWalk ทั้งหมด*/
Else IF (@Lead = '' AND @FirstWalk <> '' AND @Revisit = '' AND @TaskWalk1 = '' AND @TaskWalk2 = '' AND @TaskWalk3 = '' AND @TaskWalk4 ='' AND @TaskWalk5 = '' AND @TaskWalk6 ='')
Begin
set @TaskWalk1 ='1'
set @TaskWalk2 ='1'
set @TaskWalk3 ='1'
set @TaskWalk4 ='1'
set @TaskWalk5 ='1'
set @TaskWalk6 ='1';
End

/* กรณี User เลือก Revisit แต่ไม่ได้ติ๊ก Check Box ให้ Default ออกข้อมูลของ Revisit ทั้งหมด*/
Else IF (@Lead = '' AND @FirstWalk = '' AND @Revisit <> '' AND @TaskRevisit1 = '' AND @TaskRevisit2 = '' AND @TaskRevisit3 = '' AND @TaskRevisit4 ='')
Begin
set @TaskRevisit1 ='1'
set @TaskRevisit2 ='1'
set @TaskRevisit3 ='1'
set @TaskRevisit4 ='1';
End

/* กรณี User เลือก Lead และ FirstWalk แต่ไม่ได้ติ๊ก Check Box ให้ Default ออกข้อมูลของ Lead และ FirstWalk ทั้งหมด*/
Else IF (@Lead <> '' AND @FirstWalk <> '' AND @Revisit = '' AND @TaskLead1 = '' AND @TaskLead2 = '' AND @TaskLead3 = '' AND @TaskLead4 =''
AND @TaskWalk1 = '' AND @TaskWalk2 = '' AND @TaskWalk3 = '' AND @TaskWalk4 ='' AND @TaskWalk5 = '' AND @TaskWalk6 ='')
Begin
set @TaskLead1 ='1'
set @TaskLead2 ='1'
set @TaskLead3 ='1'
set @TaskLead4 ='1'
set @TaskWalk1 ='1'
set @TaskWalk2 ='1'
set @TaskWalk3 ='1'
set @TaskWalk4 ='1'
set @TaskWalk5 ='1'
set @TaskWalk6 ='1';
End


/* กรณี User เลือก Lead และ Revisit แต่ไม่ได้ติ๊ก Check Box ให้ Default ออกข้อมูลของ Lead และ Revisit ทั้งหมด*/
Else IF (@Lead <> '' AND @FirstWalk = '' AND @Revisit <> '' AND @TaskLead1 = '' AND @TaskLead2 = '' AND @TaskLead3 = '' AND @TaskLead4 =''
AND @TaskRevisit1 = '' AND @TaskRevisit2 = '' AND @TaskRevisit3 = '' AND @TaskRevisit4 ='')
Begin
set @TaskLead1 ='1'
set @TaskLead2 ='1'
set @TaskLead3 ='1'
set @TaskLead4 ='1'
set @TaskRevisit1 ='1'
set @TaskRevisit2 ='1'
set @TaskRevisit3 ='1'
set @TaskRevisit4 ='1';
End

/* กรณี User เลือก FirstWalk และ Revisit แต่ไม่ได้ติ๊ก Check Box ให้ Default ออกข้อมูลของ FirstWalk และ Revisit ทั้งหมด*/
Else IF (@Lead = '' AND @FirstWalk <> '' AND @Revisit <> '' AND @TaskWalk1 = '' AND @TaskWalk2 = '' AND @TaskWalk3 = '' AND @TaskWalk4 ='' AND @TaskWalk5 = '' AND @TaskWalk6 =''
AND @TaskRevisit1 = '' AND @TaskRevisit2 = '' AND @TaskRevisit3 = '' AND @TaskRevisit4 ='')
Begin
set @TaskWalk1 ='1'
set @TaskWalk2 ='1'
set @TaskWalk3 ='1'
set @TaskWalk4 ='1'
set @TaskWalk5 ='1'
set @TaskWalk6 ='1'
set @TaskRevisit1 ='1'
set @TaskRevisit2 ='1'
set @TaskRevisit3 ='1'
set @TaskRevisit4 ='1';
End

/* กรณี User เลือก Lead,FirstWalk,Revisit แต่ไม่ได้ติ๊ก Check Box ให้ Default ออกข้อมูลของ Lead,FirstWalk,Revisit ทั้งหมด*/
Else IF (@Lead <> '' AND @FirstWalk <> '' AND @Revisit <> '' AND @TaskLead1 = '' AND @TaskLead2 = '' AND @TaskLead3 = '' AND @TaskLead4 =''
AND @TaskWalk1 = '' AND @TaskWalk2 = '' AND @TaskWalk3 = '' AND @TaskWalk4 ='' AND @TaskWalk5 = '' AND @TaskWalk6 =''
AND @TaskRevisit1 = '' AND @TaskRevisit2 = '' AND @TaskRevisit3 = '' AND @TaskRevisit4 ='')
Begin
set @TaskLead1 ='1'
set @TaskLead2 ='1'
set @TaskLead3 ='1'
set @TaskLead4 ='1'
set @TaskWalk1 ='1'
set @TaskWalk2 ='1'
set @TaskWalk3 ='1'
set @TaskWalk4 ='1'
set @TaskWalk5 ='1'
set @TaskWalk6 ='1'
set @TaskRevisit1 ='1'
set @TaskRevisit2 ='1'
set @TaskRevisit3 ='1'
set @TaskRevisit4 ='1';
End
---------- Select Project by Permission ---------------
--If(Isnull(@Username,'')='')Set @Username='พลอยไพลิน ธนกิจวรบูลย์'
--If(Object_ID('tempdb..#TProject')Is not null)Drop table #TProject

		Declare @ProductID1 NVARCHAR(50)
		Set @ProductID1 = (select ProjectNo from [crmrevo].PRJ.Project With (Nolock) where id = @ProductID)

--    --SELECT *
--    --INTO #TProject
--    --FROM (   SELECT ProductID
--    --         FROM [dbo].[fn_GetProjectAuthorised](ISNULL(@Username, '')) t
--    --         WHERE (ISNULL(@ProductID1, '') = '' OR t.ProductID = @ProductID1)
--    --         UNION
--    --         SELECT ProjectNo
--    --         FROM PRJ.Project P
--			 --Inner JOIN MST.MasterCenter MST With (Nolock) ON MST.ID = P.ProjectStatusMasterCenterID AND MST.[Key] = 1
--    --         WHERE 1=1
--			 ----ISNULL(RTPExcusive, 0) = 1
--    --             AND (ISNULL(@Username, '') = '' OR ISNULL(@Username, '') = 'Administrator')
--    --             AND (ISNULL(@ProductID1, '') = '' OR P.ProjectNo = @ProductID1)) t;



Declare @EmpCode nvarchar(50)
--if(ISNUMERIC(@LCByProduct)=-1)Set @LCByProduct='-1'
Set @EmpCode = Isnull((SELECT EmployeeNo FROM [crmrevo].USR.[User] With (Nolock) WHERE ISNULL(@LCByProduct, '') <> '' and Convert(nvarchar(50),EmployeeNo)=@LCByProduct),'')


If(ISNULL(@DateStart2,'')='')Set @DateStart2='18000101'
If(ISNULL(@DateEnd2,'')='')Set @DateEnd2='70001231'
set @DateStart2 =  CONVERT(DATETIME,CONVERT(NVARCHAR,@DateStart2,103),103)
set @DateEnd2 =  CONVERT(DATETIME,CONVERT(NVARCHAR,@DateEnd2,103),103)
DECLARE @DateEnd2InStore Datetime
SET @DateEnd2InStore = [dbo].[fn_GetMaxDate](@DateEnd2)

if(object_id('tempdb..#temp')is not null)drop table #temp;
if(object_id('tempdb..#TmpQN')is not null)drop table #TmpQN;
If(Object_ID('tempdb..#TmpQN1')is not null)drop table #TmpQN1;
if(object_id('tempdb..#TmpOp')is not null)drop table #TmpOp;
if(object_id('tempdb..#TmpLeads')is not null)drop table #TmpLeads;
if(object_id('tempdb..#Temp')is not null)drop table #Temp;
if(object_id('tempdb..#TmpCurrentOp')is not null)drop table #TmpCurrentOp;
if(object_id('tempdb..#TmpCurrentAcct_Lead')is not null)drop table #TmpCurrentAcct_Lead;  
if(object_id('tempdb..#TmpCurrentAcct_Opp')is not null)drop table #TmpCurrentAcct_Opp;  
if(object_id('tempdb..#TmpCurrentLead')is not null)drop table #TmpCurrentLead;
if(object_id('tempdb..#CTM_Opportunity')is not null)drop table #CTM_Opportunity;
if(object_id('tempdb..#ctm_OpportunityActivityStatus1')is not null)drop table #ctm_OpportunityActivityStatus1;
--if(object_id('tempdb..#CRM_OpportunitiesDetail')is not null)drop table #CRM_OpportunitiesDetail;
if(object_id('tempdb..#CTM_Activity')is not null)drop table #CTM_Activity;
if(object_id('tempdb..#CTM_Leads')is not null)drop table #CTM_Leads;
if(object_id('tempdb..#CTM_LeadsActivity')is not null)drop table #CTM_LeadsActivity;
If(Object_ID('tempdb..#Project')is not null)Drop table #Project
If(Object_ID('tempdb..#CustomerAnswerHeader')is not null)Drop table #CustomerAnswerHeader
If(Object_ID('tempdb..#CustomerAnswer')is not null)Drop table #CustomerAnswer
If(Object_ID('tempdb..#Answer')is not null)Drop table #Answer
If(Object_ID('tempdb..#Questionnaire')is not null)Drop table #Questionnaire
If(Object_ID('tempdb..#CTM_LeadsCategory')is not null)Drop table #CTM_LeadsCategory
--If(Object_ID('tempdb..#SCVCustomer')is not null)Drop table #SCVCustomer

Select * 
INTO #CTM_Opportunity
FROM [crmrevo].CTM.Opportunity O With(NoLock) 
WHERE ProjectID in(@ProductID)
and O.IsDeleted =0



Select *
INTO #CTM_Activity
FROM(
SELECT 
	a.ID ,a.ActualDate ,a.OpportunityID,a.DueDate,a.Description,a.OpportunityActivityTypeMasterCenterID AS ActivityTypeMasterCenterID ,a.Created,a.CreatedByUserID,a.Updated,a.UpdatedByUserID
	,ats.Description as DescriptionStatus ,ats.WalkActivityStatusTypeMasterCenterId AS StatusMasterID 
	,ats.Code AS StatusID ,a.IsCompleted
	,'ActivityType' = '2'
FROM [crmrevo].CTM.OpportunityActivity  a With(NoLock) 
LEFT JOIN [crmrevo].CTM.OpportunityActivityResult ar With (Nolock) on a.ID = ar.OpportunityAcitivityID
LEFT JOIN [crmrevo].ctm.OpportunityActivityStatus ats With (Nolock) on ar.StatusID = ats.ID
WHERE 1=1
AND a.IsDeleted <> 1
AND a.OpportunityID in(Select ID From #CTM_Opportunity)
Union
SELECT R.ID,R.ActualDate,R.OpportunityID,Null AS DueDate ,R.Description,R.RevisitActivityTypeMasterCenterID AS ActivityTypeMasterCenterID, R.Created,R.CreatedByUserID,R.Updated,R.UpdatedByUserID
,RAS.Description AS DescriptionStatus ,Null AS StatusMasterID ,RAS.Code AS StatusID ,r.IsCompleted,'ActivityType' = '3'
FROM [crmrevo].CTM.RevisitActivity R With (Nolock)
LEFT JOIN [crmrevo].CTM.RevisitActivityResult RS With (Nolock) ON R.ID = RS.RevisitAcitivityID
LEFT JOIN [crmrevo].CTM.RevisitActivityStatus RAS With (Nolock) ON RS.StatusID = RAS.ID
WHERE 1=1
AND R.IsDeleted <> 1
AND R.OpportunityID in(Select ID From #CTM_Opportunity)
) T



Select * 
INTO #CTM_Leads 
FROM [crmrevo].CTM.Lead L With(NoLock) 
WHERE ProjectID in (@ProductID)


Select la.* ,'ActivityType' = '1',las.Code
INTO #CTM_LeadsActivity 
FROM [crmrevo].CTM.LeadActivity la With(NoLock) 
LEFT JOIN [crmrevo].CTM.LeadActivityStatus las With (Nolock) on la.StatusID = las.ID 
WHERE 1=1
AND la.IsDeleted <> 1
AND la.LeadID in(Select ID From #CTM_Leads); --1284


select MSTS.[key] AS LeadsCategoryID,MSTS.Name AS LeadsCategory,MSTS.[Order] AS LeadsCategorySeq ,LA.ID AS LeadsSubCategoryID ,LA.Description AS LeadsSubCategory
,LA.[Order] AS LeadsSubCategorySeq,MSTF.[key] AS Status, MSTF.Name AS Description
into #CTM_LeadsCategory 
from [crmrevo].CTM.LeadActivityStatus LA With (Nolock)
LEFT JOIN [crmrevo].MST.MasterCenter MSTF With (Nolock) ON MSTF.ID = LA.LeadActivityFollowUpTypeMasterCenterID AND MSTF.MasterCenterGroupKey = 'LeadActivityFollowUpType'
LEFT JOIN [crmrevo].MST.MasterCenter MSTS With (Nolock) ON MSTS.ID = LA.LeadActivityStatusTypeMasterCenterID AND MSTS.MasterCenterGroupKey = 'LeadActivityStatusType'
where LA.id in (select CurrentLeadActivityStatusID from #CTM_Leads )
and LA.IsActive =1

--------------------#TmpOp-----------------------------
-- Print('Load Opp => '+Convert(nvarchar(50),getdate(),113))
select  TA.ID AS OpportunityID
,P.ProjectNo AS ProjectID 
,a.ID AS ReferentID
,con.ContactNo AS ContactID
--,ta.OpportunityNo
, Usr.EmployeeNo AS OwnerID
, Convert(datetime,a.DueDate) AS ActivityDate
,Convert(datetime,a.Created) AS CreateDate
,Convert(datetime,a.ActualDate) AS ActualDate
,a.ActivityType
,MST.[KEY] AS TaskID
,a.IsCompleted as StatusID
,'ProductCompare'=convert(nvarchar(1000),'')
,'UnitNumber' =  Isnull(ISNULL(TA.InterestedProduct1,'')+CASE WHEN ISNULL(TA.InterestedProduct2,'')='' THEN ''ELSE' , '+ISNULL(TA.InterestedProduct2,'')END,'')
,'CustomerFeature' = NULL --No Migrate Table CRM_OpportunitiesDetail
,'Probability' = MTL.Name
,a.Description AS remark
,'SourceType'= CASE WHEN L.LeadTypeMasterCenterID IS NOT NULL THEN MLD.Name Else 'First walk'End 
,'SourceDate'=Case  WHEN MLD.[KEY] = 'C' THEN Convert(datetime,l.Created) WHEN MLD.[KEY] = 'W' THEN convert(datetime,l.Created) WHEN MLD.[KEY] = 'F' THEN convert(datetime,l.Created)
					ELSE Convert(datetime,TA.Created) END
,convert(datetime,ta.Created) AS OpportunityDate
,'OppDetail2'=convert(nvarchar(1000),'')
,'OppDetail3'=convert(nvarchar(1000),'')
,'OppDetail4'=convert(nvarchar(1000),'')
,'OppDetail6'=convert(nvarchar(1000),'')
,'OppDetail7'=convert(nvarchar(1000),'')
,'OppDetail8'=convert(nvarchar(1000),'')
,'OppDetail9'=convert(nvarchar(1000),'')
,'PreviousStatus'=convert(nvarchar(1000),'')
,a.ID AS ActivityID
into #TmpOp
from #CTM_Opportunity TA WITH (NOLOCK)
left OUTER JOIN #CTM_Activity a WITH (NOLOCK) ON TA.ID = a.OpportunityID AND a.ActivityType = '2'--AND a.StatusID <> '-1'
left OUTER JOIN [crmrevo].CTM.Contact con WITH (NOLOCK) ON con.ID=ta.ContactID
left OUTER JOIN [crmrevo].PRJ.Project P With (Nolock) ON P.ID = TA.ProjectID
LEFT OUTER JOIN [crmrevo].usr.[User] Usr With (Nolock) ON TA.OwnerID = Usr.ID
LEFT JOIN [crmrevo].MST.MasterCenter MST With (Nolock) ON MST.ID = a.ActivityTypeMasterCenterID
LEFT OUTER JOIN [crmrevo].MST.MasterCenter MTL With (Nolock) ON MTL.ID = TA.EstimateSalesOpportunityMasterCenterID AND MTL.MasterCenterGroupKey = 'EstimateSalesOpportunity'
Left Join  (SELECT  MIN(Created)Created,LeadTypeMasterCenterID,ContactID,ProjectID  FROM  #CTM_Leads WITH (NOLOCK)
 WHERE  NumberOfContact = 1  GROUP BY LeadTypeMasterCenterID,ContactID,ProjectID ) l ON l.ContactID=con.ID and l.ContactID is not null and  ta.ProjectID = l.ProjectID 
--left OUTER JOIN #CTM_Leads l WITH (NOLOCK) ON l.ContactID=con.ID and l.ContactID is not null and  ta.ProjectID = l.ProjectID
LEFT OUTER JOIN [crmrevo].MST.MasterCenter MLD With (Nolock) ON MLD.ID = l.LeadTypeMasterCenterID AND MLD.MasterCenterGroupKey = 'LeadType'
where 1=1 
and (@ProductID IS NULL or ta.ProjectID=@ProductID)
and (dbo.fn_ClearTime(isnull(a.ActualDate,'18000101')) BETWEEN @DateStart2 and @DateEnd2InStore)
--or (dbo.fn_ClearTime(isnull(ta.Created,'18000101')) BETWEEN @DateStart2 and @DateEnd2InStore)
--or (dbo.fn_ClearTime(isnull(l.Created,'18000101'))  BETWEEN @DateStart2 and @DateEnd2InStore))
and ( 
	 (@TaskWalk1='1' and @FirstWalk='1' and ActivityType='2' and MST.[KEY]='1')
	or (@TaskWalk2='1' and @FirstWalk='1' and ActivityType='2' and MST.[KEY]='2')
	or (@TaskWalk3='1' and @FirstWalk='1' and ActivityType='2' and MST.[KEY]='3')
	or (@TaskWalk4='1' and @FirstWalk='1' and ActivityType='2' and MST.[KEY]='4')
	or (@TaskWalk5='1' and @FirstWalk='1' and ActivityType='2' and MST.[KEY]='5')
	or (@TaskWalk6='1' and @FirstWalk='1' and ActivityType='2' and MST.[KEY]='6')
	or (@TaskWalkEnd='1' and @FirstWalk='1' and ActivityType='2' and MST.[KEY]='7')

	--or (@TaskRevisit1='1' and @Revisit='1' and ActivityType='3' and MST.[KEY]='1')
	--or (@TaskRevisit2='1' and @Revisit='1' and ActivityType='3' and MST.[KEY]='2')
	--or (@TaskRevisit3='1' and @Revisit='1' and ActivityType='3' and MST.[KEY]='3')
	--or (@TaskRevisit4='1' and @Revisit='1' and ActivityType='3' and MST.[KEY]='4')
	)
Order by P.ProjectNo,ta.Created


Insert into #TmpOp
select  
TA.ID AS OpportunityID
,P.ProjectNo AS ProjectID 
,a.ID AS ReferentID
,con.ContactNo AS ContactID
--,ta.OpportunityNo
, Usr.EmployeeNo AS OwnerID
, Convert(datetime,a.DueDate) AS ActivityDate
,Convert(datetime,a.Created) AS CreateDate
,Convert(datetime,a.ActualDate) AS ActualDate
,a.ActivityType
,MST.[KEY] AS TaskID
,a.IsCompleted as StatusID
,'ProductCompare'=convert(nvarchar(1000),'')
,'UnitNumber' =  Isnull(ISNULL(TA.InterestedProduct1,'')+CASE WHEN ISNULL(TA.InterestedProduct2,'')='' THEN ''ELSE' , '+ISNULL(TA.InterestedProduct2,'')END,'')
,'CustomerFeature' = NULL --No Migrate Table CRM_OpportunitiesDetail
,'Probability' = MTL.Name
,a.Description AS remark
,'SourceType'= CASE WHEN L.LeadTypeMasterCenterID IS NOT NULL THEN MLD.Name Else 'First walk'End 
,'SourceDate'=Case  WHEN MLD.[KEY] = 'C' THEN Convert(datetime,l.Created) WHEN MLD.[KEY] = 'W' THEN convert(datetime,l.Created) WHEN MLD.[KEY] = 'F' THEN convert(datetime,l.Created)
					ELSE Convert(datetime,TA.Created) END
,convert(datetime,ta.Created) AS OpportunityDate
,'OppDetail2'=convert(nvarchar(1000),'')
,'OppDetail3'=convert(nvarchar(1000),'')
,'OppDetail4'=convert(nvarchar(1000),'')
,'OppDetail6'=convert(nvarchar(1000),'')
,'OppDetail7'=convert(nvarchar(1000),'')
,'OppDetail8'=convert(nvarchar(1000),'')
,'OppDetail9'=convert(nvarchar(1000),'')
,'PreviousStatus'=convert(nvarchar(1000),'')
,a.ID AS ActivityID
from #CTM_Opportunity TA WITH (NOLOCK)
left OUTER JOIN #CTM_Activity a WITH (NOLOCK) ON TA.ID = a.OpportunityID AND a.ActivityType = '3'--AND a.StatusID <> '-1'
left OUTER JOIN [crmrevo].CTM.Contact con WITH (NOLOCK) ON con.ID=ta.ContactID
left OUTER JOIN [crmrevo].PRJ.Project P With (Nolock) ON P.ID = TA.ProjectID
LEFT OUTER JOIN [crmrevo].usr.[User] Usr With (Nolock) ON TA.OwnerID = Usr.ID
LEFT JOIN [crmrevo].MST.MasterCenter MST With (Nolock) ON MST.ID = a.ActivityTypeMasterCenterID
LEFT OUTER JOIN [crmrevo].MST.MasterCenter MTL With (Nolock) ON MTL.ID = TA.EstimateSalesOpportunityMasterCenterID AND MTL.MasterCenterGroupKey = 'EstimateSalesOpportunity'
Left Join  (SELECT  MIN(Created)Created,LeadTypeMasterCenterID,ContactID,ProjectID  FROM  #CTM_Leads WITH (NOLOCK)
 WHERE  NumberOfContact = 1  GROUP BY LeadTypeMasterCenterID,ContactID,ProjectID ) l ON l.ContactID=con.ID and l.ContactID is not null and  ta.ProjectID = l.ProjectID 
--left OUTER JOIN #CTM_Leads l WITH (NOLOCK) ON l.ContactID=con.ID and l.ContactID is not null and  ta.ProjectID = l.ProjectID
LEFT OUTER JOIN [crmrevo].MST.MasterCenter MLD With (Nolock) ON MLD.ID = l.LeadTypeMasterCenterID AND MLD.MasterCenterGroupKey = 'LeadType'
where 1=1 
and (@ProductID IS NULL or ta.ProjectID=@ProductID)
and (dbo.fn_ClearTime(isnull(a.ActualDate,'18000101')) BETWEEN @DateStart2 and @DateEnd2InStore)
--or (dbo.fn_ClearTime(isnull(ta.Created,'18000101')) BETWEEN @DateStart2 and @DateEnd2InStore)
--or (dbo.fn_ClearTime(isnull(l.Created,'18000101'))  BETWEEN @DateStart2 and @DateEnd2InStore))
and (  
	(@TaskRevisit1='1' and @Revisit='1' and ActivityType='3' and MST.[KEY]='1')
	or (@TaskRevisit2='1' and @Revisit='1' and ActivityType='3' and MST.[KEY]='2')
	or (@TaskRevisit3='1' and @Revisit='1' and ActivityType='3' and MST.[KEY]='3')
	or (@TaskRevisit4='1' and @Revisit='1' and ActivityType='3' and MST.[KEY]='4')
	)
Order by P.ProjectNo,ta.Created




--update #TmpOp
--set 
----select 'PreviousStatus1' = Left(Isnull((select top(1) description from #CTM_Activity tt where tt.OpportunityID = ta.OpportunityID and tt.ActualDate <> ta.ActualDate and tt.ActivityType = ta.ActivityType and tt.ActualDate<ISnull(ta.ActivityDate,ta.ac order by tt.ActualDate),''),1000)
--from  #TmpOp ta 
--where ta.ActivityType ='3' and OpportunityID = '8B1EECD9-4C8D-45ED-A39B-470B0EAA8E04'
--select *  from #CTM_Activity tt where tt.OpportunityID = '8B1EECD9-4C8D-45ED-A39B-470B0EAA8E04' and tt.ActualDate <> ta.ActualDate order by tt.ActualDate

Update #TmpOp
Set PreviousStatus=Left(Isnull((Select Top 1 replace(Description,',','') From #CTM_Activity tt  With(NoLock)Where TA.OpportunityID = tt.OpportunityID and tt.ActivityType=ta.ActivityType and isnull(tt.DueDate,tt.ActualDate)<isnull(ta.ActivityDate,ta.ActualDate) Order by isnull(tt.DueDate,tt.ActualDate) Desc),''),1000)
From #TmpOp ta

Update #TmpOp
Set PreviousStatus=Left(Isnull((Select Top 1 replace(Description,',','') From #CTM_Activity tt  With(NoLock)Where t.ActivityID=tt.ID),''),1000)
From #TmpOp t
Where  t.ActivityID in (Select ID From #CTM_Activity tt  With(NoLock)Where tt.OpportunityID=t.OpportunityID)
and ActualDate In(Select min(ActualDate)ActualDate	
					From #CTM_Activity a  With(NoLock)
					Where a.OpportunityID=t.OpportunityID and a.ActivityType=t.ActivityType
					Group by a.OpportunityID,a.ActivityType)

Update #TmpOp
Set UnitNumber=Isnull(OppDetail2,''),OppDetail2=''
Where Isnull(UnitNumber,'')=''

-------------------------------#TmpLeads-----------------------------
-- Print('Load Lead => '+Convert(nvarchar(50),getdate(),113))

select  
l.ID AS LeadsID
,convert(datetime,dbo.fn_ClearTime(l.Created)) AS LeadDate
,CT.ContactNo AS ContactID
,P.ProjectNo AS ProjectID
, MST.[KEY] AS LeadsTypeID
,l.Remark as RemarkLeads
, Usr.EmployeeNo AS OwnerID
,l.FirstName
 ,MSA.[KEY] AS TaskID
,a.IsCompleted AS StatusID
,l.LastName
,l.PhoneNumber
,l.HouseNo AS HouseID
,l.Moo
,l.Village
,l.Soi
,l.Road
,l.District
,l.SubDistrict
,l.Province
,l.PostalCode
,a.ID AS ActivityID
,a.LeadID AS ReferentID
,a.ActivityType
,Convert(datetime,a.DueDate) AS ActivityDate
,Convert(datetime,a.ActualDate) AS ActualDate
,a.Description as RemarkAct
,Convert(datetime,a.Created) AS CreateDate 
,Convert(datetime,a.Updated) AS EditDate 
,'SourceType'=Case MST.[key] when 'W'Then'Web' When'C'Then'Call' When 'F' Then 'FaceBook'Else ''End
,'SourceDate'=Convert(datetime,dbo.fn_ClearTime(l.Created))
,'PreviousStatus'=Isnull((Select Top 1 replace(Description,',','') From #CTM_Activity tt  With(NoLock)Where a.LeadID = tt.OpportunityID and tt.ActivityType=a.ActivityType and tt.StatusID<>-1 and tt.ID<l.ID Order by tt.DueDate Desc),'')
,b.LeadsSubCategory
into #TmpLeads
from  #CTM_Leads l WITH (NOLOCK)
left join #CTM_LeadsActivity a WITH (NOLOCK)on l.ID = a.LeadID 
left join #CTM_LeadsCategory b on b.LeadsSubCategoryID = l.CurrentLeadActivityStatusID 
LEFT OUTER JOIN [crmrevo].CTM.Contact CT With (Nolock) ON CT.ID = l.ContactID
LEFT OUTER JOIN [crmrevo].PRJ.Project P With (Nolock) ON P.ID = l.ProjectID
LEFT JOIN [crmrevo].usr.[User] Usr With (Nolock) ON l.OwnerID = Usr.ID
LEFT JOIN [crmrevo].MST.MasterCenter MSA With (Nolock) ON MSA.ID = A.LeadActivityTypeMasterCenterID
LEFT JOIN [crmrevo].MST.MasterCenter MST With (Nolock) ON MST.ID = l.LeadTypeMasterCenterID	AND MST.MasterCenterGroupKey = 'LeadType' 
where 1=1 
AND l.ContactID Is null -- เฉพาะรายการ Lead ที่ยังไม่เป็น Opp
and (@ProductID IS NULL or l.ProjectID=@ProductID)
--and (dbo.fn_ClearTime(isnull(l.Created,'18000101')) BETWEEN @DateStart2 and @DateEnd2InStore)
and  (dbo.fn_ClearTime(isnull(a.ActualDate,'18000101')) BETWEEN @DateStart2 and @DateEnd2InStore)-------- จะต้องมีวันที่ทำจริงเท่านั้น 
and ( 
	   (@TaskLead1='1' and @Lead='1' and ActivityType='1' and MSA.[KEY]='1')
	or (@TaskLead2='1' and @Lead='1' and ActivityType='1' and MSA.[KEY]='2')
	or (@TaskLead3='1' and @Lead='1' and ActivityType='1' and MSA.[KEY]='3')
	or (@TaskLead4='1' and @Lead='1' and ActivityType='1' and MSA.[KEY]='4')
	)
Order by l.ProjectID,l.Created



Update #TmpLeads
Set PreviousStatus=Left(Isnull((Select Top 1 replace(Description,',','') From #CTM_LeadsActivity tt  With(NoLock)Where l.LeadsID = tt.LeadID and tt.ActivityType=l.ActivityType and tt.DueDate<l.ActivityDate  Order by tt.DueDate Desc),''),1000)
From #TmpLeads l


-- Update PreviousStatus for first activity
Update #TmpLeads
Set PreviousStatus=Left(Isnull((Select Top 1 replace(Description,',','') From #CTM_LeadsActivity tt  With(NoLock)Where t.ActivityID = tt.ID),''),1000)
From #TmpLeads t
Where t.ActivityID in (Select ID From #CTM_LeadsActivity tt  With(NoLock)Where tt.LeadID=t.LeadsID)
and ActivityDate In(Select min(DueDate)ActivityDate	
					From #CTM_LeadsActivity a  With(NoLock)
					Where a.LeadID=t.LeadsID and a.ActivityType=t.ActivityType
					Group by LeadID,ActivityType)




--------------------#TmpCurrentAcct_Opp-----------------------------
-- Print('Load Current Opp => '+Convert(nvarchar(50),getdate(),113))
--select Max(CreateDate)LastActivityDate,ReferentID,max(ActivityType )ActivityType
select 
Max(ActualDate)LastActivityDate
,OpportunityID AS ReferentID
,max(ActivityType )ActivityType-----------เนื่องจากuserมีการคีย์ย้อนหลัง
Into #TmpCurrentAcct_Opp
from #CTM_Activity l WITH (NOLOCK)
Where 1=1
AND EXISTS(Select OpportunityID From #TmpOp WHERE OpportunityID=l.OpportunityID) 
Group by OpportunityID
--select * from #TmpCurrentAcct_Opp
--------------------#TmpCurrentAcct_Lead-----------------------------
-- Print('Load Current Lead => '+Convert(nvarchar(50),getdate(),113))
select 
Max(Created)LastActivityDate
,LeadID
,Max(ActivityType)ActivityType
Into #TmpCurrentAcct_Lead
from #CTM_LeadsActivity l WITH (NOLOCK)
Where 1=1
AND exists(Select LeadsID From #TmpLeads WHERE LeadsID=l.LeadID)
Group by LeadID


-------------------------------------------------------------------
Select TA.ID AS OpportunityID,TA.ProjectID,LastActivityDate,TA.Created AS OpportunityDate,acc.Description AS Remark,acc.IsCompleted AS StatusID,a.ActivityType, MST.[KEY] AS TaskID ,MST.Name AS TaskName
Into #TmpCurrentOp
From #CTM_Opportunity ta WITH (NOLOCK)
left join #TmpCurrentAcct_Opp a WITH (NOLOCK)on TA.ID = a.ReferentID
Left join #CTM_Activity acc WITH (NOLOCK)on TA.ID = acc.OpportunityID and [dbo].[fn_ClearTime](acc.ActualDate)=a.LastActivityDate -- walk , revisit
LEFT OUTER JOIN [crmrevo].PRJ.Project P With (Nolock) ON P.ID = ta.ProjectID
LEFT JOIN [crmrevo].MST.MasterCenter MST With (Nolock) ON MST.ID = acc.ActivityTypeMasterCenterID
Where 1=1 
--and a.ActivityType is not null
--and exists(Select OpportunityID From #TmpOp WHERE OpportunityID=TA.OpportunityID)



-- Print('Load Current Lead => '+Convert(nvarchar(50),getdate(),113))
Select l.ID AS LeadsID,P.ProjectNo AS ProjectID,LastActivityDate,l.Created AS LeadDate,acc.Description AS Remark,acc.IsCompleted as StatusID,a.ActivityType,acc.id as ActivityID,MST.[KEY] AS TaskID,MSL.[Key] AS LeadsStatus ,MST.Name AS LeadName
Into #TmpCurrentLead
From #CTM_Leads l  With(NoLock)
Inner join #TmpCurrentAcct_Lead a on l.ID = a.LeadID
left join #CTM_LeadsActivity acc  With(NoLock)on l.ID = acc.LeadID and acc.Created=a.LastActivityDate 
LEFT join [crmrevo].PRJ.Project P With (Nolock) ON l.ProjectID = P.ID
LEFT JOIN [crmrevo].MST.MasterCenter MST With (Nolock) ON MST.ID = acc.LeadActivityTypeMasterCenterID
LEFT JOIN [crmrevo].MST.MasterCenter MSL With (Nolock) ON MSL.ID = l.LeadStatusMasterCenterID
Where 1=1 

--AND exists(Select LeadsID From #TmpLeads WHERE LeadsID=l.LeadsID)


---- Print('Load Full Opp => '+Convert(nvarchar(50),getdate(),113))
SELECT distinct 'NameType'=Convert(nvarchar(10),'OPP'),
Convert(datetime,tp.SourceDate) AS IssueDate
,tp.SourceType IssuedStatus 
,'FirstName' = Convert(nvarchar(500),ISNULL(TZ.FirstNameTH,'-'))
,'SurName' = Convert(nvarchar(500),ISNULL(TZ.LastNameTH,'-'))
,'Contact_Tel' = Convert(nvarchar(500),isnull(CTP.PhoneNumber,''))
,'Address' = Convert(nvarchar(500),CASE WHEN CTA4.SubDistrictID IS NULL AND CTA4.ForeignSubDistrict IS NOT NULL Then  N'ต.'+ISNULL(CTA4.ForeignSubDistrict,'')
							WHEN PO4.NameTH like '%กรุงเทพ%' AND CTA4.SubDistrictID IS NOT NULL Then N'แขวง'+ISNULL(SDT4.NameTH,'')
							WHEN CTA4.SubDistrictID IS NULL AND CTA4.ForeignSubDistrict IS  NULL Then  ''
							 ELSE N'ต.'+ISNULL(SDT4.NameTH,'') 
							 END+' ' 
				+ CASE WHEN CTA4.DistrictID IS NULL AND CTA4.ForeignDistrict IS NOT NULL Then  N'อ.'+ISNULL(CTA4.ForeignDistrict,'')
							WHEN PO4.NameTH like '%กรุงเทพ%' AND CTA4.DistrictID IS NOT NULL Then N'เขต'+ISNULL(DT4.NameTH,'')
							WHEN CTA4.DistrictID IS NULL AND CTA4.ForeignDistrict IS  NULL Then  ''
							ELSE N'อ.'+ISNULL(DT4.NameTH,'')
							 END+' '
				+ CASE WHEN CTA4.ProvinceID IS NULL AND CTA4.ForeignProvince IS NOT NULL Then  N'จ.'+ISNULL(CTA4.ForeignProvince,'')
							WHEN PO4.NameTH like '%กรุงเทพ%' AND CTA4.ProvinceID IS NOT NULL Then ISNULL(PO4.NameTH,'')
							WHEN CTA4.ProvinceID IS NULL AND CTA4.ForeignProvince IS  NULL Then  ''
							ELSE N'จ.'+ISNULL(PO4.NameTH,'')
							 END
							 )


,'Address_SubDistrict'=CASE WHEN CTA4.SubDistrictID IS NULL AND CTA4.ForeignSubDistrict IS NOT NULL Then  N'ต.'+ISNULL(CTA4.ForeignSubDistrict,'')
							WHEN PO4.NameTH like '%กรุงเทพ%' AND CTA4.SubDistrictID IS NOT NULL Then N'แขวง'+ISNULL(SDT4.NameTH,'')
							WHEN CTA4.SubDistrictID IS NULL AND CTA4.ForeignSubDistrict IS  NULL Then  ''
							 ELSE N'ต.'+ISNULL(SDT4.NameTH,'') 
							 END
,'Address_District'=CASE WHEN CTA4.DistrictID IS NULL AND CTA4.ForeignDistrict IS NOT NULL Then  N'อ.'+ISNULL(CTA4.ForeignDistrict,'')
							WHEN PO4.NameTH like '%กรุงเทพ%' AND CTA4.DistrictID IS NOT NULL Then N'เขต'+ISNULL(DT4.NameTH,'')
							WHEN CTA4.DistrictID IS NULL AND CTA4.ForeignDistrict IS  NULL Then  ''
							ELSE N'อ.'+ISNULL(DT4.NameTH,'')
							 END
,'Address_Province'=CASE WHEN CTA4.ProvinceID IS NULL AND CTA4.ForeignProvince IS NOT NULL Then  N'จ.'+ISNULL(CTA4.ForeignProvince,'')
							WHEN PO4.NameTH like '%กรุงเทพ%' AND CTA4.ProvinceID IS NOT NULL Then ISNULL(PO4.NameTH,'')
							WHEN CTA4.ProvinceID IS NULL AND CTA4.ForeignProvince IS  NULL Then  ''
							ELSE N'จ.'+ISNULL(PO4.NameTH,'')
							 END
,'Address_Job' =  Convert(NVarchar(1000),Left(CASE WHEN ISNULL(CTA3.RoadTH,'')='' THEN '' 
							ELSE'ถ.'+ISNULL(CTA3.RoadTH,'')
							 END+' '
					+ CASE WHEN CTA3.DistrictID IS NULL AND CTA3.ForeignDistrict IS NOT NULL Then  N'อ.'+ISNULL(CTA3.ForeignDistrict,'')
							WHEN PO3.NameTH like '%กรุงเทพ%' AND CTA3.DistrictID IS NOT NULL Then N'เขต'+ISNULL(DT3.NameTH,'')
							WHEN CTA3.DistrictID IS NULL AND CTA3.ForeignDistrict IS  NULL Then  ''
							ELSE N'อ.'+ISNULL(DT3.NameTH,'')
							 END+' '
					+  CASE WHEN CTA3.ProvinceID IS NULL AND CTA3.ForeignProvince IS NOT NULL Then  N'จ.'+ISNULL(CTA3.ForeignProvince,'')
							WHEN PO3.NameTH like '%กรุงเทพ%' AND CTA3.ProvinceID IS NOT NULL Then ISNULL(PO3.NameTH,'')
							WHEN CTA3.ProvinceID IS NULL AND CTA3.ForeignProvince IS  NULL Then  ''
							ELSE N'จ.'+ISNULL(PO3.NameTH,'')
							 END,1000))

--CASE WHEN ISNULL(CTA3.RoadTH,'')='' THEN '' 
--					ELSE N'ถ.'+ISNULL(CTA3.RoadTH,'') END+' '
--			+CASE WHEN ISNULL(DT3.NameTH,'')='' THEN '' 
--					WHEN PO3.NameTH like '%กรุงเทพ%' THEN N'เขต'+ISNULL(DT3.NameTH,'')
--					ELSE N'อ.'+ISNULL(DT3.NameTH,'') END+' '
--			+CASE WHEN ISNULL(PO3.NameTH,'')='' THEN '' 
--					WHEN PO3.NameTH like '%กรุงเทพ%' THEN ISNULL(PO3.NameTH,'')
--					ELSE N'จ.'+ISNULL(PO3.NameTH,'') End
					--,1000))
,'Address_Job_SubDistrict' = CASE WHEN CTA3.SubDistrictID IS NULL AND CTA3.ForeignSubDistrict IS NOT NULL Then  N'ต.'+ISNULL(CTA3.ForeignSubDistrict,'')
							WHEN PO3.NameTH like '%กรุงเทพ%' AND CTA3.SubDistrictID IS NOT NULL Then N'แขวง'+ISNULL(SDT3.NameTH,'')
							WHEN CTA3.SubDistrictID IS NULL AND CTA3.ForeignSubDistrict IS  NULL Then  ''
							 ELSE N'ต.'+ISNULL(SDT3.NameTH,'') 
							 END
 --Convert(NVarchar(500),Left(CASE WHEN ISNULL(SDT3.NameTH,'')='' THEN '' 
	--				WHEN PO3.NameTH like '%กรุงเทพ%' THEN N'เขต'+ISNULL(SDT3.NameTH,'')
	--				ELSE N'อ.'+ISNULL(SDT3.NameTH,'') End,500))
,'Address_Job_District' = CASE WHEN CTA3.DistrictID IS NULL AND CTA3.ForeignDistrict IS NOT NULL Then  N'อ.'+ISNULL(CTA3.ForeignDistrict,'')
							WHEN PO3.NameTH like '%กรุงเทพ%' AND CTA3.DistrictID IS NOT NULL Then N'เขต'+ISNULL(DT3.NameTH,'')
							WHEN CTA3.DistrictID IS NULL AND CTA3.ForeignDistrict IS  NULL Then  ''
							ELSE N'อ.'+ISNULL(DT3.NameTH,'')
							 END

 --Convert(NVarchar(500),Left(CASE WHEN ISNULL(DT3.NameTH,'')='' THEN '' 
	--				WHEN PO3.NameTH like '%กรุงเทพ%' THEN N'เขต'+ISNULL(DT3.NameTH,'')
	--				ELSE N'อ.'+ISNULL(DT3.NameTH,'') End,500))
,'Address_Job_Province' = CASE WHEN CTA3.ProvinceID IS NULL AND CTA3.ForeignProvince IS NOT NULL Then  N'จ.'+ISNULL(CTA3.ForeignProvince,'')
							WHEN PO3.NameTH like '%กรุงเทพ%' AND CTA3.ProvinceID IS NOT NULL Then ISNULL(PO3.NameTH,'')
							WHEN CTA3.ProvinceID IS NULL AND CTA3.ForeignProvince IS  NULL Then  ''
							ELSE N'จ.'+ISNULL(PO3.NameTH,'')
							 END
 --Convert(NVarchar(500),Left(CASE WHEN ISNULL(PO3.NameTH,'')='' THEN '' 
	--				WHEN PO3.NameTH like '%กรุงเทพ%' THEN ISNULL(PO3.NameTH,'')
	--				ELSE N'จ.'+ISNULL(PO3.NameTH,'') End,500))
,'Presentation'=Convert(NVarchar(500),'')
,'OwnerID'=Convert(NVarchar(50),tp.OwnerID)
,'LC' = Convert(NVarchar(500),US.DisplayName)
,p.ProjectNo AS ProductID
, P.ProjectNameTH AS Project--,TA.EditDate,
,'Budget'=Convert(NVarchar(500),''),'Income_1'=Convert(NVarchar(500),''),'Income_2'=Convert(NVarchar(500),''),'ProductCompare'=Convert(NVarchar(500),'')
,'UnitNumber'=convert(nvarchar(50),tp.UnitNumber )
,'CustomerFeature'=Convert(NVarchar(500),'')
,'Probability'=Convert(nvarchar(50),tp.Probability)
,convert(nvarchar(1000),PreviousStatus) PreviousStatus 
,convert(datetime,null) DateUpdate ,
convert(nvarchar(1000),null) CurrentMess ,
convert(nvarchar(1000),null) CurrentStatus,
convert(nvarchar(50),null) [Status]
,'OpportunityID'=Convert(nvarchar(50),Tp.OpportunityID)
,'ContactID'=Convert(nvarchar(50),TZ.ContactNo)--,tp.CreateDate
,convert(nvarchar(50),'') ActivityType
,tp.TaskID
,Convert(datetime,tp.OpportunityDate) AS OpportunityDate
,Convert(datetime,tp.ActualDate) AS ActualDate
,'OppDetail2' =  Left(Isnull(OppDetail2,''),1000)
,'OppDetail3' =  Left(Isnull(OppDetail3,''),1000)
,'OppDetail4' =  Left(Isnull(OppDetail4,''),1000)
,'OppDetail6' =  Left(Isnull(OppDetail6,''),1000)
,'OppDetail7' =  Left(Isnull(OppDetail7,''),1000)
,'OppDetail8' =  Left(Isnull(OppDetail8,''),1000)
,'OppDetail9' =  Left(Isnull(OppDetail9,''),1000)
,ActivityType ActivityTypeID
,tp.ActivityID
,isnull(convert(datetime,tp.ActivityDate),convert(datetime,tp.ActualDate)) AS ActivityDate
,'CurrentActivityType'=Convert(nvarchar(50),'')
,'TaskName'=Convert(nvarchar(100),'')
,'LeadsSubCategory' =Convert(nvarchar(100),'')
into #temp
FROM #TmpOp tp 
	Inner Join [crmrevo].CTM.Contact TZ WITH (NOLOCK)on tp.ContactId = TZ.ContactNo
	LEFT OUTER JOIN [crmrevo].PRJ.Project P WITH (NOLOCK)ON tp.[ProjectID] = P.ProjectNo 
	LEFT OUTER JOIN [crmrevo].CTM.ContactPhone CTP With (Nolock) ON CTP.ContactID = TZ.ID AND CTP.IsMain =1
	LEFT OUTER JOIN [crmrevo].CTM.ContactAddress CTA3 WITH (NOLOCK) ON TZ.ID = CTA3.ContactID AND CTA3.ContactAddressTypeMasterCenterID IN (select ID FROM [crmrevo].mst.MasterCenter With (Nolock) where [key] = 3 
																															  AND Name = 'ที่ทำงาน')
	LEFT OUTER JOIN [crmrevo].MST.Province PO3 WITH (NOLOCK) ON PO3.ID = CTA3.ProvinceID
	LEFT OUTER JOIN [crmrevo].MST.District DT3 WITH (NOLOCK) ON DT3.ID = CTA3.DistrictID
	LEFT OUTER JOIN [crmrevo].MST.SubDistrict SDT3 WITH (NOLOCK) ON SDT3.ID = CTA3.SubDistrictID
	LEFT OUTER JOIN [crmrevo].CTM.ContactAddress CTA4 WITH (NOLOCK) ON TZ.ID = CTA4.ContactID AND CTA4.ContactAddressTypeMasterCenterID IN (select ID FROM [crmrevo].mst.MasterCenter With (Nolock) where [key] = 0 
																															  AND Name = 'ติดต่อได้')
																															  AND CTA4.ID = (select top 1 ContactAddressID from [crmrevo].CTM.ContactAddressProject with(nolock)
																															  where IsDeleted =0 and ContactAddressID = CTA4.ID AND ProjectID = P.ID )
	LEFT OUTER JOIN [crmrevo].MST.Province PO4 WITH (NOLOCK) ON PO4.ID = CTA4.ProvinceID
	LEFT OUTER JOIN [crmrevo].MST.District DT4 WITH (NOLOCK) ON DT4.ID = CTA4.DistrictID
	LEFT OUTER JOIN [crmrevo].MST.SubDistrict SDT4 WITH (NOLOCK) ON SDT4.ID = CTA4.SubDistrictID
	LEFT OUTER JOIN [crmrevo].[USR].[User] US WITH (NOLOCK)ON tp.OwnerID = US.EmployeeNo 
WHERE 1=1  

----select * from #TmpOp
-----------------------------------Insert #tmp----------------------------
---- Print('Load Full Lead => '+Convert(nvarchar(50),getdate(),113))
--select * from #TmpLeads
Insert Into #temp
SELECT  distinct  'NameType'='Leads',
	Convert(datetime,l.SourceDate) AS IssueDate
	,l.SourceType IssuedStatus 
	,'FirstName' = ISNULL(l.FirstName,'-')
	,'SurName' = ISNULL(l.LastName,'-')
	,'Contact_Tel' = l.PhoneNumber
	,'Address' =  isnull(l.HouseID+' '+l.Moo+' '+l.Village+' '+l.Soi+' '+l.Road+' '+l.District+' '+l.SubDistrict+' '+l.Province+' '+l.PostalCode,'')
	,'Address_SubDistrict'=ISNULL(l.SubDistrict,'')
	,'Address_District'=ISNULL(l.District,'')
	,'Address_Province'=ISNULL(l.Province,'')
	,'Address_Job' = ''
	,'Address_Job_SubDistrict'=''
	,'Address_Job_District'=''
	,'Address_Job_Province'=''
	,convert(nvarchar(50),'') Presentation
	,l.OwnerID
	,'LC' = US.DisplayName
	,p.ProjectNo AS ProductID
	, P.ProjectNameTH AS Project
	,convert(nvarchar(50),'') Budget 
	,convert(nvarchar(50),'') Income_1 
	,convert(nvarchar(50),'')
	,convert(nvarchar(max),'')ProductCompare
	,convert(nvarchar(50),'')UnitNumber 
	,convert(nvarchar(max),'')CustomerFeature 
	,convert(nvarchar(50),'')Probability 
	,PreviousStatus 
	,convert(datetime,null) DateUpdate ,
	convert(nvarchar(max),'') CurrentMess ,
	convert(nvarchar(50),'') CurrentStatus,
	convert(nvarchar(10),'') [Status]
,l.LeadsID,l.ContactID
,convert(nvarchar(50),'') CurrentType
,l.TaskID
,'OpportunityDate'=convert(datetime,null)
,Convert(datetime,l.ActualDate) AS ActualDate
,'OppDetail2' =  ''
,'OppDetail3' =  ''
,'OppDetail4' =  ''
,'OppDetail6' =  ''
,'OppDetail7' =  ''
,'OppDetail8' =  ''
,'OppDetail9' =  ''
,ActivityType ActivityTypeID
,l.ActivityID,l.ActivityDate
,'CurrentActivityType'=Convert(nvarchar(50),'')
,'TaskName'=Convert(nvarchar(100),'')
,LeadsSubCategory
from  #TmpLeads l
LEFT  JOIN [crmrevo].PRJ.Project P  With(NoLock)ON l.ProjectID = P.ProjectNo 
left join [crmrevo].[USR].[User]US  With(NoLock)ON l.OwnerID = US.EmployeeNo 
WHERE 1=1  

---------------------------update opp -------------------------	
---- Print('Update Full Opp => '+Convert(nvarchar(50),getdate(),113))
update #temp 
set DateUpdate		=(select top 1 a.ActualDate
						from     #TmpOp tp
						left join (select max(ActualDate)ActualDate, OpportunityID,ReferentID,ProjectID from  #TmpOp  group by  OpportunityID,ProjectID,ReferentID ) a 
						 on a.OpportunityID = tp.OpportunityID and a.ActualDate = tp.ActualDate and a.ProjectID = tp.ProjectID
						 where  a.OpportunityID = t.OpportunityID and a.ProjectID = t.ProductID ) 

,CurrentMess=Left(isnull((Select Top 1 replace(Remark,',','') From #TmpCurrentOp tt Where tt.OpportunityID=t.OpportunityID order by TaskID asc),''),1000)
,CurrentStatus=Left(isnull((Select Top 1 Isnull(mWalk.Name ,mRevisit.Name )
				From #TmpCurrentOp tt 
				Left Join [crmrevo].MST.MasterCenter mWalk  With(NoLock)on mWalk.MasterCenterGroupKey='OpportunityActivityType' and mWalk.[Key]=tt.TaskID and tt.ActivityType=2
				Left Join [crmrevo].MST.MasterCenter mRevisit  With(NoLock)on mRevisit.MasterCenterGroupKey='RevisitActivityType' and mRevisit.[Key]=tt.TaskID and tt.ActivityType=3
				Where tt.OpportunityID=t.OpportunityID
				order by TaskID asc),''),1000)
,[Status]= (Select Top 1 case when tt.StatusID = 1 then 'Complete'
							  when tt.StatusID = 0 then 'follow up'
						 end  From #TmpCurrentOp tt Where tt.OpportunityID=t.OpportunityID) -- รอแก้ดาต้า ISCOMPLES -1
,ActivityType=(Select Top 1 
						 Case when tt.ActivityType = 2 then 'First walk'
						 when tt.ActivityType = 3 then 'Revisit'
						 end  From #TmpOp tt Where tt.ActivityID=t.ActivityID)
from #temp t 
where NameType = 'Opp'

---------------------------update Leads -------------------------	
---- Print('Update Full Lead => '+Convert(nvarchar(50),getdate(),113))
update #temp 
set DateUpdate		=(select top 1 a.ActualDate
					from #TmpLeads tp
						LEFT join (select max(ActualDate)ActualDate, LeadsID,ReferentID,ProjectID from  #TmpLeads  group by  LeadsID,ProjectID,ReferentID ) a 
						 on a.LeadsID = tp.LeadsID and a.ActualDate = tp.ActualDate and a.ProjectID = tp.ProjectID
						 where  a.ReferentID = t.OpportunityID and a.ProjectID = t.ProductID ) 
,CurrentMess=Left(isnull((Select Top 1 replace(Remark,',','') From #TmpCurrentLead tt Where tt.LeadsID=t.OpportunityID order by TaskID asc),''),1000)
,CurrentStatus=(Select Top 1 Isnull(tt.LeadName ,'' )
				From #TmpCurrentLead tt 
				Where tt.LeadsID=t.OpportunityID)
,[Status]=(Select Top 1 case when tt.LeadsStatus = 2 then 'Disqualify'
						when tt.StatusID = 1 then 'Complete'
						 when tt.StatusID = 0 then 'Follow up'				 
						 end  From #TmpCurrentLead tt Where tt.LeadsID=t.OpportunityID)       -- รอแก้ดาต้า ISCOMPLES -1
,ActivityType='Lead'
from #temp t 
where NameType = 'Leads'

Update #temp Set Address_Job='' Where Replace(Address_Job,' ','')='อ.-'
Update #temp Set Address_Job_District='' Where Replace(Address_Job_District,' ','')='อ.-'
Update #temp Set Address='' Where Replace(Address_Job,' ','')='อ.-'
Update #temp Set Address_District='' Where Replace(Address_District,' ','')='อ.-'
Update #temp set CurrentActivityType=Isnull(Case When ActivityTypeID=1 Then 'Lead' When ActivityTypeID=2 Then 'First Walk'When ActivityTypeID=3 Then 'Revisit'End,'')
Update #temp set TaskName=Isnull(m.Name,'')
from  #temp t
Left JOin [crmrevo].MST.MasterCenter m With (Nolock) on m.MasterCenterGroupKey =Case When t.ActivityTypeID=1 Then 'LeadActivityType'
When t.ActivityTypeID=2 Then 'OpportunityActivityType'
When t.ActivityTypeID=3 Then 'RevisitActivityType'End  
and m.[Key]=Convert(nvarchar(50),t.TaskID)


/* Load QN Data*/
--Select ContactID From #temp Where ContactID Is Not null
If(Object_ID('tempdb..#CTM_Contact')is not null)Drop table #CTM_Contact
--If(Object_ID('tempdb..#SCVCustomerMapping')is not null)Drop table #SCVCustomerMapping
SELECT ID AS ItemId,ContactNo
INTO #CTM_Contact
FROM [crmrevo].CTM.Contact a With (Nolock)
WHERE (EXISTS
(
    SELECT ContactID
    FROM #temp
    WHERE ContactID IS NOT NULL AND ContactID = a.ContactNo
)
      );
--WHERE ContactID In(Select ContactID From #temp Where ContactID Is Not null);


--SELECT a.ScvCustomerId,
--       DataSourceCustomerId
--INTO #SCVCustomerMapping
--FROM [DBLINK_SVR_SCV].APSCV.dbo.SCVCustomerMapping a WITH (NOLOCK)
--WHERE (EXISTS
--(
--    SELECT ContactID
--    FROM #ICON_EntForms_Contacts
--    WHERE ContactID = a.DataSourceCustomerId
--));
----WHERE DataSourceCustomerID In(Select ContactID From #ICON_EntForms_Contacts)
	If(Object_ID('tempdb..#TmpQN')is not null)Drop table #TmpQN
	If(Object_ID('tempdb..#Project')is not null)Drop table #Project
	If(Object_ID('tempdb..#CustomerAnswerHeader')is not null)Drop table #CustomerAnswerHeader
	If(Object_ID('tempdb..#CustomerAnswer')is not null)Drop table #CustomerAnswer
	If(Object_ID('tempdb..#Question')is not null)Drop table #Question
	If(Object_ID('tempdb..#Answer')is not null)Drop table #Answer
	If(Object_ID('tempdb..#Questionnaire')is not null)Drop table #Questionnaire
	If(Object_ID('tempdb..#TmpQNNew')is not null)Drop table #TmpQNNew
	If(Object_ID('tempdb..#TmpQN1')is not null)Drop table #TmpQN1
	If(Object_ID('tempdb..#TmpQN2')is not null)Drop table #TmpQN2
	If(Object_ID('tempdb..#TmpQN3')is not null)Drop table #TmpQN3
	If(Object_ID('tempdb..#TmpQN4')is not null)Drop table #TmpQN4
	If(Object_ID('tempdb..#TmpQN5')is not null)Drop table #TmpQN5
	If(Object_ID('tempdb..#TmpQN6')is not null)Drop table #TmpQN6
	If(Object_ID('tempdb..#TmpQN7')is not null)Drop table #TmpQN7
	If(Object_ID('tempdb..#TmpQN8')is not null)Drop table #TmpQN8
	If(Object_ID('tempdb..#TmpQN9')is not null)Drop table #TmpQN9
	If(Object_ID('tempdb..#TmpQN10')is not null)Drop table #TmpQN10
	If(Object_ID('tempdb..#TmpQN11')is not null)Drop table #TmpQN11
	If(Object_ID('tempdb..#TmpQN12')is not null)Drop table #TmpQN12
	If(Object_ID('tempdb..#TmpQN13')is not null)Drop table #TmpQN13

	If(Object_ID('tempdb..#APQuestionnaire')is not null)Drop table #APQuestionnaire
	--If(Object_ID('tempdb..#SCVCustomer')is not null)Drop table #SCVCustomer
	Select * 
	INTO #Project 
	FROM [DBLINK_SVR_QN].APQuestionnaire.dbo.Project p With(NoLock) 
	WHERE p.ProjectCode=@ProductID1

	Select ID,CustomerID,QuestionnaireID,QuestionnaireTakenDateOnDevice,ProjectID 
	INTO #CustomerAnswerHeader 
	FROM [DBLINK_SVR_QN].APQuestionnaire.dbo.CustomerAnswerHeader c WITH (NOLOCK) 
	WHERE (exists(Select ID From #Project WHERE ID=c.ProjectID)) --ProjectID in(Select ID From #Project) 
		AND (exists(Select ID From [DBLINK_SVR_QN].APQuestionnaire.dbo.Questionnaire With (Nolock) Where QuestionnaireTypeID=1 AND ID=c.QuestionnaireID));

	Select ID,AnswerID,QuestionID,CustomerAnswerHeaderID,AnswerText 
	INTO #CustomerAnswer 
	FROM [DBLINK_SVR_QN].APQuestionnaire.dbo.CustomerAnswer c WITH (NOLOCK) 
	WHERE QuestionID in(89,90,91,92,93,94,95,97,11,128,279,287,294,72,73,327,364,363,365,381,392,396,399,400,401,402,403,404,398,418,419) 
		AND EXISTS(Select ID From #CustomerAnswerHeader WHERE id=c.CustomerAnswerHeaderID);

	Select ID,Answer 
	INTO #Answer 
	FROM [DBLINK_SVR_QN].APQuestionnaire.dbo.Answer a WITH (NOLOCK) 
	WHERE exists(Select AnswerID From #CustomerAnswer WHERE AnswerID=a.ID)

	SELECT ID,Question 
	INTO #Question 
	FROM [DBLINK_SVR_QN].APQuestionnaire.dbo.Question a WITH (NOLOCK) 
	WHERE exists(Select QuestionId From #CustomerAnswer WHERE QuestionId=a.ID)


Select Distinct d.ProjectCode,d.ProjectName,a.CustomerID
--,'ContactID'=Convert(NVarchar(50),'')
,'ContactID'=Convert(NVarchar(50),a.CustomerID)
,Convert(DateTime,Convert(nvarchar(8),a.QuestionnaireTakenDateOnDevice,112)) AnswerDate
,'Question' = CASE WHEN q.id IN (89,392) THEN 'ทราบข่าวจาก'
				 WHEN q.id = 90 THEN 'ป้าย'
				 WHEN q.id = 91 THEN 'หนังสือพิมพ์'
				 WHEN q.id = 92 THEN 'Internet'
				 WHEN q.id = 93 THEN 'สื่ออื่นๆ'
				 WHEN q.id = 94 THEN 'โทรทัศน์'
				 WHEN q.id = 95 THEN 'นิตยสาร'
				 WHEN q.id = 97 THEN 'วิทยุ' 
				 WHEN q.id = 418 THEN 'สื่ออื่นๆที่ท่านพบเห็น (Online)' 
				 WHEN q.id = 419 THEN 'สื่ออื่นๆที่ท่านพบเห็น (Offline)' END
,'Answer'= (Case When  isnull(b.AnswerText,'') <> '' then b.AnswerText Else c.Answer end)
,'QuestionType'=Case when QuestionID in(89,90,91,92,93,94,95,97 ,392,418,419) THEN 'Media' 
     WHEN QuestionID in(11,294,381,398)Then 'Budget' 
     WHEN QuestionID in(72,365 )Then 'Income' 
     WHEN QuestionID in(73,364 ,396)Then 'IncomeFamily'   
	 When QuestionID in(399)Then 'ลูกค้ามากี่คน'
	 When QuestionID in(400)Then 'CustomerFeature'--บุคลิกที่โดดเด่น(จุดเด่น/จุดด้อย)
	 When QuestionID in(128,279,327) Then 'เหตุผลที่แวะมาดูAP'
	 When QuestionID in(401)Then 'ProductCompare'--คู่แข่งที่เปรียบเทียบ
	 When QuestionID in(402)Then 'คนที่ตัดสินใจ'
	 When QuestionID in(403)Then 'ลักษณะสินค้าที่สนใจ'
	 When QuestionID in(363)Then 'ข้อโต้แย้ง'
	 When QuestionID in(404)Then 'ลูกค้าจะซื้อโครงการเราหรือไม่'
	 When QuestionID in(287)Then 'ความคิดเห็นพนักงาน/อื่นๆ' 
	 End 
	 ,'QN' = N'Old'
into #TmpQN
From #CustomerAnswerHeader as a WITH (NOLOCK)
Left Join #CustomerAnswer b WITH (NOLOCK)on a.id=b.CustomerAnswerHeaderID 
LEFT JOIN #Question q ON b.QuestionId = q.id
Left Join #Answer c WITH (NOLOCK)on b.AnswerID=c.ID 
Left Join #Project d WITH (NOLOCK)on d.ID=a.ProjectID 
Where QuestionID in(89,90,91,92,93,94,95,97,11,128,279,287,294,72,73,327,364,363,365,381,392,396,399,400,401,402,403,404,398,418,419) -- Media สื่อ,Budget,Income
and d.ProjectCode=@ProductID1
--and [dbo].[fn_ClearTime](a.QuestionnaireTakenDateOnDevice) between @DateStart2 and @DateEnd2InStore




select * 
INTO #APQuestionnaire
from [crmrevo].EQN.CustomerTransQAns with (nolock)
where projectid = @ProductID1
--and [dbo].[fn_ClearTime](created) between @DateStart2 and @DateEnd2InStore


Select Distinct a.projectid as ProjectCode,a.project_name as ProjectName
,Convert(NVarchar(50),a.contact_ref_id) as CustomerID
,'ContactID'=Convert(NVarchar(50),a.contact_ref_id)
,Convert(DateTime,Convert(nvarchar(8),a.created,112)) AnswerDate
,'Question' = Convert(NVarchar(100),NULL)
,'Answer'= a.csbudget
,'QuestionType'= N'Budget'
,'QN' = N'New'
into #TmpQN1
From #APQuestionnaire a WITH (NOLOCK) 
Where 1=1
and a.projectid=@ProductID1

Select Distinct a.projectid as ProjectCode,a.project_name as ProjectName
,Convert(NVarchar(50),a.contact_ref_id) as CustomerID
,'ContactID'=Convert(NVarchar(50),a.contact_ref_id)
,Convert(DateTime,Convert(nvarchar(8),a.created,112)) AnswerDate
,'Question' = Convert(NVarchar(100),NULL)
,'Answer'= (N'สื่ออื่นๆที่ท่านพบเห็น (Online) = ' +ISNULL(a.online_media,'-')) +','+ (N'สื่ออื่นๆที่ท่านพบเห็น (Offline) = ' + ISNULL(a.offline_media,'-'))
,'QuestionType'= N'Media'
,'QN' = N'New'
into #TmpQN2
From #APQuestionnaire a WITH (NOLOCK) 
Where 1=1
and a.projectid=@ProductID1 


Select Distinct a.projectid as ProjectCode,a.project_name as ProjectName
,Convert(NVarchar(50),a.contact_ref_id) as CustomerID
,'ContactID'=Convert(NVarchar(50),a.contact_ref_id)
,Convert(DateTime,Convert(nvarchar(8),a.created,112)) AnswerDate
,'Question' = Convert(NVarchar(100),NULL)
,'Answer'= a.csincome
,'QuestionType'= N'Income'
,'QN' = N'New'
into #TmpQN3
From #APQuestionnaire a WITH (NOLOCK) 
Where 1=1
and a.projectid=@ProductID1

Select Distinct a.projectid as ProjectCode,a.project_name as ProjectName
,Convert(NVarchar(50),a.contact_ref_id) as CustomerID
,'ContactID'=Convert(NVarchar(50),a.contact_ref_id)
,Convert(DateTime,Convert(nvarchar(8),a.created,112)) AnswerDate
,'Question' = Convert(NVarchar(100),NULL)
,'Answer'= a.family_income
,'QuestionType'= N'IncomeFamily'
,'QN' = N'New'
into #TmpQN4
From #APQuestionnaire a WITH (NOLOCK) 
Where 1=1
and a.projectid=@ProductID1

Select Distinct a.projectid as ProjectCode,a.project_name as ProjectName
,Convert(NVarchar(50),a.contact_ref_id) as CustomerID
,'ContactID'=Convert(NVarchar(50),a.contact_ref_id)
,Convert(DateTime,Convert(nvarchar(8),a.created,112)) AnswerDate
,'Question' = Convert(NVarchar(100),NULL)
,'Answer'= a.proj_compare
,'QuestionType'= N'ProductCompare'
,'QN' = N'New'
into #TmpQN5
From #APQuestionnaire a WITH (NOLOCK) 
Where 1=1
and a.projectid=@ProductID1

Select Distinct a.projectid as ProjectCode,a.project_name as ProjectName
,Convert(NVarchar(50),a.contact_ref_id) as CustomerID
,'ContactID'=Convert(NVarchar(50),a.contact_ref_id)
,Convert(DateTime,Convert(nvarchar(8),a.created,112)) AnswerDate
,'Question' = Convert(NVarchar(100),NULL)
,'Answer'= a.cspersona
,'QuestionType'= N'CustomerFeature'
,'QN' = N'New'
into #TmpQN6
From #APQuestionnaire a WITH (NOLOCK) 
Where 1=1
and a.projectid=@ProductID1

Select Distinct a.projectid as ProjectCode,a.project_name as ProjectName
,Convert(NVarchar(50),a.contact_ref_id) as CustomerID
,'ContactID'=Convert(NVarchar(50),a.contact_ref_id)
,Convert(DateTime,Convert(nvarchar(8),a.created,112)) AnswerDate
,'Question' = Convert(NVarchar(100),NULL)
,'Answer'= a.reason_visit
,'QuestionType'= N'เหตุผลที่แวะมาดูAP'
,'QN' = N'New'
into #TmpQN7
From #APQuestionnaire a WITH (NOLOCK) 
Where 1=1
and a.projectid=@ProductID1 

Select Distinct a.projectid as ProjectCode,a.project_name as ProjectName
,Convert(NVarchar(50),a.contact_ref_id) as CustomerID
,'ContactID'=Convert(NVarchar(50),a.contact_ref_id)
,Convert(DateTime,Convert(nvarchar(8),a.created,112)) AnswerDate
,'Question' = Convert(NVarchar(100),NULL)
,'Answer'= a.products_interest
,'QuestionType'= N'ลักษณะสินค้าที่สนใจ'
,'QN' = N'New'
into #TmpQN8
From #APQuestionnaire a WITH (NOLOCK) 
Where 1=1
and a.projectid=@ProductID1 

Select Distinct a.projectid as ProjectCode,a.project_name as ProjectName
,Convert(NVarchar(50),a.contact_ref_id) as CustomerID
,'ContactID'=Convert(NVarchar(50),a.contact_ref_id)
,Convert(DateTime,Convert(nvarchar(8),a.created,112)) AnswerDate
,'Question' = Convert(NVarchar(100),NULL)
,'Answer'= a.contradiction
,'QuestionType'= N'ข้อโต้แย้ง'
,'QN' = N'New'
into #TmpQN9
From #APQuestionnaire a WITH (NOLOCK) 
Where 1=1     
and a.projectid=@ProductID1

Select Distinct a.projectid as ProjectCode,a.project_name as ProjectName
,Convert(NVarchar(50),a.contact_ref_id) as CustomerID
,'ContactID'=Convert(NVarchar(50),a.contact_ref_id)
,Convert(DateTime,Convert(nvarchar(8),a.created,112)) AnswerDate
,'Question' =Convert(NVarchar(100),NULL)
,'Answer'= a.buyornot
,'QuestionType'= N'ลูกค้าจะซื้อโครงการเราหรือไม่'
,'QN' = N'New'
into #TmpQN10
From #APQuestionnaire a WITH (NOLOCK) 
Where 1=1 
and a.projectid=@ProductID1

Select Distinct a.projectid as ProjectCode,a.project_name as ProjectName
,Convert(NVarchar(50),a.contact_ref_id) as CustomerID
,'ContactID'=Convert(NVarchar(50),a.contact_ref_id)
,Convert(DateTime,Convert(nvarchar(8),a.created,112)) AnswerDate
,'Question' = Convert(NVarchar(100),NULL)
,'Answer'=isnull(a.comment,'')+ ' ' +isnull(a.other,'')
,'QuestionType'= N'ความคิดเห็นพนักงาน/อื่นๆ'
,'QN' = N'New'
into #TmpQN11
From #APQuestionnaire a WITH (NOLOCK) 
Where 1=1 
and a.projectid=@ProductID1

Select Distinct a.projectid as ProjectCode,a.project_name as ProjectName
,Convert(NVarchar(50),a.contact_ref_id) as CustomerID
,'ContactID'=Convert(NVarchar(50),a.contact_ref_id)
,Convert(DateTime,Convert(nvarchar(8),a.created,112)) AnswerDate
,'Question' = Convert(NVarchar(100),NULL)
,'Answer'=Convert(NVarchar(100),NULL)
,'QuestionType'= N'ลูกค้ามากี่คน'
,'QN' = N'New'
into #TmpQN12
From #APQuestionnaire a WITH (NOLOCK) 
Where 1=1 
and a.projectid=@ProductID1

Select Distinct a.projectid as ProjectCode,a.project_name as ProjectName
,Convert(NVarchar(50),a.contact_ref_id) as CustomerID
,'ContactID'=Convert(NVarchar(50),a.contact_ref_id)
,Convert(DateTime,Convert(nvarchar(8),a.created,112)) AnswerDate
,'Question' = Convert(NVarchar(100),NULL)
,'Answer'=Convert(NVarchar(100),NULL)
,'QuestionType'= N'คนที่ตัดสินใจ'
,'QN' = N'New'
into #TmpQN13
From #APQuestionnaire a WITH (NOLOCK) 
Where 1=1 
and a.projectid=@ProductID1
 
select  a.* 
into #TmpQNNew
from 
(
select * from #TmpQN1 union select * from #TmpQN2 union select * from #TmpQN3 union select * from #TmpQN4 union select * from #TmpQN5
union select * from #TmpQN6 union select * from #TmpQN7 union select * from #TmpQN8 union select * from #TmpQN9 union select * from #TmpQN10 
union select * from #TmpQN11 union select * from #TmpQN12 union select * from #TmpQN13
) a
If(Object_ID('tempdb..#UnionQN')is not null)Drop table #UnionQN

select a.*
into #UnionQN
from 
(
select * from #TmpQNNew
union
select * from  #TmpQN 
) a




Update #temp
Set Presentation=Left(Isnull((SELECT  distinct   
							STUFF((    SELECT  case when sub.QN = 'Old' then  ',' + SUB.Question +'='+ SUB.Answer 
												Else ',' + SUB.Answer end
											 AS [text()]
										FROM #UnionQN SUB
										WHERE QuestionType='Media' and 
										SUB.CustomerID = t.CustomerID and SUB.ProjectCode = t.ProjectCode
										and SUB.AnswerDate = (select max(AnswerDate) from #UnionQN where ContactID = SUB.ContactID and ProjectCode=SUB.ProjectCode )										
										FOR XML PATH('') 
										), 1, 1, '' )
							AS [Sub Categories]
							FROM  #UnionQN t
							Where QuestionType='Media' and t.ProjectCode=temp.ProductID and t.ContactID=temp.ContactID
							),''),500)
							

,Budget= Left(Isnull((SELECT  distinct   
							STUFF((    SELECT ',' + ISNULL(SUB.Answer,'') AS [text()]
										FROM #UnionQN SUB
										WHERE QuestionType='Budget' And SUB.Answer Is Not Null and 
										SUB.CustomerID = t.CustomerID and SUB.ProjectCode = t.ProjectCode
										and SUB.AnswerDate = (select max(AnswerDate) from #UnionQN where ContactID = SUB.ContactID and ProjectCode=SUB.ProjectCode)		
										FOR XML PATH('') 
										), 1, 1, '' )
							AS [Sub Categories]
				FROM  #UnionQN t
				Where QuestionType='Budget' and t.ProjectCode=temp.ProductID and t.ContactID=temp.ContactID),''),500)


,Income_1=Left(Isnull((SELECT  distinct   
							STUFF((    SELECT ',' + ISNULL(SUB.Answer,'') AS [text()]
										FROM #UnionQN SUB
										WHERE QuestionType='Income' and 
										SUB.CustomerID = t.CustomerID and SUB.ProjectCode = t.ProjectCode
										and SUB.AnswerDate = (select max(AnswerDate) from #UnionQN where ContactID = SUB.ContactID and ProjectCode=SUB.ProjectCode)		
										FOR XML PATH('') 
										), 1, 1, '' )
							AS [Sub Categories]
				FROM  #UnionQN t
				Where QuestionType='Income' and t.ProjectCode=temp.ProductID and t.ContactID=temp.ContactID),''),500)
,Income_2=Left(Isnull((SELECT  distinct   
							STUFF((    SELECT ',' + ISNULL(SUB.Answer,'') AS [text()]
										FROM #UnionQN SUB
										WHERE QuestionType='IncomeFamily' and
										SUB.CustomerID = t.CustomerID and SUB.ProjectCode = t.ProjectCode
										and SUB.AnswerDate = (select max(AnswerDate) from #UnionQN where ContactID = SUB.ContactID and ProjectCode=SUB.ProjectCode)		
										FOR XML PATH('') 
										), 1, 1, '' )
							AS [Sub Categories]
				FROM  #UnionQN t
				Where QuestionType='IncomeFamily' and t.ProjectCode=temp.ProductID and t.ContactID=temp.ContactID),''),500)
,ProductCompare=Left(Isnull(temp.ProductCompare,'')+' '+ IsNull((Select Top 1 t.Answer From #UnionQN t Where t.QuestionType='ProductCompare' and t.ProjectCode=temp.ProductID and t.ContactID=temp.ContactID order by t.AnswerDate desc),'') ,500)
,CustomerFeature=Left(Isnull(temp.CustomerFeature,'')+' '+IsNull((Select Top 1 t.Answer From #UnionQN t Where t.QuestionType='CustomerFeature' and t.ProjectCode=temp.ProductID and t.ContactID=temp.ContactID order by t.AnswerDate,t.Answer desc),'') ,500)
, OppDetail8 =  Left(IsNull((Select Top 1 t.Answer From #UnionQN t Where t.QuestionType='ลูกค้ามากี่คน' and t.ProjectCode=temp.ProductID and t.ContactID=temp.ContactID order by t.AnswerDate desc),'') ,500)
, OppDetail3 =  Left(IsNull((Select Top 1 t.Answer From #UnionQN t Where t.QuestionType='เหตุผลที่แวะมาดูAP' and t.ProjectCode=temp.ProductID and t.ContactID=temp.ContactID order by t.AnswerDate desc),'') ,500)
, OppDetail4 =  Left(IsNull((Select Top 1 t.Answer From #UnionQN t Where t.QuestionType='คนที่ตัดสินใจ' and t.ProjectCode=temp.ProductID and t.ContactID=temp.ContactID order by t.AnswerDate desc),'') ,500)
, OppDetail2 =  Left(IsNull((Select Top 1 t.Answer From #UnionQN t Where t.QuestionType='ลักษณะสินค้าที่สนใจ' and t.ProjectCode=temp.ProductID and t.ContactID=temp.ContactID order by t.AnswerDate desc),'') ,500)
, OppDetail7 =  Left(IsNull((Select Top 1 t.Answer From #UnionQN t Where t.QuestionType='ข้อโต้แย้ง' and t.ProjectCode=temp.ProductID and t.ContactID=temp.ContactID order by t.AnswerDate desc),'') ,500)
, OppDetail6 =  Left(IsNull((Select Top 1 t.Answer From #UnionQN t Where t.QuestionType='ลูกค้าจะซื้อโครงการเราหรือไม่' and t.ProjectCode=temp.ProductID and t.ContactID=temp.ContactID order by t.AnswerDate desc),'') ,500)
, OppDetail9 =  Left(IsNull((Select Top 1 t.Answer From #UnionQN t Where t.QuestionType='ความคิดเห็นพนักงาน/อื่นๆ' and t.ProjectCode=temp.ProductID and t.ContactID=temp.ContactID order by t.AnswerDate desc),'') ,500)

From #temp temp 

If(Object_ID('TempFollow')is not null)Drop table TempFollow
select *,
@DateStart2 AS DateStart2,
@DateEnd2 AS DateEnd2
into TempFollow
from #temp 
where ((@Disqualify=0  )
						or (@Disqualify=1  and status <> 'Disqualify')
						or (@Disqualify=2  and status = 'Disqualify'))
and  (Isnull(@EmpCode,'')='' or OwnerID=@EmpCode)

--select * from ##TempFollow


go

