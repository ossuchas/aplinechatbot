
CREATE PROCEDURE [dbo].[sp_Executive_ByProject]
--declare
@ProjectID varchar(500)=''
,@DateStart DATETIME  
,@DateEnd DATETIME 
AS 
BEGIN
    SET NOCOUNT ON;

	--SET @DateStart = '20200921'
	--SET @DateEnd = '20200930'
	
	PRINT @DateStart
	PRINT @DateEnd

	-------------------#Temp_Walk
	IF(OBJECT_ID('tempdb..#vw_CRM_Walk') IS NOT NULL) DROP table #vw_CRM_Walk
	SELECT * INTO #vw_CRM_Walk FROM crmrevo.dbo.vw_CRM_Walk_1 WHERE 1=1 AND CreateDate BETWEEN @DateStart AND @DateEnd

	EXEC sp_RPT_ExecutiveMail_Prepare @DateStart = @DateStart, @DateEnd = @DateEnd
													
	------------------Final Before Insert Table Closing---------------
	IF(OBJECT_ID('tempdb..##temp_ex') IS NOT NULL) DROP table ##temp_ex

	SELECT 'CloseDate' = @DateStart, 
	'Weeks' = (SELECT TOP 1 W FROM crmrevo.BI.Mst_Calendar_Week WHERE @DateStart BETWEEN StartDate AND EndDate)
	,t.ProjectID, t.ProductID AS ProjectNo
	,'isJV' = (SELECT COUNT(*) FROM dbo.vw_SaleProjectJV tt WITH(NOLOCK) WHERE tt.ProjectID = t.ProjectID)
	, t.Project AS ProjectName
	,t.BU AS BG, t.ProjectGroup AS SubBG, t.TotalUnit, t.TotalPrice, t.EmptyUnit AS AvailableUnit
	,t.EmptyPrice AS AvailablePrice, 
	--t.TotalWalk, 
	'TotalWalk' = ISNULL((SELECT SUM(a.WalkAmt) FROM #vw_CRM_Walk a WHERE 1=1 AND a.Project = t.ProductID),0),
	t.BookingTotalUnit AS GrossTotalUnit, t.BookingTotalPrice AS GrossTotalPrice
	,t.CancelTotalUnit	,t.CancelTotalPrice	,ISNULL(t.BookingTotalUnit,0) + ISNULL(t.CancelTotalUnit,0) AS NetTotalUnit
	,ISNULL(t.BookingTotalPrice,0) + ISNULL(t.CancelTotalPrice,0) AS NetTotalPrice
	,t.TransferTotalUnit, t.TransferTotalPrice
	--,t.PTDBookingTotalPrice, t.PTDBookingTotalUnit, t.PTDTransferTotalPrice, t.PTDTransferTotalUnit
	,ISNULL(gr.GrossTotalUnit,0) AS PTDBookingTotalUnit, ISNULL(gr.GrossNetPrice,0)/1000000 AS PTDBookingTotalPrice
	,ISNULL(tf.TransferTotalUnit,0) AS PTDTransferTotalUnit, ISNULL(tf.TransferNetPrice,0)/1000000 AS PTDTransferTotalPrice
	,tff.FirstUnitTransferDate, tff.LasttUnitTransferDate,
	'IsUpCountry' = ISNULL((SELECT TOP 1 p.IsUpCountry FROM crmrevo.PRJ.Project p WITH(NOLOCK) WHERE 1=1 AND p.ID = t.ProjectID),0) --Modified by Suchat S.
	INTO ##temp_ex
	FROM ##ExecutiveReport t 
	LEFT JOIN (
		SELECT a.ProjectID, COUNT(a.UnitNo) AS GrossTotalUnit, SUM(a.TotalPrice)-SUM(a.FreedownPrice) AS GrossNetPrice
		FROM dbo.vw_UnitStatusBacklog a WITH(NOLOCK)
		WHERE 1=1
		AND a.UnitStatus NOT IN ('AV')
		GROUP BY a.ProjectID
	) gr ON gr.ProjectID = t.ProjectID
	LEFT JOIN (
		SELECT a.ProjectID, COUNT(a.UnitNo) AS TransferTotalUnit, SUM(a.TotalPrice)-SUM(a.FreedownPrice) AS TransferNetPrice
		FROM dbo.vw_UnitStatusBacklog a WITH(NOLOCK)
		WHERE 1=1
		AND a.UnitStatus = 'TF'
		GROUP BY a.ProjectID
	) tf ON tf.ProjectID = t.ProjectID
	LEFT JOIN (
		SELECT a.ProjectID, MIN(a.ActualTransferDate) AS FirstUnitTransferDate, MAX(a.ActualTransferDate) as LasttUnitTransferDate
		FROM dbo.vw_ActualTransfer a WITH(NOLOCK)
		WHERE a.ProjectID IS NOT NULL
		GROUP BY a.ProjectID 
	) tff ON tff.ProjectID = t.ProjectID
	WHERE t.Project NOT LIKE '%(ระงับใช้)%'
	ORDER BY ProjectGroup, Bu, ProductID

	
END;



go

