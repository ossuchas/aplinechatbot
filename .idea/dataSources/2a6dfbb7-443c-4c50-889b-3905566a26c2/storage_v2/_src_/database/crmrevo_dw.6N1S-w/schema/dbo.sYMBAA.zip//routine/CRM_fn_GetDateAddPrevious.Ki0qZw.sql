CREATE FUNCTION [dbo].[CRM_fn_GetDateAddPrevious]
(
    @ApprovedDate DATE,
    @day_add INT
)
RETURNS DATE
AS
BEGIN
    DECLARE @TRAN_ID BIGINT;
    DECLARE @DateOfYear DATE;
    --DECLARE @ApprovedDate DATE;
    DECLARE @i_count INT;
    --DECLARE @day_add INT;

    --SET @day_add = 7;
    SET @i_count = 0;
    --SET @ApprovedDate = '2019-10-09';

    SELECT TOP 1
        @DateOfYear = DateOfYear
    FROM crmrevo.BI.Mst_WorkDayCalendar WITH(NOLOCK)
    WHERE 1 = 1
          AND DateOfYear = @ApprovedDate;

    DECLARE db_cursor CURSOR FOR
    SELECT DateOfYear,
           Tran_Id
    FROM crmrevo.BI.Mst_WorkDayCalendar
    WHERE 1 = 1
      AND SatSunDayFlag = 'N'
      AND HolidayFlag = 'N'
      AND DateOfYear < @DateOfYear
	  ORDER BY DateOfYear desc

    OPEN db_cursor;
    FETCH NEXT FROM db_cursor
    INTO @DateOfYear,
         @TRAN_ID;

    WHILE @@FETCH_STATUS = 0
    BEGIN

        --PRINT @TRAN_ID;

        SET @i_count = @i_count + 1;

        IF @i_count >= @day_add
        BEGIN
            --PRINT 'kai : TRAN_ID = ' + CAST(@TRAN_ID AS VARCHAR(3)) + ' Date = ' + CAST(@DateOfYear AS VARCHAR(20));
            RETURN @DateOfYear;
            BREAK;
        END;

        FETCH NEXT FROM db_cursor
        INTO @DateOfYear,
             @TRAN_ID;
    END;

    CLOSE db_cursor;
    DEALLOCATE db_cursor;

    RETURN CAST(GETDATE() AS DATE);

END;

go

