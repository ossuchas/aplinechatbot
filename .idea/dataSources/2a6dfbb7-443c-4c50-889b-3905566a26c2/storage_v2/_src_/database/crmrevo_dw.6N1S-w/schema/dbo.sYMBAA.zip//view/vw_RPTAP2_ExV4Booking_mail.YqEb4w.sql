

--SELECT * FROM [dbo].[vw_RPTAP2_ExV4Booking]
CREATE VIEW [dbo].[vw_RPTAP2_ExV4Booking_mail]
AS
SELECT	BK.UnitID
		, COUNT(BK.UnitID) AS UnitAmt
		--, SUM(CASE	WHEN ISNULL(BK.CancelType, 0) = 2 AND ISNULL(BK.IsFromChangeUnit, 0) = 1 AND BK.ChangeFromBookingID IS NULL
		, SUM(CASE	WHEN ISNULL(BK.CancelType, 0) = 2 AND BK.ChangeFromBookingID IS NULL
					THEN   
						ISNULL(ISNULL(ISNULL(ISNULL(ISNULL(ISNULL(ISNULL(UP7.SellingPrice,UP6.SellingPrice),UP5.SellingPrice),UP4.SellingPrice),UP3.SellingPrice),UP2.SellingPrice),UP1.SellingPrice),0) 
						- ISNULL(ISNULL(ISNULL(ISNULL(ISNULL(ISNULL(ISNULL(UP7.CashDiscount,UP6.CashDiscount),UP5.CashDiscount),UP4.CashDiscount),UP3.CashDiscount),UP2.CashDiscount),UP1.CashDiscount),0) 
						- ISNULL(ISNULL(ISNULL(ISNULL(ISNULL(ISNULL(ISNULL(UP7.TransferDiscount,UP6.TransferDiscount),UP5.TransferDiscount),UP4.TransferDiscount),UP3.TransferDiscount),UP2.TransferDiscount),UP1.TransferDiscount),0) 
					ELSE ISNULL(UP.SellingPrice, 0) - ISNULL(UP.TransferDiscount, 0) - ISNULL(UP.CashDiscount, 0) END) AS BKPrice
		, BK.BookingDate
		, DATEPART(WEEK, BK.BookingDate) AS WeekAmt
		, DATEPART(MM, BK.BookingDate) AS MonthAmt
		, BK.ProjectID AS ProjectID
		,bk.id AS BookingID
FROM	[crmrevo].[SAL].[Booking] BK WITH (NOLOCK)
		LEFT OUTER JOIN [crmrevo].[SAL].[Booking] BK1 WITH (NOLOCK) ON BK.ID = BK1.ChangeFromBookingID AND ISNULL(BK1.IsDeleted,0) = 0
		LEFT OUTER JOIN [crmrevo].[SAL].[Booking] BK2 WITH (NOLOCK) ON BK1.ID = BK2.ChangeFromBookingID AND ISNULL(BK2.IsDeleted,0) = 0
		LEFT OUTER JOIN [crmrevo].[SAL].[Booking] BK3 WITH (NOLOCK) ON BK2.ID = BK3.ChangeFromBookingID AND ISNULL(BK3.IsDeleted,0) = 0
		LEFT OUTER JOIN [crmrevo].[SAL].[Booking] BK4 WITH (NOLOCK) ON BK3.ID = BK4.ChangeFromBookingID AND ISNULL(BK4.IsDeleted,0) = 0
		LEFT OUTER JOIN [crmrevo].[SAL].[Booking] BK5 WITH (NOLOCK) ON BK4.ID = BK5.ChangeFromBookingID AND ISNULL(BK5.IsDeleted,0) = 0
		LEFT OUTER JOIN [crmrevo].[SAL].[Booking] BK6 WITH (NOLOCK) ON BK5.ID = BK6.ChangeFromBookingID AND ISNULL(BK6.IsDeleted,0) = 0
		LEFT OUTER JOIN [crmrevo].[SAL].[Booking] BK7 WITH (NOLOCK) ON BK6.ID = BK7.ChangeFromBookingID AND ISNULL(BK7.IsDeleted,0) = 0
		LEFT OUTER JOIN (SELECT UP.* FROM [crmrevo].[dbo].[vw_UnitPrice] UP WITH (NOLOCK)
							INNER JOIN[crmrevo]. [MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '1' --1=จอง
						) AS UP ON BK.ID = UP.BookingID
		LEFT OUTER JOIN (SELECT UP.* FROM [crmrevo].[dbo].[vw_UnitPrice] UP WITH (NOLOCK)
							INNER JOIN [crmrevo].[MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '1' --1=จอง
						) AS UP1 ON BK1.ID = UP1.BookingID
		LEFT OUTER JOIN (SELECT UP.* FROM [crmrevo].[dbo].[vw_UnitPrice] UP WITH (NOLOCK)
							INNER JOIN [crmrevo].[MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '1' --1=จอง
						) AS UP2 ON BK2.ID = UP2.BookingID
		LEFT OUTER JOIN (SELECT UP.* FROM [crmrevo].[dbo].[vw_UnitPrice] UP WITH (NOLOCK)
							INNER JOIN [crmrevo].[MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '1' --1=จอง
						) AS UP3 ON BK3.ID = UP3.BookingID
		LEFT OUTER JOIN (SELECT UP.* FROM [crmrevo].[dbo].[vw_UnitPrice] UP WITH (NOLOCK)
							INNER JOIN [crmrevo].[MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '1' --1=จอง
						) AS UP4 ON BK4.ID = UP4.BookingID
		LEFT OUTER JOIN (SELECT UP.* FROM [crmrevo].[dbo].[vw_UnitPrice] UP WITH (NOLOCK)
							INNER JOIN [crmrevo].[MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '1' --1=จอง
						) AS UP5 ON BK5.ID = UP5.BookingID
		LEFT OUTER JOIN (SELECT UP.* FROM [crmrevo].[dbo].[vw_UnitPrice] UP WITH (NOLOCK)
							INNER JOIN [crmrevo].[MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '1' --1=จอง
						) AS UP6 ON BK6.ID = UP6.BookingID
		LEFT OUTER JOIN (SELECT UP.* FROM [crmrevo].[dbo].[vw_UnitPrice] UP WITH (NOLOCK)
							INNER JOIN [crmrevo].[MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '1' --1=จอง
						) AS UP7 ON BK7.ID = UP7.BookingID
WHERE ISNULL(BK.IsDeleted, 0) = 0 AND ISNULL(BK.BookingNo, '') <> '' AND BK.id NOT IN(SELECT BookingID FROM [crmrevo].dbo.vw_ChangeUnit)
	  AND ((ISNULL(BK.IsFromChangeUnit, 0) = 0) AND (ISNULL(BK.CancelType, 0) = 0) 
      --OR ((ISNULL(BK.IsFromChangeUnit, 0) = 1) AND (ISNULL(BK.CancelType, 0) = 2) AND (BK.ChangeFromBookingID IS NULL))
      OR ((ISNULL(BK.CancelType, 0) = 2) AND (BK.ChangeFromBookingID IS NULL))
      OR ((ISNULL(BK.IsFromChangeUnit, 0) = 0) AND (ISNULL(BK.CancelType, 0) IN (3, 1)) AND (BK.ChangeFromBookingID IS NULL)))
GROUP BY BK.UnitID, BK.BookingDate, BK.ProjectID,bk.id;


go

