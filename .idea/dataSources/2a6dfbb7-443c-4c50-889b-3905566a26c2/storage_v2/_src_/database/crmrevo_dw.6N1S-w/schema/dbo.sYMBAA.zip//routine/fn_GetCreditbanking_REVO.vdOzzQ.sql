CREATE FUNCTION [dbo].[fn_GetCreditbanking_REVO] 
(
	@ContractNumber nvarchar(100)
)
RETURNS nvarchar(1000)
AS
BEGIN
	DECLARE @strCreditbanking nvarchar(1000)

	DECLARE @strBankName nvarchar(100) 
	DECLARE @strloan nvarchar(100) 
	DECLARE @strStatus nvarchar(100) 
	
	set @strCreditbanking=''
	set @strBankName=''
	set @strloan=''
	set @strStatus=''
	
	DECLARE db_cursor CURSOR FOR  
	
    Select bank.Alias,CONVERT(VARCHAR,ApprovedAmount,1) amount,m.[KEY] AS [status] 
	from [crmrevo].sal.CreditBanking as C With(NoLock)
	 Left JOIN [crmrevo].mst.Bank as Bank  With(NoLock)on (C.BankID = Bank.id) AND bank.IsDeleted = 0
	 INNER JOIN [crmrevo].mst.MasterCenter m With(NoLock) ON m.id = C.LoanStatusMasterCenterID
	 LEFT JOIN [crmrevo].sal.Booking b With(NoLock) ON  b.id = c.BookingID AND b.IsDeleted = 0
	  LEFT JOIN [crmrevo].sal.Agreement ag With(NoLock) ON C.BookingID = ag.BookingID AND ag.IsDeleted = 0	
	where (ag.AgreementNo = @ContractNumber OR b.BookingNo = @ContractNumber )AND c.IsDeleted = 0
	Order by c.LoanSubmitDate
    
    OPEN db_cursor   
	FETCH NEXT FROM db_cursor INTO @strBankName,@strloan,@strStatus

	WHILE @@FETCH_STATUS = 0   
	BEGIN   
	   if ISNULL(@strCreditbanking,'')='' 
		begin
			if @strStatus ='1'
				SET @strCreditbanking = @strCreditbanking + @strBankName + '(' +@strloan+')'
			else if @strStatus ='2'
				SET @strCreditbanking = @strCreditbanking + @strBankName + '(R)'
			else if isnull(@strStatus,'3') ='3'
				SET @strCreditbanking = @strCreditbanking + @strBankName + '(W)'
			else if @strStatus ='4'
				SET @strCreditbanking = @strCreditbanking + @strBankName + '(C)'
		 end
	   else
		   begin
			if @strStatus ='1'
				SET @strCreditbanking = @strCreditbanking + '/'+@strBankName + '(' +@strloan+')'
			else if @strStatus ='2'
				SET @strCreditbanking = @strCreditbanking + '/'+@strBankName + '(R)'
			else if isnull(@strStatus,'3') ='3'
				SET @strCreditbanking = @strCreditbanking + '/'+@strBankName + '(W)'
			else if @strStatus ='4'
				SET @strCreditbanking = @strCreditbanking + '/'+@strBankName + '(C)'
		   end	 
      
       FETCH NEXT FROM db_cursor INTO @strBankName,@strloan ,@strStatus 
	END   

	CLOSE db_cursor   
	DEALLOCATE db_cursor

	RETURN @strCreditbanking

END

go

