CREATE PROCEDURE [dbo].[sp_RPT_MornitorTracking_Followup_excel] @ProductID uniqueidentifier
  , @DateStart DATETIME       --วันที่ต้องทำ(Plan)   ActivityDate
  , @DateEnd DATETIME
  , @DateStart2 DATETIME         --วันที่ทำจริง
  , @DateEnd2 DATETIME 
  , @DateStart3 DATETIME         --LeadDate
  , @DateEnd3 DATETIME 
  , @DateStart4 DATETIME         --OppDate
  , @DateEnd4 DATETIME 
  , @Username NVARCHAR(100)
  , @EmpCode1 NVARCHAR(50)
  , @LCByProduct NVARCHAR(100)
  , @Lead NVARCHAR(10) = '1'
  , @FirstWalk NVARCHAR(10) = '1'
  , @Revisit NVARCHAR(10) = '1'
  , @FollowUpStatus NVARCHAR(50) = ''
  AS
--DECLARE
--    @ProductID uniqueidentifier= '76B1B40F-74C7-43E3-B0A6-26D5B9FACD6D'
--  , @DateStart DATETIME      =NULL      --วันที่ต้องทำ(Plan)   ActivityDate
--  , @DateEnd DATETIME		 =NULL 
--  , @DateStart2 DATETIME    = NULL--'20200101'       --วันที่ทำจริง
--  , @DateEnd2 DATETIME  = NULL--'20200430'
--  , @DateStart3 DATETIME    = '2020-09-28' -- LeadDate
--  , @DateEnd3 DATETIME  = '2020-09-28' -- LeadDate
--  , @DateStart4 DATETIME    = NULL -- OpDate
--  , @DateEnd4 DATETIME  = NULL -- OpDate
--  , @Username NVARCHAR(100) = 'ธนพล วงศ์พิภพมงคล'
--  , @EmpCode1 NVARCHAR(50) = 'AP004824'
--  , @LCByProduct  NVARCHAR(100) = ''
--  , @Lead NVARCHAR(10) = '1'
--  , @FirstWalk NVARCHAR(10) = ''
--  , @Revisit NVARCHAR(10) = ''
--  , @FollowUpStatus NVARCHAR(50) = '3' -- All,Disqualify,Followup,Completed

BEGIN
	
    IF (@DateStart IS NULL)
        SET @DateStart = '18000101';

    IF (@DateEnd IS NULL)
        SET @DateEnd = '70001231';

    IF (@DateStart2 IS NULL)
        SET @DateStart2 = '18000101';

    IF (@DateEnd2 IS NULL)
        SET @DateEnd2 = '70001231';

	IF (@DateStart3 IS NULL)
        SET @DateStart3 = '18000101';

    IF (@DateEnd3 IS NULL)
        SET @DateEnd3 = '70001231';

	IF (@DateStart4 IS NULL)
        SET @DateStart4 = '18000101';

    IF (@DateEnd4 IS NULL)
        SET @DateEnd4 = '70001231';

    IF (@FollowUpStatus IS NULL)
        SET @FollowUpStatus = '';

    ---------- Select Project by Permission ---------------
 --   DECLARE @EmpCode NVARCHAR(50);
 --   IF (ISNULL(@LCByProduct,'') = '')
	--	Set @EmpCode = '';
		
 --   --    SET @LCByProduct = '-1';
	--IF (ISNULL(@LCByProduct,'') <> '')
	-- SET @EmpCode = (SELECT top 1 EmployeeNo FROM USR.[User]
	--  WHERE 1=1
	--  AND (EmployeeNo = @LCByProduct OR ISNULL(@LCByProduct,'') = ''));

	--IF (@DateStart3 IS NOT NULL OR (@DateEnd3 IS NOT NULL))
	--	SET @Lead ='1'
	--	SET @FirstWalk = ''
	--	SET @Revisit = '';


    IF (ISNULL(@Username, '') = 'Administrator')
        SET @EmpCode1 = '';


    IF (@EmpCode1 IS NULL)
	    SET @EmpCode1 = '';
	

    IF (OBJECT_ID('tempdb..#TProject') IS NOT NULL)
        DROP TABLE #TProject;
	

    SELECT *
    INTO #TProject
    FROM (   SELECT ProjectID
             FROM [dbo].[fn_GetProjectAuthorised](ISNULL(@EmpCode1, '')) t
             WHERE (@ProductID IS NULL OR t.ProjectID = @ProductID)
             UNION
             SELECT P.ID AS ProjectID
             FROM [crmrevo].PRJ.Project P With (nolock)
			 Inner JOIN [crmrevo].MST.MasterCenter MST With (nolock) ON MST.ID = P.ProjectStatusMasterCenterID AND MST.[Key] = 1
             WHERE 1=1
			 --ISNULL(RTPExcusive, 0) = 1
                 AND (ISNULL(@Username, '') = '' OR ISNULL(@Username, '') = 'Administrator')
                 AND (@ProductID IS NULL  OR P.ID = @ProductID)) t;
				 --select * from #TProject

	 DECLARE @OwnerID NVARCHAR(200);
	IF (ISNULL(@LCByProduct,'') = '')
		Set @OwnerID = '';


	IF (ISNULL(@LCByProduct,'') <> '')
	 SET @OwnerID = (SELECT top 1 ID FROM [crmrevo].USR.[User]
	  WHERE 1=1
	  AND (EmployeeNo = @LCByProduct OR ISNULL(@LCByProduct,'') = ''));



    --SET @EmpCode = ISNULL((SELECT EmployeeID FROM Users WHERE ISNULL(@LCByProduct, '') <> '' AND CONVERT(NVARCHAR(50), UserID) = @LCByProduct), '');
    --IF (ISNULL(@Username, '') = 'Administrator')
    --    SET @EmpCode = '';
		--select @EmpCode
    IF OBJECT_ID('tempdb..#tmpLeads') IS NOT NULL
        DROP TABLE #tmpLeads;

    SELECT L.ID AS LeadsID --
      , L.ContactID
      --, L.LeadReference --
      , L.FirstName
      , L.LastName
      , L.PhoneNumber
      , L.Telephone
      , L.TelephoneExt
      , P.ProjectNo AS ProjectID
      , p.ProjectNameTH AS ProjectName
      , MST.[KEY] AS LeadsTypeID
	  , MST.Name AS LeadsTypeName1
      , MSTA.[Name] AS Advertisement
      , MSTA.[KEY] AS AdvertisementID
      , MSTS.[KEY] AS LeadsStatus
      , L.Remark
	  , Usr.ID AS UserID
      , Usr.EmployeeNo AS OwnerID
      , L.CreatedByUserID AS CreateBy
      , Convert(datetime,L.Created) AS CreateDate
      , L.UpdatedByUserID AS EditBy
      , Convert(datetime,L.Updated) AS EditDate
      , L.refID
      , L.SubLeadType AS ContactType
      , N'โครงการ'+ MSTP.name AS Producttype
      , 'LeadsTypeName' = (CASE WHEN MST.[KEY] = 'W' THEN N'Web' WHEN MST.[KEY] = 'C' THEN N'Call' WHEN MST.[KEY]= 'F' THEN N'Facebook' ELSE '' END)
	  , LA.ID AS CurrentCategoryID
	  , L.LeadDate
    INTO #tmpLeads
    FROM [crmrevo].CTM.Lead L With (Nolock)
    LEFT JOIN [crmrevo].PRJ.Project p With (Nolock) ON L.ProjectID = p.ID
	LEFT JOIN [crmrevo].usr.[User] Usr With (Nolock) ON L.OwnerID = Usr.ID
	LEFT JOIN [crmrevo].CTM.LeadActivityStatus LA With (Nolock) ON L.CurrentLeadActivityStatusID = LA.id	
	LEFT JOIN [crmrevo].MST.MasterCenter MST With (Nolock) ON MST.ID = L.LeadTypeMasterCenterID	AND MST.MasterCenterGroupKey = 'LeadType' 		
	LEFT JOIN [crmrevo].MST.MasterCenter MSTA With (Nolock) ON MSTA.ID = L.AdvertisementMasterCenterID AND MSTA.MasterCenterGroupKey = 'Advertisement' 
	LEFT JOIN [crmrevo].MST.MasterCenter MSTS With (Nolock) ON MSTS.ID = L.LeadStatusMasterCenterID AND MSTS.MasterCenterGroupKey = 'LeadStatus'
	LEFT JOIN [crmrevo].MST.MasterCenter MSTP With (Nolock) ON MSTP.ID = P.ProductTypeMasterCenterID AND MSTP.MasterCenterGroupKey = 'ProductType'
    WHERE 1 = 1 --L.LeadsStatus = '0'
		AND P.ID IN (SELECT ProjectID FROM #TProject)
		AND (cast(L.OwnerID AS nvarchar(200)) = @OwnerID OR isnull(@OwnerID,'') ='')  
        AND ((YEAR(@DateStart3) = 1800 OR @DateStart3 IS NULL)  AND (YEAR(@DateEnd3) = 7000 OR @DateEnd3 IS NULL) OR dbo.fn_ClearTime(L.LeadDate) BETWEEN @DateStart3 AND @DateEnd3)
		--AND MSTS.[key] = 0 /*CRM-9752 เพิ่ม status Disqualify*/
		and L.IsDeleted =0


	IF OBJECT_ID('tempdb..#tmpOpp') IS NOT NULL
        DROP TABLE #tmpOpp;
		select O.*
		INTO #tmpOpp
		FROM [crmrevo].CTM.Opportunity O
		where 1 =1
		AND O.IsDeleted =0
		AND  O.ProjectID IN (SELECT ProjectID FROM #TProject)
		AND (cast(O.OwnerID AS nvarchar(200)) = @OwnerID OR isnull(@OwnerID,'') ='')  
		AND ((YEAR(@DateStart4) = 1800 OR @DateStart4 IS NULL)  AND (YEAR(@DateEnd4) = 7000 OR @DateEnd4 IS NULL) OR dbo.fn_ClearTime(O.Created) BETWEEN @DateStart4 AND @DateEnd4)

    DECLARE @ToDayDate AS DATE = CONVERT(DATE, GETDATE());

	--////////// #temp LeadActivity //////////////////// Begin

    IF OBJECT_ID('tempdb..#tmpActivity') IS NOT NULL
        DROP TABLE #tmpActivity;

    SELECT *
      , (CASE
            WHEN A.ActualDate IS NULL
                AND CONVERT(DATE, A.DueDate) < @ToDayDate THEN N'red'
            WHEN A.ActualDate IS NULL
                AND CONVERT(DATE, A.DueDate) = @ToDayDate THEN N'yellow'
            WHEN A.ActualDate IS NULL
                AND CONVERT(DATE, A.DueDate) > @ToDayDate THEN N'white'
            WHEN A.ActualDate IS NOT NULL THEN N'green'
        END) AS OverDue
      , 'DateDiff' = (CASE WHEN A.ActualDate IS NOT NULL THEN DATEDIFF(DAY, A.ActualDate, A.DueDate)ELSE DATEDIFF(DAY, @ToDayDate, A.DueDate) END)
    INTO #tmpActivity
    FROM [crmrevo].CTM.LeadActivity A With (Nolock)
    WHERE 1 = 1 and A.IsDeleted =0		
        AND (YEAR(@DateStart) = 1800 OR YEAR(@DateEnd) = 7000 OR dbo.fn_ClearTime(A.DueDate) BETWEEN @DateStart AND @DateEnd)
        AND (YEAR(@DateStart2) = 1800 OR YEAR(@DateEnd2) = 7000 OR dbo.fn_ClearTime(A.ActualDate) BETWEEN @DateStart2 AND @DateEnd2)
		

    IF OBJECT_ID('tempdb..#tmpLeadsActivity') IS NOT NULL
        DROP TABLE #tmpLeadsActivity;

    SELECT 'Topic' = N'Lead'
      , A.ID AS ActivityID
      , CONVERT(uniqueidentifier,NULL) AS OpportunityID
      --, CONVERT(NVARCHAR(351), L.LeadsID) AS RefID
      , MST.[KEY] AS TaskID
      , MST.name AS TaskText
      , '1' AS ActivityType
      , N'Leads' AS ActivityTypeText
      , ISNULL(L.FirstName, '') + ' ' + ISNULL(L.LastName, '') AS DisplayName
      , L.PhoneNumber AS Mobile
      , Convert(datetime,A.DueDate) AS ActivityDate
      , Convert(datetime,A.ActualDate) AS ActualDate
	  --, Convert(datetime,L.LeadDate) AS LeadDate
	  --, Convert(datetime,NULL) AS Oppdate
      , Convert(datetime,A.AppointmentDate) AS AppointDate
      , L.LeadsTypeID
      , L.LeadsTypeName1 AS LeadsTypeText
	  , L.UserID
      , L.OwnerID
      , Usr.FirstName + ' ' + Usr.LastName AS OwnerName
      , ISNULL(L.Remark,'') + ', ' + ISNULL(REPLACE(A.Description,',',''),'') AS Remark
      , L.ProjectID ProjectCode
      , L.ProjectName
      , '' AS PersonalID
      , L.Producttype
      , A.OverDue
      , A.[DateDiff]
      , ISNULL(Las.Description, '') AS CategoryName
      , L.LeadsTypeName
	  ,'FollowUpStatus' = case when A.ActualDate IS NULL AND L.LeadsStatus = '0' then N'Followup'
							   when A.ActualDate IS NOT NULL AND L.LeadsStatus = '0' then N'Completed'
							   when L.LeadsStatus = '1' then N'Qualify'
							   when L.LeadsStatus = '2' then N'Disqualify'
							   Else '-'
							   END
    INTO #tmpLeadsActivity
    FROM #tmpActivity A
    INNER JOIN #tmpLeads L ON A.LeadID = L.LeadsID
	LEFT OUTER JOIN [crmrevo].CTM.LeadActivityStatus LAS With (Nolock) ON LAS.ID = a.StatusID
	LEFT JOIN [crmrevo].MST.MasterCenter MST With (Nolock) ON MST.ID = A.LeadActivityTypeMasterCenterID
    LEFT JOIN [crmrevo].Usr.[User] Usr With (Nolock) ON L.OwnerID = Usr.EmployeeNo
    WHERE 1=1
        AND ISNULL(@Lead, '1') = '1'
		AND ((@FollowUpStatus = '' OR @FollowUpStatus = 'All')
				OR (@FollowUpStatus = '0' AND L.LeadsStatus = '2') /*CRM-9752 เพิ่ม status Disqualify*/
                OR (@FollowUpStatus = '1' AND A.ActualDate IS NULL AND L.LeadsStatus = '0')
                OR (@FollowUpStatus = '2' AND A.ActualDate IS NOT NULL AND L.LeadsStatus = '0')
				OR (@FollowUpStatus = '3' AND L.LeadsStatus = '1')); /*CRM-9796 เพิ่ม status Qualify* 2020-10-14*/ 

--////////// #temp LeadActivity //////////////////// END
--////////// #temp OpportunityActivity //////////////////// Begin
 IF OBJECT_ID('tempdb..#tmpOpportunityActivity') IS NOT NULL
        DROP TABLE #tmpOpportunityActivity;
    SELECT *
      , (CASE
            WHEN A.ActualDate IS NULL
                AND CONVERT(DATE, A.DueDate) < @ToDayDate THEN 'red'
            WHEN A.ActualDate IS NULL
                AND CONVERT(DATE, A.DueDate) = @ToDayDate THEN 'yellow'
            WHEN A.ActualDate IS NULL
                AND CONVERT(DATE, A.DueDate) > @ToDayDate THEN 'white'
            WHEN A.ActualDate IS NOT NULL THEN 'green'
        END) AS OverDue
      , 'DateDiff' = (CASE WHEN A.ActualDate IS NOT NULL THEN DATEDIFF(DAY, A.ActualDate, A.DueDate)ELSE DATEDIFF(DAY, @ToDayDate, A.DueDate) END)
    INTO #tmpOpportunityActivity
    FROM [crmrevo].CTM.OpportunityActivity A With (Nolock)
    WHERE 1 = 1 and A.IsDeleted =0
        AND (YEAR(@DateStart) = 1800 OR YEAR(@DateEnd) = 7000 OR dbo.fn_ClearTime(A.DueDate) BETWEEN @DateStart AND @DateEnd)
        AND (YEAR(@DateStart2) = 1800 OR YEAR(@DateEnd2) = 7000 OR dbo.fn_ClearTime(A.ActualDate) BETWEEN @DateStart2 AND @DateEnd2)
        AND ((@FollowUpStatus = '' OR @FollowUpStatus = 'All')
                OR (@FollowUpStatus = '1' AND A.ActualDate IS NULL)
                OR (@FollowUpStatus = '2' AND A.ActualDate IS NOT NULL));


    IF OBJECT_ID('tempdb..#tmpWalkActivity') IS NOT NULL
        DROP TABLE #tmpWalkActivity;


    SELECT 'Topic' = N'First Walk'
      , A.ID AS ActivityID
      , O.ID AS OpportunityID
     -- , C.ID AS RefID
      , MST.[KEY] AS TaskID
      , MST.name AS TaskText
      , '2' AS ActivityType
      , 'Walk' AS ActivityTypeText
      , 'DisplayName'=C.FirstNameTH +' ' +C.LastNameTH
      , CP.PhoneNumber AS Mobile
      , Convert(datetime,A.DueDate) AS ActivityDate
      , Convert(datetime,A.ActualDate) AS ActualDate
	  --, Convert(datetime,NULL) AS LeadDate
	  --, Convert(datetime,O.Created) AS Oppdate
      , Convert(datetime,AppointmentDate) AS AppointDate
      , '' AS LeadsTypeID
      , '' AS LeadsTypeText
	  , USR.ID AS UserID
      , Usr.EmployeeNo AS OwnerID
      , Usr.FirstName + ' ' + Usr.LastName AS OwnerName
      , Case When A.Description = ',' Then ''
			 Else A.Description END AS Remark
      , P.ProjectNo AS ProjectCode
      , P.ProjectNameTH AS ProjectName
      , C.CitizenIdentityNo AS PersonalID
      , N'โครงการ'+ MSTP.name AS Producttype
      , A.OverDue
      , A.[DateDiff]
      , ISNULL(OAS.Description, '') AS CategoryName
      , '' LeadsTypeName
	  ,'FollowUpStatus' = case when A.ActualDate IS NULL  then N'Followup'
							   when A.ActualDate IS NOT NULL  then N'Completed'
							   Else '-'
							   END
    INTO #tmpWalkActivity
    FROM #tmpOpportunityActivity A
	LEFT JOIN #tmpOpp O With (Nolock) ON O.ID = A.OpportunityID AND O.IsDeleted = 0 
    LEFT JOIN [crmrevo].CTM.OpportunityActivityResult OAR With (Nolock) ON OAR.OpportunityAcitivityID = A.ID
	LEFT JOIN [crmrevo].CTM.OpportunityActivityStatus OAS With (Nolock) ON OAS.ID = OAR.StatusID
	LEFT JOIN [crmrevo].CTM.Contact C With (Nolock) ON O.ContactID = C.ID
	LEFT JOIN [crmrevo].CTM.ContactPhone CP With (Nolock) ON CP.ContactID =C.ID AND CP.IsMain=1											 

	LEFT JOIN [crmrevo].PRJ.project P With (Nolock) ON O.ProjectID = P.ID  
	LEFT JOIN [crmrevo].MST.MasterCenter MST With (Nolock) ON MST.ID = A.OpportunityActivityTypeMasterCenterID 
	LEFT JOIN [crmrevo].MST.MasterCenter MSTP With (Nolock) ON MSTP.ID = P.ProductTypeMasterCenterID AND MSTP.MasterCenterGroupKey = 'ProductType'
    LEFT JOIN [crmrevo].usr.[User] Usr With (Nolock) ON O.OwnerID = Usr.ID
    WHERE 1=1
        AND P.ID IN (SELECT ProjectID FROM #TProject)
       -- AND (Usr.EmployeeNo = @EmpCode OR @EmpCode = '')
        AND ISNULL(@FirstWalk, '1') = '1'
		--select * from #tmpWalkActivity
		
--////////// #temp OpportunityActivity //////////////////// END

--////////// #temp RevisitActivity //////////////////// Begin

	 IF OBJECT_ID('tempdb..#tmpRevisitActivity') IS NOT NULL
        DROP TABLE #tmpRevisitActivity;

    SELECT *
		,N'green' AS OverDue
      , 'DateDiff' = NULL--(CASE WHEN A.ActualDate IS NOT NULL THEN DATEDIFF(DAY, A.ActualDate, A.DueDate)ELSE DATEDIFF(DAY, @ToDayDate, A.DueDate) END)
    INTO #tmpRevisitActivity
    FROM [crmrevo].CTM.RevisitActivity A With (Nolock)
    WHERE 1 = 1 AND A.IsDeleted = 0
        AND ((YEAR(@DateStart) = 1800 OR @DateStart IS NULL)  AND (YEAR(@DateEnd) = 7000 OR @DateEnd IS NULL) OR dbo.fn_ClearTime(A.ActualDate) BETWEEN @DateStart AND @DateEnd)
		 AND ((YEAR(@DateStart2) = 1800 OR @DateStart2 IS NULL)  AND (YEAR(@DateEnd2) = 7000 OR @DateEnd2 IS NULL) OR dbo.fn_ClearTime(A.ActualDate) BETWEEN @DateStart2 AND @DateEnd2)

        --AND (YEAR(@DateStart2) = 1800 OR YEAR(@DateEnd2) = 7000 OR dbo.fn_ClearTime(A.ActualDate) BETWEEN @DateStart2 AND @DateEnd2)

	--	AND (((YEAR(@DateStart) = 1800 OR ISNULL(@DateStart, '') = '') AND (YEAR(@DateEnd) = 7000 OR ISNULL(@DateEnd, '') = ''))
	--		OR ((TF.ActualTransferDate BETWEEN CONVERT(NVARCHAR(50), @DateStart, 120) AND CONVERT(NVARCHAR(50), @DateEndInStore, 120)) 
	--		OR ISNULL(@DateStart, '') = '' OR ISNULL(@DateEnd, '') = ''))
 --AND (((YEAR(@DateStart) <> 1800 AND ISNULL(@DateStart, '') <> '') AND (YEAR(@DateEnd) <> 7000 AND ISNULL(@DateEnd, '') <> ''))
	--		OR ((TF.ActualTransferDate BETWEEN CONVERT(NVARCHAR(50), @DateStart, 120) AND CONVERT(NVARCHAR(50), @DateEndInStore, 120))
	--		OR ISNULL(@DateStart, '') = '' OR ISNULL(@DateEnd, '') = ''))
        AND ((@FollowUpStatus = '' OR @FollowUpStatus = 'All')
                OR (@FollowUpStatus = '1' AND A.ActualDate IS NULL)
                OR (@FollowUpStatus = '2' AND A.ActualDate IS NOT NULL));

				

    IF OBJECT_ID('tempdb..#tmpRevisit') IS NOT NULL
        DROP TABLE #tmpRevisit;

    SELECT 'Topic' = N'Revisit'
      , A.ID AS ActivityID
      , O.ID AS OpportunityID
      --, C.ID AS RefID
	  , MST.[KEY] AS TaskID
      , MST.name AS TaskText
      , '3' AS ActivityType
      , 'Revisit' AS ActivityTypeText
      , 'DisplayName'=C.FirstNameTH +' ' +C.LastNameTH
      , CP.PhoneNumber AS Mobile
      , CONVERT(datetime,NULL)  AS ActivityDate
      , Convert(datetime,A.ActualDate) AS ActualDate
	  --, Convert(datetime,NULL) AS LeadDate
	  --, Convert(datetime,NULL) AS Oppdate
      , Convert(datetime,A.AppointmentDate) AS AppointDate
      , '' AS LeadsTypeID
      , '' AS LeadsTypeText
	  , USR.ID AS UserID
      , Usr.EmployeeNo AS OwnerID
      , Usr.FirstName + ' ' + Usr.LastName AS OwnerName
      , Case When A.Description = ',' Then ''
			 Else A.Description END AS Remark
      , P.ProjectNo AS ProjectCode
      , P.ProjectNameTH AS ProjectName
      , C.CitizenIdentityNo AS PersonalID
      , N'โครงการ'+ MSTP.name AS Producttype
      , A.OverDue
      , A.[DateDiff]
      , ISNULL(RAS.Description, '') AS CategoryName
      , '' LeadsTypeName
	  ,'FollowUpStatus' = case when A.ActualDate IS NULL  then N'Followup'
							   when A.ActualDate IS NOT NULL  then N'Completed'
							   Else '-'
							   END
    INTO #tmpRevisit
    FROM #tmpRevisitActivity A
    LEFT JOIN [crmrevo].CTM.Opportunity O With (Nolock) ON O.ID = A.OpportunityID  and O.IsDeleted = 0--AND O.SalesOpportunityMasterCenterID is not null
	--AND O.SalesOpportunityMasterCenterID  
	--											<> (select ID from MST.MasterCenter where MasterCenterGroupKey 
	--											= 'SalesOpportunity' and [key] = '3')
	LEFT JOIN [crmrevo].CTM.RevisitActivityResult RAR With (Nolock) ON RAR.RevisitAcitivityID = A.ID
	LEFT JOIN [crmrevo].CTM.RevisitActivityStatus RAS With (Nolock) ON RAS.ID = RAR.StatusID
    LEFT JOIN [crmrevo].PRJ.Project P With (Nolock) ON O.ProjectID = P.ID
    LEFT JOIN [crmrevo].CTM.Contact C With (Nolock) ON O.ContactID = C.ID
	LEFT JOIN [crmrevo].CTM.ContactPhone CP With (Nolock) ON CP.ContactID =C.ID AND CP.IsMain=1		
	LEFT JOIN [crmrevo].MST.MasterCenter MST With (Nolock) ON MST.ID = A.RevisitActivityTypeMasterCenterID 
	LEFT JOIN [crmrevo].MST.MasterCenter MSTP With (Nolock) ON MSTP.ID = P.ProductTypeMasterCenterID AND MSTP.MasterCenterGroupKey = 'ProductType'
    LEFT JOIN [crmrevo].usr.[User] Usr With (Nolock) ON O.OwnerID = Usr.ID
    WHERE 1=1
        AND P.ID IN (SELECT ProjectID FROM #TProject)
        --AND (Usr.EmployeeNo = @EmpCode OR @EmpCode = '')
        AND ISNULL(@Revisit, '1') = '1';
		--select * from #tmpRevisit
		--END;
 IF OBJECT_ID('TmpMonitor') IS NOT NULL DROP TABLE TmpMonitor;
    SELECT * 
	INTO TmpMonitor
    FROM
	(
		SELECT * FROM #tmpLeadsActivity
		UNION 
		SELECT * FROM #tmpWalkActivity
		UNION 
		SELECT * FROM #tmpRevisit
	) AS tbRst
    where 1=1
	AND (cast(UserID AS nvarchar(200)) = @OwnerID OR isnull(@OwnerID,'') = '')  
	ORDER BY ProjectCode
		, OwnerID
		, ActivityDate; --DESC
	
	--SELECT * FROM #tmpLeads;
	--SELECT * FROM #tmpActivity WHERE ReferentID IN (SELECT LeadsID FROM #tmpLeads);
	--SELECT * FROM #TProject;

END;

go

