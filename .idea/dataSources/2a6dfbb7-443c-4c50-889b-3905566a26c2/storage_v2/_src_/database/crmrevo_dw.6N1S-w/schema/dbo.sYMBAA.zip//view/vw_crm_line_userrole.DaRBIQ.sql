CREATE VIEW [dbo].[vw_crm_line_userrole]
AS
SELECT CAST([ID] AS VARCHAR(20)) + '-' + CAST([UserID] AS VARCHAR(20)) + '-' + CAST([RoleID] AS VARCHAR(20)) AS id_user_role,
       [ID] AS id
      ,[UserID] AS userid
      ,[UserGUID] AS userguid
      ,[UserName] AS username
      ,[EmpCode] AS empcode
      ,[TitleName] AS titlename
      ,[FirstName] AS firstname
      ,[LastName] AS lastname
      ,[FullName] AS fullname
      ,[Email] AS email
      ,[PositionName] AS positionname
      ,[RoleID] AS roleid
      ,[RoleCode] AS rolecode
      ,[RoleName] AS rolename
      ,[AssignType] AS assigntype
      ,[SourceType] AS sourcetype
      ,[Remark] AS remark
      ,[StartDate] AS startdate
      ,[EndDate] AS enddate
FROM [DBLINK_SVR_AUTHORIZE].[db_AuthorizationCenter].[dbo].[vw_userrole]
go

