--EXEC [sp_GetGrossCancelRevenueBG1] '1'
--EXEC [sp_GetGrossCancelRevenueBG1] '2'
--EXEC [sp_GetGrossCancelRevenueBG1] '3'

CREATE PROC [dbo].[sp_GetGrossCancelRevenueBG1] @flag VARCHAR(2)
AS
--DECLARE @flag VARCHAR(2)
BEGIN
	SET NOCOUNT ON
	--Flag = 1 Gross
	--Flag = 2 Cancel
	--Flag = 3 LC Transfer
	DECLARE @StartDate VARCHAR(8)
	DECLARE @EndDate VARCHAR(8)
	DECLARE @BG VARCHAR(2)

	SET @BG = '1'
	--SET @flag = '2' 
	SELECT  @StartDate = CONVERT(VARCHAR(20), DATEADD(qq, DATEDIFF(qq, 0, GETDATE()), 0),112),
           @EndDate = CONVERT(VARCHAR(8), GETDATE() - 1, 112)

	--SET @StartDate = '20190101'
	--SET @EndDate = '20191231'

	--PRINT @StartDate
	--PRINT @EndDate

	
	IF(OBJECT_ID('tempdb..#vw_RPTAP2_ExV4Booking')IS NOT NULL) DROP TABLE #vw_RPTAP2_ExV4Booking
	IF(OBJECT_ID('tempdb..#vw_RPTAP2_ExV4BookingCancel')IS NOT NULL) DROP TABLE #vw_RPTAP2_ExV4BookingCancel
	IF(OBJECT_ID('tempdb..#vwCancel') IS NOT NULL) DROP TABLE #vwCancel;
	IF(OBJECT_ID('tempdb..#vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract')IS NOT NULL) DROP TABLE #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract
	IF(OBJECT_ID('tempdb..#ICON_EntForms_Products')IS NOT NULL) DROP TABLE #ICON_EntForms_Products
	IF(OBJECT_ID('tempdb..#ICON_EntForms_Unit')IS NOT NULL) DROP TABLE #ICON_EntForms_Unit

	SELECT * INTO #vw_RPTAP2_ExV4Booking FROM crmrevo.[dbo].[vw_RPTAP2_ExV4Booking] WITH(NOLOCK) WHERE BookingDate Between @StartDate and @EndDate
	SELECT * INTO #vw_RPTAP2_ExV4BookingCancel FROM crmrevo.[dbo].[vw_RPTAP2_ExV4BookingCancel] WITH(NOLOCK) WHERE  CancelDate BETWEEN @StartDate and @EndDate 
	EXEC crmrevo.dbo.sp_ExecutiveReport_Adjust
	SELECT * INTO #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract FROM ##ExecutiveReport_Adjust WITH(NOLOCK) 

	SELECT a.* INTO #vwCancel FROM #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract a With(NoLock) WHERE BookingCancelDate BETWEEN  @StartDate AND @EndDate and CurrentStatus='ยกเลิก'

	--Modified by Suchat S. 2020-12-10 for change get Project Active
	--SELECT p.* INTO #ICON_EntForms_Products FROM [crmrevo].prj.project p WITH(NOLOCK) INNER JOIN [crmrevo].mst.MasterCenter m WITH(NOLOCK) ON p.ProjectStatusMasterCenterID = m.id AND m.[Key] = '1' WHERE  p.IsDeleted = 0 AND p.IsActive = 1
	SELECT p.* INTO #ICON_EntForms_Products FROM [crmrevo].PRJ.Project p WITH (NOLOCK) WHERE p.IsDeleted = 0 AND p.IsActive = 1 AND SUBSTRING(p.[Group], 3, 1) <> '0' AND p.ProjectNameTH NOT LIKE '%ระงับใช้%';
	SELECT * INTO #ICON_EntForms_Unit FROM (SELECT a.*,b.[Key] FROM [crmrevo].prj.Unit a WITH(NOLOCK) INNER JOIN [crmrevo].mst.MasterCenter b WITH(NOLOCK) ON b.id = a.AsSETTypeMasterCenterID AND a.IsDeleted = 0) aa


	IF @flag = '1'
	BEGIN
	    PRINT 'Gross'

		-------------- Gross PresalesAmount -----------------------
		IF (OBJECT_ID('tempdb..#TempExec') IS NOT NULL) DROP TABLE #TempExec;
		SELECT	p.ID AS ProjectID, ex.BookingDate, ex.UnitID, SUBSTRING(p.[Group],1,1) AS BG, p.ProjectNo, p.ProjectNameTH, u.UnitNo
		,'SaleUserID' = CONVERT(NVARCHAR(50),'')
		,'SaleEmployeeCode' = CONVERT(NVARCHAR(50),'')
		,'SaleFullName' = CONVERT(NVARCHAR(50),'')
		,SUM(ex.BKPrice) AS BKPrice, SUM(ex.UnitAmt) AS UnitAmt
		,'FreedownAmount' = CONVERT(int,0)
		INTO #TempExec
		FROM #vw_RPTAP2_ExV4Booking ex WITH(NOLOCK)
		--LEFT  JOIN crmrevo.SAL.Booking bk ON ex.ProjectID = bk.ProjectID AND ex.UnitID = bk.UnitID AND bk.IsDeleted = 0 
		LEFT JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON ex.ProjectID = p.id 
		LEFT JOIN #ICON_EntForms_Unit u WITH(NOLOCK) ON u.ProjectID = p.ID AND u.ID = ex.UnitID AND u.IsDeleted = 0
		WHERE	1=1 
		AND SUBSTRING(p.[Group],1,1) = @BG
		GROUP BY p.ID, ex.BookingDate, ex.UnitID, SUBSTRING(p.[Group],1,1), p.ProjectNo, p.ProjectNameTH, u.UnitNo

		UPDATE #TempExec
		SET SaleEmployeeCode = (SELECT TOP 1 dbo.fn_GetUserFullName (ISNULL(ISNULL(b.SaleUserID,b.AgentID),b.CreatedByUserID),'EmpCode') FROM crmrevo.sal.Booking b WITH(NOLOCK) WHERE t.UnitID = b.UnitID AND b.IsDeleted = 0 AND b.BookingDate = t.BookingDate ORDER BY b.Created  )
		,SaleFullName =  (SELECT  TOP 1 dbo.fn_GetUserFullName (ISNULL(ISNULL(b.SaleUserID,b.AgentID),b.CreatedByUserID),'FullName') FROM crmrevo.sal.Booking b WITH(NOLOCK) WHERE t.UnitID = b.UnitID AND b.IsDeleted = 0 AND  b.BookingDate = t.BookingDate ORDER BY b.Created  )
		FROM  #TempExec t

		-------------------------------------#Temp_Subtract---------------------------------------------
		IF(OBJECT_ID('tempdb..#Temp_Subtract')IS NOT NULL)DROP TABLE #Temp_Subtract
		SELECT ex.ProjectID, ex.BookingDate, u.ID AS UnitID, SUBSTRING(p.[Group],1,1) AS BG, ex.ProjectNo, p.ProjectNameTH, ex.UnitNo,ex.BookingNumber
		,'SaleUserID' = CONVERT(NVARCHAR(50),'')
		,'SaleEmployeeCode' = CONVERT(NVARCHAR(50),'')
		,'SaleFullName' = CONVERT(NVARCHAR(50),'')
		,SUM(ex.SubtractGrossBookingAmount*-1) AS SubtractGrossBookingAmount, SUM(ex.SubtractGrossBookingUnit) AS SubtractGrossBookingUnit
		,'FreedownAmount' = SUM(ex.SubtractGrossBookingAmount)
		INTO #Temp_Subtract
		FROM #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract ex WITH(NOLOCK)
		LEFT JOIN #ICON_EntForms_Unit u WITH(NOLOCK) ON u.ProjectID = ex.ProjectID AND u.UnitNo = ex.UnitNo AND u.IsDeleted = 0
		--LEFT JOIN crmrevo.SAL.Booking bk ON ex.ProjectID = bk.ProjectID AND u.ID = bk.UnitID AND bk.IsDeleted = 0 AND bk.IsCancelled = 0
		LEFT JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON ex.ProjectID = p.id 
		WHERE 1=1 
		AND SUBSTRING(p.[Group],1,1) = @BG
		AND ex.BookingDate between @StartDate and @EndDate
		GROUP BY ex.ProjectID, ex.BookingDate, u.ID, SUBSTRING(p.[Group],1,1), ex.ProjectNo, p.ProjectNameTH, ex.UnitNo,ex.BookingNumber

		UPDATE #Temp_Subtract
		SET SaleEmployeeCode = (SELECT TOP 1 dbo.fn_GetUserFullName (ISNULL(ISNULL(b.SaleUserID,b.AgentID),b.CreatedByUserID),'EmpCode') FROM crmrevo.sal.Booking b WITH(NOLOCK) WHERE t.UnitID = b.UnitID AND b.IsDeleted = 0 AND b.BookingNo = t.BookingNumber ORDER BY b.Created DESC )
		,SaleFullName =  (SELECT TOP 1 dbo.fn_GetUserFullName (ISNULL(ISNULL(b.SaleUserID,b.AgentID),b.CreatedByUserID),'FullName') FROM crmrevo.sal.Booking b WITH(NOLOCK) WHERE t.UnitID = b.UnitID AND b.IsDeleted = 0 AND b.BookingNo = t.BookingNumber ORDER BY b.Created DESC )
		FROM  #Temp_Subtract t

		SELECT CAST(BookingDate AS DATE) AS BookingDate, BG,
		(SELECT TOP 1 w FROM crmrevo.BI.Mst_Calendar_Week WHERE CAST(BookingDate AS DATE) BETWEEN CAST(StartDate AS DATE) AND CAST(EndDate AS DATE)) AS Weeks,
		ProjectNo, ProjectNameTH, UnitNo,SaleEmployeeCode,SaleFullName,BKPrice,UnitAmt ,FreedownAmount
		FROM #TempExec
		UNION ALL
		SELECT CAST(BookingDate AS DATE) AS BookingDate, BG,
		(SELECT TOP 1 w FROM crmrevo.BI.Mst_Calendar_Week WHERE CAST(BookingDate AS DATE) BETWEEN CAST(StartDate AS DATE) AND CAST(EndDate AS DATE)) AS Weeks,
		ProjectNo, ProjectNameTH, UnitNo,SaleEmployeeCode,SaleFullName,SubtractGrossBookingAmount,SubtractGrossBookingUnit ,FreedownAmount
		FROM #Temp_Subtract
		ORDER BY BG, ProjectNo,UnitNo
		
	END
	ELSE
	BEGIN
	    IF @flag = '2'
		BEGIN
		    PRINT 'Cancel'

			--------------------------------vw_RPTAP2_ExV4BookingCancel----------------
			IF (OBJECT_ID('tempdb..#TempExecCancel') IS NOT NULL) DROP TABLE #TempExecCancel;
			SELECT	p.ID AS ProjectID, ex.CancelDate, ex.UnitID, SUBSTRING(p.[Group],1,1) AS BG, p.ProjectNo, p.ProjectNameTH, u.UnitNo,ex.BookingDate
			,'SaleUserID' = CONVERT(NVARCHAR(50),'')
			,'SaleEmployeeCode' = CONVERT(NVARCHAR(50),'')
			,'SaleFullName' = CONVERT(NVARCHAR(50),'')
			,SUM(ex.BKPrice) AS BKPrice, SUM(ex.UnitAmt) AS UnitAmt
			INTO #TempExecCancel
			FROM	#vw_RPTAP2_ExV4BookingCancel ex WITH(NOLOCK)
			--LEFT JOIN crmrevo.SAL.Booking bk ON ex.ProjectID = bk.ProjectID AND ex.UnitID = bk.UnitID AND bk.IsDeleted = 0 AND bk.IsCancelled = 1 AND CAST(ex.CancelDate AS DATE) = CAST(bk.CancelDate AS DATE)
			LEFT JOIN #ICON_EntForms_Products p WITH(NOLOCK) ON ex.ProjectID = p.id 
			LEFT JOIN #ICON_EntForms_Unit u WITH(NOLOCK) ON u.ProjectID = p.ID AND u.ID = ex.UnitID AND u.IsDeleted = 0
			WHERE	1=1 
			AND SUBSTRING(p.[Group],1,1) = @BG
			GROUP BY p.ID, ex.CancelDate, ex.UnitID, SUBSTRING(p.[Group],1,1), p.ProjectNo, p.ProjectNameTH, u.UnitNo,ex.BookingDate

			UPDATE #TempExecCancel
			SET SaleEmployeeCode = (SELECT TOP 1 dbo.fn_GetUserFullName (ISNULL(ISNULL(b.SaleUserID,b.AgentID),b.CreatedByUserID),'EmpCode') FROM crmrevo.sal.Booking b WITH(NOLOCK) WHERE t.UnitID = b.UnitID AND b.IsDeleted = 0 AND b.BookingDate = t.BookingDate ORDER BY b.Created DESC )
			,SaleFullName =  (SELECT TOP 1 dbo.fn_GetUserFullName (ISNULL(ISNULL(b.SaleUserID,b.AgentID),b.CreatedByUserID),'FullName') FROM crmrevo.sal.Booking b WITH(NOLOCK) WHERE t.UnitID = b.UnitID AND b.IsDeleted = 0 AND b.BookingDate = t.BookingDate ORDER BY b.Created DESC )
			FROM  #TempExecCancel t
			
			IF(OBJECT_ID('tempdb..#Temp_Subtract_Cancel')IS NOT NULL)DROP TABLE #Temp_Subtract_Cancel
			
			SELECT bg, projectid,ProjectNo,ProjectNameTH, t.UnitNo,BookingDate,BookingCancelDate,'SubtractCancelAmount'=Sum(SubtractCancelAmount*-1) ,'SubtractCancelUnit'=Sum(SubtractCancelUnit*-1) 
			,'SaleEmployeeCode' = CONVERT(NVARCHAR(50),'')
			,'SaleFullName' = CONVERT(NVARCHAR(50),'')
			,BookingNumber
			INTO #Temp_Subtract_Cancel 
			FROM(
				SELECT SUBSTRING(p.[Group],1,1) AS BG, ex.ProjectNo, p.ProjectNameTH, u.UnitNo,ex.projectid,BookingDate ,BookingCancelDate,ex.BookingNumber
				,'SubtractCancelAmount'=Sum(SubtractCancelAmount) ,'SubtractCancelUnit'=Sum(1)
				FROM #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract ex 
				LEFT JOIN #ICON_EntForms_Unit u ON ex.unitno = u.UnitNo AND ex.projectid = u.ProjectID AND u.IsDeleted = 0
				LEFT JOIN #ICON_EntForms_Products p ON p.id = ex.projectid AND p.IsDeleted = 0
				WHERE 1=1 AND SUBSTRING(p.[Group],1,1) = @BG
				and ((Convert(nvarchar(8),BookingDate,112) between @StartDate and @EndDate and BookingType='จองพิเศษ'))
				Group by SUBSTRING(p.[Group],1,1), ex.ProjectNo, p.ProjectNameTH, u.UnitNo,ex.projectid,BookingDate,BookingCancelDate,ex.BookingNumber
				UNION
				SELECT SUBSTRING(p.[Group],1,1) AS BG, a.ProjectNo, p.ProjectNameTH, u.UnitNo,a.projectid,BookingDate,BookingCancelDate ,a.BookingNumber
				,'SubtractCancelAmount'=Sum(SubtractCancelAmount) ,'SubtractCancelUnit'=Sum(SubtractCancelUnit)
				FROM #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract a 
				LEFT JOIN #ICON_EntForms_Unit u ON a.unitno = u.UnitNo AND a.projectid = u.ProjectID AND u.IsDeleted = 0
				LEFT JOIN #ICON_EntForms_Products p ON p.id = a.projectid AND p.IsDeleted = 0
				WHERE 1=1  AND SUBSTRING(p.[Group],1,1) = @BG
					and ( (Convert(nvarchar(8),BookingCancelDate,112) between @StartDate and @EndDate and CurrentStatus='ยกเลิก'))
					and (BookingDate>=@StartDate or BookingType<>'จองพิเศษ')
					and not exists(SELECT *
							FROM #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract b WITH(NOLOCK)
							WHERE 1=1 
								and ((Convert(nvarchar(8),BookingDate,112) between @StartDate and @EndDate and BookingType='จองพิเศษ'))
								and a.BookingNumber=b.BookingNumber)
				Group by SUBSTRING(p.[Group],1,1), a.ProjectNo, p.ProjectNameTH, u.UnitNo,a.projectid,BookingCancelDate,BookingDate,a.BookingNumber
			)t
			Group by bg, ProjectNo,ProjectNameTH, t.UnitNo,projectid,BookingDate,BookingCancelDate,BookingNumber


			UPDATE #Temp_Subtract_Cancel
			SET SaleEmployeeCode = (SELECT TOP 1 dbo.fn_GetUserFullName (ISNULL(ISNULL(b.SaleUserID,b.AgentID),b.CreatedByUserID),'EmpCode') 
									FROM crmrevo.sal.Booking b WITH(NOLOCK) LEFT JOIN #ICON_EntForms_Unit u ON b.UnitID = u.id AND u.IsDeleted = 0 
									WHERE t.unitno = u.UnitNo AND t.projectid = b.ProjectID  AND b.IsDeleted = 0 AND b.BookingNo = t.BookingNumber ORDER BY b.Created DESC )
			,SaleFullName =  (SELECT TOP 1 dbo.fn_GetUserFullName (ISNULL(ISNULL(b.SaleUserID,b.AgentID),b.CreatedByUserID),'FullName')
								FROM crmrevo.sal.Booking b WITH(NOLOCK) LEFT JOIN #ICON_EntForms_Unit u ON b.UnitID = u.id AND u.IsDeleted = 0 
									WHERE t.unitno = u.UnitNo AND t.projectid = b.ProjectID  AND b.IsDeleted = 0 AND  b.BookingNo = t.BookingNumber ORDER BY b.Created DESC )
			FROM  #Temp_Subtract_Cancel t

			SELECT CancelDate  , 
			(SELECT TOP 1 w FROM crmrevo.BI.Mst_Calendar_Week WHERE [dbo].[fn_ClearTime](CancelDate)  BETWEEN StartDate AND EndDate ) AS Weeks,
			bg, ProjectNo, ProjectNameTH, UnitNo, SaleEmployeeCode, SaleFullName, BKPrice, UnitAmt,BookingDate FROM #TempExecCancel
			UNION ALL
			SELECT  BookingCancelDate,
			(SELECT TOP 1 w FROM crmrevo.BI.Mst_Calendar_Week WHERE [dbo].[fn_ClearTime](BookingCancelDate)  BETWEEN StartDate AND EndDate ) AS Weeks,
			bg, ProjectNo, ProjectNameTH, UnitNo, SaleEmployeeCode, SaleFullName, SubtractCancelAmount, SubtractCancelUnit ,BookingDate FROM #Temp_Subtract_Cancel
			ORDER BY bg, ProjectNo,UnitNo
		END

		ELSE
		BEGIN
		    PRINT 'Revenue'
			--------------------------------Actual Transfer----------------
			IF(OBJECT_ID('tempdb..#TempTrans')IS NOT NULL)DROP TABLE #TempTrans
			SELECT tf.ProjectNo, tf.ProjectNameTH, tf.BG, tf.ProjectType, tf.UnitNo, tf.UnitID
			,CAST(tf.ActualTransferDate AS DATE) AS ActualTransferDate,b.BookingDate,
			(SELECT TOP 1 w FROM crmrevo.BI.Mst_Calendar_Week WHERE CAST(tf.ActualTransferDate AS DATE) BETWEEN CAST(StartDate AS DATE) AND CAST(EndDate AS DATE)) AS Weeks,
			tf.SaleEmpCode AS TransEmpCode, tf.SaleFullName AS TransFullName, tf.TotalPrice, tf.FreeDownAmount, tf.NetPriceExclFD
			,'SaleEmployeeCode'=  CONVERT(NVARCHAR(50),'')--(SELECT TOP 1 dbo.fn_GetUserFullName (ISNULL(b.SaleUserID,b.AgentID),'EmpCode') FROM crmrevo.sal.Booking bb WHERE bb.id = b.ID AND bb.IsDeleted = 0 AND bb.CancelDate IS NOT NULL ORDER BY bb.Created DESC )
			,'SaleFullName' = CONVERT(NVARCHAR(50),'')--(SELECT TOP 1 dbo.fn_GetUserFullName (ISNULL(b.SaleUserID,b.AgentID),'FullName') FROM crmrevo.sal.Booking bb WHERE bb.ID = b.IDAND bb.IsDeleted = 0 AND bb.CancelDate IS NOT NULL ORDER BY bb.Created DESC )
			INTO #TempTrans
			FROM dbo.vw_ActualTransfer tf WITH(NOLOCK)
			LEFT JOIN #ICON_EntForms_Products p WITH(NOLOCK) on tf.ProjectID = p.ID 
			LEFT JOIN crmrevo.sal.Booking  B WITH(NOLOCK) ON tf.BookingID = B.id  AND B.IsDeleted = 0 
			WHERE 1=1		
			AND tf.ActualTransferDate between @StartDate and @EndDate
			AND SUBSTRING(p.[Group],1,1) = @BG
		--	SELECT * FROM #TempTrans

			UPDATE #TempTrans
			SET SaleEmployeeCode = (SELECT TOP 1 dbo.fn_GetUserFullName (ISNULL(ISNULL(b.SaleUserID,b.AgentID),b.CreatedByUserID),'EmpCode') FROM crmrevo.sal.Booking b WITH(NOLOCK) WHERE t.UnitID = b.UnitID AND b.IsDeleted = 0 AND b.BookingDate = t.BookingDate ORDER BY b.Created DESC )
			,SaleFullName =  (SELECT TOP 1  dbo.fn_GetUserFullName (ISNULL(ISNULL(b.SaleUserID,b.AgentID),b.CreatedByUserID),'FullName') FROM crmrevo.sal.Booking b WITH(NOLOCK) WHERE t.UnitID = b.UnitID AND b.IsDeleted = 0 AND b.BookingDate = t.BookingDate ORDER BY b.Created DESC )
			FROM  #TempTrans t

			SELECT * FROM #TempTrans ORDER BY ProjectNo,UnitNo
		END
	END

END



go

