CREATE PROCEDURE [dbo].[sp_proc_line_ex_data]
@p_period AS varchar(10)
As

    SET NOCOUNT ON;

	--Parameter period
	--CW -> Current Week
	--LW -> Last Week
	--QTD -> Quarter to Date
	--YTD -> Year to Date

    DECLARE @text_msg_header AS VARCHAR(255);
    DECLARE @text_msg_detail AS VARCHAR(255);
    DECLARE @bg1_grosspresalesunit AS FLOAT;
    DECLARE @bg1_grosspresalesamount AS FLOAT;
    DECLARE @bg2_grosspresalesunit AS FLOAT;
    DECLARE @bg2_grosspresalesamount AS FLOAT;
    DECLARE @bg3_grosspresalesunit AS FLOAT;
    DECLARE @bg3_grosspresalesamount AS FLOAT;
    DECLARE @bg4_grosspresalesunit AS FLOAT;
    DECLARE @bg4_grosspresalesamount AS FLOAT;
    DECLARE @total_grosspresalesunit AS FLOAT;
    DECLARE @total_grosspresalesamount AS FLOAT;
    DECLARE @bg1_cancelunit AS FLOAT;
    DECLARE @bg1_cancelamount AS FLOAT;
    DECLARE @bg2_cancelunit AS FLOAT;
    DECLARE @bg2_cancelamount AS FLOAT;
    DECLARE @bg3_cancelunit AS FLOAT;
    DECLARE @bg3_cancelamount AS FLOAT;
    DECLARE @bg4_cancelunit AS FLOAT;
    DECLARE @bg4_cancelamount AS FLOAT;
    DECLARE @total_cancelunit AS FLOAT;
    DECLARE @total_cancelamount AS FLOAT;
    DECLARE @bg1_netpresalesunit AS FLOAT;
    DECLARE @bg1_netpresalesamount AS FLOAT;
    DECLARE @bg2_netpresalesunit AS FLOAT;
    DECLARE @bg2_netpresalesamount AS FLOAT;
    DECLARE @bg3_netpresalesunit AS FLOAT;
    DECLARE @bg3_netpresalesamount AS FLOAT;
    DECLARE @bg4_netpresalesunit AS FLOAT;
    DECLARE @bg4_netpresalesamount AS FLOAT;
    DECLARE @total_netpresalesunit AS FLOAT;
    DECLARE @total_netpresalesamount AS FLOAT;
    DECLARE @bg1_transferunit AS FLOAT;
    DECLARE @bg1_transferamount AS FLOAT;
    DECLARE @bg2_transferunit AS FLOAT;
    DECLARE @bg2_transferamount AS FLOAT;
    DECLARE @bg3_transferunit AS FLOAT;
    DECLARE @bg3_transferamount AS FLOAT;
    DECLARE @bg4_transferunit AS FLOAT;
    DECLARE @bg4_transferamount AS FLOAT;
    DECLARE @total_transferunit AS FLOAT;
    DECLARE @total_transferamount AS FLOAT;

	--UpCountry 
	DECLARE @bg1_up_grosspresalesunit AS FLOAT;
	DECLARE @bg1_up_grosspresalesamount AS FLOAT;
	DECLARE @bg1_up_cancelunit AS FLOAT;
	DECLARE @bg1_up_cancelamount AS FLOAT;
	DECLARE @bg1_up_netpresalesunit AS FLOAT;
	DECLARE @bg1_up_netpresalesamount AS FLOAT;
	DECLARE @bg1_up_transferunit AS FLOAT;
	DECLARE @bg1_up_transferamount AS FLOAT;


    DECLARE @startDate AS VARCHAR(8);
    DECLARE @endDate AS VARCHAR(8);
	DECLARE @current_week AS INT;
	DECLARE @txt_start_date AS VARCHAR(20);
	DECLARE @txt_end_date AS VARCHAR(20);
	DECLARE @current_flag AS VARCHAR(2);
	DECLARE @period AS VARCHAR(20);
	DECLARE @txt_header_title AS VARCHAR(255);

SET @current_flag = 'Y'
	
	IF @p_period = 'LW'
	BEGIN
		PRINT 'Last Week'
		SET @current_flag = 'N'
		SET @period = 'W'
		--Get Range Date 
		SELECT @startDate = CONVERT(VARCHAR(8), StartDate, 112),
				   @endDate = CONVERT(VARCHAR(8), EndDate, 112),
				   @current_week = W,
				   @txt_start_date = FORMAT(StartDate,'dd/MM/yy'),
				   @txt_end_date = FORMAT(EndDate,'dd/MM/yy')
			FROM crmrevo.BI.Mst_Calendar_Week WITH(NOLOCK)
			WHERE 1=1
			AND DATEPART(YEAR, StartDate) = DATEPART(YEAR,GETDATE())
			AND W = (
				SELECT w - 1
				FROM crmrevo.BI.Mst_Calendar_Week WITH(NOLOCK)
				WHERE 1=1
				AND DATEPART(YEAR, StartDate) = DATEPART(YEAR,GETDATE())
				AND CAST(GETDATE() AS DATE) BETWEEN CAST(StartDate AS DATE) AND CAST(EndDate AS DATE)
			)

		SET @txt_header_title = 'w' + CAST(@current_week AS VARCHAR(5)) + ' (' + @txt_start_date + '-' + @txt_end_date + ')'

	END
	ELSE
	BEGIN
		IF @p_period = 'CW'
		BEGIN
			PRINT 'Current Week'
			SET @period = 'W'
			--Get Range Date 
			SELECT @startDate = CONVERT(VARCHAR(8), StartDate, 112),
				   @endDate = CONVERT(VARCHAR(8), EndDate, 112),
				   @current_week = W,
				   @txt_start_date = FORMAT(StartDate,'dd/MM/yy'),
				   @txt_end_date = FORMAT(EndDate,'dd/MM/yy')
			FROM crmrevo.BI.Mst_Calendar_Week WITH (NOLOCK)
			WHERE 1 = 1
				  AND CAST(GETDATE() AS DATE)
				  BETWEEN CAST(StartDate AS DATE) AND CAST(EndDate AS DATE);

			SET @txt_header_title = 'w' + CAST(@current_week AS VARCHAR(5)) + ' (' + @txt_start_date + '-' + @txt_end_date + ')'
		END
		ELSE
		BEGIN
			SET @period = @p_period
			IF @p_period = 'YTD'
			BEGIN
				PRINT 'YTD'
				SELECT @startDate = FORMAT(DATEADD(yy, DATEDIFF(yy, 0, GETDATE()), 0),'yyyyMMdd'),
				       @endDate = FORMAT(DATEADD (dd, -1, DATEADD(yy, DATEDIFF(yy, 0, GETDATE()) +1, 0)),'yyyyMMdd'),
					   @txt_start_date = FORMAT(DATEADD(yy, DATEDIFF(yy, 0, GETDATE()), 0), 'dd/MM/yy'), 
				       @txt_end_date = FORMAT(DATEADD (dd, -1, DATEADD(yy, DATEDIFF(yy, 0, GETDATE()) +1, 0)),'dd/MM/yy')

				SET @current_week = 2
				SET @txt_header_title = 'w1-w53' + ' (' + @txt_start_date + '-' + @txt_end_date + ')'

			END
			ELSE
			BEGIN
				IF @p_period = 'QTD'
				BEGIN
				    PRINT 'QTD'
					SELECT @startDate = FORMAT(DATEADD(qq, DATEDIFF(qq, 0, GETDATE()), 0),'yyyyMMdd'),  
					@endDate = FORMAT(DATEADD (dd, -1, DATEADD(qq, DATEDIFF(qq, 0, GETDATE()) +1, 0)),'yyyyMMdd'),
					@txt_start_date = FORMAT(DATEADD(qq, DATEDIFF(qq, 0, GETDATE()), 0),'dd/MM/yy'), 
					@txt_end_date = FORMAT(DATEADD (dd, -1, DATEADD(qq, DATEDIFF(qq, 0, GETDATE()) +1, 0)),'dd/MM/yy')
				
					SET @current_week = 2
					SET @txt_header_title = 'w40-w53' + ' (' + @txt_start_date + '-' + @txt_end_date + ')'

				END
				ELSE
				BEGIN
				    PRINT 'QTDL'
					SET @StartDate = '20200701'
					SET @EndDate = '20200930'
				END
			END
		END
	END

--SET @StartDate = '20200401'
--SET @EndDate = '20200630'

if(object_id('tempdb..##ExecutiveReport')is not null) DROP TABLE ##ExecutiveReport

exec dbo.[sp_RPT_ExecutiveMail_Prepare] @StartDate,@EndDate

Update ##ExecutiveReport Set CancelTotalPrice=ABS(CancelTotalPrice),CancelTotalUnit=ABS(CancelTotalUnit)

---------------------------------#TotalProject-----------------------------------------------------------
If(Object_Id('tempdb..#Project')Is Not Null)Drop Table #Project
select distinct SUBSTRING([Group], 1,1) AS Ptype, ProjectNo AS ProductID,ProjectNameTH AS Project
, BookOff_Unit  = Convert(int,0)
, BookOff_Value = Convert(decimal(18,2),0)
, Cancel_Unit = Convert(int,0)
, Cancel_Value  = Convert(decimal(18,2),0)
, Net_Unit = Convert(int,0)
, Net_Value = Convert(decimal(18,2),0)
, Transfer_Unit = Convert(int,0)
, Transfer_Value  = Convert(decimal(18,2),0)
into #Project
from crmrevo.prj.Project WITH(NOLOCK)
where 1=1
AND IsDeleted = 0
AND IsActive = 1


Update #Project
Set BookOff_Value=Isnull((Select BookingTotalPrice From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,BookOff_Unit=Isnull((Select BookingTotalUnit From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,Cancel_Value=Isnull((Select CancelTotalPrice From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,Cancel_Unit=Isnull((Select CancelTotalUnit From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,Transfer_Value=Isnull((Select TransferTotalPrice From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,Transfer_Unit=Isnull((Select TransferTotalUnit From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
From #Project t

update #Project
set Net_Value=BookOff_Value-Cancel_Value
,Net_Unit=BookOff_Unit-Cancel_Unit

If(Object_Id('tempdb..#TotalProject')Is Not Null)Drop Table #TotalProject
select Ptype as ptype
, sum(BookOff_Unit) AS grosspresalesunit
, sum(BookOff_Value) AS grosspresalesamount
, sum(Cancel_Unit) AS cancelunit
, sum(Cancel_Value) AS cancelamount
, sum(Net_Unit) AS netpresalesunit
, sum(Net_Value) AS netpresalesamount
, sum(Transfer_Unit) AS transferunit
, sum(Transfer_Value) AS transferamount
into #TotalProject
 from #Project
 group by Ptype
 order by PType

--Modified By Suchat S. 2020-10-27 for change table select
--PRINT @current_week
--SELECT   ex.BG AS ptype, 
--       SUM(ex.GrossTotalUnit) AS grosspresalesunit,
--       SUM(ex.GrossTotalPrice) AS grosspresalesamount,
--       SUM(ex.CancelTotalUnit) AS cancelunit,
--       SUM(ex.CancelTotalPrice) AS cancelamount,
--       SUM(ex.NetTotalUnit) AS netpresalesunit,
--       SUM(ex.NetTotalPrice) AS netpresalesamount,
--       SUM(ex.TransferTotalUnit) AS transferunit,
--       SUM(ex.TransferTotalPrice) AS transferamount
--into #TotalProject
--FROM dbo.crm_ex_by_project ex WITH(NOLOCK), crmrevo.prj.Project p WITH(NOLOCK)
--WHERE 1 = 1
--AND ex.Weeks = @current_week
--AND ex.ProjectID = p.ID
--AND p.IsDeleted = 0
--AND p.IsActive = 1
--AND SUBSTRING(p.[Group], 1,1) IN ('1','2','3','4')
--AND SUBSTRING(p.[Group],3,1) <> '0'
--GROUP BY ex.BG
--ORDER BY ex.BG

--select * from #TotalProject Order By ptype

--Set value Gross Unit
SET @bg1_grosspresalesunit = ISNULL((SELECT grosspresalesunit FROM #TotalProject WHERE ptype = '1'),0);
SET @bg2_grosspresalesunit = ISNULL((SELECT grosspresalesunit FROM #TotalProject WHERE ptype = '2'),0);
SET @bg3_grosspresalesunit = ISNULL((SELECT grosspresalesunit FROM #TotalProject WHERE ptype = '3'),0);
SET @bg4_grosspresalesunit = ISNULL((SELECT grosspresalesunit FROM #TotalProject WHERE ptype = '4'),0);

--Set value Gross Amount
SET @bg1_grosspresalesamount = ISNULL((SELECT grosspresalesamount FROM #TotalProject WHERE ptype = '1'),0.00);
SET @bg2_grosspresalesamount = ISNULL((SELECT grosspresalesamount FROM #TotalProject WHERE ptype = '2'),0.00);
SET @bg3_grosspresalesamount = ISNULL((SELECT grosspresalesamount FROM #TotalProject WHERE ptype = '3'),0.00);
SET @bg4_grosspresalesamount = ISNULL((SELECT grosspresalesamount FROM #TotalProject WHERE ptype = '4'),0.00);

--Set value Cancel Unit
SET @bg1_cancelunit = ISNULL((SELECT cancelunit FROM #TotalProject WHERE ptype = '1'),0);
SET @bg2_cancelunit = ISNULL((SELECT cancelunit FROM #TotalProject WHERE ptype = '2'),0);
SET @bg3_cancelunit = ISNULL((SELECT cancelunit FROM #TotalProject WHERE ptype = '3'),0);
SET @bg4_cancelunit = ISNULL((SELECT cancelunit FROM #TotalProject WHERE ptype = '4'),0);

--Set value Cancel Amount
SET @bg1_cancelamount = ISNULL((SELECT cancelamount FROM #TotalProject WHERE ptype = '1'),0.00);
SET @bg2_cancelamount = ISNULL((SELECT cancelamount FROM #TotalProject WHERE ptype = '2'),0.00);
SET @bg3_cancelamount = ISNULL((SELECT cancelamount FROM #TotalProject WHERE ptype = '3'),0.00);
SET @bg4_cancelamount = ISNULL((SELECT cancelamount FROM #TotalProject WHERE ptype = '4'),0.00);

--Set value Net Unit
SET @bg1_netpresalesunit = ISNULL((SELECT netpresalesunit FROM #TotalProject WHERE ptype = '1'),0);
SET @bg2_netpresalesunit = ISNULL((SELECT netpresalesunit FROM #TotalProject WHERE ptype = '2'),0);
SET @bg3_netpresalesunit = ISNULL((SELECT netpresalesunit FROM #TotalProject WHERE ptype = '3'),0);
SET @bg4_netpresalesunit = ISNULL((SELECT netpresalesunit FROM #TotalProject WHERE ptype = '4'),0);

--Set value Net Amount
SET @bg1_netpresalesamount = ISNULL((SELECT netpresalesamount FROM #TotalProject WHERE ptype = '1'),0.00);
SET @bg2_netpresalesamount = ISNULL((SELECT netpresalesamount FROM #TotalProject WHERE ptype = '2'),0.00);
SET @bg3_netpresalesamount = ISNULL((SELECT netpresalesamount FROM #TotalProject WHERE ptype = '3'),0.00);
SET @bg4_netpresalesamount = ISNULL((SELECT netpresalesamount FROM #TotalProject WHERE ptype = '4'),0.00);

--Set value Transfer Unit
SET @bg1_transferunit = ISNULL((SELECT transferunit FROM #TotalProject WHERE ptype = '1'),0);
SET @bg2_transferunit = ISNULL((SELECT transferunit FROM #TotalProject WHERE ptype = '2'),0);
SET @bg3_transferunit = ISNULL((SELECT transferunit FROM #TotalProject WHERE ptype = '3'),0);
SET @bg4_transferunit = ISNULL((SELECT transferunit FROM #TotalProject WHERE ptype = '4'),0);

--Set value Transfer Amount
SET @bg1_transferamount = ISNULL((SELECT transferamount FROM #TotalProject WHERE ptype = '1'),0.00);
SET @bg2_transferamount = ISNULL((SELECT transferamount FROM #TotalProject WHERE ptype = '2'),0.00);
SET @bg3_transferamount = ISNULL((SELECT transferamount FROM #TotalProject WHERE ptype = '3'),0.00);
SET @bg4_transferamount = ISNULL((SELECT transferamount FROM #TotalProject WHERE ptype = '4'),0.00);

-- Sum Total by Type
SET @total_grosspresalesunit = @bg1_grosspresalesunit + @bg2_grosspresalesunit + @bg3_grosspresalesunit + @bg4_grosspresalesunit;
SET @total_grosspresalesamount = @bg1_grosspresalesamount + @bg2_grosspresalesamount + @bg3_grosspresalesamount + @bg4_grosspresalesamount;
SET @total_cancelunit = @bg1_cancelunit + @bg2_cancelunit + @bg3_cancelunit + @bg4_cancelunit
SET @total_cancelamount = @bg1_cancelamount + @bg2_cancelamount + @bg3_cancelamount + @bg4_cancelamount
SET @total_netpresalesunit = @bg1_netpresalesunit + @bg2_netpresalesunit + @bg3_netpresalesunit + @bg4_netpresalesunit;
SET @total_netpresalesamount = @bg1_netpresalesamount + @bg2_netpresalesamount + @bg3_netpresalesamount + @bg4_netpresalesamount;
SET @total_transferunit = @bg1_transferunit + @bg2_transferunit + @bg3_transferunit + @bg4_transferunit;
SET @total_transferamount = @bg1_transferamount + @bg2_transferamount + @bg3_transferamount + @bg4_transferamount;


IF @p_period = 'QTDL'
BEGIN
	--Update Last Quarter in YTD Card
    UPDATE dbo.crm_line_exct_report
	SET 
	--text_msg_header  =  'w' + CAST(@current_week AS VARCHAR(5)) + ' (' + @txt_start_date + '-' + @txt_end_date + ')'
	--text_msg_header  =  @txt_header_title
	--,text_msg_detail  =  'Last updated ' + FORMAT(GETDATE(),'dd/MM/yyyy hh:mm tt')
	bg1_grosspresalesunit   = ISNULL(@bg1_grosspresalesunit ,0)
	,bg1_grosspresalesamount   = ISNULL(@bg1_grosspresalesamount ,0)
	,bg2_grosspresalesunit   = ISNULL(@bg2_grosspresalesunit ,0)
	,bg2_grosspresalesamount   = ISNULL(@bg2_grosspresalesamount ,0)
	,bg3_grosspresalesunit   = ISNULL(@bg3_grosspresalesunit ,0)
	,bg3_grosspresalesamount   = ISNULL(@bg3_grosspresalesamount ,0)
	,bg4_grosspresalesunit   = ISNULL(@bg4_grosspresalesunit ,0)
	,bg4_grosspresalesamount   = ISNULL(@bg4_grosspresalesamount ,0)
	,total_grosspresalesunit   = ISNULL(@total_grosspresalesunit ,0)
	,total_grosspresalesamount   = ISNULL(@total_grosspresalesamount ,0)
	,bg1_cancelunit   = ISNULL(@bg1_cancelunit ,0)
	,bg1_cancelamount   = ISNULL(@bg1_cancelamount ,0)
	,bg2_cancelunit   = ISNULL(@bg2_cancelunit ,0)
	,bg2_cancelamount   = ISNULL(@bg2_cancelamount ,0)
	,bg3_cancelunit   = ISNULL(@bg3_cancelunit ,0)
	,bg3_cancelamount   = ISNULL(@bg3_cancelamount ,0)
	,bg4_cancelunit   = ISNULL(@bg4_cancelunit ,0)
	,bg4_cancelamount   = ISNULL(@bg4_cancelamount ,0)
	,total_cancelunit   = ISNULL(@total_cancelunit ,0)
	,total_cancelamount   = ISNULL(@total_cancelamount ,0)
	,bg1_netpresalesunit   = ISNULL(@bg1_netpresalesunit ,0)
	,bg1_netpresalesamount   = ISNULL(@bg1_netpresalesamount ,0)
	,bg2_netpresalesunit   = ISNULL(@bg2_netpresalesunit ,0)
	,bg2_netpresalesamount   = ISNULL(@bg2_netpresalesamount ,0)
	,bg3_netpresalesunit   = ISNULL(@bg3_netpresalesunit ,0)
	,bg3_netpresalesamount   = ISNULL(@bg3_netpresalesamount ,0)
	,bg4_netpresalesunit   = ISNULL(@bg4_netpresalesunit ,0)
	,bg4_netpresalesamount   = ISNULL(@bg4_netpresalesamount ,0)
	,total_netpresalesunit   = ISNULL(@total_netpresalesunit ,0)
	,total_netpresalesamount   = ISNULL(@total_netpresalesamount ,0)
	,bg1_transferunit   = ISNULL(@bg1_transferunit ,0)
	,bg1_transferamount   = ISNULL(@bg1_transferamount ,0)
	,bg2_transferunit   = ISNULL(@bg2_transferunit ,0)
	,bg2_transferamount   = ISNULL(@bg2_transferamount ,0)
	,bg3_transferunit   = ISNULL(@bg3_transferunit ,0)
	,bg3_transferamount   = ISNULL(@bg3_transferamount ,0)
	,bg4_transferunit   = ISNULL(@bg4_transferunit ,0)
	,bg4_transferamount   = ISNULL(@bg4_transferamount ,0)
	,total_transferunit   = ISNULL(@total_transferunit ,0)
	,total_transferamount   = ISNULL(@total_transferamount	,0)
	,modifyby = 'batch'
	,modifydate = GETDATE()
	WHERE 1=1
	AND trans_id = 7
END
ELSE
BEGIN
    UPDATE dbo.crm_line_exct_report
	SET 
	--text_msg_header  =  'w' + CAST(@current_week AS VARCHAR(5)) + ' (' + @txt_start_date + '-' + @txt_end_date + ')'
	text_msg_header  =  @txt_header_title
	,text_msg_detail  =  'Last updated ' + FORMAT(GETDATE(),'dd/MM/yyyy hh:mm tt')
	,bg1_grosspresalesunit   = ISNULL(@bg1_grosspresalesunit ,0)
	,bg1_grosspresalesamount   = ISNULL(@bg1_grosspresalesamount ,0)
	,bg2_grosspresalesunit   = ISNULL(@bg2_grosspresalesunit ,0)
	,bg2_grosspresalesamount   = ISNULL(@bg2_grosspresalesamount ,0)
	,bg3_grosspresalesunit   = ISNULL(@bg3_grosspresalesunit ,0)
	,bg3_grosspresalesamount   = ISNULL(@bg3_grosspresalesamount ,0)
	,bg4_grosspresalesunit   = ISNULL(@bg4_grosspresalesunit ,0)
	,bg4_grosspresalesamount   = ISNULL(@bg4_grosspresalesamount ,0)
	,total_grosspresalesunit   = ISNULL(@total_grosspresalesunit ,0)
	,total_grosspresalesamount   = ISNULL(@total_grosspresalesamount ,0)
	,bg1_cancelunit   = ISNULL(@bg1_cancelunit ,0)
	,bg1_cancelamount   = ISNULL(@bg1_cancelamount ,0)
	,bg2_cancelunit   = ISNULL(@bg2_cancelunit ,0)
	,bg2_cancelamount   = ISNULL(@bg2_cancelamount ,0)
	,bg3_cancelunit   = ISNULL(@bg3_cancelunit ,0)
	,bg3_cancelamount   = ISNULL(@bg3_cancelamount ,0)
	,bg4_cancelunit   = ISNULL(@bg4_cancelunit ,0)
	,bg4_cancelamount   = ISNULL(@bg4_cancelamount ,0)
	,total_cancelunit   = ISNULL(@total_cancelunit ,0)
	,total_cancelamount   = ISNULL(@total_cancelamount ,0)
	,bg1_netpresalesunit   = ISNULL(@bg1_netpresalesunit ,0)
	,bg1_netpresalesamount   = ISNULL(@bg1_netpresalesamount ,0)
	,bg2_netpresalesunit   = ISNULL(@bg2_netpresalesunit ,0)
	,bg2_netpresalesamount   = ISNULL(@bg2_netpresalesamount ,0)
	,bg3_netpresalesunit   = ISNULL(@bg3_netpresalesunit ,0)
	,bg3_netpresalesamount   = ISNULL(@bg3_netpresalesamount ,0)
	,bg4_netpresalesunit   = ISNULL(@bg4_netpresalesunit ,0)
	,bg4_netpresalesamount   = ISNULL(@bg4_netpresalesamount ,0)
	,total_netpresalesunit   = ISNULL(@total_netpresalesunit ,0)
	,total_netpresalesamount   = ISNULL(@total_netpresalesamount ,0)
	,bg1_transferunit   = ISNULL(@bg1_transferunit ,0)
	,bg1_transferamount   = ISNULL(@bg1_transferamount ,0)
	,bg2_transferunit   = ISNULL(@bg2_transferunit ,0)
	,bg2_transferamount   = ISNULL(@bg2_transferamount ,0)
	,bg3_transferunit   = ISNULL(@bg3_transferunit ,0)
	,bg3_transferamount   = ISNULL(@bg3_transferamount ,0)
	,bg4_transferunit   = ISNULL(@bg4_transferunit ,0)
	,bg4_transferamount   = ISNULL(@bg4_transferamount ,0)
	,total_transferunit   = ISNULL(@total_transferunit ,0)
	,total_transferamount   = ISNULL(@total_transferamount	,0)
	,modifyby = 'batch'
	,modifydate = GETDATE()
	WHERE 1=1
	--AND trans_id = 1
	AND period = @p_period
	AND sub_period = 0
END


----# Update upcountry for chatbot
----Modified by Suchat S. update upcontry
--SELECT @bg1_up_grosspresalesunit = ISNULL(SUM(GrossTotalUnit),0),
--       @bg1_up_grosspresalesamount = ISNULL(SUM(GrossTotalPrice),0.00),
--       @bg1_up_cancelunit = ISNULL(SUM(CancelTotalUnit),0),
--       @bg1_up_cancelamount = ISNULL(SUM(CancelTotalPrice),0.00),
--       @bg1_up_netpresalesunit = ISNULL(SUM(NetTotalUnit),0),
--       @bg1_up_netpresalesamount = ISNULL(SUM(NetTotalPrice),0.00),
--       @bg1_up_transferunit = ISNULL(SUM(TransferTotalUnit),0),
--       @bg1_up_transferamount = ISNULL(SUM(TransferTotalPrice),0.00)
--FROM dbo.crm_ex_by_project WITH(NOLOCK)
--WHERE Weeks = 47
--      AND IsUpCountry = 1
--      AND BG = 1;

IF @p_period = 'LW'
BEGIN
	--# Update upcountry for chatbot
	--Modified by Suchat S. update upcontry
	SELECT @bg1_up_grosspresalesunit = ISNULL(SUM(GrossTotalUnit),0),
		   @bg1_up_grosspresalesamount = ISNULL(SUM(GrossTotalPrice),0.00),
		   @bg1_up_cancelunit = ISNULL(SUM(CancelTotalUnit),0),
		   @bg1_up_cancelamount = ISNULL(SUM(CancelTotalPrice),0.00),
		   @bg1_up_netpresalesunit = ISNULL(SUM(NetTotalUnit),0),
		   @bg1_up_netpresalesamount = ISNULL(SUM(NetTotalPrice),0.00),
		   @bg1_up_transferunit = ISNULL(SUM(TransferTotalUnit),0),
		   @bg1_up_transferamount = ISNULL(SUM(TransferTotalPrice),0.00)
	FROM dbo.crm_ex_by_project WITH(NOLOCK)
	WHERE Weeks = @current_week
		  AND IsUpCountry = 1
		  AND BG = 1;

    UPDATE dbo.crm_line_exct_report
	SET bg1_up_grosspresalesunit = @bg1_up_grosspresalesunit,
		bg1_up_grosspresalesamount = @bg1_up_grosspresalesamount,
		bg1_up_cancelunit = @bg1_up_cancelunit,
		bg1_up_cancelamount = @bg1_up_cancelamount,
		bg1_up_netpresalesunit = @bg1_up_netpresalesunit,
		bg1_up_netpresalesamount = @bg1_up_netpresalesamount,
		bg1_up_transferunit = @bg1_up_transferunit,
		bg1_up_transferamount = @bg1_up_transferamount,
		bg1_grosspresalesunit = bg1_grosspresalesunit - @bg1_up_grosspresalesunit,
		bg1_grosspresalesamount = bg1_grosspresalesamount - @bg1_up_grosspresalesamount,
		bg1_cancelunit = bg1_cancelunit - @bg1_up_cancelunit,
		bg1_cancelamount = bg1_cancelamount - @bg1_up_cancelamount,
		bg1_netpresalesunit = bg1_netpresalesunit - @bg1_up_netpresalesunit,
		bg1_netpresalesamount = bg1_netpresalesamount - @bg1_up_netpresalesamount,
		bg1_transferunit = bg1_transferunit - @bg1_up_transferunit,
		bg1_transferamount = bg1_transferamount - @bg1_up_transferamount
	WHERE trans_id =2 ; -- Update 1= Current Week, 3 = Current Quarter, 4 = YTD
END
ELSE
BEGIN
    IF @p_period = 'QTD'
	BEGIN
		SELECT @bg1_up_grosspresalesunit = ISNULL(SUM(GrossTotalUnit),0),
		   @bg1_up_grosspresalesamount = ISNULL(SUM(GrossTotalPrice),0.00),
		   @bg1_up_cancelunit = ISNULL(SUM(CancelTotalUnit),0),
		   @bg1_up_cancelamount = ISNULL(SUM(CancelTotalPrice),0.00),
		   @bg1_up_netpresalesunit = ISNULL(SUM(NetTotalUnit),0),
		   @bg1_up_netpresalesamount = ISNULL(SUM(NetTotalPrice),0.00),
		   @bg1_up_transferunit = ISNULL(SUM(TransferTotalUnit),0),
		   @bg1_up_transferamount = ISNULL(SUM(TransferTotalPrice),0.00)
		FROM dbo.crm_ex_by_project WITH(NOLOCK)
		WHERE 1=1
		AND Quarters = DATEPART(QUARTER, GETDATE())
			  AND IsUpCountry = 1
			  AND BG = 1;

	    UPDATE dbo.crm_line_exct_report
		SET bg1_up_grosspresalesunit = @bg1_up_grosspresalesunit,
			bg1_up_grosspresalesamount = @bg1_up_grosspresalesamount,
			bg1_up_cancelunit = @bg1_up_cancelunit,
			bg1_up_cancelamount = @bg1_up_cancelamount,
			bg1_up_netpresalesunit = @bg1_up_netpresalesunit,
			bg1_up_netpresalesamount = @bg1_up_netpresalesamount,
			bg1_up_transferunit = @bg1_up_transferunit,
			bg1_up_transferamount = @bg1_up_transferamount,
			bg1_grosspresalesunit = bg1_grosspresalesunit - @bg1_up_grosspresalesunit,
			bg1_grosspresalesamount = bg1_grosspresalesamount - @bg1_up_grosspresalesamount,
			bg1_cancelunit = bg1_cancelunit - @bg1_up_cancelunit,
			bg1_cancelamount = bg1_cancelamount - @bg1_up_cancelamount,
			bg1_netpresalesunit = bg1_netpresalesunit - @bg1_up_netpresalesunit,
			bg1_netpresalesamount = bg1_netpresalesamount - @bg1_up_netpresalesamount,
			bg1_transferunit = bg1_transferunit - @bg1_up_transferunit,
			bg1_transferamount = bg1_transferamount - @bg1_up_transferamount
		WHERE trans_id =3 ; -- Update 1= Current Week, 3 = Current Quarter, 4 = YTD
	END
	ELSE
    BEGIN
        IF @p_period = 'YTD'
		BEGIN
			SELECT @bg1_up_grosspresalesunit = ISNULL(SUM(GrossTotalUnit),0),
			   @bg1_up_grosspresalesamount = ISNULL(SUM(GrossTotalPrice),0.00),
			   @bg1_up_cancelunit = ISNULL(SUM(CancelTotalUnit),0),
			   @bg1_up_cancelamount = ISNULL(SUM(CancelTotalPrice),0.00),
			   @bg1_up_netpresalesunit = ISNULL(SUM(NetTotalUnit),0),
			   @bg1_up_netpresalesamount = ISNULL(SUM(NetTotalPrice),0.00),
			   @bg1_up_transferunit = ISNULL(SUM(TransferTotalUnit),0),
			   @bg1_up_transferamount = ISNULL(SUM(TransferTotalPrice),0.00)
			FROM dbo.crm_ex_by_project WITH(NOLOCK)
			WHERE 1=1
			AND Years = DATEPART(YEAR, GETDATE())
				  AND IsUpCountry = 1
				  AND BG = 1;

		    UPDATE dbo.crm_line_exct_report
			SET bg1_up_grosspresalesunit = @bg1_up_grosspresalesunit,
				bg1_up_grosspresalesamount = @bg1_up_grosspresalesamount,
				bg1_up_cancelunit = @bg1_up_cancelunit,
				bg1_up_cancelamount = @bg1_up_cancelamount,
				bg1_up_netpresalesunit = @bg1_up_netpresalesunit,
				bg1_up_netpresalesamount = @bg1_up_netpresalesamount,
				bg1_up_transferunit = @bg1_up_transferunit,
				bg1_up_transferamount = @bg1_up_transferamount,
				bg1_grosspresalesunit = bg1_grosspresalesunit - @bg1_up_grosspresalesunit,
				bg1_grosspresalesamount = bg1_grosspresalesamount - @bg1_up_grosspresalesamount,
				bg1_cancelunit = bg1_cancelunit - @bg1_up_cancelunit,
				bg1_cancelamount = bg1_cancelamount - @bg1_up_cancelamount,
				bg1_netpresalesunit = bg1_netpresalesunit - @bg1_up_netpresalesunit,
				bg1_netpresalesamount = bg1_netpresalesamount - @bg1_up_netpresalesamount,
				bg1_transferunit = bg1_transferunit - @bg1_up_transferunit,
				bg1_transferamount = bg1_transferamount - @bg1_up_transferamount
			WHERE trans_id = 4 -- QTD
		END
		ELSE
        BEGIN
            IF @p_period = 'CW'
			BEGIN
			    --# Update upcountry for chatbot
				--Modified by Suchat S. update upcontry
				SELECT @bg1_up_grosspresalesunit = ISNULL(SUM(GrossTotalUnit),0),
					   @bg1_up_grosspresalesamount = ISNULL(SUM(GrossTotalPrice),0.00),
					   @bg1_up_cancelunit = ISNULL(SUM(CancelTotalUnit),0),
					   @bg1_up_cancelamount = ISNULL(SUM(CancelTotalPrice),0.00),
					   @bg1_up_netpresalesunit = ISNULL(SUM(NetTotalUnit),0),
					   @bg1_up_netpresalesamount = ISNULL(SUM(NetTotalPrice),0.00),
					   @bg1_up_transferunit = ISNULL(SUM(TransferTotalUnit),0),
					   @bg1_up_transferamount = ISNULL(SUM(TransferTotalPrice),0.00)
				FROM dbo.crm_ex_by_project WITH(NOLOCK)
				WHERE Weeks = @current_week
					  AND IsUpCountry = 1
					  AND BG = 1;

				UPDATE dbo.crm_line_exct_report
				SET bg1_up_grosspresalesunit = @bg1_up_grosspresalesunit,
					bg1_up_grosspresalesamount = @bg1_up_grosspresalesamount,
					bg1_up_cancelunit = @bg1_up_cancelunit,
					bg1_up_cancelamount = @bg1_up_cancelamount,
					bg1_up_netpresalesunit = @bg1_up_netpresalesunit,
					bg1_up_netpresalesamount = @bg1_up_netpresalesamount,
					bg1_up_transferunit = @bg1_up_transferunit,
					bg1_up_transferamount = @bg1_up_transferamount,
					bg1_grosspresalesunit = bg1_grosspresalesunit - @bg1_up_grosspresalesunit,
					bg1_grosspresalesamount = bg1_grosspresalesamount - @bg1_up_grosspresalesamount,
					bg1_cancelunit = bg1_cancelunit - @bg1_up_cancelunit,
					bg1_cancelamount = bg1_cancelamount - @bg1_up_cancelamount,
					bg1_netpresalesunit = bg1_netpresalesunit - @bg1_up_netpresalesunit,
					bg1_netpresalesamount = bg1_netpresalesamount - @bg1_up_netpresalesamount,
					bg1_transferunit = bg1_transferunit - @bg1_up_transferunit,
					bg1_transferamount = bg1_transferamount - @bg1_up_transferamount
				WHERE trans_id =1 ; -- Update 1= Current Week
			END
        END
    END
END





--3	QTD
--4	YTD


go

