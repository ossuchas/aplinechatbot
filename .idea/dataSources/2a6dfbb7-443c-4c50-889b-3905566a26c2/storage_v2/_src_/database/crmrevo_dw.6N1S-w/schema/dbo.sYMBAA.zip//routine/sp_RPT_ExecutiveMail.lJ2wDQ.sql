CREATE Proc [dbo].[sp_RPT_ExecutiveMail]

As

if(convert(nvarchar(8),getdate(),112)='20200330')
begin
	declare @date datetime   set @date=getdate()
	exec DBLINK_SVR_EMAIL.APMail.dbo.SP_Save_Mail @CMD=1 ,@AttempTime=@date,@MailFrom='crmconsult@apthai.com'
	,@MailTo='tanonchai@apthai.com',@MailCC=N'',@Topic='*** แจ้งเตือนให้ส่ง Executive Mail Report แบบ Manual',@Detail='เนื่องจากเป็น Week สุดท้ายของ Q กรุณาส่ง Executive Mail แบบ Manual แทน',@MailType=N'ExecutiveMail'
	,@Key1='',@Key2='',@Key3='',@Key4='',@ReceiverID=N'',@MailTime=@date

	return; -- วันจันทร์ที่ 30/12/2019 ไม่ต้องส่ง เพราะยังไม่หมด week ให้ส่งแบบ manual แทน
end
Declare @Mail NVarchar(Max)
If(Object_Id('tempdb..#TotalProject')Is Not Null)Drop Table #TotalProject
If(Object_Id('tempdb..#ExistingProject')Is Not Null)Drop Table #ExistingProject
If(Object_Id('tempdb..#NewProjectPerformance')Is Not Null)Drop Table #NewProjectPerformance
If(Object_Id('tempdb..#GrossBooking')Is Not Null)Drop Table #GrossBooking
If(Object_Id('tempdb..#NetBooking')Is Not Null)Drop Table #NetBooking
If(Object_Id('tempdb..#NetTransfer')Is Not Null)Drop Table #NetTransfer
If(Object_Id('tempdb..#NetCancel')Is Not Null)Drop Table #NetCancel
If(Object_Id('tempdb..#BookingOffline')Is Not Null)Drop Table #BookingOffline
If(Object_Id('tempdb..#TotalProject_JV')Is Not Null)Drop Table #TotalProject_JV

Set Datefirst 1
Declare @StartDate Date,@EndDate Date,@CurrentDate DateTime,@CurrentWeek int,@Year int
Set @CurrentDate = GETDATE()
Set @Year= Year(GetDate())
Set @CurrentDate=convert(datetime,convert(nvarchar(8),@CurrentDate,112)+' 23:59:59')

----------------------หาว่าใช่วันแรกของสัปดาห์หรือป่าว 
--IF @CurrentDate = (SELECT StartDate FROM [crmrevo].[BI].[Mst_Calendar_Week] With(NoLock) Where @CurrentDate between StartDate and convert(datetime,convert(nvarchar(8),EndDate,112)+' 23:59:59'))
--BEGIN 
--	SELECT @CurrentWeek=W-1 From [crmrevo].[BI].[Mst_Calendar_Week] With(NoLock) Where @CurrentDate between StartDate and convert(datetime,convert(nvarchar(8),EndDate,112)+' 23:59:59') 
--END
--ELSE 	SELECT @CurrentWeek=W From [crmrevo].[BI].[Mst_Calendar_Week] With(NoLock) Where @CurrentDate between StartDate and convert(datetime,convert(nvarchar(8),EndDate,112)+' 23:59:59') 

--SET @CurrentWeek = 39 --Modified by Suchat S.

--if @CurrentWeek = 0 set @CurrentWeek = 1

--select @StartDate = startdate, @EndDate = EndDate from [crmrevo].[BI].[Mst_Calendar_Week] With(NoLock) Where w = @CurrentWeek and @Year = y
--Modified by Suchat S. 2020-10-01
SELECT @StartDate = StartDate, @EndDate = EndDate, @CurrentWeek = W
FROM crmrevo.BI.Mst_Calendar_Week WHERE y = DATEPART(YEAR, GETDATE())
AND W = (
SELECT MAX(W)
	FROM crmrevo.bi.Mst_Calendar_Week WITH(NOLOCK)
	WHERE 1=1
	  AND W < ( SELECT W FROM crmrevo.BI.Mst_Calendar_Week WITH (NOLOCK) 
	  WHERE CAST(@CurrentDate AS DATE) BETWEEN CAST(StartDate AS DATE) AND CAST(EndDate AS DATE) ))

Set @StartDate=convert(datetime,convert(nvarchar(8),@StartDate,112)+' 23:59:59')
Set @EndDate=convert(nvarchar(8),@EndDate,112)

SELECT @CurrentWeek, @StartDate,@EndDate

print @CurrentDate
print @CurrentWeek
print @StartDate
print @EndDate




If(Object_Id('tempdb..#vw_RPTAP2_ExV4Booking')Is Not Null)Drop Table #vw_RPTAP2_ExV4Booking
SELECT * INTO #vw_RPTAP2_ExV4Booking FROM [crmrevo].dbo.vw_RPTAP2_ExV4Booking 

Declare @Booking Table (TotalUnit Int,TotalPrice Money,ProjectID nvarchar(100),Ptype int,bookingdate date)
Insert Into @Booking (TotalUnit,TotalPrice,ProjectID,PType,bookingdate)
Select	ISNULL(SUM(B.UnitAmt),0) AS TotalUnit,ISNULL(Sum(B.BKPrice),0) AS TotalPrice ,p.ProjectNo Project,a.BGNo AS PType,bookingdate
From	#vw_RPTAP2_ExV4Booking B With(NoLock)
left join crmrevo.prj.project p With(NoLock) on b.ProjectID = p.id
LEFT JOIN crmrevo.mst.BG a With(NoLock) ON a.id = p.BGID
Where	1=1 --and B.Project='10142'
and p.BGID is not null
GROUP BY p.ProjectNo,a.BGNo,bookingdate


/*Load Adj Freedown*/

EXEC crmrevo.dbo.sp_ExecutiveReport_Adjust
Insert Into @Booking (TotalUnit,TotalPrice,ProjectID,PType,bookingdate)
Select 'TotalUnit'=Sum(SubtractGrossBookingUnit*-1),'TotalPrice'=Sum(SubtractGrossBookingAmount*-1),b.projectno , a.BGNo AS PType,b.BOokingDate
From ##ExecutiveReport_Adjust b
left join crmrevo.prj.project p With(NoLock) on b.projectno = p.ProjectNo
LEFT JOIN crmrevo.mst.BG a With(NoLock) ON a.id = p.BGID
Where	1=1 --and B.Project='10142'
and p.BGID is not null
GROUP BY b.projectno,a.BGNo,bookingdate
Order by b.projectno,b.BOokingDate




if(object_id('tempdb..#vw_UnitPrice')is not null)drop table #vw_UnitPrice
Select a.*,cc.[key]
INTO #vw_UnitPrice 
FROM crmrevo.dbo.vw_UnitPrice a WITH(NOLOCK) 
INNER JOIN crmrevo.mst.MasterCenter cc WITH(NOLOCK) ON cc.id = a.UnitPriceStageMasterCenterID 
WHERE 1=1 AND A.IsDeleted = 0 


if(object_id('tempdb..#ZTEMP_Booking')is not null)drop table #ZTEMP_Booking
SELECT * INTO #ZTEMP_Booking FROM (SELECT bg.BGNo,p.ProjectNameTH AS Project,p.ProjectNo,a.id,a.ProjectID,a.UnitID,a.BookingDate,uu.AgreementPrice,uu.CashDiscount,uu.TransferDiscount,b.[Name]
									 FROM crmrevo.sal.Booking a WITH(NOLOCK) INNER JOIN crmrevo.mst.MasterCenter b WITH(NOLOCK) ON a.CreateBookingFROMMasterCenterID = b.id AND b.[Key] = '2' 
									INNER JOIN (SELECT c.BookingID,c.AgreementPrice,c.CashDiscount,c.TransferDiscount FROM  #vw_UnitPrice c WITH(NOLOCK) WHERE c.[KEY] = '1' ) uu ON a.id = uu.BookingID 
												LEFT JOIN crmrevo.prj.Project p WITH(NOLOCK) ON a.ProjectID = p.id AND p.IsDeleted = 0
												LEFT JOIN crmrevo.mst.bg bg WITH(NOLOCK) ON bg.id = p.BGID
									WHERE a.ConfirmDate IS NULL  AND a.IsDeleted = 0 AND a.IsCancelled = 0 )aa
					

if(object_id('tempdb..#TempCancel')is not null)drop table #TempCancel
SELECT bk.* ,u.TotalPrice,u.FreedownDiscount,p.ProjectNo 
INTO #TempCancel
FROM crmrevo.sal.Booking bk  WITH(NOLOCK)
LEFT JOIN (SELECT a.* FROM #vw_UnitPrice a WITH(NOLOCK) WHERE a.[Key] = '1') u ON bk.id = u.BookingID
LEFT JOIN crmrevo.prj.Project p WITH(NOLOCK) ON bk.ProjectID = p.id  AND p.IsDeleted = 0
WHERE	ISNULL(BK.IsDeleted, 0) = 0
		AND ((BK.CancelDate IS NOT NULL) 
		AND (ISNULL(BK.CancelType, 0) IN (3, 1) 
		AND ISNULL(BK.IsFromChangeUnit, 0) = 0 
		OR ISNULL(BK.CancelType, 0) IN (3, 1) 
		AND ISNULL(BK.IsFromChangeUnit, 0) = 1))


if(object_id('tempdb..#TempTrans')is not null)drop table #TempTrans
SELECT t.* ,p.ProjectNo,u.TotalPrice,u.FreedownDiscount
INTO #TempTrans
FROM crmrevo.sal.[Transfer] t WITH(NOLOCK)
LEFT JOIN crmrevo.sal.Agreement a WITH(NOLOCK) ON t.AgreementID = a.id AND a.IsDeleted = 0
LEFT JOIN (SELECT a.* FROM #vw_UnitPrice a  WHERE a.[Key] = '3' ) u ON u.BookingID = a.BookingID
LEFT JOIN crmrevo.prj.Project p WITH(NOLOCK) ON t.ProjectID = p.ID AND p.IsDeleted = 0
WHERE   t.IsDeleted = 0 
AND a.IsCancel = 0

--if(object_id('tempdb..#temp')is not null)drop table #temp
--select * 
--into #temp 
--from vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract 

--if(object_id('tempdb..#vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract')is not null)drop table #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract
--select * into #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract from #temp 
--Where ((Convert(nvarchar(8),BookingDate,112) between @StartDate and @EndDate and BookingType='จองพิเศษ')
--				or (Convert(nvarchar(8),BookingCancelDate,112) between @StartDate and @EndDate and CurrentStatus='ยกเลิก'))
---- non 19/9/2019 แก้ไขเนื่องจาก fi budget แจ้งว่า รายงาน ex  เดือน 1-6 ไม่มีรายการที่เป็นจองพิเศษ
----where BookingCancelDate Between @StartDate and @EndDate  order by 1,2

--if(object_id('tempdb..#vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract')is not null)drop table #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract
--select * 
--into #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract 
--from vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract 

--If(Object_Id('tempdb..#Temp_Subtract_Cancel')Is Not Null)Drop Table #Temp_Subtract_Cancel
--	Select ProjectID,'SubtractCancelAmount'=Sum(SubtractCancelAmount) ,'SubtractCancelUnit'=Sum(SubtractCancelUnit) 
--	into #Temp_Subtract_Cancel
--	From(
--		SELECT ProjectID
--		,'SubtractCancelAmount'=Sum(SubtractCancelAmount) ,'SubtractCancelUnit'=Sum(1)
--		FROM #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract With(NoLock)
--		Where 1=1 
--			and ((Convert(nvarchar(8),BookingDate,112) between @StartDate and @EndDate and BookingType='จองพิเศษ'))
--		Group by ProjectID
--		UNION
--		SELECT ProjectID
--		,'SubtractCancelAmount'=Sum(SubtractCancelAmount) ,'SubtractCancelUnit'=Sum(SubtractCancelUnit)
--		FROM #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract a With(NoLock)
--		Where 1=1 
--			and ( (Convert(nvarchar(8),BookingCancelDate,112) between @StartDate and @EndDate and CurrentStatus='ยกเลิก'))
--			and (BookingDate>=@StartDate or BookingType<>'จองพิเศษ')
--			and not exists(SELECT *
--					FROM #vw_RPTAP2_ExV4Booking_ExecutiveReport_Subtract b With(NoLock)
--					Where 1=1 
--						and ((Convert(nvarchar(8),BookingDate,112) between @StartDate and @EndDate and BookingType='จองพิเศษ'))
--						and a.BookingNumber=b.BookingNumber)
--		Group by ProjectID
--	)t
--	Group by ProjectID
---------------------------------#TotalProject-----------------------------------------------------------
If(Object_Id('tempdb..#Project')Is Not Null)Drop Table #Project
SELECT DISTINCT b.BGNo AS Ptype,p.ProjectNo AS Productid, p.ProjectNameTH AS Project
, BookOff_Unit  = Convert(int,0)
, BookOff_Value = Convert(decimal(18,2),0)
, Cancel_Unit = Convert(int,0)
, Cancel_Value  = Convert(decimal(18,2),0)
, Net_Unit = Convert(int,0)
, Net_Value = Convert(decimal(18,2),0)
, Transfer_Unit = Convert(int,0)
, Transfer_Value  = Convert(decimal(18,2),0)
into #Project
from crmrevo.prj.Project p With(NoLock)
LEFT JOIN crmrevo.mst.bg b With(NoLock) ON p.BGID = b.id 
where p.BGID  is not null 
and p.IsActive = 1 AND p.IsDeleted = 0


exec [sp_RPT_ExecutiveMail_Prepare] @StartDate,@EndDate
--select * from ##ExecutiveReport
Update ##ExecutiveReport Set CancelTotalPrice=ABS(CancelTotalPrice),CancelTotalUnit=ABS(CancelTotalUnit)

Update #Project
Set BookOff_Value=Isnull((Select BookingTotalPrice From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,BookOff_Unit=Isnull((Select BookingTotalUnit From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,Cancel_Value=Isnull((Select CancelTotalPrice From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,Cancel_Unit=Isnull((Select CancelTotalUnit From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,Transfer_Value=Isnull((Select TransferTotalPrice From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,Transfer_Unit=Isnull((Select TransferTotalUnit From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
From #Project t

update #Project
set Net_Value=BookOff_Value-Cancel_Value
,Net_Unit=BookOff_Unit-Cancel_Unit

select Ptype as BG
, sum(BookOff_Unit)  BookOff_Unit
, sum(BookOff_Value) BookOff_Value
, sum(Cancel_Unit)Cancel_Unit
, sum(Cancel_Value)Cancel_Value
, sum(Net_Unit)Net_Unit
, sum(Net_Value)Net_Value
, sum(Transfer_Unit) Transfer_Unit
, sum(Transfer_Value)Transfer_Value
into #TotalProject
 from #Project
 group by Ptype
 order by PType

 PRINT 'TotalProject'


------------------------ table #NewProjectPerformance---------------------------------------

select distinct ProjectNo AS ProductID, ProjectNameTH AS Project,b.BGNo as BG
, BookOff_Unit  = Convert(int,0)
, BookOff_Value = Convert(decimal(18,2),0)
, Cancel_Unit = Convert(int,0)
, Cancel_Value  = Convert(decimal(18,2),0)
, Net_Unit = Convert(int,0)
, Net_Value = Convert(decimal(18,2),0)
, Transfer_Unit = Convert(int,0)
, Transfer_Value  = Convert(decimal(18,2),0)
, BookAccum_Unit = Convert(int,0)
, BookAccum_Value = Convert(decimal(18,2),0)
, TransAccum_Unit = Convert(int,0)
, TransAccum_Value = Convert(decimal(18,2),0)
into #NewProjectPerformance
from crmrevo.prj.Project p  With(NoLock)
LEFT JOIN crmrevo.mst.BG b  With(NoLock) ON p.BGID = b.id AND b.IsDeleted = 0
where p.IsActive = 1  AND p.IsDeleted = 0
--and  year(StartSale) =  2016
and  year(ProjectStartDate) = year(@CurrentDate)
And ProjectStartDate<=GetDate() -- เพิ่มเงื่อนไขกรณี ใส่วันที่ StartSale ล่วงหน้า ยังไม่ต้องแสดง

update #NewProjectPerformance
--set BookOff_Unit = (Isnull((Select Sum(TotalUnit) From @Booking b  Where bookingdate  Between @StartDate and @EndDate and    b.ProjectID=t.ProductID group by Ptype ),0)
--				+
--						Isnull((SELECT COUNT(b.UnitID) FROM #ZTEMP_Booking b
--						WHERE  b.ProjectNo = t.ProductID  AND dbo.fn_ClearTime(BookingDate) Between @StartDate and @EndDate  and BookingDate<>'20130930'GROUP BY b.ProjectID ),0))
--,BookOff_Value = (Isnull((Select Sum(TotalPrice) From @Booking b Where b.ProjectID=t.ProductID and bookingdate  Between @StartDate and @EndDate),0)
--				+
--				Isnull((SELECT sum(ISNULL(b.AgreementPrice,0))AS BookingOfflinePrice_NotConfirm
--				--SUM(SellNetPrice-Isnull(b.TransferDiscount,0)) AS BookingOfflinePrice_NotConfirm แก้ไข SellNetPrice
--				FROM #ZTEMP_Booking b WHERE   b.projectNo = t.ProductID AND  dbo.fn_ClearTime(BookingDate) Between @StartDate and @EndDate  and BookingDate<>'20130930'	GROUP BY b.ProjectID ),0))/1000000
--,Cancel_Unit = 	Isnull((SELECT COUNT(UnitID) FROM #TempCancel b WHERE  b.ProjectNo = t.ProductID AND dbo.fn_ClearTime(b.CancelDate) Between @StartDate and @EndDate	GROUP BY b.ProjectID),0)
--				-isnull((Select sum(SubtractCancelUnit) 
--					FROM #Temp_Subtract_Cancel b LEFT JOIN prj.Project p ON b.ProjectID = p.id AND p.IsDeleted = 0 
--					WHERE p.ProjectNo = t.ProductID),0)
--,Cancel_Value = Isnull((SELECT  sum(ISNULL(b.TotalPrice,0)-Isnull(b.FreedownDiscount,0))AS BookingPrice_Cancel
--				--SUM(B.SellingPrice-Isnull(b.TransferDiscount,0)) AS BookingPrice_Cancel แก้ไข SellingPrice
--				FROM #TempCancel b WHERE  b.ProjectNo  = t.ProductID and dbo.fn_ClearTime(b.CancelDate) Between @StartDate and @EndDate
--				 -- and not exists(select * from RPT_PreCancel_V2 t Where t.DocumentNumber=b.BookingNumber and RevertDate Is null and Createdate<=@EndDate)
--				GROUP BY b.ProjectID),0)/1000000
--				-isnull((Select sum(SubtractCancelamount) 
--					FROM #Temp_Subtract_Cancel b LEFT JOIN prj.Project p ON b.ProjectID = p.id AND p.IsDeleted = 0 
--					WHERE p.ProjectNo = t.ProductID),0)/1000000
--,Net_Unit = 	Isnull((Select Sum(TotalUnit) From @Booking b Where bookingdate  Between @StartDate and @EndDate and   b.ProjectID=t.ProductID ),0)
--				-
--				Isnull((SELECT COUNT(B.UnitID) FROM #TempCancel B  With(NoLock) WHERE  b.ProjectNo = t.ProductID  and dbo.fn_ClearTime(b.CancelDate) Between @StartDate and @EndDate GROUP BY b.ProjectNo),0)				
--				+
--				Isnull((SELECT COUNT(b.UnitID)	FROM #ZTEMP_Booking b WHERE b.ProjectNo = t.ProductID	GROUP BY b.ProjectID ),0)
--				+isnull((Select sum(SubtractCancelUnit) from #Temp_Subtract_Cancel b LEFT JOIN prj.Project p ON b.ProjectID = p.id AND p.IsDeleted = 0  Where p.ProjectNo = t.ProductID),0)
--,Net_Value = (Isnull((Select Sum(TotalPrice) From @Booking b Where bookingdate  Between @StartDate and @EndDate and   b.ProjectID=t.ProductID),0)
--				-
--				Isnull((SELECT sum(ISNULL(b.TotalPrice,0)-Isnull(b.FreedownDiscount,0))AS BookingPrice_Cancel
--				--SUM(B.SellingPrice-Isnull(b.TransferDiscount,0)) AS BookingPrice_Cancel แก้ไข SellingPrice
--				FROM #TempCancel b	WHERE  b.ProjectNo = t.ProductID and dbo.fn_ClearTime(b.CancelDate) Between @StartDate and @EndDate GROUP BY b.ProjectID),0)
--				+
--				Isnull((SELECT sum(ISNULL(b.AgreementPrice,0))AS BookingOfflinePrice_NotConfirm
--				--SUM(SellNetPrice-Isnull(b.TransferDiscount,0)) AS BookingOfflinePrice_NotConfirm แก้ไข SellNetPrice
--				FROM #ZTEMP_Booking b WHERE   b.projectNo = t.ProductID AND dbo.fn_ClearTime(BookingDate) Between @StartDate and @EndDate  and BookingDate<>'20130930'	GROUP BY b.ProjectID ),0))/1000000
--,Transfer_Unit = Isnull((select count(b.UnitID) FROM #tempTrans b	where  b.ProjectNo = t.ProductID AND b.ActualTransferDate Between @StartDate and @EndDate GROUP BY b.ProjectID),0)
--,Transfer_Value = Isnull((select sum (isnull(b.TotalPrice,0)-Isnull(b.FreedownDiscount,0))	from #TempTrans b WHERE  b.projectNo = t.ProductID	AND b.ActualTransferDate Between @StartDate and @EndDate ),0)/1000000
set BookAccum_Unit = Isnull((Select Sum(TotalUnit) From @Booking b Where year(bookingdate) = year(@CurrentDate) and bookingdate <= @CurrentDate and   b.ProjectID=t.ProductID ),0)
				-
				Isnull((SELECT COUNT(b.UnitID) 
				FROM #TempCancel b 
				WHERE 1=1
				  and year(CancelDate) = year(@CurrentDate)--and CancelDate<>'20130930'
				  and CancelDate <= @CurrentDate
				  and b.projectNo = t.ProductID
				GROUP BY b.ProjectID),0)				
				+
				Isnull((SELECT COUNT(b.UnitID)
				FROM #ZTEMP_Booking b
				WHERE b.ProjectNo = t.ProductID 
					and year(BookingDate) = year(@CurrentDate)
					and BookingDate <= @CurrentDate
				GROUP BY b.ProjectID ),0)
,BookAccum_Value =  (Isnull((Select Sum(TotalPrice) From @Booking b  Where year(bookingdate) = year(@CurrentDate)  and bookingdate <= @CurrentDate and      b.ProjectID=t.ProductID),0)
				-
				Isnull((SELECT sum(ISNULL(b.TotalPrice,0)-Isnull(b.FreedownDiscount,0))AS BookingPrice_Cancel
				--SUM(B.SellingPrice-Isnull(b.TransferDiscount,0)) AS BookingPrice_Cancel แก้ไข SellingPrice
				FROM #TempCancel b
				WHERE 1=1
				  and year(CancelDate) = year(@CurrentDate)
				  and CancelDate <= @CurrentDate
				  and b.projectNo = t.ProductID
				 -- and not exists(select * from RPT_PreCancel_V2 t Where t.DocumentNumber=b.BookingNumber and RevertDate Is null and Createdate<=@EndDate)
				GROUP BY b.ProjectID),0)
				+
				Isnull((SELECT sum(ISNULL(b.AgreementPrice,0))AS BookingOfflinePrice_NotConfirm
				--SUM(SellNetPrice-Isnull(b.TransferDiscount,0)) AS BookingOfflinePrice_NotConfirm แก้ไข SellNetPrice
				FROM #ZTEMP_Booking b
				WHERE  b.ProjectNo = t.ProductID  
					and year(BookingDate) = year(@CurrentDate)
					and BookingDate <= @CurrentDate
				GROUP BY b.ProjectID ),0))/1000000
,TransAccum_Unit =  Isnull((select count(b.UnitID)
				from #TempTrans b
				where 1=1
				and b.projectNo = t.ProductID
				and year(b.ActualTransferDate) = year(@CurrentDate)
				and b.ActualTransferDate <= @CurrentDate
				),0)
,TransAccum_Value = Isnull((select sum (isnull(b.TotalPrice,0)-Isnull(b.FreedownDiscount,0))
				from #TempTrans b
				where 1=1
				and b.projectNo = t.ProductID
				and year(b.ActualTransferDate) = year(@CurrentDate)
				and b.ActualTransferDate <= @CurrentDate
				),0)/1000000
from #NewProjectPerformance t
--select * from #NewProjectPerformance


Update #NewProjectPerformance
Set BookOff_Value=Isnull((Select BookingTotalPrice From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,BookOff_Unit=Isnull((Select BookingTotalUnit From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,Cancel_Value=Isnull((Select CancelTotalPrice From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,Cancel_Unit=Isnull((Select CancelTotalUnit From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,Transfer_Value=Isnull((Select TransferTotalPrice From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,Transfer_Unit=Isnull((Select TransferTotalUnit From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
From #NewProjectPerformance t

update #NewProjectPerformance
set Net_Value=BookOff_Value-Cancel_Value
,Net_Unit=BookOff_Unit-Cancel_Unit

PRINT 'NewProjectPerformance'
------------------------------------------------table #ExistingProject-------------------------------------
If(Object_Id('tempdb..#Existing')Is Not Null)Drop Table #Existing

SELECT p.ProjectNo AS ProductID,p.ProjectNameTH AS Project,b.BGNo AS PType
, BookOff_Unit  = Convert(int,0)
, BookOff_Value = Convert(decimal(18,2),0)
, Cancel_Unit = Convert(int,0)
, Cancel_Value  = Convert(decimal(18,2),0)
, Net_Unit = Convert(int,0)
, Net_Value = Convert(decimal(18,2),0)
, Transfer_Unit = Convert(int,0)
, Transfer_Value  = Convert(decimal(18,2),0)
, Off_Unit = Convert(int,0)
, Off_Value =  Convert(decimal(18,2),0)
into #Existing
from  crmrevo.prj.Project p  With(NoLock)
LEFT JOIN crmrevo.mst.bg b  With(NoLock) ON p.BGID = b.id AND b.IsDeleted = 0
where p.ProjectNo not in (select ProductID from #NewProjectPerformance )
and p.IsActive = 1 

--update #Existing
--set  BookOff_Unit = (Isnull((Select Sum(TotalUnit) From @Booking b  Where bookingdate  Between @StartDate and @EndDate and    b.ProjectID=t.ProductID group by Ptype ),0)
--				+
--						Isnull((SELECT COUNT(UnitNumber)
--				FROM dbo.ZTEMP_Booking b With(NoLock)
--				--left join [dbo].[ICON_EntForms_Products] p on b.ProjectID = p.ProductID
--				WHERE ISNULL(IsConfirm,0) = 0 and b.ProjectID = t.ProductID  AND  iscancel = 0 
--					and dbo.fn_ClearTime(BookingDate) Between @StartDate and @EndDate and BookingDate<>'20130930'
--				GROUP BY b.ProjectID ),0))
--,BookOff_Value = (Isnull((Select Sum(TotalPrice) From @Booking b Where b.ProjectID=t.ProductID and bookingdate  Between @StartDate and @EndDate),0)
--				+
--				Isnull((SELECT sum((sellprice - isnull(discount,0)) -Isnull(b.TransferDiscount,0))AS BookingOfflinePrice_NotConfirm
--				--SUM(SellNetPrice-Isnull(b.TransferDiscount,0)) AS BookingOfflinePrice_NotConfirm แก้ไข SellNetPrice
--				FROM dbo.ZTEMP_Booking b With(NoLock)
--				--left join [dbo].[ICON_EntForms_Products] p on b.ProjectID = p.ProductID
--				WHERE ISNULL(IsConfirm,0) = 0 and b.ProjectID = t.ProductID and  b.iscancel = 0 
--					and dbo.fn_ClearTime(BookingDate) Between @StartDate and @EndDate  and BookingDate<>'20130930'
--				GROUP BY b.ProjectID ),0))/1000000
--,Cancel_Unit = 		Isnull((SELECT COUNT(UnitNumber) 
--				FROM dbo.ICON_EntForms_Booking B  With(NoLock)
--				--left join [dbo].[ICON_EntForms_Products] p on b.ProductID = p.ProductID 
--				WHERE ((CancelDate IS NOT NULL) 
--						AND (ISNULL(Cancel, 0) IN (3, 1) 
--						AND ISNULL(ChangeUnit, 0) = 0 OR
--					  ISNULL(Cancel, 0) IN (3, 1) 
--						AND ISNULL(ChangeUnit, 0) = 1))
--				  and dbo.fn_ClearTime(CancelDate) Between @StartDate and @EndDate --and CancelDate<>'20130930'
--				  and b.ProductID = t.ProductID
--				GROUP BY b.ProductID),0)
--				-isnull((Select sum(SubtractCancelunit) from #Temp_Subtract_Cancel b Where b.ProductID = t.ProductID),0)
--,Cancel_Value = Isnull((SELECT  sum(((TotalSellingPrice + isnull(FurniturePrice,0)) - isnull(Cashdiscount,0)) -Isnull(b.TransferDiscount,0)-Isnull(fd.FreedownAmount,0))AS BookingPrice_Cancel
--				--SUM(B.SellingPrice-Isnull(b.TransferDiscount,0)) AS BookingPrice_Cancel แก้ไข SellingPrice
--				FROM dbo.ICON_EntForms_Booking B  With(NoLock)
--				Left join #CRM_FreeDown fd With(NoLock)on fd.DocumentType=1 and fd.DocumentID=b.BookingNumber
--			--	left join [dbo].[ICON_EntForms_Products] p on b.ProductID = p.ProductID
--				WHERE ((CancelDate IS NOT NULL) 
--						AND (ISNULL(Cancel, 0) IN (3, 1) 
--						AND ISNULL(ChangeUnit, 0) = 0 OR
--					  ISNULL(Cancel, 0) IN (3, 1) 
--						AND ISNULL(ChangeUnit, 0) = 1))
--				  and dbo.fn_ClearTime(CancelDate) Between @StartDate and @EndDate and CancelDate<>'20130930'
--				  and b.ProductID = t.ProductID
--				 -- and not exists(select * from RPT_PreCancel_V2 t Where t.DocumentNumber=b.BookingNumber and RevertDate Is null and Createdate<=@EndDate)
--				GROUP BY b.ProductID),0)/1000000
--				-isnull((Select sum(SubtractCancelamount) from #Temp_Subtract_Cancel b Where b.ProductID = t.ProductID),0)/1000000
--,Net_Unit = 	Isnull((Select Sum(TotalUnit) From @Booking b Where bookingdate  Between @StartDate and @EndDate and   b.ProjectID=t.ProductID ),0)
--				-
--				Isnull((SELECT COUNT(UnitNumber) 
--				FROM dbo.ICON_EntForms_Booking B  With(NoLock)
--				--left join [dbo].[ICON_EntForms_Products] p on b.ProductID = p.ProductID 
--				WHERE ((CancelDate IS NOT NULL) 
--						AND (ISNULL(Cancel, 0) IN (3, 1) 
--						AND ISNULL(ChangeUnit, 0) = 0 OR
--					  ISNULL(Cancel, 0) IN (3, 1) 
--						AND ISNULL(ChangeUnit, 0) = 1))
--				  and dbo.fn_ClearTime(CancelDate) Between @StartDate and @EndDate --and CancelDate<>'20130930'
--				  and b.ProductID = t.ProductID
--				GROUP BY b.ProductID),0)				
--				+
--				Isnull((SELECT COUNT(UnitNumber)
--				FROM dbo.ZTEMP_Booking b With(NoLock)
--				--left join [dbo].[ICON_EntForms_Products] p on b.ProjectID = p.ProductID
--				WHERE ISNULL(IsConfirm,0) = 0 and b.ProjectID = t.ProductID AND  iscancel = 0 
--					and dbo.fn_ClearTime(BookingDate) Between @StartDate and @EndDate and BookingDate<>'20130930'
--				GROUP BY b.ProjectID ),0)
--,Net_Value = (Isnull((Select Sum(TotalPrice) From @Booking b Where bookingdate  Between @StartDate and @EndDate and   b.ProjectID=t.ProductID),0)
--				-
--				Isnull((SELECT sum(((TotalSellingPrice + isnull(FurniturePrice,0)) - isnull(Cashdiscount,0)) -Isnull(b.TransferDiscount,0)-Isnull(fd.FreedownAmount,0))AS BookingPrice_Cancel
--				--SUM(B.SellingPrice-Isnull(b.TransferDiscount,0)) AS BookingPrice_Cancel แก้ไข SellingPrice
--				FROM dbo.ICON_EntForms_Booking B  With(NoLock)
--				Left join #CRM_FreeDown fd With(NoLock)on fd.DocumentType=1 and fd.DocumentID=b.BookingNumber
--				--left join [dbo].[ICON_EntForms_Products] p on b.ProductID = p.ProductID
--				WHERE ((CancelDate IS NOT NULL) 
--						AND (ISNULL(Cancel, 0) IN (3, 1) 
--						AND ISNULL(ChangeUnit, 0) = 0 OR
--					  ISNULL(Cancel, 0) IN (3, 1) 
--						AND ISNULL(ChangeUnit, 0) = 1))
--				  and dbo.fn_ClearTime(CancelDate) Between @StartDate and @EndDate and CancelDate<>'20130930'
--				  and b.ProductID = t.ProductID
--				 -- and not exists(select * from RPT_PreCancel_V2 t Where t.DocumentNumber=b.BookingNumber and RevertDate Is null and Createdate<=@EndDate)
--				GROUP BY b.ProductID),0)
--				+
--				Isnull((SELECT sum((sellprice - isnull(discount,0)) -Isnull(b.TransferDiscount,0))AS BookingOfflinePrice_NotConfirm
--				--SUM(SellNetPrice-Isnull(b.TransferDiscount,0)) AS BookingOfflinePrice_NotConfirm แก้ไข SellNetPrice
--				FROM dbo.ZTEMP_Booking b With(NoLock)
--				--left join [dbo].[ICON_EntForms_Products] p on b.ProjectID = p.ProductID
--				WHERE ISNULL(IsConfirm,0) = 0 and b.ProjectID = t.ProductID AND  b.iscancel = 0 
--					and dbo.fn_ClearTime(BookingDate) Between @StartDate and @EndDate  and BookingDate<>'20130930'
--				GROUP BY b.ProjectID ),0))/1000000
--,Transfer_Unit = Isnull((select count(a.TransferNumber)
--				from ICON_EntForms_Transfer a With(NoLock)
--				left join ICON_EntForms_Agreement b With(NoLock) on a.ContractNumber = b.ContractNumber and b.CancelDate is null
--				--left join ICON_EntForms_Products p on b.ProductID = p.ProductID
--				where 1=1
--				and b.ProductID = t.ProductID
--				and a.TransferDateApprove Between @StartDate and @EndDate
--				),0)
--,Transfer_Value = Isnull((select sum (isnull(a.NetSalePrice,0)-Isnull(fd.FreedownAmount,0))
--				from ICON_EntForms_Transfer a With(NoLock)
--				left join ICON_EntForms_Agreement b With(NoLock) on a.ContractNumber = b.ContractNumber and b.CancelDate is null
--				Left join #CRM_FreeDown fd With(NoLock)on fd.DocumentType=2 and fd.DocumentID=b.ContractNumber
--				--left join ICON_EntForms_Products p on b.ProductID = p.ProductID
--				where 1=1
--				and b.ProductID = t.ProductID
--				and a.TransferDateApprove Between @StartDate and @EndDate
--				),0)/1000000
--,Off_Unit = Isnull((SELECT COUNT(UnitNumber)
--				FROM dbo.ZTEMP_Booking b With(NoLock)
--				--left join [dbo].[ICON_EntForms_Products] p on b.ProjectID = p.ProductID
--				WHERE ISNULL(IsConfirm,0) = 0 and b.ProjectID = t.ProductID AND  iscancel = 0 
--					and dbo.fn_ClearTime(BookingDate) Between @StartDate and @EndDate and BookingDate<>'20130930'
--				GROUP BY b.ProjectID ),0)
--,Off_Value = (Isnull((SELECT sum((sellprice - isnull(discount,0)) -Isnull(b.TransferDiscount,0))AS BookingOfflinePrice_NotConfirm
--				--SUM(SellNetPrice-Isnull(b.TransferDiscount,0)) AS BookingOfflinePrice_NotConfirm แก้ไข SellNetPrice
--				FROM dbo.ZTEMP_Booking b With(NoLock)
--				--left join [dbo].[ICON_EntForms_Products] p on b.ProjectID = p.ProductID
--				WHERE ISNULL(IsConfirm,0) = 0 and b.ProjectID = t.ProductID AND  b.iscancel = 0 
--					and dbo.fn_ClearTime(BookingDate) Between @StartDate and @EndDate  and BookingDate<>'20130930'
--				GROUP BY b.ProjectID ),0))/1000000
--from #Existing t


Update #Existing
Set BookOff_Value=Isnull((Select BookingTotalPrice From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,BookOff_Unit=Isnull((Select BookingTotalUnit From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,Cancel_Value=Isnull((Select CancelTotalPrice From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,Cancel_Unit=Isnull((Select CancelTotalUnit From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,Transfer_Value=Isnull((Select TransferTotalPrice From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
,Transfer_Unit=Isnull((Select TransferTotalUnit From ##ExecutiveReport e Where e.ProductiD=t.ProductID),0)
From #Existing t

update #Existing
set Net_Value=BookOff_Value-Cancel_Value
,Net_Unit=BookOff_Unit-Cancel_Unit

select  PType as BG
, sum(BookOff_Unit)BookOff_Unit
, sum(BookOff_Value) BookOff_Value
, sum(Cancel_Unit)Cancel_Unit
, sum(Cancel_Value) Cancel_Value
, sum(Net_Unit)  Net_Unit
, sum(Net_Value) Net_Value
, sum(Transfer_Unit) Transfer_Unit
, sum(Transfer_Value) Transfer_Value
, sum(Off_Unit) Off_Unit
, sum(Off_Value) Off_Value
into #ExistingProject
from #Existing 
group by PType
order by PType

--select * from #ExistingProject
PRINT 'ExistingProject'


---------------------------------#TotalProject_JV-----------------------------------------------------------
If(Object_Id('tempdb..#Project_JV')Is Not Null)Drop Table #Project_JV
select distinct b.BGNo AS Ptype,p.ProjectNo AS ProductID,p.ProjectNameTH AS Project
, BookOff_Unit  = Convert(int,0)
, BookOff_Value = Convert(decimal(18,2),0)
, Cancel_Unit = Convert(int,0)
, Cancel_Value  = Convert(decimal(18,2),0)
, Net_Unit = Convert(int,0)
, Net_Value = Convert(decimal(18,2),0)
, Transfer_Unit = Convert(int,0)
, Transfer_Value  = Convert(decimal(18,2),0)
into #Project_JV
from crmrevo.prj.Project p With(NoLock)
LEFT JOIN crmrevo.mst.bg b With(NoLock) ON p.BGID = b.id 
where b.BGNo is not null and p.ProjectNo in(Select jv.ProductID From crmrevo.dbo.vw_Project_JV jv)
and p.IsActive = 1 AND p.IsDeleted = 0

exec [sp_RPT_ExecutiveMail_Prepare_JV] @StartDate,@EndDate
--select * from ##ExecutiveReport_JV
Update ##ExecutiveReport_JV Set CancelTotalPrice=ABS(CancelTotalPrice),CancelTotalUnit=ABS(CancelTotalUnit)

Update #Project_JV
Set BookOff_Value=Isnull((Select BookingTotalPrice From ##ExecutiveReport_JV e Where e.ProductiD=t.ProductID),0)
,BookOff_Unit=Isnull((Select BookingTotalUnit From ##ExecutiveReport_JV e Where e.ProductiD=t.ProductID),0)
,Cancel_Value=Isnull((Select CancelTotalPrice From ##ExecutiveReport_JV e Where e.ProductiD=t.ProductID),0)
,Cancel_Unit=Isnull((Select CancelTotalUnit From ##ExecutiveReport_JV e Where e.ProductiD=t.ProductID),0)
,Transfer_Value=Isnull((Select TransferTotalPrice From ##ExecutiveReport_JV e Where e.ProductiD=t.ProductID),0)
,Transfer_Unit=Isnull((Select TransferTotalUnit From ##ExecutiveReport_JV e Where e.ProductiD=t.ProductID),0)
From #Project_JV t

update #Project_JV
set Net_Value=BookOff_Value-Cancel_Value
,Net_Unit=BookOff_Unit-Cancel_Unit

select Ptype as BG
, sum(BookOff_Unit)  BookOff_Unit
, sum(BookOff_Value) BookOff_Value
, sum(Cancel_Unit)Cancel_Unit
, sum(Cancel_Value)Cancel_Value
, sum(Net_Unit)Net_Unit
, sum(Net_Value)Net_Value
, sum(Transfer_Unit) Transfer_Unit
, sum(Transfer_Value)Transfer_Value
into #TotalProject_JV
 from #Project_JV
 group by Ptype
 order by PType

 PRINT 'TotalProject_JV'
-----------------------------------------#Gross------------------------------------------------------
Select * 
into #GrossBooking
From(
	Select *
	,ROW_NUMBER()over(Partition by BG order by BG,BookOff_Value desc)Seq
	From (
		select  ptype as BG,ProductID,Project,sum(BookOff_Unit) BookOff_Unit ,sum(BookOff_Value) BookOff_Value
		 from #Project 
		 group by ptype ,ProductID,Project 
	 )t
 )t
 Where seq in(1,2,3)
 order by BG,Seq 
 
 --select * from #GrossBooking

----------------------------------------------#NetBooking-------------------------------------------------

Select * 
into #NetBooking
From(
	Select *
	,ROW_NUMBER()over(Partition by BG order by BG,Net_Value desc)Seq
	From (
		select  ptype as BG,ProductID,Project,sum(Net_Unit) Net_Unit ,sum(Net_Value) Net_Value
		 from #Project 
		 group by ptype ,ProductID,Project 
	 )t
 )t
 Where seq in(1,2,3)
 order by BG,Seq 
 
 --select * from #NetBooking


-----------------------------------------------#NetTransfer-------------------------------------------------------

Select * 
into #NetTransfer
From(
	Select *
	,ROW_NUMBER()over(Partition by BG order by BG,Transfer_Value desc)Seq
	From (
		select  ptype as  BG ,ProductID,Project,sum(Transfer_Unit) Transfer_Unit ,sum(Transfer_Value) Transfer_Value
		 from #Project 
		 group by ptype ,ProductID,Project 
	 )t
 )t
 Where seq in(1,2,3)
 order by BG,Seq 

--select * from #NetTransfer

---------------------------------------------------------#NetCancel---------------------------------------------------------
Select * 
into #NetCancel
From(
	Select *
	,ROW_NUMBER()over(Partition by BG order by BG,Cancel_Unit desc)Seq
	From (
		select  ptype as BG ,ProductID,Project,sum(Cancel_Unit) Cancel_Unit ,sum(Cancel_Value) Cancel_Value
		 from #Project 
		 group by ptype ,ProductID,Project 
	 )t
 )t
 Where seq in(1,2,3)
 order by BG,Seq 

--select * from #NetCancel
-----------------------------------------------------#BookingOffline-------------------------------------

SELECT b.BGNo as BG , b.ProjectNo AS ProjectID,b.Project
,COUNT(b.UnitID) AS BookingOffline_Unit
, sum(isnull(b.AgreementPrice,0))/1000000 As BookingOffline_Value
				--SUM(SellNetPrice-Isnull(b.TransferDiscount,0)) AS BookingOfflinePrice_NotConfirm แก้ไข SellNetPrice
				into #BookingOffline
				FROM #ZTEMP_Booking b
				WHERE 1=1
				and dbo.fn_ClearTime(BookingDate) Between @StartDate and @EndDate  and BookingDate<>'20130930'
				GROUP BY b.BGNo, b.ProjectNo,b.Project
--select * from #BookingOffline
--------------------------------------------------------------------------------------
/*Load Email Template*/
If(Object_Id('tempdb..#EmailTemplate')Is Not Null)Drop Table #EmailTemplate
Select Convert(NVarchar(max),'')Content  Into #EmailTemplate 
Delete From #EmailTemplate
--ALTER TABLE #EmailTemplate  
--ALTER COLUMN Content NVarchar(max) COLLATE Thai_CI_AS;  
--BULK INSERT #EmailTemplate FROM 'E:\DB\Template\TemplateMail.html'
--BULK INSERT #EmailTemplate FROM 'O:\Template\TemplateMail.html'
BULK INSERT #EmailTemplate FROM 'E:\Template\TemplateMail.html'
WITH (ROWTERMINATOR ='')
--Select * From #EmailTemplate 
Select @Mail=Content From #EmailTemplate


/*Assign value to Email*/
declare @FormatDecimal NVarchar(10)  = '0.00',@FormatInt NVarchar(10)  = '0'

-------------------------------------------------#TotalProject------------------------------------------------------------------
Set @Mail=Replace(@Mail,'@TotalProject_BG1_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 BookOff_Unit From #TotalProject t Where BG=1)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG1_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #TotalProject t Where BG=1)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG1_Cancel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #TotalProject t Where BG=1)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG1_Cancel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #TotalProject t Where BG=1)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG1_Net_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #TotalProject t Where BG=1)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG1_Net_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #TotalProject t Where BG=1)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG1_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #TotalProject t Where BG=1)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG1_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #TotalProject t Where BG=1)AS money), 1))

Set @Mail=Replace(@Mail,'@TotalProject_BG2_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 BookOff_Unit From #TotalProject t Where BG=2)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG2_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #TotalProject t Where BG=2)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG2_Cancel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #TotalProject t Where BG=2)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG2_Cancel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #TotalProject t Where BG=2)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG2_Net_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #TotalProject t Where BG=2)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG2_Net_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #TotalProject t Where BG=2)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG2_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #TotalProject t Where BG=2)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG2_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #TotalProject t Where BG=2)AS money), 1))

Set @Mail=Replace(@Mail,'@TotalProject_BG3_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 BookOff_Unit From #TotalProject t Where BG=3)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG3_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #TotalProject t Where BG=3)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG3_Cancel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #TotalProject t Where BG=3)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG3_Cancel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #TotalProject t Where BG=3)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG3_Net_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #TotalProject t Where BG=3)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG3_Net_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #TotalProject t Where BG=3)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG3_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #TotalProject t Where BG=3)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG3_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #TotalProject t Where BG=3)AS money), 1))

Set @Mail=Replace(@Mail,'@TotalProject_BG4_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 BookOff_Unit From #TotalProject t Where BG=4)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG4_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #TotalProject t Where BG=4)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG4_Cancel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #TotalProject t Where BG=4)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG4_Cancel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #TotalProject t Where BG=4)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG4_Net_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #TotalProject t Where BG=4)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG4_Net_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #TotalProject t Where BG=4)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG4_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #TotalProject t Where BG=4)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_BG4_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #TotalProject t Where BG=4)AS money), 1))

Set @Mail=Replace(@Mail,'@TotalProject_Total_Booking_Unit',CONVERT(varchar, CAST(((Select Top 1 BookOff_Unit From #TotalProject t Where BG=1) + (Select Top 1 BookOff_Unit From #TotalProject t Where BG=2) + (Select Top 1 BookOff_Unit From #TotalProject t Where BG=3)+ (select Top 1 BookOff_Unit From #TotalProject t Where BG=4) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_Total_Booking_Amt',CONVERT(varchar, CAST(((Select Top 1 BookOff_Value From #TotalProject t Where BG=1) + (Select Top 1 BookOff_Value From #TotalProject t Where BG=2) + (Select Top 1 BookOff_Value From #TotalProject t Where BG=3)+ (select Top 1 BookOff_Value From #TotalProject t Where BG=4) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_Total_Cancel_Unit',CONVERT(varchar, CAST(((Select Top 1 Cancel_Unit From #TotalProject t Where BG=1) + (Select Top 1 Cancel_Unit From #TotalProject t Where BG=2) + (Select Top 1 Cancel_Unit From #TotalProject t Where BG=3)+ (select Top 1 Cancel_Unit From #TotalProject t Where BG=4) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_Total_Cancel_Amt',CONVERT(varchar, CAST(((Select Top 1 Cancel_Value From #TotalProject t Where BG=1) + (Select Top 1 Cancel_Value From #TotalProject t Where BG=2) + (Select Top 1 Cancel_Value From #TotalProject t Where BG=3)+ (select Top 1 Cancel_Value From #TotalProject t Where BG=4) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_Total_Net_Unit',CONVERT(varchar, CAST(((Select Top 1 Net_Unit From #TotalProject t Where BG=1) + (Select Top 1 Net_Unit From #TotalProject t Where BG=2) + (Select Top 1 Net_Unit From #TotalProject t Where BG=3)+ (select Top 1 Net_Unit From #TotalProject t Where BG=4) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_Total_Net_Amt',CONVERT(varchar, CAST(((Select Top 1 Net_Value From #TotalProject t Where BG=1) + (Select Top 1 Net_Value From #TotalProject t Where BG=2) + (Select Top 1 Net_Value From #TotalProject t Where BG=3)+ (select Top 1 Net_Value From #TotalProject t Where BG=4) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_Total_Transfer_Unit',CONVERT(varchar, CAST(((Select Top 1 Transfer_Unit From #TotalProject t Where BG=1) + (Select Top 1 Transfer_Unit From #TotalProject t Where BG=2) + (Select Top 1 Transfer_Unit From #TotalProject t Where BG=3)+ (select Top 1 Transfer_Unit From #TotalProject t Where BG=4) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_Total_Transfer_Amt',CONVERT(varchar, CAST(((Select Top 1 Transfer_Value From #TotalProject t Where BG=1) + (Select Top 1 Transfer_Value From #TotalProject t Where BG=2) + (Select Top 1 Transfer_Value From #TotalProject t Where BG=3)+ (select Top 1 Transfer_Value From #TotalProject t Where BG=4) )AS money), 1))

-------------------------------------------------#TotalProject_JV------------------------------------------------------------------
Set @Mail=Replace(@Mail,'@TotalProject_JV_BG3_Booking_Unit',CONVERT(varchar, ISNULL(CAST((Select Top 1 BookOff_Unit From #TotalProject_JV t Where BG=3)AS money),0), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_BG3_Booking_Amt',CONVERT(varchar, ISNULL(CAST((Select Top 1 BookOff_Value From #TotalProject_JV t Where BG=3)AS money),0), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_BG3_Cancel_Unit',CONVERT(varchar, ISNULL(CAST((Select Top 1 Cancel_Unit From #TotalProject_JV t Where BG=3)AS money),0), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_BG3_Cancel_Amt',CONVERT(varchar, ISNULL(CAST((Select Top 1 Cancel_Value From #TotalProject_JV t Where BG=3)AS money),0), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_BG3_Net_Unit',CONVERT(varchar, ISNULL(CAST((Select Top 1 Net_Unit From #TotalProject_JV t Where BG=3)AS money),0), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_BG3_Net_Amt',CONVERT(varchar, ISNULL(CAST((Select Top 1 Net_Value From #TotalProject_JV t Where BG=3)AS money),0), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_BG3_Transfer_Unit',CONVERT(varchar, ISNULL(CAST((Select Top 1 Transfer_Unit From #TotalProject_JV t Where BG=3)AS money),0), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_BG3_Transfer_Amt',CONVERT(varchar, ISNULL(CAST((Select Top 1 Transfer_Value From #TotalProject_JV t Where BG=3)AS money),0), 1))

Set @Mail=Replace(@Mail,'@TotalProject_JV_BG4_Booking_Unit',CONVERT(varchar, ISNULL(CAST((Select Top 1 BookOff_Unit From #TotalProject_JV t Where BG=4)AS money),0), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_BG4_Booking_Amt',CONVERT(varchar, ISNULL(CAST((Select Top 1 BookOff_Value From #TotalProject_JV t Where BG=4)AS money),0), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_BG4_Cancel_Unit',CONVERT(varchar, ISNULL(CAST((Select Top 1 Cancel_Unit From #TotalProject_JV t Where BG=4)AS money),0), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_BG4_Cancel_Amt',CONVERT(varchar, ISNULL(CAST((Select Top 1 Cancel_Value From #TotalProject_JV t Where BG=4)AS money),0), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_BG4_Net_Unit',CONVERT(varchar, ISNULL(CAST((Select Top 1 Net_Unit From #TotalProject_JV t Where BG=4)AS money),0), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_BG4_Net_Amt',CONVERT(varchar, ISNULL(CAST((Select Top 1 Net_Value From #TotalProject_JV t Where BG=4)AS money),0), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_BG4_Transfer_Unit',CONVERT(varchar, ISNULL(CAST((Select Top 1 Transfer_Unit From #TotalProject_JV t Where BG=4)AS money),0), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_BG4_Transfer_Amt',CONVERT(varchar, ISNULL(CAST((Select Top 1 Transfer_Value From #TotalProject_JV t Where BG=4)AS money),0), 1))

Set @Mail=Replace(@Mail,'@TotalProject_JV_Total_Booking_Unit',CONVERT(varchar, CAST((ISNULL((Select Top 1 BookOff_Unit From #TotalProject_JV t Where BG=1),0) + ISNULL((Select Top 1 BookOff_Unit From #TotalProject_JV t Where BG=2),0) + ISNULL((Select Top 1 BookOff_Unit From #TotalProject_JV t Where BG=3),0)+ ISNULL((select Top 1 BookOff_Unit From #TotalProject_JV t Where BG=4),0) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_Total_Booking_Amt',CONVERT(varchar, CAST((ISNULL((Select Top 1 BookOff_Value From #TotalProject_JV t Where BG=1),0) + ISNULL((Select Top 1 BookOff_Value From #TotalProject_JV t Where BG=2),0) + ISNULL((Select Top 1 BookOff_Value From #TotalProject_JV t Where BG=3),0)+ ISNULL((select Top 1 BookOff_Value From #TotalProject_JV t Where BG=4),0) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_Total_Cancel_Unit',CONVERT(varchar, CAST((ISNULL((Select Top 1 Cancel_Unit From #TotalProject_JV t Where BG=1),0) + ISNULL((Select Top 1 Cancel_Unit From #TotalProject_JV t Where BG=2),0) + ISNULL((Select Top 1 Cancel_Unit From #TotalProject_JV t Where BG=3),0)+ ISNULL((select Top 1 Cancel_Unit From #TotalProject_JV t Where BG=4),0) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_Total_Cancel_Amt',CONVERT(varchar, CAST((ISNULL((Select Top 1 Cancel_Value From #TotalProject_JV t Where BG=1),0) + ISNULL((Select Top 1 Cancel_Value From #TotalProject_JV t Where BG=2),0) + ISNULL((Select Top 1 Cancel_Value From #TotalProject_JV t Where BG=3),0)+ ISNULL((select Top 1 Cancel_Value From #TotalProject_JV t Where BG=4),0) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_Total_Net_Unit',CONVERT(varchar, CAST((ISNULL((Select Top 1 Net_Unit From #TotalProject_JV t Where BG=1),0) + ISNULL((Select Top 1 Net_Unit From #TotalProject_JV t Where BG=2),0) + ISNULL((Select Top 1 Net_Unit From #TotalProject_JV t Where BG=3),0)+ ISNULL((select Top 1 Net_Unit From #TotalProject_JV t Where BG=4),0) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_Total_Net_Amt',CONVERT(varchar, CAST((ISNULL((Select Top 1 Net_Value From #TotalProject_JV t Where BG=1),0) + ISNULL((Select Top 1 Net_Value From #TotalProject_JV t Where BG=2),0) + ISNULL((Select Top 1 Net_Value From #TotalProject_JV t Where BG=3),0)+ ISNULL((select Top 1 Net_Value From #TotalProject_JV t Where BG=4),0) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_Total_Transfer_Unit',CONVERT(varchar, CAST((ISNULL((Select Top 1 Transfer_Unit From #TotalProject_JV t Where BG=1),0) + ISNULL((Select Top 1 Transfer_Unit From #TotalProject_JV t Where BG=2),0) + ISNULL((Select Top 1 Transfer_Unit From #TotalProject_JV t Where BG=3),0)+ ISNULL((select Top 1 Transfer_Unit From #TotalProject_JV t Where BG=4),0) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_JV_Total_Transfer_Amt',CONVERT(varchar, CAST((ISNULL((Select Top 1 Transfer_Value From #TotalProject_JV t Where BG=1),0) + ISNULL((Select Top 1 Transfer_Value From #TotalProject_JV t Where BG=2),0) + ISNULL((Select Top 1 Transfer_Value From #TotalProject_JV t Where BG=3),0)+ ISNULL((select Top 1 Transfer_Value From #TotalProject_JV t Where BG=4),0) )AS money), 1))

-------------------------------------------------#TotalProject_AP------------------------------------------------------------------
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG1_Booking_Unit',CONVERT(varchar, CAST(ISNULL((Select Top 1 BookOff_Unit From #TotalProject t Where BG=1),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG1_Booking_Amt',CONVERT(varchar, CAST(ISNULL((Select Top 1 BookOff_Value From #TotalProject t Where BG=1),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG1_Cancel_Unit',CONVERT(varchar, CAST(ISNULL((Select Top 1 Cancel_Unit From #TotalProject t Where BG=1),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG1_Cancel_Amt',CONVERT(varchar, CAST(ISNULL((Select Top 1 Cancel_Value From #TotalProject t Where BG=1),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG1_Net_Unit',CONVERT(varchar, CAST(ISNULL((Select Top 1 Net_Unit From #TotalProject t Where BG=1),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG1_Net_Amt',CONVERT(varchar, CAST(ISNULL((Select Top 1 Net_Value From #TotalProject t Where BG=1),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG1_Transfer_Unit',CONVERT(varchar, CAST(ISNULL((Select Top 1 Transfer_Unit From #TotalProject t Where BG=1),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG1_Transfer_Amt',CONVERT(varchar, CAST(ISNULL((Select Top 1 Transfer_Value From #TotalProject t Where BG=1),0)AS money), 1))

Set @Mail=Replace(@Mail,'@TotalProject_AP_BG2_Booking_Unit',CONVERT(varchar, CAST(ISNULL((Select Top 1 BookOff_Unit From #TotalProject t Where BG=2),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG2_Booking_Amt',CONVERT(varchar, CAST(ISNULL((Select Top 1 BookOff_Value From #TotalProject t Where BG=2),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG2_Cancel_Unit',CONVERT(varchar, CAST(ISNULL((Select Top 1 Cancel_Unit From #TotalProject t Where BG=2),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG2_Cancel_Amt',CONVERT(varchar, CAST(ISNULL((Select Top 1 Cancel_Value From #TotalProject t Where BG=2),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG2_Net_Unit',CONVERT(varchar, CAST(ISNULL((Select Top 1 Net_Unit From #TotalProject t Where BG=2),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG2_Net_Amt',CONVERT(varchar, CAST(ISNULL((Select Top 1 Net_Value From #TotalProject t Where BG=2),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG2_Transfer_Unit',CONVERT(varchar, CAST(ISNULL((Select Top 1 Transfer_Unit From #TotalProject t Where BG=2),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG2_Transfer_Amt',CONVERT(varchar, CAST(ISNULL((Select Top 1 Transfer_Value From #TotalProject t Where BG=2),0)AS money), 1))

Set @Mail=Replace(@Mail,'@TotalProject_AP_BG3_Booking_Unit',CONVERT(varchar, CAST(ISNULL((Select Top 1 BookOff_Unit From #TotalProject t Where BG=3),0)-ISNULL((Select Top 1 BookOff_Unit From #TotalProject_JV t Where BG=3),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG3_Booking_Amt',CONVERT(varchar, CAST(ISNULL((Select Top 1 BookOff_Value From #TotalProject t Where BG=3),0)-ISNULL((Select Top 1 BookOff_Value From #TotalProject_JV t Where BG=3),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG3_Cancel_Unit',CONVERT(varchar, CAST(ISNULL((Select Top 1 Cancel_Unit From #TotalProject t Where BG=3),0)-ISNULL((Select Top 1 Cancel_Unit From #TotalProject_JV t Where BG=3),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG3_Cancel_Amt',CONVERT(varchar, CAST(ISNULL((Select Top 1 Cancel_Value From #TotalProject t Where BG=3),0)-ISNULL((Select Top 1 Cancel_Value From #TotalProject_JV t Where BG=3),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG3_Net_Unit',CONVERT(varchar, CAST(ISNULL((Select Top 1 Net_Unit From #TotalProject t Where BG=3),0)-ISNULL((Select Top 1 Net_Unit From #TotalProject_JV t Where BG=3),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG3_Net_Amt',CONVERT(varchar, CAST(ISNULL((Select Top 1 Net_Value From #TotalProject t Where BG=3),0)-ISNULL((Select Top 1 Net_Value From #TotalProject_JV t Where BG=3),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG3_Transfer_Unit',CONVERT(varchar, CAST(ISNULL((Select Top 1 Transfer_Unit From #TotalProject t Where BG=3),0)-ISNULL((Select Top 1 Transfer_Unit From #TotalProject_JV t Where BG=3),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG3_Transfer_Amt',CONVERT(varchar, CAST(ISNULL((Select Top 1 Transfer_Value From #TotalProject t Where BG=3),0)-ISNULL((Select Top 1 Transfer_Value From #TotalProject_JV t Where BG=3),0)AS money), 1))

Set @Mail=Replace(@Mail,'@TotalProject_AP_BG4_Booking_Unit',CONVERT(varchar, CAST(ISNULL((Select Top 1 BookOff_Unit From #TotalProject t Where BG=4),0)-ISNULL((Select Top 1 BookOff_Unit From #TotalProject_JV t Where BG=4),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG4_Booking_Amt',CONVERT(varchar, CAST(ISNULL((Select Top 1 BookOff_Value From #TotalProject t Where BG=4),0)-ISNULL((Select Top 1 BookOff_Value From #TotalProject_JV t Where BG=4),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG4_Cancel_Unit',CONVERT(varchar, CAST(ISNULL((Select Top 1 Cancel_Unit From #TotalProject t Where BG=4),0)-ISNULL((Select Top 1 Cancel_Unit From #TotalProject_JV t Where BG=4),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG4_Cancel_Amt',CONVERT(varchar, CAST(ISNULL((Select Top 1 Cancel_Value From #TotalProject t Where BG=4),0)-ISNULL((Select Top 1 Cancel_Value From #TotalProject_JV t Where BG=4),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG4_Net_Unit',CONVERT(varchar, CAST(ISNULL((Select Top 1 Net_Unit From #TotalProject t Where BG=4),0)-ISNULL((Select Top 1 Net_Unit From #TotalProject_JV t Where BG=4),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG4_Net_Amt',CONVERT(varchar, CAST(ISNULL((Select Top 1 Net_Value From #TotalProject t Where BG=4),0)-ISNULL((Select Top 1 Net_Value From #TotalProject_JV t Where BG=4),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG4_Transfer_Unit',CONVERT(varchar, CAST(ISNULL((Select Top 1 Transfer_Unit From #TotalProject t Where BG=4),0)-ISNULL((Select Top 1 Transfer_Unit From #TotalProject_JV t Where BG=4),0)AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_BG4_Transfer_Amt',CONVERT(varchar, CAST(ISNULL((Select Top 1 Transfer_Value From #TotalProject t Where BG=4),0)-ISNULL((Select Top 1 Transfer_Value From #TotalProject_JV t Where BG=4),0)AS money), 1))

Set @Mail=Replace(@Mail,'@TotalProject_AP_Total_Booking_Unit',CONVERT(varchar, CAST((ISNULL((Select Top 1 BookOff_Unit From #TotalProject t Where BG=1),0) + ISNULL((Select Top 1 BookOff_Unit From #TotalProject t Where BG=2),0) + ISNULL((Select Top 1 BookOff_Unit From #TotalProject t Where BG=3),0)+ ISNULL((select Top 1 BookOff_Unit From #TotalProject t Where BG=4),0)-ISNULL((select Top 1 BookOff_Unit From #TotalProject_JV t Where BG=3),0)-ISNULL((select Top 1 BookOff_Unit From #TotalProject_JV t Where BG=4),0) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_Total_Booking_Amt',CONVERT(varchar, CAST((ISNULL((Select Top 1 BookOff_Value From #TotalProject t Where BG=1),0) + ISNULL((Select Top 1 BookOff_Value From #TotalProject t Where BG=2),0) + ISNULL((Select Top 1 BookOff_Value From #TotalProject t Where BG=3),0)+ ISNULL((select Top 1 BookOff_Value From #TotalProject t Where BG=4),0)-ISNULL((select Top 1 BookOff_Value From #TotalProject_JV t Where BG=3),0)-ISNULL((select Top 1 BookOff_Value From #TotalProject_JV t Where BG=4),0) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_Total_Cancel_Unit',CONVERT(varchar, CAST((ISNULL((Select Top 1 Cancel_Unit From #TotalProject t Where BG=1),0) + ISNULL((Select Top 1 Cancel_Unit From #TotalProject t Where BG=2),0) + ISNULL((Select Top 1 Cancel_Unit From #TotalProject t Where BG=3),0)+ ISNULL((select Top 1 Cancel_Unit From #TotalProject t Where BG=4),0)-ISNULL((select Top 1 Cancel_Unit From #TotalProject_JV t Where BG=3),0)-ISNULL((select Top 1 Cancel_Unit From #TotalProject_JV t Where BG=4),0) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_Total_Cancel_Amt',CONVERT(varchar, CAST((ISNULL((Select Top 1 Cancel_Value From #TotalProject t Where BG=1),0) + ISNULL((Select Top 1 Cancel_Value From #TotalProject t Where BG=2),0) + ISNULL((Select Top 1 Cancel_Value From #TotalProject t Where BG=3),0)+ ISNULL((select Top 1 Cancel_Value From #TotalProject t Where BG=4),0)-ISNULL((select Top 1 Cancel_Value From #TotalProject_JV t Where BG=3),0)-ISNULL((select Top 1 Cancel_Value From #TotalProject_JV t Where BG=4),0) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_Total_Net_Unit',CONVERT(varchar, CAST((ISNULL((Select Top 1 Net_Unit From #TotalProject t Where BG=1),0) + ISNULL((Select Top 1 Net_Unit From #TotalProject t Where BG=2),0) + ISNULL((Select Top 1 Net_Unit From #TotalProject t Where BG=3),0)+ ISNULL((select Top 1 Net_Unit From #TotalProject t Where BG=4),0)-ISNULL((select Top 1 Net_Unit From #TotalProject_JV t Where BG=3),0)-ISNULL((select Top 1 Net_Unit From #TotalProject_JV t Where BG=4),0) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_Total_Net_Amt',CONVERT(varchar, CAST((ISNULL((Select Top 1 Net_Value From #TotalProject t Where BG=1),0) + ISNULL((Select Top 1 Net_Value From #TotalProject t Where BG=2),0) + ISNULL((Select Top 1 Net_Value From #TotalProject t Where BG=3),0)+ ISNULL((select Top 1 Net_Value From #TotalProject t Where BG=4),0)-ISNULL((select Top 1 Net_Value From #TotalProject_JV t Where BG=3),0)-ISNULL((select Top 1 Net_Value From #TotalProject_JV t Where BG=4),0) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_Total_Transfer_Unit',CONVERT(varchar, CAST((ISNULL((Select Top 1 Transfer_Unit From #TotalProject t Where BG=1),0) + ISNULL((Select Top 1 Transfer_Unit From #TotalProject t Where BG=2),0) + ISNULL((Select Top 1 Transfer_Unit From #TotalProject t Where BG=3),0)+ ISNULL((select Top 1 Transfer_Unit From #TotalProject t Where BG=4),0)-ISNULL((select Top 1 Transfer_Unit From #TotalProject_JV t Where BG=3),0)-ISNULL((select Top 1 Transfer_Unit From #TotalProject_JV t Where BG=4),0) )AS money), 1))
Set @Mail=Replace(@Mail,'@TotalProject_AP_Total_Transfer_Amt',CONVERT(varchar, CAST((ISNULL((Select Top 1 Transfer_Value From #TotalProject t Where BG=1),0) + ISNULL((Select Top 1 Transfer_Value From #TotalProject t Where BG=2),0) + ISNULL((Select Top 1 Transfer_Value From #TotalProject t Where BG=3),0)+ ISNULL((select Top 1 Transfer_Value From #TotalProject t Where BG=4),0)-ISNULL((select Top 1 Transfer_Value From #TotalProject_JV t Where BG=3),0)-ISNULL((select Top 1 Transfer_Value From #TotalProject_JV t Where BG=4),0) )AS money), 1))


-----------------------------------------------------------------------#ExistingProject----------------------------------------------------------------------------------
Set @Mail=Replace(@Mail,'@ExistingProject_BG1_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 BookOff_Unit From #ExistingProject t Where BG=1)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG1_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #ExistingProject t Where BG=1)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG1_Cancel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #ExistingProject t Where BG=1)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG1_Cancel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #ExistingProject t Where BG=1)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG1_Net_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #ExistingProject t Where BG=1)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG1_Net_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #ExistingProject t Where BG=1)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG1_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #ExistingProject t Where BG=1)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG1_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #ExistingProject t Where BG=1)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG1_Offline_Unit',CONVERT(varchar, CAST((Select Top 1 Off_Unit From #ExistingProject t Where BG=1)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG1_Offline_Amt',CONVERT(varchar, CAST((Select Top 1 Off_Value From #ExistingProject t Where BG=1)AS money), 1))

Set @Mail=Replace(@Mail,'@ExistingProject_BG2_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 BookOff_Unit From #ExistingProject t Where BG=2)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG2_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #ExistingProject t Where BG=2)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG2_Cancel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #ExistingProject t Where BG=2)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG2_Cancel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #ExistingProject t Where BG=2)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG2_Net_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #ExistingProject t Where BG=2)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG2_Net_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #ExistingProject t Where BG=2)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG2_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #ExistingProject t Where BG=2)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG2_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #ExistingProject t Where BG=2)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG2_Offline_Unit',CONVERT(varchar, CAST((Select Top 1 Off_Unit From #ExistingProject t Where BG=2)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG2_Offline_Amt',CONVERT(varchar, CAST((Select Top 1 Off_Value From #ExistingProject t Where BG=2)AS money), 1))

Set @Mail=Replace(@Mail,'@ExistingProject_BG3_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 BookOff_Unit From #ExistingProject t Where BG=3)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG3_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #ExistingProject t Where BG=3)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG3_Cancel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #ExistingProject t Where BG=3)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG3_Cancel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #ExistingProject t Where BG=3)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG3_Net_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #ExistingProject t Where BG=3)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG3_Net_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #ExistingProject t Where BG=3)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG3_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #ExistingProject t Where BG=3)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG3_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #ExistingProject t Where BG=3)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG3_Offline_Unit',CONVERT(varchar, CAST((Select Top 1 Off_Unit From #ExistingProject t Where BG=3)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG3_Offline_Amt',CONVERT(varchar, CAST((Select Top 1 Off_Value From #ExistingProject t Where BG=3)AS money), 1))

Set @Mail=Replace(@Mail,'@ExistingProject_BG4_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 BookOff_Unit From #ExistingProject t Where BG=4)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG4_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #ExistingProject t Where BG=4)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG4_Cancel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #ExistingProject t Where BG=4)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG4_Cancel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #ExistingProject t Where BG=4)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG4_Net_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #ExistingProject t Where BG=4)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG4_Net_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #ExistingProject t Where BG=4)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG4_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #ExistingProject t Where BG=4)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG4_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #ExistingProject t Where BG=4)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG4_Offline_Unit',CONVERT(varchar, CAST((Select Top 1 Off_Unit From #ExistingProject t Where BG=4)AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_BG4_Offline_Amt',CONVERT(varchar, CAST((Select Top 1 Off_Value From #ExistingProject t Where BG=4)AS money), 1))

Set @Mail=Replace(@Mail,'@ExistingProject_Total_Booking_Unit',CONVERT(varchar, CAST(((Select Top 1 BookOff_Unit From #ExistingProject t Where BG=1) + (Select Top 1 BookOff_Unit From #ExistingProject t Where BG=2) + (Select Top 1 BookOff_Unit From #ExistingProject t Where BG=3)+ (select Top 1 BookOff_Unit From #ExistingProject t Where BG=4) )AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_Total_Booking_Amt',CONVERT(varchar, CAST(((Select Top 1 BookOff_Value From #ExistingProject t Where BG=1) + (Select Top 1 BookOff_Value From #ExistingProject t Where BG=2) + (Select Top 1 BookOff_Value From #ExistingProject t Where BG=3)+ (select Top 1 BookOff_Value From #ExistingProject t Where BG=4) )AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_Total_Cancel_Unit',CONVERT(varchar, CAST(((Select Top 1 Cancel_Unit From #ExistingProject t Where BG=1) + (Select Top 1 Cancel_Unit From #ExistingProject t Where BG=2) + (Select Top 1 Cancel_Unit From #ExistingProject t Where BG=3)+ (select Top 1 Cancel_Unit From #ExistingProject t Where BG=4) )AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_Total_Cancel_Amt',CONVERT(varchar, CAST(((Select Top 1 Cancel_Value From #ExistingProject t Where BG=1) + (Select Top 1 Cancel_Value From #ExistingProject t Where BG=2) + (Select Top 1 Cancel_Value From #ExistingProject t Where BG=3)+ (select Top 1 Cancel_Value From #ExistingProject t Where BG=4) )AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_Total_Net_Unit',CONVERT(varchar, CAST(((Select Top 1 Net_Unit From #ExistingProject t Where BG=1) + (Select Top 1 Net_Unit From #ExistingProject t Where BG=2) + (Select Top 1 Net_Unit From #ExistingProject t Where BG=3)+ (select Top 1 Net_Unit From #ExistingProject t Where BG=4) )AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_Total_Net_Amt',CONVERT(varchar, CAST(((Select Top 1 Net_Value From #ExistingProject t Where BG=1) + (Select Top 1 Net_Value From #ExistingProject t Where BG=2) + (Select Top 1 Net_Value From #ExistingProject t Where BG=3)+ (select Top 1 Net_Value From #ExistingProject t Where BG=4) )AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_Total_Transfer_Unit',CONVERT(varchar, CAST(((Select Top 1 Transfer_Unit From #ExistingProject t Where BG=1) + (Select Top 1 Transfer_Unit From #ExistingProject t Where BG=2) + (Select Top 1 Transfer_Unit From #ExistingProject t Where BG=3)+ (select Top 1 Transfer_Unit From #ExistingProject t Where BG=4) )AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_Total_Transfer_Amt',CONVERT(varchar, CAST(((Select Top 1 Transfer_Value From #ExistingProject t Where BG=1) + (Select Top 1 Transfer_Value From #ExistingProject t Where BG=2) + (Select Top 1 Transfer_Value From #ExistingProject t Where BG=3)+ (select Top 1 Transfer_Value From #ExistingProject t Where BG=4) )AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_Total_Offline_Unit',CONVERT(varchar, CAST(((Select Top 1 Off_Unit From #ExistingProject t Where BG=1) + (Select Top 1 Off_Unit From #ExistingProject t Where BG=2) + (Select Top 1 Off_Unit From #ExistingProject t Where BG=3)+ (select Top 1 Off_Unit From #ExistingProject t Where BG=4) )AS money), 1))
Set @Mail=Replace(@Mail,'@ExistingProject_Total_Offline_Amt',CONVERT(varchar, CAST(((Select Top 1 Off_Value From #ExistingProject t Where BG=1) + (Select Top 1 Off_Value From #ExistingProject t Where BG=2) + (Select Top 1 Off_Value From #ExistingProject t Where BG=3)+ (select Top 1 Off_Value From #ExistingProject t Where BG=4) )AS money), 1))

------------------------------------------ New Project Performance---------------------------------------------------
-- #NewProjectPerformance
DECLARE @BG Int,@ProductID NVarchar(50),@Html NVarchar(Max)
Set @BG=1 Set @Html=''  
While(@BG<=4)
Begin
	Set @Html=''
	DECLARE my_cursor CURSOR FOR  
	Select Distinct ProductID 
	from #NewProjectPerformance
	Where  BG=@BG
	Order by ProductID  
  
	OPEN my_cursor;    
	FETCH NEXT FROM my_cursor  
	INTO @ProductID;  
  
	WHILE @@FETCH_STATUS = 0  
	BEGIN  	
		Select @Html=@Html+Char(13)+'<tr>'+Char(13)
			+'<td style="text-align: left;width:500px;">'+(Select t.ProductID+' - '+t.Project From #NewProjectPerformance t Where t.ProductID=@ProductID)+'</td>'
			+'<td>'+(Select CONVERT(Varchar,CAST(t.BookOff_Unit As money), 1) From #NewProjectPerformance t Where t.ProductID=@ProductID)+'</td>'
			+'<td>'+(Select CONVERT(Varchar, CAST(t.BookOff_Value As money), 1) From #NewProjectPerformance t Where t.ProductID=@ProductID)+'</td>'
			+'<td>'+(Select CONVERT(Varchar, CAST(t.Cancel_Unit As money), 1) From #NewProjectPerformance t Where t.ProductID=@ProductID)+'</td>'
			+'<td>'+(Select CONVERT(Varchar, CAST(t.Cancel_Value As money), 1) From #NewProjectPerformance t Where t.ProductID=@ProductID)+'</td>'
			+'<td>'+(Select CONVERT(Varchar, CAST(t.Net_Unit As money), 1) From #NewProjectPerformance t Where t.ProductID=@ProductID)+'</td>'
			+'<td>'+(Select CONVERT(Varchar, CAST(t.Net_Value As money), 1) From #NewProjectPerformance t Where t.ProductID=@ProductID)+'</td>'
			+'<td>'+(Select CONVERT(Varchar, CAST(t.Transfer_Unit As money), 1) From #NewProjectPerformance t Where t.ProductID=@ProductID)+'</td>'
			+'<td>'+(Select CONVERT(Varchar, CAST(t.Transfer_Value As money), 1) From #NewProjectPerformance t Where t.ProductID=@ProductID)+'</td>'
			+'<td>'+(Select CONVERT(Varchar, CAST(t.BookAccum_Unit As money), 1) From #NewProjectPerformance t Where t.ProductID=@ProductID)+'</td>'
			+'<td>'+(Select CONVERT(varchar, CAST(t.BookAccum_Value As money), 1) From #NewProjectPerformance t Where t.ProductID=@ProductID)+'</td>'
			+'<td>'+(Select CONVERT(varchar, CAST(t.TransAccum_Unit As money), 1) From #NewProjectPerformance t Where t.ProductID=@ProductID)+'</td>'
			+'<td>'+(Select CONVERT(Varchar, CAST(t.TransAccum_Value As money), 1) From #NewProjectPerformance t Where t.ProductID=@ProductID)+'</td>'
		+Char(13)+'</tr>'
		Fetch NEXT FROM my_cursor  Into @ProductID;  
	END  
	CLOSE my_cursor;  
	DEALLOCATE my_cursor;

	

	Set @Mail=Replace(@Mail,'<!--@NewProject_BG'+Convert(NVarchar(5),@BG)+'-->',@Html)
	Set @Mail=Replace(@Mail,'@NewProject_BG'+Convert(NVarchar(5),@BG)+'_Booking_Unit',CONVERT(varchar, CAST(IsNull((Select Sum(t.BookOff_Unit) From #NewProjectPerformance t Where t.BG=@BG),0)AS money), 1))
	Set @Mail=Replace(@Mail,'@NewProject_BG'+Convert(NVarchar(5),@BG)+'_Booking_Amt',CONVERT(varchar, CAST(IsNull((Select Sum(t.BookOff_Value) From #NewProjectPerformance t Where t.BG=@BG),0)AS money), 1))
	Set @Mail=Replace(@Mail,'@NewProject_BG'+Convert(NVarchar(5),@BG)+'_Cancel_Unit',CONVERT(varchar, CAST(IsNull((Select Sum(t.Cancel_Unit) From #NewProjectPerformance t Where t.BG=@BG),0)AS money), 1))
	Set @Mail=Replace(@Mail,'@NewProject_BG'+Convert(NVarchar(5),@BG)+'_Cancel_Amt',CONVERT(varchar, CAST(IsNull((Select Sum(t.Cancel_Value) From #NewProjectPerformance t Where t.BG=@BG),0)AS money), 1))
	Set @Mail=Replace(@Mail,'@NewProject_BG'+Convert(NVarchar(5),@BG)+'_Net_Unit',CONVERT(varchar, CAST(IsNull((Select Sum(t.Net_Unit) From #NewProjectPerformance t Where t.BG=@BG),0)AS money), 1))
	Set @Mail=Replace(@Mail,'@NewProject_BG'+Convert(NVarchar(5),@BG)+'_Net_Amt',CONVERT(varchar, CAST(IsNull((Select Sum(t.Net_Value) From #NewProjectPerformance t Where t.BG=@BG),0)AS money), 1))
	Set @Mail=Replace(@Mail,'@NewProject_BG'+Convert(NVarchar(5),@BG)+'_Transfer_Unit',CONVERT(varchar, CAST(IsNull((Select Sum(t.Transfer_Unit) From #NewProjectPerformance t Where t.BG=@BG),0)AS money), 1))
	Set @Mail=Replace(@Mail,'@NewProject_BG'+Convert(NVarchar(5),@BG)+'_Transfer_Amt',CONVERT(varchar, CAST(IsNull((Select Sum(t.Transfer_Value) From #NewProjectPerformance t Where t.BG=@BG),0)AS money), 1))
	Set @Mail=Replace(@Mail,'@NewProject_BG'+Convert(NVarchar(5),@BG)+'_BookingAccum_Unit',CONVERT(varchar, CAST(IsNull((Select Sum(t.BookAccum_Unit) From #NewProjectPerformance t Where t.BG=@BG),0)AS money), 1))
	Set @Mail=Replace(@Mail,'@NewProject_BG'+Convert(NVarchar(5),@BG)+'_BookingAccum_Amt',CONVERT(varchar, CAST(IsNull((Select Sum(t.BookAccum_Value) From #NewProjectPerformance t Where t.BG=@BG),0)AS money), 1))
	Set @Mail=Replace(@Mail,'@NewProject_BG'+Convert(NVarchar(5),@BG)+'_TransferAccum_Unit',CONVERT(varchar, CAST(IsNull((Select Sum(t.TransAccum_Unit) From #NewProjectPerformance t Where t.BG=@BG),0)AS money), 1))
	Set @Mail=Replace(@Mail,'@NewProject_BG'+Convert(NVarchar(5),@BG)+'_TransferAccum_Amt',CONVERT(varchar, CAST(IsNull((Select Sum(t.TransAccum_Value) From #NewProjectPerformance t Where t.BG=@BG),0)AS money), 1))
	--Print(@Html)
	Set @BG=@BG+1
End
  
Set @Mail=Replace(@Mail,'@NewProject_Total_Booking_Unit',CONVERT(varchar, CAST(IsNull((Select Sum(t.BookOff_Unit) From #NewProjectPerformance t ),0)AS money), 1))
Set @Mail=Replace(@Mail,'@NewProject_Total_Booking_Amt',CONVERT(varchar, CAST(IsNull((Select Sum(t.BookOff_Value) From #NewProjectPerformance t ),0)AS money), 1))
Set @Mail=Replace(@Mail,'@NewProject_Total_Cancel_Unit',CONVERT(varchar, CAST(IsNull((Select Sum(t.Cancel_Unit) From #NewProjectPerformance t ),0)AS money), 1))
Set @Mail=Replace(@Mail,'@NewProject_Total_Cancel_Amt',CONVERT(varchar, CAST(IsNull((Select Sum(t.Cancel_Value) From #NewProjectPerformance t ),0)AS money), 1))
Set @Mail=Replace(@Mail,'@NewProject_Total_Net_Unit',CONVERT(varchar, CAST(IsNull((Select Sum(t.Net_Unit) From #NewProjectPerformance t ),0)AS money), 1))
Set @Mail=Replace(@Mail,'@NewProject_Total_Net_Amt',CONVERT(varchar, CAST(IsNull((Select Sum(t.Net_Value) From #NewProjectPerformance t ),0)AS money), 1))
Set @Mail=Replace(@Mail,'@NewProject_Total_Transfer_Unit',CONVERT(varchar, CAST(IsNull((Select Sum(t.Transfer_Unit) From #NewProjectPerformance t ),0)AS money), 1))
Set @Mail=Replace(@Mail,'@NewProject_Total_Transfer_Amt',CONVERT(varchar, CAST(IsNull((Select Sum(t.Transfer_Value) From #NewProjectPerformance t ),0)AS money), 1))
Set @Mail=Replace(@Mail,'@NewProject_Total_BookingAccum_Unit',CONVERT(varchar, CAST(IsNull((Select Sum(t.BookAccum_Unit) From #NewProjectPerformance t ),0)AS money), 1))
Set @Mail=Replace(@Mail,'@NewProject_Total_BookingAccum_Amt',CONVERT(varchar, CAST(IsNull((Select Sum(t.BookAccum_Value) From #NewProjectPerformance t ),0)AS money), 1))
Set @Mail=Replace(@Mail,'@NewProject_Total_TransferAccum_Unit',CONVERT(varchar, CAST(IsNull((Select Sum(t.TransAccum_Unit) From #NewProjectPerformance t ),0)AS money), 1))
Set @Mail=Replace(@Mail,'@NewProject_Total_TransferAccum_Amt',CONVERT(varchar, CAST(IsNull((Select Sum(t.TransAccum_Value) From #NewProjectPerformance t ),0)AS money), 1))

------------------------------------------Top 3 Key Contributor--------------------------------------------------------------------
Set @Mail=Replace(@Mail,'@Contributor_BG1_1_Gross_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #GrossBooking t Where BG=1 and  seq = 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_2_Gross_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #GrossBooking t Where BG=1 and  seq = 2))
Set @Mail=Replace(@Mail,'@Contributor_BG1_3_Gross_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #GrossBooking t Where BG=1 and  seq = 3))
Set @Mail=Replace(@Mail,'@Contributor_BG1_1_Gross_Unit',CONVERT(varchar, CAST((Select Top 1 bookoff_Unit From #GrossBooking t Where BG=1 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_2_Gross_Unit',CONVERT(varchar, CAST((Select Top 1 bookoff_Unit From #GrossBooking t Where BG=1 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_3_Gross_Unit',CONVERT(varchar, CAST((Select Top 1 bookoff_Unit From #GrossBooking t Where BG=1 and  seq = 3)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_1_Gross_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #GrossBooking t Where BG=1 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_2_Gross_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #GrossBooking t Where BG=1 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_3_Gross_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #GrossBooking t Where BG=1 and  seq = 3)AS money), 1))

Set @Mail=Replace(@Mail,'@Contributor_BG1_1_Booking_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetBooking t Where BG=1 and  seq = 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_2_Booking_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetBooking t Where BG=1 and  seq = 2))
Set @Mail=Replace(@Mail,'@Contributor_BG1_3_Booking_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetBooking t Where BG=1 and  seq = 3))
Set @Mail=Replace(@Mail,'@Contributor_BG1_1_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #NetBooking t Where BG=1 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_2_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #NetBooking t Where BG=1 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_3_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #NetBooking t Where BG=1 and  seq = 3)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_1_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #NetBooking t Where BG=1 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_2_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #NetBooking t Where BG=1 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_3_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #NetBooking t Where BG=1 and  seq = 3)AS money), 1))

Set @Mail=Replace(@Mail,'@Contributor_BG1_1_Transfer_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetTransfer t Where BG=1 and  seq = 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_2_Transfer_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetTransfer t Where BG=1 and  seq = 2))
Set @Mail=Replace(@Mail,'@Contributor_BG1_3_Transfer_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetTransfer t Where BG=1 and  seq = 3))
Set @Mail=Replace(@Mail,'@Contributor_BG1_1_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #NetTransfer t Where BG=1 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_2_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #NetTransfer t Where BG=1 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_3_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #NetTransfer t Where BG=1 and  seq = 3)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_1_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #NetTransfer t Where BG=1 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_2_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #NetTransfer t Where BG=1 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_3_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #NetTransfer t Where BG=1 and  seq = 3)AS money), 1))

Set @Mail=Replace(@Mail,'@Contributor_BG1_1_Cacnel_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetCancel t Where BG=1 and  seq = 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_2_Cacnel_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetCancel t Where BG=1 and  seq = 2))
Set @Mail=Replace(@Mail,'@Contributor_BG1_3_Cacnel_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetCancel t Where BG=1 and  seq = 3))
Set @Mail=Replace(@Mail,'@Contributor_BG1_1_Cacnel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #NetCancel t Where BG=1 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_2_Cacnel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #NetCancel t Where BG=1 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_3_Cacnel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #NetCancel t Where BG=1 and  seq = 3)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_1_Cacnel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #NetCancel t Where BG=1 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_2_Cacnel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #NetCancel t Where BG=1 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG1_3_Cacnel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #NetCancel t Where BG=1 and  seq = 3)AS money), 1))

Set @Mail=Replace(@Mail,'@Contributor_BG2_1_Gross_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #GrossBooking t Where BG=2 and  seq = 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_2_Gross_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #GrossBooking t Where BG=2 and  seq = 2))
Set @Mail=Replace(@Mail,'@Contributor_BG2_3_Gross_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #GrossBooking t Where BG=2 and  seq = 3))
Set @Mail=Replace(@Mail,'@Contributor_BG2_1_Gross_Unit',CONVERT(varchar, CAST((Select Top 1 bookoff_Unit From #GrossBooking t Where BG=2 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_2_Gross_Unit',CONVERT(varchar, CAST((Select Top 1 bookoff_Unit From #GrossBooking t Where BG=2 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_3_Gross_Unit',CONVERT(varchar, CAST((Select Top 1 bookoff_Unit From #GrossBooking t Where BG=2 and  seq = 3)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_1_Gross_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #GrossBooking t Where BG=2 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_2_Gross_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #GrossBooking t Where BG=2 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_3_Gross_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #GrossBooking t Where BG=2 and  seq = 3)AS money), 1))

Set @Mail=Replace(@Mail,'@Contributor_BG2_1_Booking_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetBooking t Where BG=2 and  seq = 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_2_Booking_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetBooking t Where BG=2 and  seq = 2))
Set @Mail=Replace(@Mail,'@Contributor_BG2_3_Booking_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetBooking t Where BG=2 and  seq = 3))
Set @Mail=Replace(@Mail,'@Contributor_BG2_1_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #NetBooking t Where BG=2 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_2_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #NetBooking t Where BG=2 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_3_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #NetBooking t Where BG=2 and  seq = 3)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_1_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #NetBooking t Where BG=2 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_2_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #NetBooking t Where BG=2 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_3_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #NetBooking t Where BG=2 and  seq = 3)AS money), 1))

Set @Mail=Replace(@Mail,'@Contributor_BG2_1_Transfer_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetTransfer t Where BG=2 and  seq = 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_2_Transfer_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetTransfer t Where BG=2 and  seq = 2))
Set @Mail=Replace(@Mail,'@Contributor_BG2_3_Transfer_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetTransfer t Where BG=2 and  seq = 3))
Set @Mail=Replace(@Mail,'@Contributor_BG2_1_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #NetTransfer t Where BG=2 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_2_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #NetTransfer t Where BG=2 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_3_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #NetTransfer t Where BG=2 and  seq = 3)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_1_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #NetTransfer t Where BG=2 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_2_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #NetTransfer t Where BG=2 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_3_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #NetTransfer t Where BG=2 and  seq = 3)AS money), 1))

Set @Mail=Replace(@Mail,'@Contributor_BG2_1_Cacnel_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetCancel t Where BG=2 and  seq = 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_2_Cacnel_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetCancel t Where BG=2 and  seq = 2))
Set @Mail=Replace(@Mail,'@Contributor_BG2_3_Cacnel_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetCancel t Where BG=2 and  seq = 3))
Set @Mail=Replace(@Mail,'@Contributor_BG2_1_Cacnel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #NetCancel t Where BG=2 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_2_Cacnel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #NetCancel t Where BG=2 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_3_Cacnel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #NetCancel t Where BG=2 and  seq = 3)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_1_Cacnel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #NetCancel t Where BG=2 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_2_Cacnel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #NetCancel t Where BG=2 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG2_3_Cacnel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #NetCancel t Where BG=2 and  seq = 3)AS money), 1))

Set @Mail=Replace(@Mail,'@Contributor_BG3_1_Gross_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #GrossBooking t Where BG=3 and  seq = 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_2_Gross_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #GrossBooking t Where BG=3 and  seq = 2))
Set @Mail=Replace(@Mail,'@Contributor_BG3_3_Gross_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #GrossBooking t Where BG=3 and  seq = 3))
Set @Mail=Replace(@Mail,'@Contributor_BG3_1_Gross_Unit',CONVERT(varchar, CAST((Select Top 1 bookoff_Unit From #GrossBooking t Where BG=3 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_2_Gross_Unit',CONVERT(varchar, CAST((Select Top 1 bookoff_Unit From #GrossBooking t Where BG=3 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_3_Gross_Unit',CONVERT(varchar, CAST((Select Top 1 bookoff_Unit From #GrossBooking t Where BG=3 and  seq = 3)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_1_Gross_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #GrossBooking t Where BG=3 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_2_Gross_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #GrossBooking t Where BG=3 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_3_Gross_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #GrossBooking t Where BG=3 and  seq = 3)AS money), 1))

Set @Mail=Replace(@Mail,'@Contributor_BG3_1_Booking_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetBooking t Where BG=3 and  seq = 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_2_Booking_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetBooking t Where BG=3 and  seq = 2))
Set @Mail=Replace(@Mail,'@Contributor_BG3_3_Booking_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetBooking t Where BG=3 and  seq = 3))
Set @Mail=Replace(@Mail,'@Contributor_BG3_1_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #NetBooking t Where BG=3 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_2_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #NetBooking t Where BG=3 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_3_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #NetBooking t Where BG=3 and  seq = 3)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_1_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #NetBooking t Where BG=3 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_2_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #NetBooking t Where BG=3 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_3_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #NetBooking t Where BG=3 and  seq = 3)AS money), 1))

Set @Mail=Replace(@Mail,'@Contributor_BG3_1_Transfer_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetTransfer t Where BG=3 and  seq = 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_2_Transfer_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetTransfer t Where BG=3 and  seq = 2))
Set @Mail=Replace(@Mail,'@Contributor_BG3_3_Transfer_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetTransfer t Where BG=3 and  seq = 3))
Set @Mail=Replace(@Mail,'@Contributor_BG3_1_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #NetTransfer t Where BG=3 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_2_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #NetTransfer t Where BG=3 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_3_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #NetTransfer t Where BG=3 and  seq = 3)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_1_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #NetTransfer t Where BG=3 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_2_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #NetTransfer t Where BG=3 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_3_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #NetTransfer t Where BG=3 and  seq = 3)AS money), 1))

Set @Mail=Replace(@Mail,'@Contributor_BG3_1_Cacnel_Project',(Select Top 1 ProductID+' '+Project as project  From #NetCancel t Where BG=3 and  seq = 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_2_Cacnel_Project',(Select Top 1 ProductID+' '+Project as project  From #NetCancel t Where BG=3 and  seq = 2))
Set @Mail=Replace(@Mail,'@Contributor_BG3_3_Cacnel_Project',(Select Top 1 ProductID+' '+Project as project  From #NetCancel t Where BG=3 and  seq = 3))
Set @Mail=Replace(@Mail,'@Contributor_BG3_1_Cacnel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #NetCancel t Where BG=3 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_2_Cacnel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #NetCancel t Where BG=3 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_3_Cacnel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #NetCancel t Where BG=3 and  seq = 3)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_1_Cacnel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #NetCancel t Where BG=3 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_2_Cacnel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #NetCancel t Where BG=3 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG3_3_Cacnel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #NetCancel t Where BG=3 and  seq = 3)AS money), 1))

Set @Mail=Replace(@Mail,'@Contributor_BG4_1_Gross_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #GrossBooking t Where BG=4 and  seq = 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_2_Gross_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #GrossBooking t Where BG=4 and  seq = 2))
Set @Mail=Replace(@Mail,'@Contributor_BG4_3_Gross_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #GrossBooking t Where BG=4 and  seq = 3))
Set @Mail=Replace(@Mail,'@Contributor_BG4_1_Gross_Unit',CONVERT(varchar, CAST((Select Top 1 bookoff_Unit From #GrossBooking t Where BG=4 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_2_Gross_Unit',CONVERT(varchar, CAST((Select Top 1 bookoff_Unit From #GrossBooking t Where BG=4 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_3_Gross_Unit',CONVERT(varchar, CAST((Select Top 1 bookoff_Unit From #GrossBooking t Where BG=4 and  seq = 3)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_1_Gross_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #GrossBooking t Where BG=4 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_2_Gross_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #GrossBooking t Where BG=4 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_3_Gross_Amt',CONVERT(varchar, CAST((Select Top 1 BookOff_Value From #GrossBooking t Where BG=4 and  seq = 3)AS money), 1))

Set @Mail=Replace(@Mail,'@Contributor_BG4_1_Booking_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetBooking t Where BG=4 and  seq = 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_2_Booking_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetBooking t Where BG=4 and  seq = 2))
Set @Mail=Replace(@Mail,'@Contributor_BG4_3_Booking_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetBooking t Where BG=4 and  seq = 3))
Set @Mail=Replace(@Mail,'@Contributor_BG4_1_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #NetBooking t Where BG=4 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_2_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #NetBooking t Where BG=4 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_3_Booking_Unit',CONVERT(varchar, CAST((Select Top 1 Net_Unit From #NetBooking t Where BG=4 and  seq = 3)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_1_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #NetBooking t Where BG=4 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_2_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #NetBooking t Where BG=4 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_3_Booking_Amt',CONVERT(varchar, CAST((Select Top 1 Net_Value From #NetBooking t Where BG=4 and  seq = 3)AS money), 1))

Set @Mail=Replace(@Mail,'@Contributor_BG4_1_Transfer_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetTransfer t Where BG=4 and  seq = 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_2_Transfer_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetTransfer t Where BG=4 and  seq = 2))
Set @Mail=Replace(@Mail,'@Contributor_BG4_3_Transfer_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetTransfer t Where BG=4 and  seq = 3))
Set @Mail=Replace(@Mail,'@Contributor_BG4_1_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #NetTransfer t Where BG=4 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_2_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #NetTransfer t Where BG=4 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_3_Transfer_Unit',CONVERT(varchar, CAST((Select Top 1 Transfer_Unit From #NetTransfer t Where BG=4 and  seq = 3)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_1_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #NetTransfer t Where BG=4 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_2_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #NetTransfer t Where BG=4 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_3_Transfer_Amt',CONVERT(varchar, CAST((Select Top 1 Transfer_Value From #NetTransfer t Where BG=4 and  seq = 3)AS money), 1))

Set @Mail=Replace(@Mail,'@Contributor_BG4_1_Cacnel_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetCancel t Where BG=4 and  seq = 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_2_Cacnel_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetCancel t Where BG=4 and  seq = 2))
Set @Mail=Replace(@Mail,'@Contributor_BG4_3_Cacnel_Project',(Select Top 1 ProductID+' '+'-'+' '+Project as project  From #NetCancel t Where BG=4 and  seq = 3))
Set @Mail=Replace(@Mail,'@Contributor_BG4_1_Cacnel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #NetCancel t Where BG=4 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_2_Cacnel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #NetCancel t Where BG=4 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_3_Cacnel_Unit',CONVERT(varchar, CAST((Select Top 1 Cancel_Unit From #NetCancel t Where BG=4 and  seq = 3)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_1_Cacnel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #NetCancel t Where BG=4 and  seq = 1)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_2_Cacnel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #NetCancel t Where BG=4 and  seq = 2)AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_BG4_3_Cacnel_Amt',CONVERT(varchar, CAST((Select Top 1 Cancel_Value From #NetCancel t Where BG=4 and  seq = 3)AS money), 1))

Set @Mail=Replace(@Mail,'@Contributor_TotalTop_Gross_Unit',CONVERT(varchar, CAST((Select sum(BookOff_Unit) BookOff_Unit From #GrossBooking t  )AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_TotalTop_Gross_Amt',CONVERT(varchar, CAST((Select sum(BookOff_Value) BookOff_Value From #GrossBooking t  )AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_Total_Gross_Unit',CONVERT(varchar, CAST((Select sum(BookOff_Unit) BookOff_Unit From #TotalProject t  )AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_Total_Gross_Amt',CONVERT(varchar, CAST((Select sum(BookOff_Value) BookOff_Value From #TotalProject t  )AS money), 1))
Declare @Contributor_Total_Gross_Amt decimal(18,2)
Set @Contributor_Total_Gross_Amt=Isnull((Select sum(BookOff_Value) BookOff_Value From #TotalProject t  ),0)
if(@Contributor_Total_Gross_Amt>0)
Set @Mail=Replace(@Mail,'@Contributor_Percent_Gross_Amt',CONVERT(varchar, CAST((((Select sum(BookOff_Value) BookOff_Value From #GrossBooking t )/(Select sum(BookOff_Value) BookOff_Value From #TotalProject t))*100  )AS money), 1))
else 
Set @Mail=Replace(@Mail,'@Contributor_Percent_Gross_Amt',CONVERT(varchar, CAST(0AS money), 1))


Set @Mail=Replace(@Mail,'@Contributor_TotalTop_Booking_Unit',CONVERT(varchar, CAST((Select sum(Net_Unit) Net_Unit From #NetBooking t  )AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_TotalTop_Booking_Amt',CONVERT(varchar, CAST((Select sum(Net_Value) Net_Value From #NetBooking t  )AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_Total_Booking_Unit',CONVERT(varchar, CAST((Select sum(Net_Unit) Net_Unit From #TotalProject t  )AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_Total_Booking_Amt',CONVERT(varchar, CAST((Select sum(Net_Value) Net_Value From #TotalProject t  )AS money), 1))
Declare @Contributor_Total_Booking_Amt decimal(18,2)
Set @Contributor_Total_Booking_Amt=Isnull((Select sum(Net_Value) Net_Value From #TotalProject t  ),0)
if(@Contributor_Total_Booking_Amt>0)
Set @Mail=Replace(@Mail,'@Contributor_Percent_Booking_Amt',CONVERT(varchar, CAST((((Select sum(Net_Value) Net_Value From #NetBooking t )/(Select sum(Net_Value) Net_Value From #TotalProject t))*100  )AS money), 1))
else 
Set @Mail=Replace(@Mail,'@Contributor_Percent_Booking_Amt',CONVERT(varchar, CAST(0AS money), 1))


Set @Mail=Replace(@Mail,'@Contributor_TotalTop_Transfer_Unit',CONVERT(varchar, CAST((Select sum(Transfer_Unit) Transfer_Unit From #NetTransfer t  )AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_TotalTop_Transfer_Amt',CONVERT(varchar, CAST((Select sum(Transfer_Value) Transfer_Value From #NetTransfer t  )AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_Total_Transfer_Unit',CONVERT(varchar, CAST((Select sum(Transfer_Unit) Transfer_Unit From #TotalProject t  )AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_Total_Transfer_Amt',CONVERT(varchar, CAST((Select sum(Transfer_Value) Transfer_Value From #TotalProject t  )AS money), 1))
Declare @Contributor_Total_Transfer_Amt decimal(18,2)
Set @Contributor_Total_Transfer_Amt=Isnull((Select sum(Transfer_Value) Transfer_Value From #TotalProject t  ),0)
if(@Contributor_Total_Transfer_Amt>0)
Set @Mail=Replace(@Mail,'@Contributor_Percent_Transfer_Amt',CONVERT(varchar, CAST((((Select sum(Transfer_Value) Transfer_Value From #NetTransfer t )/(Select sum(Transfer_Value) Transfer_Value From #TotalProject t))*100  )AS money), 1))
else 
Set @Mail=Replace(@Mail,'@Contributor_Percent_Transfer_Amt',CONVERT(varchar, CAST(0AS money), 1))


Set @Mail=Replace(@Mail,'@Contributor_TotalTop_Cacnel_Unit',CONVERT(varchar, CAST((Select sum(Cancel_Unit) Cancel_Unit From #NetCancel t  )AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_TotalTop_Cacnel_Amt',CONVERT(varchar, CAST((Select sum(Cancel_Value) Cancel_Value From #NetCancel t  )AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_Total_Cacnel_Unit',CONVERT(varchar, CAST((Select sum(Cancel_Unit) Cancel_Unit From #TotalProject t  )AS money), 1))
Set @Mail=Replace(@Mail,'@Contributor_Total_Cacnel_Amt',CONVERT(varchar, CAST((Select sum(Cancel_Value) Cancel_Value From #TotalProject t  )AS money), 1))
Declare @Contributor_Total_Cacnel_Amt decimal(18,2)
Set @Contributor_Total_Cacnel_Amt=Isnull((Select sum(Cancel_Value) Cancel_Value From #TotalProject t  ),0)
if(@Contributor_Total_Cacnel_Amt>0)
Set @Mail=Replace(@Mail,'@Contributor_Percent_Cacnel_Amt',CONVERT(varchar, CAST((((Select sum(Cancel_Value) Cancel_Value From #NetCancel t )/(Select sum(Cancel_Value) Cancel_Value From #TotalProject t))*100  )AS money), 1))
else 
Set @Mail=Replace(@Mail,'@Contributor_Percent_Cacnel_Amt',CONVERT(varchar, CAST(0AS money), 1))

------------------------------------------ New Project Performance---------------------------------------------------
-- #NewProjectPerformance
/*Declare variable*/
--DECLARE @BG Int,@ProductID NVarchar(50),@Html NVarchar(Max)
Declare @Count int
Set @BG=1 Set @Html=''  Set @Count=1
While(@BG<=4)
Begin
	Set @Html='' Set @Count=1  
	If(Not Exists(Select Distinct ProjectID from #BookingOffline Where  BG=@BG))
		Select @Html=@Html+Char(13)+'<tr><td class="NewProject_BGName" colspan="1" rowspan="@rowspan" style="text-align: center;"><strong>'
				+Case When @BG=1 Then 'BG1 SDH'
					When @BG=2 Then 'BG2 TH'
					When @BG=3 Then 'BG CD1'
					When @BG=4 Then 'BG CD2'
					Else ''End
				+'</strong></td>'+Char(13)
				+'<td>'+'No Offline'+'</td>'
				+'<td>'+CONVERT(Varchar, CAST(0 As money), 1)+'</td>'
				+'<td>'+CONVERT(varchar, CAST(0 As money), 1)+'</td>'
			+Char(13)+'</tr>'
	Else
	Begin
	
		DECLARE my_cursor CURSOR FOR  
		Select Distinct ProjectID 
		from #BookingOffline
		Where  BG=@BG
		Order by ProjectID  
  
		OPEN my_cursor;    
		FETCH NEXT FROM my_cursor  
		INTO @ProductID;  
		Set @Count=1
		WHILE @@FETCH_STATUS = 0  
		BEGIN  	
			If(@Count=1)			
				Select @Html=@Html+Char(13)+'<tr><td class="NewProject_BGName" rowspan="@rowspan" style="text-align: center;"><strong>'
						+Case When @BG=1 Then 'BG1 SDH'
						When @BG=2 Then 'BG2 TH'
						When @BG=3 Then 'BG CD1'
						When @BG=4 Then 'BG CD2'
						Else ''End+'</strong></td>'+Char(13)
			Else 
				Select @Html=@Html+Char(13)+'<tr>'+Char(13)
			

			Select @Html=@Html
				+'<td style="text-align: left;">'+(Select t.ProjectID+' - '+t.Project From #BookingOffline t Where t.ProjectID=@ProductID)+'</td>'
				+'<td>'+CONVERT(varchar, CAST(IsNull((Select t.BookingOffline_Unit From #BookingOffline t Where t.ProjectID=@ProductID),0)AS money), 1)+'</td>'
				+'<td>'+CONVERT(varchar, CAST(IsNull((Select t.BookingOffline_Value From #BookingOffline t Where t.ProjectID=@ProductID),0)AS money), 1)+'</td>'
			+Char(13)+'</tr>'
			Set @Count=@Count+1
			Fetch NEXT FROM my_cursor  Into @ProductID;  
		END  

		CLOSE my_cursor;  
		DEALLOCATE my_cursor;
		Set @Html=Replace(@Html,'@rowspan',convert(nvarchar(5),@Count-1))
	End
		
		--select @BG BG,@Html
		Set @Mail=Replace(@Mail,'<!--@BookingOffline_BG'+Convert(NVarchar(5),@BG)+'-->',@Html)
		Print(@Html)
		Set @BG=@BG+1
End
--select CHARINDEX('<!--@BookingOffline_BG',@Mail)CHARINDEXx

Set @Mail=Replace(@Mail,'@BookingOffline_Total_Unit',CONVERT(varchar, CAST(IsNull((Select sum(BookingOffline_Unit) From #BookingOffline t  ),0)AS money), 1))
Set @Mail=Replace(@Mail,'@BookingOffline_Total_Amt',CONVERT(varchar, CAST(IsNull((Select sum(BookingOffline_Value) From #BookingOffline t  ),0)AS money), 1))
--Select @Mail
----------------------------------------------------------------------------
Set @Mail=Replace(@Mail,'@AsOfDate',convert(nvarchar(20),Getdate(),113))
Set @Mail=Replace(@Mail,'@Week','   ( Week '+convert(nvarchar(10),@CurrentWeek)+' : '+ convert(nvarchar(10),@StartDate,103) +' - '+ convert(nvarchar(10),@EndDate,103)+' )'  )




Print(@Mail)
Select @Mail EmailContent
--set @mail='<h1 style="">เรียนท่านผู้บริหาร<br/>
--เนื่องด้วย Mail ที่ส่ง Auto จากระบบให้เมื่อวาน แสดงยอดเป็นของ Week 38 (16-22/9/2019) เนื่องจากเป็น Week สุดท้ายของ Quater และถูกกำหนดเป็นช่วงวันที่ 23-30/9/2019<br/>
--ซึ่งเป็น วันจันทร์ ถึง จันทร์ แต่โดยปกติแล้วจะเป็น วันจันทร์ ถึง วันอาทิตย์ <br/>
--จึงขอส่ง Mail สำหรับ Week 39 มาตามรายละเอียดด้านล่าง </h1><br/>'+@mail

/*Send email*/
Declare @To NVarchar(100),@From NVarchar(100),@SendDate DateTime=GetDate()
Set @To = 'apichaya@apthai.com;suchat_s@apthai.com'  -- for test
--Set @To = 'tanonchai@apthai.com'  -- for test
--Set @To='executive_rpt_group@apthai.com'    -- for 
Set @From='crmconsult@apthai.com'
exec DBLINK_SVR_EMAIL.APMail.dbo.SP_Save_Mail @CMD=1 ,@AttempTime=@SendDate,@MailFrom=@From
	,@MailTo=@To,@MailCC=N'',@Topic='Executive Mail Report',@Detail=@Mail,@MailType=N'ExecutiveMail'
	,@Key1='',@Key2='',@Key3='',@Key4='',@ReceiverID=N'',@MailTime=@SendDate


select * from #TotalProject Order By bg
Select * From #ExistingProject Order By bg
Select * From #NewProjectPerformance Order By bg,ProductID
Select * From #BookingOffline Order By bg,ProjectID
SELECT * FROM #TotalProject_JV



go

