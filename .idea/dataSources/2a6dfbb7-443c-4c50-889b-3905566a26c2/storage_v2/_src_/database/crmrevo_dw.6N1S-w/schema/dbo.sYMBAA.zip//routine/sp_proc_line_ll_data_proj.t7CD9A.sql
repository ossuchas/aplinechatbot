

CREATE PROCEDURE [dbo].[sp_proc_line_ll_data_proj]
    @by_type AS VARCHAR(10), --BG, SUBBG
	@p_bg AS INT,
	@p_years AS INT,
	@p_period AS VARCHAR(5),
	@p_flag AS VARCHAR(2), -- Current Flag Y = Current, N = Last Week
	@p_projectid AS VARCHAR(5)
AS
BEGIN
    SET NOCOUNT ON;

	--@p_period
	--YTD = Year to Date
	--QTD = Quarter to Date
	--M = Month
	--W = Week
	--Y = Yesterday to Current

    DECLARE @tg_transferamount MONEY;
    DECLARE @at_transferamount MONEY;
    DECLARE @icon_transferamount VARCHAR(255);
    DECLARE @tg_transferunit MONEY;
    DECLARE @at_transferunit MONEY;
    DECLARE @icon_transferunit VARCHAR(255);
    DECLARE @tg_qcpass MONEY;
    DECLARE @at_qcpass MONEY;
    DECLARE @icon_qcpass VARCHAR(255);
    DECLARE @tg_checkunit MONEY;
    DECLARE @at_checkunit MONEY;
    DECLARE @icon_checkunit VARCHAR(255);
    DECLARE @tg_acceptunit MONEY;
    DECLARE @at_acceptunit MONEY;
    DECLARE @icon_acceptunit VARCHAR(255);
    DECLARE @tg_bankapprove MONEY;
    DECLARE @at_bankapprove MONEY;
    DECLARE @icon_bankapprove VARCHAR(255);
    DECLARE @tg_grosspresalesamount MONEY;
    DECLARE @at_grosspresalesamount MONEY;
    DECLARE @icon_grosspresalesamount VARCHAR(255);
    DECLARE @tg_netpresalesamount MONEY;
    DECLARE @at_netpresalesamount MONEY;
    DECLARE @icon_netpresalesamount VARCHAR(255);
    DECLARE @tg_netpresales_precancelamount MONEY;
    DECLARE @at_netpresales_precancelamount MONEY;
    DECLARE @icon_netpresales_precancelamount VARCHAR(255);
    DECLARE @tg_precancelamount MONEY;
    DECLARE @at_precancelamount MONEY;
    DECLARE @icon_precancelamount VARCHAR(255);
    DECLARE @tg_grosspresalesunit MONEY;
    DECLARE @at_grosspresalesunit MONEY;
    DECLARE @icon_grosspresalesunit VARCHAR(255);
    DECLARE @tg_netpresalesunit MONEY;
    DECLARE @at_netpresalesunit MONEY;
    DECLARE @icon_netpresalesunit VARCHAR(255);
    DECLARE @tg_netpresales_precancelunit MONEY;
    DECLARE @at_netpresales_precancelunit MONEY;
    DECLARE @icon_netpresales_precancelunit VARCHAR(255);
    DECLARE @tg_precancelunit MONEY;
    DECLARE @at_precancelunit MONEY;
    DECLARE @icon_precancelunit VARCHAR(255);
    DECLARE @tg_walk MONEY;
    DECLARE @at_walk MONEY;
    DECLARE @icon_walk VARCHAR(255);
    DECLARE @tg_walk2 MONEY;
    DECLARE @at_walk2 MONEY;
    DECLARE @icon_walk2 VARCHAR(255);
    DECLARE @tg_conversion MONEY;
    DECLARE @at_conversion MONEY;
    DECLARE @icon_conversion VARCHAR(255);

	DECLARE @i_count AS INT;
	DECLARE @bg_code AS VARCHAR(5) --SDH,TH,CD1,CD2
	DECLARE @begin_week AS INT;
	DECLARE @end_week AS INT;
	DECLARE @current_week AS INT;
	DECLARE @txt_start_date AS VARCHAR(20);
	DECLARE @txt_end_date AS VARCHAR(20);
	DECLARE @txt_start_week AS VARCHAR(10);
	DECLARE @txt_end_week AS VARCHAR(10);
	DECLARE @text_msg AS VARCHAR(1000);
	DECLARE @project_name AS VARCHAR(255);

	IF @p_period = 'YTD'
		SELECT @begin_week = MIN(w), @end_week = MAX(w), @current_week = MAX(w)
		FROM crmrevo.bi.Mst_Calendar_Week WITH(NOLOCK)
		WHERE 1=1
		AND DATEPART(YEAR, StartDate) = DATEPART(YEAR,GETDATE())
		-- AND CAST(GETDATE() AS DATE) > CAST(StartDate AS DATE) -- Modified by Suchat S. 2019-12-06 get all week in current year
	ELSE IF @p_period = 'QTD'
		SELECT @begin_week = MIN(w), @end_week = MAX(w), @current_week = MAX(w)
		FROM crmrevo.bi.Mst_Calendar_Week WITH(NOLOCK)
		WHERE 1=1
		AND DATEPART(YEAR, StartDate) = DATEPART(YEAR,GETDATE())
		AND DATEPART(QUARTER, StartDate) = DATEPART(QUARTER,GETDATE())
		-- AND CAST(GETDATE() AS DATE) > CAST(StartDate AS DATE) -- Modified by Suchat S. 2019-12-06 get all week in current year
	ELSE IF @p_period = 'W' --
		IF @p_flag = 'Y'
			--SELECT @begin_week = MIN(w)-1, @end_week = MAX(w), @current_week = MAX(w)
			SELECT @begin_week = MIN(w), @end_week = MAX(w), @current_week = MAX(w)
			FROM crmrevo.bi.Mst_Calendar_Week WITH(NOLOCK)
			WHERE 1=1
			AND DATEPART(YEAR, StartDate) = DATEPART(YEAR,GETDATE())
			--AND DATEPART(WEEK, StartDate) = DATEPART(WEEK,GETDATE())
			AND CAST(GETDATE() AS DATE) BETWEEN CAST(StartDate AS DATE) AND CAST(EndDate AS DATE)
		ELSE
			--SELECT @begin_week = MIN(w)-2, @end_week = MAX(w)-1, @current_week = MAX(w)
			SELECT @begin_week = MIN(w)-1, @end_week = MAX(w)-1, @current_week = MAX(w)
			FROM crmrevo.bi.Mst_Calendar_Week WITH(NOLOCK)
			WHERE 1=1
			AND DATEPART(YEAR, StartDate) = DATEPART(YEAR,GETDATE())
			--AND DATEPART(WEEK, StartDate) = DATEPART(WEEK,GETDATE())
			AND CAST(GETDATE() AS DATE) BETWEEN CAST(StartDate AS DATE) AND CAST(EndDate AS DATE)
	ELSE --Yesterday
	    PRINT 'xx'

	--PRINT 'begin_week = ' + CAST(@begin_week AS VARCHAR(50)) + ', end_week = ' + CAST(@end_week AS VARCHAR(5)) + ', current_week = ' + CAST(@current_week AS VARCHAR(5))

	IF @p_period = 'W'
		IF @p_flag = 'Y'
			SELECT @txt_start_date = FORMAT(StartDate,'dd/MM/yy'), @txt_end_date = FORMAT(EndDate,'dd/MM/yy')
			FROM crmrevo.bi.Mst_Calendar_Week WITH(NOLOCK)
			WHERE 1=1
			AND w = @begin_week
			AND DATEPART(YEAR, StartDate) = DATEPART(YEAR,GETDATE())
			--AND CAST(GETDATE() AS DATE) > CAST(StartDate AS DATE) --Modified by Suchat S. 2019-12-09
			AND CAST(GETDATE() AS DATE) BETWEEN CAST(StartDate AS DATE) AND CAST(EndDate AS DATE)
		ELSE
			SELECT @txt_start_date = FORMAT(StartDate,'dd/MM/yy'), @txt_end_date = FORMAT(EndDate,'dd/MM/yy')
			FROM crmrevo.bi.Mst_Calendar_Week WITH(NOLOCK)
			WHERE 1=1
			AND w = @begin_week
			AND DATEPART(YEAR, StartDate) = DATEPART(YEAR,GETDATE())
			--AND CAST(GETDATE() AS DATE) > CAST(StartDate AS DATE) --Modified by Suchat S. 2019-12-09
			--AND CAST(GETDATE() AS DATE) BETWEEN CAST(StartDate AS DATE) AND CAST(EndDate AS DATE)
	ELSE
		--SELECT @txt_start_date = FORMAT(StartDate,'dd/MM/yy'), @txt_end_date = FORMAT(GETDATE()-1,'dd/MM/yy') -- Modified by Suchat S. 2020-01-06
		SELECT @txt_start_date = FORMAT(StartDate,'dd/MM/yy'), @txt_end_date = FORMAT(GETDATE(),'dd/MM/yy')
		FROM crmrevo.bi.Mst_Calendar_Week WITH(NOLOCK)
		WHERE 1=1
		AND w = @begin_week
		AND DATEPART(YEAR, StartDate) = DATEPART(YEAR,GETDATE())
		--AND CAST(GETDATE() AS DATE) > CAST(StartDate AS DATE) --Modified by Suchat S. 2020-04-01 for issue error QTD
		AND CAST(GETDATE() AS DATE) >= CAST(StartDate AS DATE) 

	--PRINT @txt_start_date + ', ' + @txt_end_date

	IF @p_period = 'W' OR @p_period = 'Y'
		SET @text_msg = 'w' + CAST(@begin_week AS VARCHAR(5)) + ' (' + @txt_start_date + '-' + @txt_end_date + ')'
	ELSE
		SET @text_msg = 'w' + CAST(@begin_week AS VARCHAR(5)) + '-' + 'w' + CAST(@end_week AS VARCHAR(5)) + ' (' + @txt_start_date + '-' + @txt_end_date + ')'

	SET @bg_code = CASE 
		WHEN @p_bg = 1 THEN 'SDH'
		WHEN @p_bg = 2 THEN 'TH'
		WHEN @p_bg = 3 THEN 'CD1'
		WHEN @p_bg = 4 THEN 'CD2'
		ELSE '' END

	--check existing data
	SELECT @i_count = COUNT(*) 
	FROM dbo.crm_line_ll_data WITH(NOLOCK) 
	WHERE bg = @bg_code AND years = @p_years AND period = @p_period 
	AND current_flag = @p_flag AND by_type = @by_type AND projectid = @p_projectid

	IF @i_count = 0
	BEGIN
		SELECT @project_name = ProjectNameTH FROM crmrevo.PRJ.Project WITH(NOLOCK) WHERE ProjectNo = @p_projectid

		INSERT INTO dbo.crm_line_ll_data (by_type, bg, years, begin_week, end_week, period, current_flag, projectid, project_name) 
		VALUES(@by_type, @bg_code, @p_years, @begin_week, @end_week, @p_period, @p_flag, @p_projectid, @project_name)
	END

    IF (OBJECT_ID('tempdb..#temp1') IS NOT NULL)
        DROP TABLE #temp1;

	PRINT 'begin_week = ' + CAST(@begin_week AS VARCHAR(50)) + ', end_week = ' + CAST(@end_week AS VARCHAR(5)) + ', current_week = ' + CAST(@current_week AS VARCHAR(5))

  --  SELECT a.RecType, a.SortKey, SUM(a.Actual) actual, SUM(a.Target) AS target
  --  INTO #temp1
  --  FROM [192.168.0.19].AP_STG.dbo.RPT_LeadIndicator_V3 a WITH(NOLOCK)
  --      LEFT JOIN [192.168.0.19].AP_DW.dbo.PROJECT_DIM_C b WITH(NOLOCK) ON a.ProjectID = b.PROJECT_CODE,
		--dbo.ICON_EntForms_Products p WITH (NOLOCK)
  --  WHERE a.Y = @p_years
  --        --AND a.W = @p_week
		--  AND a.W BETWEEN @begin_week AND CASE WHEN @p_period <> 'W' THEN @end_week ELSE @begin_week END
  --        AND a.RecType NOT IN ( 'BC', 'DIV', 'GrossPresales' )
  --        AND b.BU_CODE = @p_bg
		--  AND a.ProjectID = p.ProductID
  --        AND p.RTPExcusive = 1
		--  --AND p.ProjectGroup = @p_subbg
		--  AND p.ProductID = @p_projectid
  --  GROUP BY b.BU_CODE, a.RecType, a.SortKey
  --  ORDER BY a.SortKey;

	SELECT a.RecType, a.SortKey, SUM(a.Actual) actual, SUM(a.Target) AS target
	INTO #temp1
    FROM dbo.RPT_LeadIndicator a WITH(NOLOCK)
        LEFT JOIN crmrevo.PRJ.Project p WITH (NOLOCK) ON a.ProjectID = p.ProjectNo
    WHERE a.Y = @p_years
		  AND a.W BETWEEN @begin_week AND CASE WHEN @p_period <> 'W' THEN @end_week ELSE @begin_week END
          AND a.RecType NOT IN ( 'BC', 'DIV', 'GrossPresales' )
          AND SUBSTRING(p.[Group],1,1) = @p_bg
		  AND a.ProjectID = p.ProjectNo
          AND p.IsActive = 1
		  AND p.IsDeleted = 0
		  AND p.ProjectNo = @p_projectid
    GROUP BY SUBSTRING(p.[Group], 1, 1), a.RecType, a.SortKey
    ORDER BY a.SortKey;

	--SET @text_msg = 'w52 (23/12/19-31/12/19)'

	SELECT @at_transferamount = actual, @tg_transferamount = target FROM #temp1 WHERE SortKey = 1 AND RecType = 'TransferAmount';
    SELECT @at_transferunit = actual, @tg_transferunit = target FROM #temp1 WHERE SortKey = 2 AND RecType = 'TransferUnit';
    SELECT @at_qcpass = actual, @tg_qcpass = target FROM #temp1 WHERE SortKey = 3 AND RecType = 'QCPass';
    SELECT @at_checkunit = actual, @tg_checkunit = target FROM #temp1 WHERE SortKey = 4 AND RecType = 'CheckUnit';
    SELECT @at_acceptunit = actual, @tg_acceptunit = target FROM #temp1 WHERE SortKey = 5 AND RecType = 'AcceptUnit';
    SELECT @at_bankapprove = actual, @tg_bankapprove = target FROM #temp1 WHERE SortKey = 6 AND RecType = 'BankApprove';
    SELECT @at_grosspresalesamount = actual, @tg_grosspresalesamount = target FROM #temp1 WHERE SortKey = 8 AND RecType = 'GrossPresalesAmount';
    SELECT @at_netpresalesamount = actual, @tg_netpresalesamount = target FROM #temp1 WHERE SortKey = 10 AND RecType = 'NetPresalesAmount';
    SELECT @at_netpresales_precancelamount = actual, @tg_netpresales_precancelamount = target FROM #temp1 WHERE SortKey = 20 AND RecType = 'NetPresales_PreCancelAmount';
    SELECT @at_precancelamount = actual, @tg_precancelamount = target FROM #temp1 WHERE SortKey = 18 AND RecType = 'PreCancelAmount';
    SELECT @at_grosspresalesunit = actual, @tg_grosspresalesunit = target FROM #temp1 WHERE SortKey = 9 AND RecType = 'GrossPresalesUnit';
    SELECT @at_netpresalesunit = actual, @tg_netpresalesunit = target FROM #temp1 WHERE SortKey = 11 AND RecType = 'NetPresalesUnit';
    SELECT @at_netpresales_precancelunit = actual, @tg_netpresales_precancelunit = target FROM #temp1 WHERE SortKey = 19 AND RecType = 'NetPresales_PreCancelUnit';
    SELECT @at_precancelunit = actual, @tg_precancelunit = target FROM #temp1 WHERE SortKey = 17 AND RecType = 'PreCancelUnit';
    SELECT @at_walk = actual, @tg_walk = target FROM #temp1 WHERE SortKey = 12 AND RecType = 'Walk';
    SELECT @at_walk2 = actual, @tg_walk2 = target FROM #temp1 WHERE SortKey = 13 AND RecType = 'Walk2';
    
	--Cal Conversion
	IF ISNULL(@at_netpresalesunit,0) = 0 SET @at_conversion = 0	ELSE SET @at_conversion = (@at_walk + @at_walk2)/@at_netpresalesunit
	IF ISNULL(@tg_netpresalesunit,0) = 0 SET @tg_conversion = 0	ELSE SET @tg_conversion = (@tg_walk + @tg_walk2)/@tg_netpresalesunit;

	--icon
	--https://i.ibb.co/b2zz5hJ/green-32x32.png
	--https://i.ibb.co/ykFsNjm/red-32x32.png
	--https://i.ibb.co/y0hQkxb/yellow-32x32.png
	--https://i.ibb.co/Mp4pjzF/blank.png

    IF @at_transferamount < @tg_transferamount*0.8 SET @icon_transferamount	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_transferamount >= @tg_transferamount	SET @icon_transferamount = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_transferamount = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'
	IF @at_transferunit < @tg_transferunit*0.8 SET @icon_transferunit	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_transferunit >= @tg_transferunit	SET @icon_transferunit = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_transferunit = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'
	IF @at_qcpass < @tg_qcpass*0.8 SET @icon_qcpass	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_qcpass >= @tg_qcpass	SET @icon_qcpass = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_qcpass = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'
	IF @at_checkunit < @tg_checkunit*0.8 SET @icon_checkunit	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_checkunit >= @tg_checkunit	SET @icon_checkunit = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_checkunit = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'
	IF @at_acceptunit < @tg_acceptunit*0.8 SET @icon_acceptunit	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_acceptunit >= @tg_acceptunit	SET @icon_acceptunit = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_acceptunit = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'
	IF @at_bankapprove < @tg_bankapprove*0.8 SET @icon_bankapprove	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_bankapprove >= @tg_bankapprove	SET @icon_bankapprove = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_bankapprove = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'
	IF @at_grosspresalesamount < @tg_grosspresalesamount*0.8 SET @icon_grosspresalesamount	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_grosspresalesamount >= @tg_grosspresalesamount	SET @icon_grosspresalesamount = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_grosspresalesamount = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'
	IF @at_netpresalesamount < @tg_netpresalesamount*0.8 SET @icon_netpresalesamount	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_netpresalesamount >= @tg_netpresalesamount	SET @icon_netpresalesamount = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_netpresalesamount = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'
	IF @at_netpresales_precancelamount < @tg_netpresales_precancelamount*0.8 SET @icon_netpresales_precancelamount	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_netpresales_precancelamount >= @tg_netpresales_precancelamount	SET @icon_netpresales_precancelamount = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_netpresales_precancelamount = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'
	IF @at_precancelamount < @tg_precancelamount*0.8 SET @icon_precancelamount	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_precancelamount >= @tg_precancelamount	SET @icon_precancelamount = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_precancelamount = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'
	IF @at_grosspresalesunit < @tg_grosspresalesunit*0.8 SET @icon_grosspresalesunit	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_grosspresalesunit >= @tg_grosspresalesunit	SET @icon_grosspresalesunit = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_grosspresalesunit = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'
	IF @at_netpresalesunit < @tg_netpresalesunit*0.8 SET @icon_netpresalesunit	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_netpresalesunit >= @tg_netpresalesunit	SET @icon_netpresalesunit = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_netpresalesunit = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'
	IF @at_netpresales_precancelunit < @tg_netpresales_precancelunit*0.8 SET @icon_netpresales_precancelunit	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_netpresales_precancelunit >= @tg_netpresales_precancelunit	SET @icon_netpresales_precancelunit = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_netpresales_precancelunit = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'
	IF @at_precancelunit < @tg_precancelunit*0.8 SET @icon_precancelunit	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_precancelunit >= @tg_precancelunit	SET @icon_precancelunit = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_precancelunit = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'
	IF @at_walk < @tg_walk*0.8 SET @icon_walk	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_walk >= @tg_walk	SET @icon_walk = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_walk = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'
	IF @at_walk2 < @tg_walk2*0.8 SET @icon_walk2	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_walk2 >= @tg_walk2	SET @icon_walk2 = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_walk2 = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'
	
	--Modified by Suchat S. 2020-02-11 for change conversion
	--IF @at_conversion < @tg_conversion*0.8 SET @icon_conversion	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_conversion >= @tg_conversion	SET @icon_conversion = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_conversion = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'

	IF @at_conversion > @tg_conversion*0.8 SET @icon_conversion	= 'https://i.ibb.co/ykFsNjm/red-32x32.png' ELSE IF @at_conversion <= @tg_conversion*0.2	SET @icon_conversion = 'https://i.ibb.co/b2zz5hJ/green-32x32.png' ELSE SET @icon_conversion = 'https://i.ibb.co/y0hQkxb/yellow-32x32.png'

	--Set Blank icon if target = 0
	IF ISNULL( @tg_transferamount, 0) = 0 SET @icon_transferamount = 'https://i.ibb.co/Mp4pjzF/blank.png'
	IF ISNULL( @tg_transferunit, 0) = 0 SET @icon_transferunit = 'https://i.ibb.co/Mp4pjzF/blank.png'
	IF ISNULL( @tg_qcpass, 0) = 0 SET @icon_qcpass = 'https://i.ibb.co/Mp4pjzF/blank.png'
	IF ISNULL( @tg_checkunit, 0) = 0 SET @icon_checkunit = 'https://i.ibb.co/Mp4pjzF/blank.png'
	IF ISNULL( @tg_acceptunit, 0) = 0 SET @icon_acceptunit = 'https://i.ibb.co/Mp4pjzF/blank.png'
	IF ISNULL( @tg_bankapprove, 0) = 0 SET @icon_bankapprove = 'https://i.ibb.co/Mp4pjzF/blank.png'
	IF ISNULL( @tg_grosspresalesamount, 0) = 0 SET @icon_grosspresalesamount = 'https://i.ibb.co/Mp4pjzF/blank.png'
	IF ISNULL( @tg_netpresalesamount, 0) = 0 SET @icon_netpresalesamount = 'https://i.ibb.co/Mp4pjzF/blank.png'
	IF ISNULL( @tg_netpresales_precancelamount, 0) = 0 SET @icon_netpresales_precancelamount = 'https://i.ibb.co/Mp4pjzF/blank.png'
	IF ISNULL( @tg_precancelamount, 0) = 0 SET @icon_precancelamount = 'https://i.ibb.co/Mp4pjzF/blank.png'
	IF ISNULL( @tg_grosspresalesunit, 0) = 0 SET @icon_grosspresalesunit = 'https://i.ibb.co/Mp4pjzF/blank.png'
	IF ISNULL( @tg_netpresalesunit, 0) = 0 SET @icon_netpresalesunit = 'https://i.ibb.co/Mp4pjzF/blank.png'
	IF ISNULL( @tg_netpresales_precancelunit, 0) = 0 SET @icon_netpresales_precancelunit = 'https://i.ibb.co/Mp4pjzF/blank.png'
	IF ISNULL( @tg_precancelunit, 0) = 0 SET @icon_precancelunit = 'https://i.ibb.co/Mp4pjzF/blank.png'
	IF ISNULL( @tg_walk, 0) = 0 SET @icon_walk = 'https://i.ibb.co/Mp4pjzF/blank.png'
	IF ISNULL( @tg_walk2, 0) = 0 SET @icon_walk2 = 'https://i.ibb.co/Mp4pjzF/blank.png'
	IF ISNULL( @tg_conversion, 0) = 0 SET @icon_conversion = 'https://i.ibb.co/Mp4pjzF/blank.png'

	UPDATE dbo.crm_line_ll_data
	SET begin_week = @begin_week,
	end_week = @end_week,
	text_msg_header = 'BG' + CAST(@p_bg AS VARCHAR(2)) + ' - ' + @bg_code,
	text_msg = @text_msg,
	tg_transferamount	=	ISNULL(@tg_transferamount, 0),
	at_transferamount	=	ISNULL(@at_transferamount, 0),
	icon_transferamount	=	ISNULL(@icon_transferamount, 0),
	tg_transferunit	=	ISNULL(@tg_transferunit, 0),
	at_transferunit	=	ISNULL(@at_transferunit, 0),
	icon_transferunit	=	ISNULL(@icon_transferunit, 0),
	tg_qcpass	=	ISNULL(@tg_qcpass, 0),
	at_qcpass	=	ISNULL(@at_qcpass, 0),
	icon_qcpass	=	ISNULL(@icon_qcpass, 0),
	tg_checkunit	=	ISNULL(@tg_checkunit, 0),
	at_checkunit	=	ISNULL(@at_checkunit, 0),
	icon_checkunit	=	ISNULL(@icon_checkunit, 0),
	tg_acceptunit	=	ISNULL(@tg_acceptunit, 0),
	at_acceptunit	=	ISNULL(@at_acceptunit, 0),
	icon_acceptunit	=	ISNULL(@icon_acceptunit, 0),
	tg_bankapprove	=	ISNULL(@tg_bankapprove, 0),
	at_bankapprove	=	ISNULL(@at_bankapprove, 0),
	icon_bankapprove	=	ISNULL(@icon_bankapprove, 0),
	tg_grosspresalesamount	=	ISNULL(@tg_grosspresalesamount, 0),
	at_grosspresalesamount	=	ISNULL(@at_grosspresalesamount, 0),
	icon_grosspresalesamount	=	ISNULL(@icon_grosspresalesamount, 0),
	tg_netpresalesamount	=	ISNULL(@tg_netpresalesamount, 0),
	at_netpresalesamount	=	ISNULL(@at_netpresalesamount, 0),
	icon_netpresalesamount	=	ISNULL(@icon_netpresalesamount, 0),
	tg_netpresales_precancelamount	=	ISNULL(@tg_netpresales_precancelamount, 0),
	at_netpresales_precancelamount	=	ISNULL(@at_netpresales_precancelamount, 0),
	icon_netpresales_precancelamount	=	ISNULL(@icon_netpresales_precancelamount, 0),
	tg_precancelamount	=	ISNULL(@tg_precancelamount, 0),
	at_precancelamount	=	ISNULL(@at_precancelamount, 0),
	icon_precancelamount	=	ISNULL(@icon_precancelamount, 0),
	tg_grosspresalesunit	=	ISNULL(@tg_grosspresalesunit, 0),
	at_grosspresalesunit	=	ISNULL(@at_grosspresalesunit, 0),
	icon_grosspresalesunit	=	ISNULL(@icon_grosspresalesunit, 0),
	tg_netpresalesunit	=	ISNULL(@tg_netpresalesunit, 0),
	at_netpresalesunit	=	ISNULL(@at_netpresalesunit, 0),
	icon_netpresalesunit	=	ISNULL(@icon_netpresalesunit, 0),
	tg_netpresales_precancelunit	=	ISNULL(@tg_netpresales_precancelunit, 0),
	at_netpresales_precancelunit	=	ISNULL(@at_netpresales_precancelunit, 0),
	icon_netpresales_precancelunit	=	ISNULL(@icon_netpresales_precancelunit, 0),
	tg_precancelunit	=	ISNULL(@tg_precancelunit, 0),
	at_precancelunit	=	ISNULL(@at_precancelunit, 0),
	icon_precancelunit	=	ISNULL(@icon_precancelunit, 0),
	tg_walk	=	ISNULL(@tg_walk, 0),
	at_walk	=	ISNULL(@at_walk, 0),
	icon_walk	=	ISNULL(@icon_walk, 0),
	tg_walk2	=	ISNULL(@tg_walk2, 0),
	at_walk2	=	ISNULL(@at_walk2, 0),
	icon_walk2	=	ISNULL(@icon_walk2, 0),
	tg_conversion	=	ISNULL(@tg_conversion, 0),
	at_conversion	=	ISNULL(@at_conversion, 0),
	icon_conversion	=	ISNULL(@icon_conversion, 0),
	modifyby = 'batch',
	modifydate	=	GETDATE()
	WHERE bg = @bg_code 
	AND period = @p_period 
	AND current_flag = @p_flag
	AND by_type = @by_type
	AND projectid = @p_projectid

END;


go

