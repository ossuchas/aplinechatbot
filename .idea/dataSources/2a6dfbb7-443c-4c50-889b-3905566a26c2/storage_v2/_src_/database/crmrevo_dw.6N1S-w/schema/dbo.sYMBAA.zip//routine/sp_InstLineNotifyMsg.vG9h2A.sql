

CREATE PROCEDURE [dbo].[sp_InstLineNotifyMsg]
    @LineToken VARCHAR(255) ,
    @LineOwner VARCHAR(255) ,
    @LineMobile VARCHAR(255) ,
    @LineMsg VARCHAR(MAX) ,
    @FilePath VARCHAR(MAX) ,
    @Remarks VARCHAR(255) ,
    @CreateBy VARCHAR(255)
AS
    BEGIN
        SET NOCOUNT ON;

        DECLARE @LineToken_Value VARCHAR(255)

        SELECT  @LineToken_Value = param_vlue
        FROM    dbo.CRM_Param WITH(NOLOCK)
        WHERE   param_code = 'LINE_TOKEN'
                AND param_data = @LineToken

        INSERT  INTO [dbo].[CRM_LineNotify]
                ( [Line_Token] ,
                  [Line_Owner] ,
                  [Line_MobileNoOwner] ,
                  [Send_Msg] ,
                  [File_Path] ,
                  [Remarks] ,
                  [Send_Status] ,
                  [Send_Date] ,
                  [CreateDate] ,
                  [CreateBy] ,
                  [ModifyDate] ,
                  [ModifyBy]
                )
        VALUES  ( @LineToken_Value ,
                  @LineOwner ,
                  @LineMobile ,
                  @LineMsg ,
                  @FilePath ,
                  @Remarks ,
                  'W' ,
                  NULL ,
                  GETDATE() ,
                  @CreateBy ,
                  GETDATE() ,
                  @CreateBy
                )

    END



go

