

CREATE PROCEDURE [dbo].[sp_GetHRCommissionByProj]
    @flag AS VARCHAR(2)
AS
BEGIN
    SET NOCOUNT ON;

	DECLARE @PeriodYear INT;
	DECLARE @PeriodMonth INT;

	SELECT @PeriodYear = DATEPART(YEAR, GETDATE()),-- Current Year
	 @PeriodMonth = DATEPART(MONTH,DATEADD(mm, DATEDIFF(mm,0,getdate())-1, 0)) -- Last Month

	IF @flag = '1' --Project HighRise Sale
	BEGIN
	    --PRINT '1'
		--ทำสัญญากับโอนในเดือนเดียวกัน
		SELECT	'BG' = BG.BGNo, 
				'SUBBG' = SBG.SubBGNo,
				'ProjectNo' = P.ProjectNo,
				'ProjectName' = P.ProjectNameTH,
				'UnitNo' = U.UnitNo, 
				'HCSName' = crmrevo.[dbo].[fn_GetHeadOfCS](CS.ProjectNo,'S'),  
				--'LCID' = LC.EmployeeNo,
				--'LCName' = LC.DisplayName,
				'LCID' = CASE WHEN ST.[Key] = '1' THEN LC.EmployeeNo
							WHEN ST.[Key] = '2' THEN 
									CASE WHEN LC.EmployeeNo = 'AP000000' THEN LC.EmployeeNo
									ELSE 'Agency' END
							WHEN ST.[Key] = '3' THEN LC.EmployeeNo END,
				'LCName' = CASE WHEN ST.[Key] = '1' THEN LC.DisplayName
							WHEN ST.[Key] = '2' THEN  
									CASE WHEN LC.EmployeeNo = 'AP000000' THEN LC.DisplayName
									ELSE ISNULL(AG.NameTH,AG.NameEN) END
							WHEN ST.[Key] = '3' THEN LC.DisplayName END,
				'LCHelperID' = LCH.EmployeeNo,
				'LCHelperName' = LCH.DisplayName,
				'LCCID' = '',
				'LCCName' = '',
				'CustomerName' = ISNULL(AO.FirstNameTH,'') + ' ' + ISNULL(AO.LastNameTH,''),  	
				'BookingDate' = CAST(B.BookingDate AS datetime),
				'ContractDate' = CAST(A.ContractDate AS datetime),
				'ApproveDate' = CAST(A.SignAgreementDate AS datetime),
				'SignContractApprovedDate' = CAST(A.SignContractApprovedDate AS datetime),
				'SellingPrice' = ISNULL(UP.AgreementPrice,0) - ISNULL(UP.TransferDiscount,0) - ISNULL(UP.FreedownDiscount,0), --เพิ่มลบฟรีดาวน์ ตามหน้าเว็บ
				'CommissionRatePercentSale' = ISNULL(CS.CommissionPercentRate,0),		
				'SaleCommissionSalePaid' = CASE WHEN LC.EmployeeNo = LCH.EmployeeNo THEN 0 ELSE ISNULL(CS.SaleUserSalePaid,0) END,
				'SaleHelperCommissionSalePaid' = CASE WHEN LC.EmployeeNo = LCH.EmployeeNo THEN 0 ELSE ISNULL(CS.ProjectSaleSalePaid,0) END,
				'TotalSaleCommission' = ISNULL(CS.SaleUserSalePaid,0) + ISNULL(CS.ProjectSaleSalePaid,0),		
				'LCCCommissionSalePaid' = 0.00,	
				'TotalCommissionPaid' = ISNULL(CS.SaleUserSalePaid,0) + ISNULL(CS.ProjectSaleSalePaid,0),
				'FlagData' = CASE WHEN CS.LastMigrateDate IS NOT NULL THEN N'Comm เก่า' WHEN CS.LastMigrateDate IS NULL THEN N'Comm ใหม่' END
				--,1
		FROM	crmrevo.[CMS].[CalculateHighRiseSale] CS WITH (NOLOCK)
				LEFT OUTER JOIN crmrevo.[SAL].[Agreement] A WITH (NOLOCK) ON CS.AgreementID = A.ID AND ISNULL(A.IsDeleted,0) = 0
				LEFT OUTER JOIN crmrevo.[SAL].[Transfer] T WITH (NOLOCK) ON CS.AgreementID= T.AgreementID AND ISNULL(T.IsDeleted,0) = 0
				LEFT OUTER JOIN crmrevo.[CMS].[CalculateHighRiseTransfer] CT WITH (NOLOCK) ON CT.TransferID = T.ID AND CS.PeriodYear= CT.PeriodYear AND CS.PeriodMonth= CT.PeriodMonth AND ISNULL(CT.IsDeleted,0) = 0
				LEFT OUTER JOIN crmrevo.[SAL].[AgreementOwner] AO WITH (NOLOCK) ON A.ID = AO.AgreementID AND ISNULL(AO.IsMainOwner,0) = 1 AND ISNULL(AO.ISDeleted,0) = 0 
				LEFT OUTER JOIN crmrevo.[SAL].[Booking] B WITH (NOLOCK) ON A.BookingID = B.ID AND ISNULL(B.ISDeleted,0) = 0
				LEFT OUTER JOIN crmrevo.[USR].[User] LC WITH (NOLOCK) ON CS.SaleUserID = LC.ID 
				LEFT OUTER JOIN crmrevo.[USR].[User] LCH WITH (NOLOCK) ON CS.ProjectSaleUserID = LCH.ID 
				LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON A.ProjectID = P.ID
				LEFT OUTER JOIN crmrevo.[PRJ].[Unit] U WITH (NOLOCK) ON A.UnitID = U.ID AND A.ProjectID = U.ProjectID
				LEFT OUTER JOIN (SELECT UP.* FROM crmrevo.[dbo].[vw_UnitPrice] UP WITH (NOLOCK)
									INNER JOIN crmrevo.[MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '2' --2=สัญญา
								) AS UP ON A.BookingID = UP.BookingID 
				LEFT OUTER JOIN crmrevo.[MST].[BG] BG WITH (NOLOCK) ON P.BGID = BG.ID 
				LEFT OUTER JOIN crmrevo.MST.SubBG SBG WITH (NOLOCK) ON SBG.ID = P.SubBGID
				LEFT OUTER JOIN crmrevo.[MST].[MasterCenter] M WITH (NOLOCK) ON P.ProjectTypeMasterCenterID = M.ID
				LEFT OUTER JOIN crmrevo.[MST].[MasterCenter] ST WITH (NOLOCK) ON CS.SaleOfficerTypeMasterCenterID  = ST.ID
				LEFT OUTER JOIN  crmrevo.MST.Agent AG WITH (NOLOCK) ON CS.AgentID = AG.ID

		WHERE	1=1
				AND CS.PeriodYear = @PeriodYear
				AND CS.PeriodMonth = @PeriodMonth																        
				AND ISNULL(CT.LCTransferPaid,0) > 0 
				AND ISNULL(CS.IsDeleted,0) = 0   

		UNION
		--ทำสัญญาแต่ยังไม่โอน
		SELECT	'BG' = BG.BGNo, 
				'SUBBG' = SBG.SubBGNo,
				'ProjectNo' = P.ProjectNo,
				'ProjectName' = P.ProjectNameTH,
				'UnitNo' = U.UnitNo, 
				'HCSName' = crmrevo.[dbo].[fn_GetHeadOfCS](CS.ProjectNo,'S'),  
				--'LCID' = LC.EmployeeNo,
				--'LCName' = LC.DisplayName,
				'LCID' = CASE WHEN ST.[Key] = '1' THEN LC.EmployeeNo
							WHEN ST.[Key] = '2' THEN 
									CASE WHEN LC.EmployeeNo = 'AP000000' THEN LC.EmployeeNo
									ELSE 'Agency' END
							WHEN ST.[Key] = '3' THEN LC.EmployeeNo END,
				'LCName' = CASE WHEN ST.[Key] = '1' THEN LC.DisplayName
							WHEN ST.[Key] = '2' THEN  
									CASE WHEN LC.EmployeeNo = 'AP000000' THEN LC.DisplayName
									ELSE ISNULL(AG.NameTH,AG.NameEN) END
							WHEN ST.[Key] = '3' THEN LC.DisplayName END,
				'LCHelperID' = LCH.EmployeeNo,
				'LCHelperName' = LCH.DisplayName,
				'LCCID' = '',
				'LCCName' = '',
				'CustomerName' = ISNULL(AO.FirstNameTH,'') + ' ' + ISNULL(AO.LastNameTH,''),
				'BookingDate' = CAST(B.BookingDate AS datetime),
				'ContractDate' = CAST(A.ContractDate AS datetime),
				'ApproveDate' = CAST(A.SignAgreementDate AS datetime),
				'SignContractApprovedDate' = CAST(A.SignContractApprovedDate AS datetime),
				'SellingPrice' = ISNULL(UP.AgreementPrice,0) - ISNULL(UP.TransferDiscount,0) - ISNULL(UP.FreedownDiscount,0), --เพิ่มลบฟรีดาวน์ ตามหน้าเว็บ
				'CommissionRatePercentSale' = ISNULL(CS.CommissionPercentRate,0),		
				'SaleCommissionSalePaid' = CASE WHEN LC.EmployeeNo = LCH.EmployeeNo THEN 0 ELSE ISNULL(CS.SaleUserSalePaid,0) END,
				'SaleHelperCommissionSalePaid' = CASE WHEN LC.EmployeeNo = LCH.EmployeeNo THEN 0 ELSE ISNULL(CS.ProjectSaleSalePaid,0) END,
				'TotalSaleCommission' = ISNULL(CS.SaleUserSalePaid,0) + ISNULL(CS.ProjectSaleSalePaid,0),	 
				'LCCCommissionSalePaid' = 0.00,	
				'TotalCommissionPaid' = ISNULL(CS.SaleUserSalePaid,0) + ISNULL(CS.ProjectSaleSalePaid,0),	
				'FlagData' = CASE WHEN CS.LastMigrateDate IS NOT NULL THEN N'Comm เก่า' WHEN CS.LastMigrateDate IS NULL THEN N'Comm ใหม่' END
				--,2

		FROM	crmrevo.[CMS].[CalculateHighRiseSale] CS WITH (NOLOCK)
				LEFT OUTER JOIN crmrevo.[SAL].[Agreement] A WITH (NOLOCK) ON CS.AgreementID = A.ID AND ISNULL(A.IsDeleted,0) = 0 
				LEFT OUTER JOIN crmrevo.[SAL].[Transfer] T WITH (NOLOCK) ON CS.AgreementID= T.AgreementID AND ISNULL(T.IsDeleted,0) = 0 
				LEFT OUTER JOIN crmrevo.[CMS].[CalculateHighRiseTransfer] CT WITH (NOLOCK) ON CT.TransferID = T.ID AND CS.PeriodYear= CT.PeriodYear AND CS.PeriodMonth= CT.PeriodMonth AND ISNULL(CT.IsDeleted,0) = 0 
				LEFT OUTER JOIN crmrevo.[SAL].[AgreementOwner] AO WITH (NOLOCK) ON A.ID = AO.AgreementID AND ISNULL(AO.IsMainOwner,0) = 1 AND ISNULL(AO.ISDeleted,0) = 0 
				LEFT OUTER JOIN crmrevo.[SAL].[Booking] B WITH (NOLOCK) ON A.BookingID = B.ID AND ISNULL(B.IsDeleted,0) = 0 
				LEFT OUTER JOIN crmrevo.[USR].[User] LC WITH (NOLOCK) ON CS.SaleUserID = LC.ID 
				LEFT OUTER JOIN crmrevo.[USR].[User] LCH WITH (NOLOCK) ON CS.ProjectSaleUserID = LCH.ID
				LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON A.ProjectID = P.ID
				LEFT OUTER JOIN crmrevo.[PRJ].[Unit] U WITH (NOLOCK) ON A.UnitID = U.ID AND A.ProjectID = U.ProjectID
				LEFT OUTER JOIN (SELECT UP.* FROM crmrevo.[dbo].[vw_UnitPrice] UP WITH (NOLOCK)
									INNER JOIN crmrevo.[MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '2' --2=สัญญา
								) AS UP ON A.BookingID = UP.BookingID 
				LEFT OUTER JOIN crmrevo.[MST].[BG] BG WITH (NOLOCK) ON P.BGID = BG.ID 
				LEFT OUTER JOIN crmrevo.MST.SubBG SBG WITH (NOLOCK) ON SBG.ID = P.SubBGID
				LEFT OUTER JOIN crmrevo.[MST].[MasterCenter] M WITH (NOLOCK) ON P.ProjectTypeMasterCenterID = M.ID
				LEFT OUTER JOIN crmrevo.[MST].[MasterCenter] ST WITH (NOLOCK) ON CS.SaleOfficerTypeMasterCenterID  = ST.ID
				LEFT OUTER JOIN crmrevo.MST.Agent AG WITH (NOLOCK) ON CS.AgentID = AG.ID

		WHERE	1=1
				AND CS.PeriodYear = @PeriodYear
				AND CS.PeriodMonth = @PeriodMonth
				AND NOT EXISTS(SELECT * FROM crmrevo.[CMS].[CalculateHighRiseTransfer] A WITH (NOLOCK) 
								LEFT OUTER JOIN crmrevo.[SAL].[Transfer] B WITH (NOLOCK) ON A.TransferID = B.ID AND ISNULL(B.IsDeleted,0) = 0 
								WHERE ISNULL(A.IsDeleted,0) = 0 AND B.ID  = CT.TransferID AND ((A.PeriodMonth <= @PeriodMonth AND A.PeriodYear = @PeriodYear) OR A.PeriodYear < @PeriodYear))
				AND ISNULL(CS.IsDeleted,0) = 0 

		ORDER BY BG,SUBBG, ProjectNo, UnitNo ASC;
	END
	ELSE
	BEGIN
	    IF @flag = '2' --Project HighRise Transfer
		BEGIN
		    --PRINT '2'
			--โอนในเดือนนี้
			SELECT  'BG' = BG.BGNo,
				'SUBBG' = SBG.SubBGNo,
				P.ProjectNo ProductID,
				P.ProjectNameTH AS ProductName,
				CT.UnitNo Unitnumber,
				crmrevo.[dbo].[fn_GetHeadOfCS](CT.ProjectNo,'S') AS HCSName,
				'LCHelperID' = U1.EmployeeNo,
				'LCHelperName' = U1.DisplayName,
				'LCCID' = NULL,
				'LCCName' = NULL,
				'CustomerName' = ISNULL(AO.FirstNameTH,'') + ' ' + ISNULL(AO.MiddleNameTH,'')+ ' ' + ISNULL(AO.LastNameTH,''),	
				CONVERT(DATETIME,B.BookingDate) AS BookingDate,
				CONVERT(DATETIME,A.ContractDate) AS ContractDate,
				CONVERT(DATETIME,A.SignAgreementDate) AS ApproveDate,
				CONVERT(DATETIME,A.SignContractApprovedDate) AS SignContractApproveDate,
				CONVERT(DATETIME,T.ActualTransferDate) AS TransferDateApprove,	
				'NetSalePrice' = UP.NetSalePrice,	
				'CommissionRatePercentTransfer' = ISNULL(CT.CommissionPercentRate,0),		
				'SaleCommissionTransPaid' = ISNULL(CT.LCTransferPaid,0),			
				'LCCCommissionTransPaid' = 0,	
				'TotalCommissionPaid' = ISNULL(CT.LCTransferPaid,0) + 0
			FROM  crmrevo.CMS.CalculateHighRiseTransfer CT WITH (NOLOCK)
			LEFT OUTER JOIN crmrevo.SAL.Transfer T WITH(NOLOCK) ON T.ID = CT.TransferID AND ISNULL(T.IsDeleted,0) = 0
			LEFT OUTER JOIN crmrevo.SAL.Agreement A WITH (NOLOCK) ON A.ID = T.AgreementID AND ISNULL(A.IsDeleted,0) = 0
			LEFT OUTER JOIN crmrevo.SAL.AgreementOwner AO WITH (NOLOCK) ON A.ID = AO.AgreementID AND ISNULL(AO.IsMainOwner,0) = 1 AND ISNULL(AO.IsDeleted,0) = 0 AND AO.[Order] = 1
			LEFT OUTER JOIN crmrevo.SAL.Booking B WITH (NOLOCK) ON A.BookingID=B.ID AND ISNULL(B.IsDeleted,0) = 0 
			LEFT OUTER JOIN crmrevo.USR.[User] U1 WITH (NOLOCK) ON CT.LCTransferID = U1.ID 
			LEFT OUTER JOIN crmrevo.PRJ.Project P WITH (NOLOCK) ON A.ProjectID=P.ID 
			LEFT OUTER JOIN crmrevo.PRJ.Unit UN WITH (NOLOCK) ON A.UnitID = UN.ID
			LEFT OUTER JOIN crmrevo.MST.BG BG WITH (NOLOCK) ON BG.ID = P.BGID
			LEFT OUTER JOIN crmrevo.MST.SubBG SBG WITH (NOLOCK) ON SBG.ID = P.SubBGID
			LEFT OUTER JOIN (
							SELECT UP.BookingID,ISNULL(UP.agreementprice,0)-ISNULL(UP.transferdiscount,0)-ISNULL(UP.freedowndiscount,0)+IncreasingAreaPrice AS NetSalePrice
							FROM crmrevo.SAL.UnitPrice UP WITH (NOLOCK)
							LEFT OUTER JOIN crmrevo.MST.MasterCenter MC WITH (NOLOCK) ON MC.ID = UP.UnitPriceStageMasterCenterID
							LEFT JOIN (SELECT itm.UnitPriceID,SUM(ISNULL(itm.Amount,0)) AS IncreasingAreaPrice 
										FROM crmrevo.SAL.UnitPriceItem itm WITH (NOLOCK)
										LEFT JOIN crmrevo.MST.MasterPriceItem mp  ON mp.ID = itm.MasterPriceItemID
										WHERE mp.[Key] = 'ExtraAreaPrice' AND itm.IsDeleted = 0
										GROUP BY itm.UnitPriceID
							) AS UPI ON UP.ID = UPI.UnitPriceID
							WHERE MC.[Key] = '3'  AND UP.IsDeleted = 0 
			) UP ON UP.BookingID = B.ID
	
			WHERE 1=1
			AND CT.PeriodYear = @PeriodYear
			AND CT.PeriodMonth = @PeriodMonth
			AND ISNULL(CT.IsDeleted,0) = 0	
	
			ORDER BY BG.BGNo,SBG.SubBGNo,P.ProjectNo,UN.UnitNo ASC;
		END
		ELSE --Project LowRise Sale-Transfer
        BEGIN
            --PRINT '3'
			----ทำสัญญากับโอนในเดือนเดียวกัน
			SELECT	'BG' = BG.BGNo,
					'SUBBG' = SBG.SubBGNo,
					'ProjectNo' = P.ProjectNo,
					'ProjectName' = P.ProjectNameTH,
					'UnitNo' = U.UnitNo,
					'HCSName' = crmrevo.[dbo].[fn_GetHeadOfCS](CS.ProjectNo,'S'),
					'LCID' = U1.EmployeeNo,
					'LCName' = U1.DisplayName,
					'LCHelperID' = U2.EmployeeNo,
					'LCHelperName' = U2.DisplayName,
					'LCCID' = NULL,
					'LCCName' = NULL,
					'CustomerName' = ISNULL(AO.FirstNameTH,'') + ' ' + ISNULL(AO.LastNameTH,''),
					'BookingDate' = CAST(B.BookingDate AS datetime),
					'ContractDate' = CAST(A.ContractDate AS datetime),
					'RDate' = CAST(A.SignAgreementDate AS datetime),
					'SignContractApprovedDate' = CAST(A.SignContractApprovedDate AS datetime),
					'ActualTransferDate' = CAST(T.ActualTransferDate AS datetime),
					'SellingPrice' = ISNULL(UP.AgreementPrice,0) - ISNULL(UP.TransferDiscount,0) - ISNULL(UP.FreedownDiscount,0), --เพิ่มลบฟรีดาวน์ ตามหน้าเว็บ
					'CommissionRatePercentSale' = ISNULL(CS.CommissionPercentRate,0),
					'CommissionSalePaid' = ISNULL(CS.SaleUserSalePaid,0),
		
					'SaleCommissionTransPaid' = CASE WHEN ISNULL(U1.EmployeeNo,NULL) <> ISNULL(U2.EmployeeNo,'') AND ISNULL(CT.ProjectSaleSalePaid,0) > 0   
													 THEN ISNULL(CT.SaleUserSalePaid,0) ELSE 0 END,
					'SaleHelperCommissionTransPaid' = CASE	WHEN ISNULL(U1.EmployeeNo,NULL) <> ISNULL(U2.EmployeeNo,'') 
															THEN ISNULL(CT.ProjectSaleSalePaid,0) ELSE 0 END,
					'TotalTransferCommission' = CASE WHEN ISNULL(U1.EmployeeNo,NULL) = ISNULL(U2.EmployeeNo,'') OR ISNULL(CT.ProjectSaleSalePaid,0) = 0  
													 THEN ISNULL(CT.SaleUserSalePaid,0) + ISNULL(CT.ProjectSaleSalePaid,0) ELSE 0 END,
		
					'SaleNewLaunchPaid' = CASE	WHEN ISNULL(U1.EmployeeNo,'') <> ISNULL(U2.EmployeeNo,'') AND ISNULL(CS.ProjectSaleNewLaunchPaid,0) > 0  
												THEN ISNULL(CS.SaleUserNewLaunchPaid,0) ELSE 0 END,  
					'SaleHelperNewLaunchPaid' = CASE WHEN ISNULL(U1.EmployeeNo,'') <> ISNULL(U2.EmployeeNo,'') 
													 THEN ISNULL(CS.ProjectSaleNewLaunchPaid,0) ELSE 0 END,  
					'TotalNewLaunch' = CASE WHEN ISNULL(U1.EmployeeNo,'') = ISNULL(U2.EmployeeNo,'') OR ISNULL(CS.ProjectSaleNewLaunchPaid,0) = 0   
											THEN ISNULL(CS.SaleUserNewLaunchPaid,0) + ISNULL(CS.ProjectSaleNewLaunchPaid,0) ELSE 0 END,  	
					'TotalCommissionPaid' = ISNULL(CS.SaleUserSalePaid,0) + ISNULL(CT.SaleUserSalePaid,0) + ISNULL(CT.ProjectSaleSalePaid,0)  
											+ ISNULL(CS.SaleUserNewLaunchPaid,0) + ISNULL(CS.ProjectSaleNewLaunchPaid,0),			
					'LCC' = 0.00,
					'FlagData' = CASE WHEN CS.LastMigrateDate IS NOT NULL THEN N'Comm เก่า' WHEN CS.LastMigrateDate IS NULL THEN N'Comm ใหม่' END
					--,'flag' = 1

			FROM	crmrevo.[CMS].[CalculateLowRiseSale] CS WITH (NOLOCK)
					LEFT OUTER JOIN crmrevo.[SAL].[Agreement] A WITH (NOLOCK) ON CS.AgreementID = A.ID AND ISNULL(A.ISDeleted,0) = 0 
					LEFT OUTER JOIN crmrevo.[SAL].[Transfer] T WITH (NOLOCK) ON CS.AgreementID = T.AgreementID AND ISNULL(T.ISDeleted,0) = 0 
					LEFT OUTER JOIN crmrevo.[CMS].[CalculateLowRiseTransfer] CT WITH (NOLOCK) ON T.ID = CT.TransferID AND CS.PeriodYear = CT.PeriodYear AND CS.PeriodMonth = CT.PeriodMonth AND ISNULL(CT.ISDeleted,0) = 0 
					LEFT OUTER JOIN crmrevo.[SAL].[AgreementOwner] AO WITH (NOLOCK) ON A.ID = AO.AgreementID AND ISNULL(AO.IsMainOwner,0) = 1 AND ISNULL(AO.ISDeleted,0) = 0 
					LEFT OUTER JOIN crmrevo.[SAL].[Booking] B WITH (NOLOCK) ON A.BookingID = B.ID AND ISNULL(B.ISDeleted,0) = 0 
					LEFT OUTER JOIN crmrevo.[USR].[User] U1 WITH (NOLOCK) ON CS.SaleUserID = U1.ID 
					LEFT OUTER JOIN crmrevo.[USR].[User] U2 WITH (NOLOCK) ON CT.ProjectSaleUserID = U2.ID
					LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON A.ProjectID = P.ID
					LEFT OUTER JOIN crmrevo.[PRJ].[Unit] U WITH (NOLOCK) ON A.UnitID = U.ID AND A.ProjectID = U.ProjectID
					LEFT OUTER JOIN (SELECT UP.* FROM crmrevo.[dbo].[vw_UnitPrice] UP WITH (NOLOCK)
										INNER JOIN crmrevo.[MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '2' --2=สัญญา
									) AS UP ON A.BookingID = UP.BookingID 
					LEFT OUTER JOIN crmrevo.[MST].[BG] BG WITH (NOLOCK) ON P.BGID = BG.ID 
					LEFT OUTER JOIN crmrevo.MST.SubBG SBG WITH (NOLOCK) ON SBG.ID = P.SubBGID
					LEFT OUTER JOIN crmrevo.[MST].[MasterCenter] M WITH (NOLOCK) ON P.ProjectTypeMasterCenterID = M.ID
			WHERE	1=1
					AND CS.PeriodYear = @PeriodYear
					AND CS.PeriodMonth = @PeriodMonth
					AND (CT.TransferID IS NOT NULL) 
					AND ISNULL(CS.IsDeleted,0) = 0

			UNION
			----ทำสัญญาแต่ยังไม่โอน
			SELECT	'BG' = BG.BGNo,
					'SUBBG' = SBG.SubBGNo,
					'ProjectNo' = P.ProjectNo,
					'ProjectName' = P.ProjectNameTH,
					'UnitNo' = U.UnitNo,
					'HCSName' = crmrevo.[dbo].[fn_GetHeadOfCS](CS.ProjectNo,'S'),  
					'LCID' = U1.EmployeeNo,
					'LCName' = U1.DisplayName,
					'LCHelperID' = U2.EmployeeNo,
					'LCHelperName' = U2.DisplayName,
					'LCCID' = NULL,
					'LCCName' = NULL,
					'CustomerName' = ISNULL(AO.FirstNameTH,'') + ' ' + ISNULL(AO.LastNameTH,''),  
					'BookingDate' = CAST(B.BookingDate AS datetime),
					'ContractDate' = CAST(A.ContractDate AS datetime),
					'RDate' = CAST(A.SignAgreementDate AS datetime),
					'SignContractApprovedDate' = CAST(A.SignContractApprovedDate AS datetime),
					'ActualTransferDate' = CAST(T.ActualTransferDate AS datetime),	 
					'SellingPrice' = ISNULL(UP.AgreementPrice,0) - ISNULL(UP.TransferDiscount,0) - ISNULL(UP.FreedownDiscount,0), --เพิ่มลบฟรีดาวน์ ตามหน้าเว็บ
					'CommissionRatePercentSale' = ISNULL(CS.CommissionPercentRate,0),		
					'CommissionSalePaid' = ISNULL(CS.SaleUserSalePaid,0),  
		
					'SaleCommissionTransPaid' = CASE WHEN ISNULL(U1.EmployeeNo,NULL) <> ISNULL(U2.EmployeeNo,'') AND ISNULL(CS.ProjectSaleTransferPaid,0) > 0 
													 THEN ISNULL(CS.SaleUserTransferPaid,0) ELSE 0 END,
					'SaleHelperCommissionTransPaid' = CASE WHEN ISNULL(U1.EmployeeNo,NULL) <> ISNULL(U2.EmployeeNo,'') 
														   THEN ISNULL(CS.ProjectSaleTransferPaid,0) ELSE 0 END,  
					'TotalTransferCommission' = CASE WHEN ISNULL(U1.EmployeeNo,NULL) = ISNULL(U2.EmployeeNo,'') OR ISNULL(CS.ProjectSaleTransferPaid,0) = 0  
													 THEN ISNULL(CS.SaleUserTransferPaid,0)+ISNULL(CS.ProjectSaleTransferPaid,0) ELSE 0 END,  
		
					'SaleNewLaunchPaid' = CASE WHEN ISNULL(U1.EmployeeNo,'') <> ISNULL(U2.EmployeeNo,'') AND ISNULL(CS.ProjectSaleNewLaunchPaid,0) > 0  
											   THEN ISNULL(CS.SaleUserNewLaunchPaid,0) ELSE 0 END,  
					'SaleHelperNewLaunchPaid' = CASE WHEN ISNULL(U1.EmployeeNo,'') <> ISNULL(U2.EmployeeNo,'') 
													 THEN ISNULL(CS.ProjectSaleNewLaunchPaid,0) ELSE 0 END,  
					'TotalNewLaunch' = CASE WHEN ISNULL(U1.EmployeeNo,'') = ISNULL(U2.EmployeeNo,'') OR ISNULL(CS.ProjectSaleNewLaunchPaid,0) = 0  
											THEN ISNULL(CS.SaleUserNewLaunchPaid,0) + ISNULL(CS.ProjectSaleNewLaunchPaid,0) ELSE 0 END,
					'TotalCommissionPaid' = ISNULL(CS.SaleUserSalePaid,0) + ISNULL(CS.SaleUserNewLaunchPaid,0)+ISNULL(CS.ProjectSaleNewLaunchPaid,0),	 
					'LCC' = 0.00,
					'FlagData' = CASE WHEN CS.LastMigrateDate IS NOT NULL THEN N'Comm เก่า' WHEN CS.LastMigrateDate IS NULL THEN N'Comm ใหม่' END
					--,'flag' = 2	

			FROM	crmrevo.[CMS].[CalculateLowRiseSale] CS WITH (NOLOCK)
					LEFT OUTER JOIN crmrevo.[SAL].[Agreement] A WITH (NOLOCK) ON CS.AgreementID = A.ID AND ISNULL(A.ISDeleted,0) = 0 
					LEFT OUTER JOIN crmrevo.[SAL].[Transfer] T WITH (NOLOCK) ON CS.AgreementID = T.AgreementID AND ISNULL(T.ISDeleted,0) = 0 
					LEFT OUTER JOIN crmrevo.[SAL].[AgreementOwner] AO WITH (NOLOCK) ON A.ID = AO.AgreementID AND ISNULL(AO.IsMainOwner,0) = 1 AND ISNULL(AO.ISDeleted,0) = 0 
					LEFT OUTER JOIN crmrevo.[SAL].[Booking] B WITH (NOLOCK) ON A.BookingID = B.ID AND ISNULL(B.ISDeleted,0) = 0 
					LEFT OUTER JOIN crmrevo.[USR].[User] U1 WITH (NOLOCK) ON CS.SaleUserID = U1.ID 
					LEFT OUTER JOIN crmrevo.[USR].[User] U2 WITH (NOLOCK) ON CS.ProjectSaleUserID = U2.ID
					LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON A.ProjectID = P.ID
					LEFT OUTER JOIN crmrevo.[PRJ].[Unit] U WITH (NOLOCK) ON A.UnitID = U.ID AND A.ProjectID = U.ProjectID
					LEFT OUTER JOIN (SELECT UP.* FROM crmrevo.[dbo].[vw_UnitPrice] UP WITH (NOLOCK)
										INNER JOIN crmrevo.[MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '2' --2=สัญญา
									) AS UP ON A.BookingID = UP.BookingID 
					LEFT OUTER JOIN crmrevo.[MST].[BG] BG WITH (NOLOCK) ON P.BGID = BG.ID 
					LEFT OUTER JOIN crmrevo.MST.SubBG SBG WITH (NOLOCK) ON SBG.ID = P.SubBGID
					LEFT OUTER JOIN crmrevo.[MST].[MasterCenter] M WITH (NOLOCK) ON P.ProjectTypeMasterCenterID = M.ID
			WHERE	1=1
					AND CS.PeriodYear = @PeriodYear
					AND CS.PeriodMonth = @PeriodMonth
					AND NOT EXISTS(SELECT * FROM crmrevo.[CMS].[CalculateLowRiseTransfer] A WITH (NOLOCK) 
									INNER JOIN crmrevo.[SAL].[Transfer] B WITH (NOLOCK) ON A.TransferID = B.ID AND ISNULL(B.IsDeleted,0) = 0
									WHERE ISNULL(A.IsDeleted,0) = 0 AND B.ID = T.ID AND ((A.PeriodMonth <= @PeriodMonth AND A.PeriodYear = @PeriodYear) OR A.PeriodYear < @PeriodYear))
					AND ISNULL(CS.IsDeleted,0) = 0

			UNION
			----ทำสัญญามาแล้วแต่มาโอนในเดือนนี้
			SELECT	'BG' = BG.BGNo,
					'SUBBG' = SBG.SubBGNo,
					'ProjectNo' = P.ProjectNo,
					'ProjectName' = P.ProjectNameTH,
					'UnitNo' = U.UnitNo,
					'HCSName' = crmrevo.[dbo].[fn_GetHeadOfCS](CT.ProjectNo,'T'),
					'LCID' = U1.EmployeeNo,
					'LCName' = U1.DisplayName,
					'LCHelperID' = U2.EmployeeNo,
					'LCHelperName' = U2.DisplayName,
					'LCCID' = NULL,
					'LCCName' = NULL,
					'CustomerName' = ISNULL(AO.FirstNameTH,'') + ' ' + ISNULL(AO.LastNameTH,''),
					'BookingDate' = CAST(B.BookingDate AS datetime),
					'ContractDate' = CAST(A.ContractDate AS datetime),
					'RDate' = CAST(A.SignAgreementDate AS datetime),
					'SignContractApprovedDate' = CAST(A.SignContractApprovedDate AS datetime),
					'ActualTransferDate' = CAST(T.ActualTransferDate AS datetime),
					'SellingPrice' = ISNULL(UP.AgreementPrice,0) - ISNULL(UP.TransferDiscount,0) - ISNULL(UP.FreedownDiscount,0), --เพิ่มลบฟรีดาวน์ ตามหน้าเว็บ
					'CommissionRatePercentSale' = ISNULL(CT.CommissionPercentRate,0),
					'CommissionSalePaid' = 0,

					'SaleCommissionTransPaid' = CASE WHEN ISNULL(U1.EmployeeNo,'') <> ISNULL(U2.EmployeeNo,'') AND ISNULL(CT.ProjectSaleSalePaid,0) > 0  
													 THEN ISNULL(CT.SaleUserSalePaid,0) ELSE 0 END, 
					'SaleHelperCommissionTransPaid' = CASE WHEN ISNULL(U1.EmployeeNo,'') <> ISNULL(U2.EmployeeNo,'') 
														   THEN ISNULL(CT.ProjectSaleSalePaid,0) ELSE 0 END, 
					'TotalTransferCommission' = CASE WHEN ISNULL(U1.EmployeeNo,'') = ISNULL(U2.EmployeeNo,'') OR ISNULL(CT.ProjectSaleSalePaid,0) > 0 
													 THEN ISNULL(CT.SaleUserSalePaid,0) + ISNULL(CT.ProjectSaleSalePaid,0) ELSE 0 END,

					'SaleNewLaunchPaid' = 0,
					'SaleHelperNewLaunchPaid' = 0,
					'TotalNewLaunch' = 0,	
					'TotalCommissionPaid' = ISNULL(CT.SaleUserSalePaid,0)+ISNULL(CT.ProjectSaleSalePaid,0),
					'LCC' = 0.00,
					'FlagData' = CASE WHEN CT.LastMigrateDate IS NOT NULL THEN N'Comm เก่า' WHEN CT.LastMigrateDate IS NULL THEN N'Comm ใหม่' END
					--,'flag' = 3

			FROM	crmrevo.[CMS].[CalculateLowRiseTransfer] CT WITH (NOLOCK)
					LEFT OUTER JOIN crmrevo.[SAL].[Transfer] T WITH (NOLOCK) ON CT.TransferID = T.ID AND ISNULL(T.IsDeleted,0) = 0
					LEFT OUTER JOIN crmrevo.[SAL].[Agreement] A WITH (NOLOCK) ON T.AgreementID = A.ID AND ISNULL(A.IsDeleted,0) = 0
					LEFT OUTER JOIN crmrevo.[SAL].[AgreementOwner] AO WITH (NOLOCK) ON A.ID = AO.AgreementID AND ISNULL(AO.IsMainOwner,0) = 1 AND ISNULL(AO.ISDeleted,0) = 0 
					LEFT OUTER JOIN crmrevo.[SAL].[Booking] B WITH (NOLOCK) ON A.BookingID = B.ID AND ISNULL(B.IsDeleted,0) = 0
					LEFT OUTER JOIN crmrevo.[USR].[User] U1 WITH (NOLOCK) ON CT.SaleUserID = U1.ID 
					LEFT OUTER JOIN crmrevo.[USR].[User] U2 WITH (NOLOCK) ON CT.ProjectSaleUserID = U2.ID
					LEFT OUTER JOIN crmrevo.[PRJ].[Project] P WITH (NOLOCK) ON A.ProjectID = P.ID
					LEFT OUTER JOIN crmrevo.[PRJ].[Unit] U WITH (NOLOCK) ON A.UnitID = U.ID AND A.ProjectID = U.ProjectID
					LEFT OUTER JOIN (SELECT UP.* FROM crmrevo.[dbo].[vw_UnitPrice] UP WITH (NOLOCK)
										INNER JOIN crmrevo.[MST].[MasterCenter] MUP WITH (NOLOCK) ON UP.UnitPriceStageMasterCenterID = MUP.ID AND MUP.[Key] = '2' --2=สัญญา
									) AS UP ON A.BookingID = UP.BookingID 
					LEFT OUTER JOIN crmrevo.[MST].[BG] BG WITH (NOLOCK) ON P.BGID = BG.ID 
					LEFT OUTER JOIN crmrevo.MST.SubBG SBG WITH (NOLOCK) ON SBG.ID = P.SubBGID
					LEFT OUTER JOIN crmrevo.[MST].[MasterCenter] M WITH (NOLOCK) ON P.ProjectTypeMasterCenterID = M.ID
			WHERE	1=1
					AND CT.PeriodYear = @PeriodYear
					AND CT.PeriodMonth = @PeriodMonth
					AND NOT EXISTS(SELECT * FROM crmrevo.[CMS].[CalculateLowRiseSale] A WITH (NOLOCK) 
									LEFT OUTER JOIN crmrevo.[SAL].[Transfer] T WITH (NOLOCK) ON A.AgreementID = T.AgreementID AND ISNULL(T.IsDeleted,0) = 0
									WHERE ISNULL(A.IsDeleted,0) = 0 AND T.ID = CT.TransferID AND A.PeriodYear = CT.PeriodYear AND A.PeriodMonth = CT.PeriodMonth)
					AND ISNULL(CT.IsDeleted,0) = 0

			ORDER BY BG,SUBBG, ProjectNo, UnitNo ASC;
        END
	END
	



END;


go

